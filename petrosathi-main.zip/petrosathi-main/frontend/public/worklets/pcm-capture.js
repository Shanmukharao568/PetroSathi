/**
 * PetroSathi microphone capture worklet.
 *
 * Converts the browser's Float32 microphone signal into what Gnani Prisma streaming expects:
 * PCM signed 16-bit little-endian, mono, 16 kHz. (MediaRecorder output — WebM/Opus — is NOT used.)
 *
 * - If the AudioContext already runs at 16 kHz (Chrome/Edge/Safari honour the requested rate and
 *   resample the mic with their own high-quality resampler) samples pass straight through.
 * - Otherwise (e.g. Firefox at 44.1/48 kHz) it low-passes by averaging the input samples that fall
 *   inside each output period and linearly interpolates, which is adequate for speech.
 *
 * Posts { type: 'pcm', buffer: ArrayBuffer } every 100 ms (1,600 samples = 3,200 bytes; the server
 * re-frames to the provider's 1,024-byte frames) and { type: 'level', rms } roughly every 50 ms.
 * On port message 'flush' it emits the final partial frame and replies { type: 'flushed' }.
 */
const TARGET_RATE = 16000;
const FRAME_SAMPLES = 1600;

class PcmCaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / TARGET_RATE; // input samples per output sample
    this.pos = 0; // fractional read position into [prev, ...block]
    this.prev = 0;
    this.acc = 0; // averaging accumulator for down-sampling
    this.accN = 0;
    this.frame = new Int16Array(FRAME_SAMPLES);
    this.idx = 0;
    this.levelSum = 0;
    this.levelN = 0;
    this.levelEvery = Math.round(sampleRate * 0.05);
    this.running = true;
    this.port.onmessage = (e) => {
      if (e.data === 'flush') {
        this.emit(true);
        this.running = false;
        this.port.postMessage({ type: 'flushed' });
      }
    };
  }

  push(sample) {
    const s = Math.max(-1, Math.min(1, sample));
    this.frame[this.idx++] = s < 0 ? s * 0x8000 : s * 0x7fff;
    if (this.idx === FRAME_SAMPLES) this.emit(false);
  }

  emit(partial) {
    if (this.idx === 0) return;
    const out = partial ? this.frame.slice(0, this.idx) : this.frame.slice();
    this.port.postMessage({ type: 'pcm', buffer: out.buffer }, [out.buffer]);
    this.idx = 0;
  }

  process(inputs) {
    if (!this.running) return false;
    const ch = inputs[0] && inputs[0][0];
    if (!ch || ch.length === 0) return true;

    for (let i = 0; i < ch.length; i++) {
      this.levelSum += ch[i] * ch[i];
      this.levelN++;
    }
    if (this.levelN >= this.levelEvery) {
      this.port.postMessage({ type: 'level', rms: Math.sqrt(this.levelSum / this.levelN) });
      this.levelSum = 0;
      this.levelN = 0;
    }

    if (Math.abs(this.ratio - 1) < 1e-6) {
      for (let i = 0; i < ch.length; i++) this.push(ch[i]);
      return true;
    }

    // Down-sample: average inputs within each output period (simple anti-alias), then interpolate.
    let pos = this.pos;
    let k = 0;
    while (pos < ch.length) {
      const i = Math.floor(pos);
      while (k < i) {
        this.acc += ch[k++];
        this.accN++;
      }
      const f = pos - i;
      const a = i === 0 ? this.prev : ch[i - 1];
      const b = ch[i];
      const interp = a + (b - a) * f;
      const sample = this.ratio > 1 && this.accN > 0 ? (this.acc + interp) / (this.accN + 1) : interp;
      this.acc = 0;
      this.accN = 0;
      this.push(sample);
      pos += this.ratio;
    }
    while (k < ch.length) {
      this.acc += ch[k++];
      this.accN++;
    }
    this.pos = pos - ch.length;
    this.prev = ch[ch.length - 1];
    return true;
  }
}

registerProcessor('pcm-capture', PcmCaptureProcessor);
