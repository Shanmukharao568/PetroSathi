import type { ReactNode } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router';
import { useAuthStore } from '../store/authStore';
import { ROLE_HOME, type Role } from '../types/auth';
import { FullPageSpinner } from '../components/ui/Spinner';

/**
 * Client-side guards are a UX convenience only — every API route enforces
 * authentication and roles on the server.
 */
export function RequireAuth({
  allowPendingPasswordChange = false,
  allowPendingEmailVerification = false,
}: {
  allowPendingPasswordChange?: boolean;
  allowPendingEmailVerification?: boolean;
}) {
  const { token, user, status } = useAuthStore();
  const location = useLocation();

  if (status !== 'ready') return <FullPageSpinner label="Checking your session…" />;
  if (!token || !user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (user.mustChangePassword && !allowPendingPasswordChange) return <Navigate to="/change-password" replace />;
  if (user.emailVerificationRequired && !allowPendingEmailVerification) return <Navigate to="/verify-email" replace />;
  return <Outlet />;
}

export function RequireRole({ roles, children }: { roles: Role[]; children?: ReactNode }) {
  const user = useAuthStore((s) => s.user);
  if (!user) return <Navigate to="/login" replace />;
  if (!roles.includes(user.role)) return <Navigate to={ROLE_HOME[user.role]} replace />;
  return children ? <>{children}</> : <Outlet />;
}

/** Sends signed-in users from "/" or "/login" to their role's dashboard. */
export function RoleHomeRedirect() {
  const { token, user, status } = useAuthStore();
  if (status !== 'ready') return <FullPageSpinner label="Checking your session…" />;
  if (!token || !user) return <Navigate to="/login" replace />;
  if (user.mustChangePassword) return <Navigate to="/change-password" replace />;
  if (user.emailVerificationRequired) return <Navigate to="/verify-email" replace />;
  return <Navigate to={ROLE_HOME[user.role]} replace />;
}
