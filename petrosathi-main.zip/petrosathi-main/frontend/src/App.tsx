import { lazy, useEffect } from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router';
import { LoginPage } from './pages/LoginPage';
import { SignUpPage } from './pages/SignUpPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { ChangePasswordPage } from './pages/ChangePasswordPage';
import { VerifyEmailPage } from './pages/VerifyEmailPage';
import { RequireAuth, RequireRole, RoleHomeRedirect } from './routes/guards';
import { AppLayout } from './components/layout/AppLayout';
import { useAuthStore } from './store/authStore';

// Role areas are code-split so operators never download admin screens.
const RoleDashboard = lazy(() => import('./pages/RoleDashboard').then((m) => ({ default: m.RoleDashboard })));
const AccountPage = lazy(() => import('./pages/AccountPage').then((m) => ({ default: m.AccountPage })));
const UsersPage = lazy(() => import('./features/admin/users/UsersPage').then((m) => ({ default: m.UsersPage })));
const EquipmentPage = lazy(() => import('./features/equipment/EquipmentPage').then((m) => ({ default: m.EquipmentPage })));
const TicketListPage = lazy(() => import('./features/tickets/TicketListPage').then((m) => ({ default: m.TicketListPage })));
const TicketDetailPage = lazy(() => import('./features/tickets/TicketDetailPage').then((m) => ({ default: m.TicketDetailPage })));
const DraftPage = lazy(() => import('./features/complaints/DraftPage').then((m) => ({ default: m.DraftPage })));
const AnalyticsPage = lazy(() => import('./features/analytics/AnalyticsPage').then((m) => ({ default: m.AnalyticsPage })));
const AuditLogsPage = lazy(() => import('./features/analytics/AuditLogsPage').then((m) => ({ default: m.AuditLogsPage })));
const DocumentsPage = lazy(() => import('./features/documents/DocumentsPage').then((m) => ({ default: m.DocumentsPage })));
const ManualReportPage = lazy(() => import('./features/report/ManualReportPage').then((m) => ({ default: m.ManualReportPage })));

const router = createBrowserRouter([
  { path: '/', element: <RoleHomeRedirect /> },
  { path: '/login', element: <LoginPage /> },
  { path: '/signup', element: <SignUpPage /> },
  {
    element: <RequireAuth allowPendingPasswordChange allowPendingEmailVerification />,
    children: [{ path: '/change-password', element: <ChangePasswordPage /> }],
  },
  {
    // After any temporary password is changed; reachable while the email is unverified.
    element: <RequireAuth allowPendingEmailVerification />,
    children: [{ path: '/verify-email', element: <VerifyEmailPage /> }],
  },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppLayout />,
        children: [
          { path: '/account', element: <AccountPage /> },
          {
            path: '/operator',
            element: <RequireRole roles={['operator']} />,
            children: [
              { path: 'dashboard', element: <RoleDashboard /> },
              { path: 'report', element: <ManualReportPage /> },
              { path: 'drafts/:id', element: <DraftPage /> },
              { path: 'tickets', element: <TicketListPage /> },
              { path: 'tickets/:id', element: <TicketDetailPage /> },
            ],
          },
          {
            path: '/engineer',
            children: [
              { path: 'dashboard', element: <RequireRole roles={['engineer']}><RoleDashboard /></RequireRole> },
              // Admins share the engineer ticket views so they can assign and oversee work.
              { path: 'tickets', element: <RequireRole roles={['engineer', 'admin']}><TicketListPage /></RequireRole> },
              { path: 'tickets/:id', element: <RequireRole roles={['engineer', 'admin']}><TicketDetailPage /></RequireRole> },
            ],
          },
          {
            path: '/admin',
            element: <RequireRole roles={['admin']} />,
            children: [
              { path: 'dashboard', element: <RoleDashboard /> },
              { path: 'users', element: <UsersPage /> },
              { path: 'equipment', element: <EquipmentPage /> },
              { path: 'documents', element: <DocumentsPage /> },
              { path: 'analytics', element: <AnalyticsPage /> },
              { path: 'audit-logs', element: <AuditLogsPage /> },
            ],
          },
        ],
      },
    ],
  },
  { path: '*', element: <NotFoundPage /> },
]);

export default function App() {
  const verify = useAuthStore((s) => s.verify);
  // Re-validate any persisted token against the server once on load.
  useEffect(() => {
    void verify();
  }, [verify]);

  return <RouterProvider router={router} />;
}
