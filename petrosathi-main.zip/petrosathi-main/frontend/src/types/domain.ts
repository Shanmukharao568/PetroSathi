import type { Role } from './auth';

// Mirrors backend/src/config/constants.ts
export const EQUIPMENT_TYPES = [
  'pump', 'compressor', 'heat_exchanger', 'valve', 'motor', 'turbine', 'separator',
  'tank', 'vessel', 'pipeline', 'instrument', 'generator', 'other',
] as const;
export type EquipmentType = (typeof EQUIPMENT_TYPES)[number];
export const EQUIPMENT_CRITICALITY = ['low', 'medium', 'high', 'critical'] as const;
export type EquipmentCriticality = (typeof EQUIPMENT_CRITICALITY)[number];
export const EQUIPMENT_STATUS = ['operational', 'degraded', 'down', 'under_maintenance', 'decommissioned'] as const;
export type EquipmentStatus = (typeof EQUIPMENT_STATUS)[number];

export const COMPLAINT_CATEGORIES = ['mechanical', 'electrical', 'instrumentation', 'process', 'safety', 'other'] as const;
export type ComplaintCategory = (typeof COMPLAINT_CATEGORIES)[number];
export const SEVERITIES = ['critical', 'high', 'medium', 'low', 'unknown'] as const;
export type Severity = (typeof SEVERITIES)[number];
export const TICKET_STATUSES = ['OPEN', 'UNDER_INSPECTION', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'] as const;
export type TicketStatus = (typeof TICKET_STATUSES)[number];

export interface Equipment {
  id: string;
  equipmentCode: string;
  name: string;
  type: EquipmentType;
  plant: string;
  location: string;
  manufacturer: string;
  model: string;
  criticality: EquipmentCriticality;
  status: EquipmentStatus;
  createdAt: string;
  updatedAt: string;
  ticketCounts?: { open: number; total: number };
}

export interface UserRef {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface HistoryEntry {
  _id: string;
  type: 'created' | 'status_changed' | 'assigned' | 'unassigned' | 'resolution_updated';
  actor: UserRef;
  at: string;
  fromStatus: TicketStatus | null;
  toStatus: TicketStatus | null;
  fromAssignee: UserRef | null;
  toAssignee: UserRef | null;
  comment: string | null;
}

export interface TicketComment {
  _id: string;
  author: UserRef;
  body: string;
  createdAt: string;
}

export interface TicketPermissions {
  view: boolean;
  comment: boolean;
  accept: boolean;
  assign: boolean;
  release: boolean;
  changeStatus: boolean;
  allowedTransitions: TicketStatus[];
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  equipmentId: string;
  equipmentCode: string;
  equipment: Pick<Equipment, 'id' | 'equipmentCode' | 'name' | 'type' | 'plant' | 'location' | 'criticality' | 'status'> | null;
  reportedBy: UserRef;
  assignedTo: UserRef | null;
  description: string;
  symptoms: string[];
  category: ComplaintCategory;
  severity: Severity;
  status: TicketStatus;
  transcript?: string | null;
  language: string | null;
  source: 'manual' | 'voice';
  resolution: { summary: string; rootCause: string; actionsTaken: string; resolvedBy: UserRef; resolvedAt: string } | null;
  history?: HistoryEntry[];
  comments?: TicketComment[];
  resolvedAt: string | null;
  closedAt: string | null;
  createdAt: string;
  updatedAt: string;
  permissions: TicketPermissions;
}

export interface AppNotification {
  id: string;
  ticketId: string | null;
  type: 'ticket_created' | 'ticket_assigned' | 'ticket_unassigned' | 'ticket_status_changed' | 'ticket_commented';
  message: string;
  isRead: boolean;
  createdAt: string;
}
