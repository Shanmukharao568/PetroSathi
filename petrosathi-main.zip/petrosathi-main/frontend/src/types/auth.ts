export const ROLES = ['operator', 'engineer', 'admin'] as const;
export type Role = (typeof ROLES)[number];

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  preferredLanguage: string;
  /** Self-editable profile details (null = not set). Optional for older API responses. */
  phone?: string | null;
  jobTitle?: string | null;
  site?: string | null;
  bio?: string | null;
  /** Profile photo as a data URL. */
  avatar?: string | null;
  isActive: boolean;
  mustChangePassword: boolean;
  emailVerified?: boolean;
  emailVerifiedAt?: string | null;
  /** Sent with the session user: true while the email still has to be confirmed with a code. */
  emailVerificationRequired?: boolean;
  lastLoginAt: string | null;
  passwordChangedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Session {
  token: string;
  expiresAt: string;
  user: User;
}

export const ROLE_LABEL: Record<Role, string> = {
  operator: 'Field Operator',
  engineer: 'Maintenance Engineer',
  admin: 'Administrator',
};

export const ROLE_HOME: Record<Role, string> = {
  operator: '/operator/dashboard',
  engineer: '/engineer/dashboard',
  admin: '/admin/dashboard',
};
