import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { api, registerAuthHooks, type ApiSuccess } from '../lib/api';
import type { Session, User } from '../types/auth';

type Status = 'idle' | 'verifying' | 'ready';

interface AuthState {
  token: string | null;
  expiresAt: string | null;
  user: User | null;
  /** 'verifying' while the persisted token is being re-validated against /auth/me. */
  status: Status;
  /** Why the user was signed out, shown on the login page. */
  signOutReason: 'expired' | 'revoked' | null;

  login: (email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  verify: () => Promise<void>;
  setSession: (s: Session) => void;
  setUser: (u: User) => void;
  clear: (reason?: 'expired' | 'revoked' | null) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      expiresAt: null,
      user: null,
      status: 'idle',
      signOutReason: null,

      async login(email, password) {
        const res = await api.post<ApiSuccess<Session>>('/auth/login', { email, password });
        get().setSession(res.data.data);
        return res.data.data.user;
      },

      async logout() {
        try {
          // Server bumps tokenVersion → token revoked on every device.
          if (get().token) await api.post('/auth/logout');
        } finally {
          get().clear(null);
        }
      },

      async verify() {
        if (!get().token) {
          set({ status: 'ready' });
          return;
        }
        set({ status: 'verifying' });
        try {
          const res = await api.get<ApiSuccess<User>>('/auth/me');
          set({ user: res.data.data, status: 'ready' });
        } catch {
          // Interceptor already cleared the session on 401; network errors keep the cached user.
          set({ status: 'ready' });
        }
      },

      setSession: (s) => set({ token: s.token, expiresAt: s.expiresAt, user: s.user, signOutReason: null, status: 'ready' }),
      setUser: (u) => set({ user: u }),
      clear: (reason = null) => set({ token: null, expiresAt: null, user: null, signOutReason: reason, status: 'ready' }),
    }),
    {
      name: 'petrosathi.auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ token: s.token, expiresAt: s.expiresAt, user: s.user }),
    },
  ),
);

registerAuthHooks({
  getToken: () => useAuthStore.getState().token,
  onAuthFailure: (reason) => {
    const state = useAuthStore.getState();
    if (reason === 'password_change') {
      if (state.user) state.setUser({ ...state.user, mustChangePassword: true });
      return;
    }
    if (reason === 'email_verification') {
      if (state.user) state.setUser({ ...state.user, emailVerificationRequired: true });
      return;
    }
    state.clear(reason);
  },
});
