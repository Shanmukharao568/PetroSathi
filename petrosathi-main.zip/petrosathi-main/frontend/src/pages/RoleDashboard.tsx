import { useCallback, useEffect, useState } from 'react';
import { Alert } from '../components/ui/Alert';
import { PageSkeleton } from '../components/ui/Spinner';
import { toApiError } from '../lib/api';
import { useAuthStore } from '../store/authStore';
import { getDashboard, type DashboardData } from '../features/dashboard/dashboardApi';
import { OperatorDashboard } from '../features/dashboard/OperatorDashboard';
import { EngineerDashboard } from '../features/dashboard/EngineerDashboard';
import { AdminDashboard } from '../features/dashboard/AdminDashboard';

const REFRESH_MS = 60_000;

/** Loads the role-specific dashboard from GET /dashboard (live data, refreshed every minute). */
export function RoleDashboard() {
  const user = useAuthStore((s) => s.user)!;
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setData(await getDashboard());
      setError(null);
    } catch (err) {
      setError(toApiError(err).message);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), REFRESH_MS);
    return () => window.clearInterval(t);
  }, [load]);

  if (error && !data) return <Alert tone="error">{error}</Alert>;
  if (!data) return <PageSkeleton label="Loading dashboard…" />;

  const firstName = user.name.split(/\s+/)[0] ?? user.name;
  if (data.role === 'operator') return <OperatorDashboard data={data} firstName={firstName} />;
  if (data.role === 'engineer') return <EngineerDashboard data={data} firstName={firstName} />;
  return <AdminDashboard data={data} firstName={firstName} />;
}
