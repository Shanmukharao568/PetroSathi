import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowRight, UserPlus } from 'lucide-react';
import { AuthShell } from '../components/layout/AuthShell';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { toApiError } from '../lib/api';
import { useAuthStore } from '../store/authStore';
import { ROLE_HOME } from '../types/auth';

const loginSchema = z.object({
  email: z.email('Enter a valid work email'),
  password: z.string().min(1, 'Password is required'),
});
type LoginValues = z.infer<typeof loginSchema>;

const REASON_TEXT = {
  expired: 'Your session expired. Please sign in again.',
  revoked: 'You were signed out. Please sign in again.',
} as const;

export function LoginPage() {
  const { token, user, signOutReason, login } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginValues>({ resolver: zodResolver(loginSchema) });

  if (token && user) return <Navigate to="/" replace />;

  const onSubmit = async (values: LoginValues) => {
    setServerError(null);
    try {
      const u = await login(values.email, values.password);
      if (u.mustChangePassword) return navigate('/change-password', { replace: true });
      if (u.emailVerificationRequired) return navigate('/verify-email', { replace: true });
      const from = (location.state as { from?: string } | null)?.from;
      // Only honour "from" if it belongs to this user's area.
      const home = ROLE_HOME[u.role];
      const areaPrefix = home.split('/').slice(0, 2).join('/');
      navigate(from && (from.startsWith(areaPrefix) || from === '/account') ? from : home, { replace: true });
    } catch (err) {
      setServerError(toApiError(err).message);
    }
  };

  return (
    <AuthShell>
      <div className="mt-10 lg:mt-0">
        <p className="type-label flex items-center gap-2 text-slate-500">
          <span className="h-3 w-1 rounded-full bg-signal-400" aria-hidden /> Secure access
        </p>
        <h2 className="type-display text-gradient-ink mt-2 text-[34px] font-bold leading-tight">Sign in</h2>
        <p className="mt-1.5 text-[15px] leading-relaxed text-slate-500">Welcome back. Sign in to report and track equipment issues.</p>
      </div>

      {signOutReason && (
        <Alert tone="warning" className="mt-6">
          {REASON_TEXT[signOutReason]}
        </Alert>
      )}

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="ring-gradient mt-8 space-y-5 rounded-2xl border border-slate-200/70 bg-white/80 p-5 shadow-raised backdrop-blur-xl sm:p-6"
      >
        <Input label="Work email" type="email" autoComplete="username" placeholder="name@company.com" error={errors.email?.message} {...register('email')} />
        <Input label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register('password')} />
        {serverError && <Alert tone="error">{serverError}</Alert>}
        <Button type="submit" size="lg" loading={isSubmitting} className="w-full">
          Sign in
        </Button>
      </form>

      <Link
        to="/signup"
        viewTransition
        className="group mt-5 flex items-center gap-3 rounded-xl border border-slate-200/80 bg-white/60 px-4 py-3 backdrop-blur transition-[border-color,background-color,transform] duration-300 ease-[var(--ease-out-expo)] hover:-translate-y-0.5 hover:border-brand-300 hover:bg-white/90"
      >
        <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-signal-300 to-signal-600 text-white shadow-md shadow-signal-600/25 transition-transform duration-300 ease-[var(--ease-spring)] group-hover:-rotate-6 group-hover:scale-110">
          <UserPlus className="size-4" aria-hidden />
        </span>
        <span className="min-w-0 flex-1 text-sm">
          <span className="block font-semibold text-navy-900">New to PetroSathi?</span>
          <span className="block text-slate-500">Create a field operator account</span>
        </span>
        <ArrowRight className="size-4 text-slate-400 transition-[transform,color] duration-300 group-hover:translate-x-1 group-hover:text-brand-600" aria-hidden />
      </Link>
    </AuthShell>
  );
}
