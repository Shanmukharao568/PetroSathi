import { Navigate, useNavigate } from 'react-router';
import { KeyRound } from 'lucide-react';
import { Logo } from '../components/brand/Logo';
import { Card } from '../components/ui/Card';
import { ChangePasswordForm } from '../features/account/ChangePasswordForm';
import { useAuthStore } from '../store/authStore';
import { ROLE_HOME } from '../types/auth';

/** Forced first-login password change for admin-issued temporary passwords. */
export function ChangePasswordPage() {
  const user = useAuthStore((s) => s.user)!;
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  if (!user.mustChangePassword) return <Navigate to={ROLE_HOME[user.role]} replace />;

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4 py-12">
      <Logo />
      <Card className="mt-8 w-full max-w-md p-6 sm:p-8">
        <div className="flex size-10 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
          <KeyRound className="size-5" aria-hidden />
        </div>
        <h1 className="mt-4 text-xl font-semibold text-navy-900">Set your password</h1>
        <p className="mt-1 text-sm text-slate-500">
          You signed in with a temporary password issued by your administrator. Choose a new password to continue.
        </p>
        <div className="mt-6">
          <ChangePasswordForm currentLabel="Temporary password" onDone={() => navigate('/', { replace: true })} />
        </div>
      </Card>
      <button
        type="button"
        onClick={() => void logout().then(() => navigate('/login', { replace: true }))}
        className="mt-6 text-sm text-slate-500 hover:text-slate-800"
      >
        Sign out instead
      </button>
    </main>
  );
}
