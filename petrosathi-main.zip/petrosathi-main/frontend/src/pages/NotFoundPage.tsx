import { Link } from 'react-router';
import { Logo } from '../components/brand/Logo';

export function NotFoundPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
      <Logo />
      <div>
        <p className="font-mono text-sm text-brand-700">404</p>
        <h1 className="mt-1 text-2xl font-semibold text-navy-900">Page not found</h1>
        <p className="mt-2 text-sm text-slate-500">The page you requested does not exist.</p>
      </div>
      <Link to="/login" className="text-sm font-medium text-brand-700 hover:text-brand-600">
        Go to sign in
      </Link>
    </main>
  );
}
