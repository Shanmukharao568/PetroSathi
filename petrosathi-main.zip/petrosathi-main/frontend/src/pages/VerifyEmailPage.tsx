import { useCallback, useEffect, useRef, useState } from 'react';
import { Navigate, useNavigate } from 'react-router';
import { CheckCircle2, Clock, MailCheck, RotateCw, ShieldCheck, Terminal } from 'lucide-react';
import { Logo } from '../components/brand/Logo';
import { PlantIllustration } from '../components/brand/PlantIllustration';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { OtpInput } from '../components/ui/OtpInput';
import { api, toApiError, type ApiSuccess } from '../lib/api';
import { useAuthStore } from '../store/authStore';
import { ROLE_HOME, type User } from '../types/auth';

interface CodeStatus {
  sentTo: string;
  expiresAt: string;
  resendAvailableAt: string;
  delivery?: 'email' | 'server-log';
}

function useNow(tickMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), tickMs);
    return () => window.clearInterval(t);
  }, [tickMs]);
  return now;
}

function mmss(ms: number) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/** One-time email confirmation: a 6-digit code is emailed and entered here once per account. */
export function VerifyEmailPage() {
  const user = useAuthStore((s) => s.user)!;
  const setUser = useAuthStore((s) => s.setUser);
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();
  const now = useNow();

  const [status, setStatus] = useState<CodeStatus | null>(null);
  const [code, setCode] = useState('');
  const [sending, setSending] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [invalidTick, setInvalidTick] = useState(0);
  const [done, setDone] = useState(false);
  const autoSent = useRef(false);

  const send = useCallback(async () => {
    setSending(true);
    setError(null);
    try {
      const res = await api.post<ApiSuccess<CodeStatus>>('/auth/email/send-code');
      setStatus(res.data.data);
      setCode('');
    } catch (err) {
      const e = toApiError(err);
      const details = (err as { response?: { data?: { error?: { details?: CodeStatus } } } }).response?.data?.error?.details;
      // A code was already sent moments ago: keep using it.
      if (e.code === 'RATE_LIMITED' && details?.resendAvailableAt) setStatus((s) => ({ ...s, ...details }));
      else if (e.code === 'CONFLICT') {
        setUser({ ...user, emailVerified: true, emailVerificationRequired: false });
      } else setError(e.message);
    } finally {
      setSending(false);
    }
  }, [setUser, user]);

  // Send the first code automatically (once, even under StrictMode double effects).
  useEffect(() => {
    if (autoSent.current || !user.emailVerificationRequired) return;
    autoSent.current = true;
    void send();
  }, [send, user.emailVerificationRequired]);

  const submit = async (value: string) => {
    if (value.length !== 6 || checking) return;
    setChecking(true);
    setError(null);
    try {
      const res = await api.post<ApiSuccess<User>>('/auth/email/verify', { code: value });
      setDone(true);
      // Short success moment, then into the app.
      window.setTimeout(() => {
        setUser(res.data.data);
        navigate(ROLE_HOME[res.data.data.role], { replace: true });
      }, 1100);
    } catch (err) {
      const e = toApiError(err);
      setError(e.message);
      setInvalidTick((n) => n + 1);
      setCode('');
      if (e.code === 'OTP_EXPIRED') setStatus((s) => (s ? { ...s, expiresAt: new Date(0).toISOString(), resendAvailableAt: new Date(0).toISOString() } : s));
    } finally {
      setChecking(false);
    }
  };

  if (!user.emailVerificationRequired && !done) return <Navigate to={ROLE_HOME[user.role]} replace />;

  const expiresIn = status ? new Date(status.expiresAt).getTime() - now : 0;
  const resendIn = status ? new Date(status.resendAvailableAt).getTime() - now : 0;
  const expired = !!status && expiresIn <= 0;

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 pb-48 pt-12 sm:pb-56">
      <div aria-hidden className="app-backdrop" />
      <PlantIllustration tone="light" className="pointer-events-none absolute inset-x-0 bottom-0 mx-auto w-full max-w-5xl opacity-60" />

      <div className="stagger relative w-full max-w-md [--stagger-step:90ms]">
        <div className="flex justify-center">
          <Logo />
        </div>

        <section className="ring-gradient mt-8 rounded-2xl border border-white/70 bg-white/85 p-6 text-center shadow-raised backdrop-blur-xl sm:p-8">
          {done ? (
            <div className="py-6" role="status">
              <span className="mx-auto flex size-16 animate-scale-in items-center justify-center rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 text-white shadow-lg shadow-emerald-600/30">
                <CheckCircle2 className="size-8" aria-hidden />
              </span>
              <h1 className="type-display mt-5 text-2xl font-bold text-navy-900">Email verified</h1>
              <p className="mt-1.5 text-sm text-slate-500">Taking you to your dashboard…</p>
            </div>
          ) : (
            <>
              <span
                className="relative mx-auto flex size-16 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-700 text-white shadow-lg shadow-brand-700/30 [animation:envelope-bob_3.2s_ease-in-out_infinite]"
                aria-hidden
              >
                <MailCheck className="size-8" />
                <span className="absolute -right-1 -top-1 flex size-4">
                  <span className="absolute inset-0 animate-ping rounded-full bg-signal-400" />
                  <span className="relative size-4 rounded-full bg-signal-400 ring-2 ring-white" />
                </span>
              </span>

              <h1 className="type-display text-gradient-ink mt-5 text-[26px] font-bold leading-tight">Check your email</h1>
              <p className="mx-auto mt-2 max-w-xs text-[15px] leading-relaxed text-slate-500">
                {status ? (
                  <>
                    We sent a 6-digit code to <span className="font-semibold text-navy-900">{status.sentTo}</span>. Enter it to verify your address.
                  </>
                ) : sending ? (
                  'Sending your code…'
                ) : (
                  'Verify your email address to finish setting up your account.'
                )}
              </p>

              {status?.delivery === 'server-log' && (
                <p className="mx-auto mt-4 flex max-w-sm items-start gap-2 rounded-lg bg-amber-50 px-3 py-2 text-left text-xs leading-relaxed text-amber-900 ring-1 ring-inset ring-amber-200">
                  <Terminal className="mt-0.5 size-3.5 shrink-0" aria-hidden />
                  Development mode: email (SMTP) is not configured, so the code was written to the backend server log instead of being emailed.
                </p>
              )}

              <form
                className="mt-7"
                onSubmit={(e) => {
                  e.preventDefault();
                  void submit(code);
                }}
              >
                <OtpInput
                  key={invalidTick}
                  value={code}
                  onChange={(v) => {
                    setCode(v);
                    if (error) setError(null);
                  }}
                  onComplete={(v) => void submit(v)}
                  disabled={checking || !status || expired}
                  invalid={invalidTick > 0 && !!error}
                  autoFocus
                />

                {error && (
                  <Alert tone="error" className="mt-4 text-left">
                    {error}
                  </Alert>
                )}

                <Button type="submit" size="lg" className="mt-6 w-full" loading={checking} disabled={code.length !== 6 || !status || expired}>
                  <ShieldCheck className="size-4" aria-hidden /> Verify email
                </Button>
              </form>

              <div className="mt-5 flex flex-wrap items-center justify-between gap-2 text-[13px]">
                <span className="inline-flex items-center gap-1.5 text-slate-500" aria-live="polite">
                  <Clock className="size-3.5" aria-hidden />
                  {!status ? '—' : expired ? 'Code expired' : <>Expires in <span className="font-mono tabular-nums text-slate-700">{mmss(expiresIn)}</span></>}
                </span>
                <button
                  type="button"
                  onClick={() => void send()}
                  disabled={sending || resendIn > 0}
                  className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 font-semibold text-brand-700 transition-colors hover:bg-brand-50 hover:text-brand-600 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:bg-transparent"
                >
                  <RotateCw className={sending ? 'size-3.5 animate-spin' : 'size-3.5'} aria-hidden />
                  {resendIn > 0 ? (
                    <>
                      Resend in <span className="font-mono tabular-nums">{mmss(resendIn)}</span>
                    </>
                  ) : (
                    'Resend code'
                  )}
                </button>
              </div>
            </>
          )}
        </section>

        {!done && (
          <p className="mt-6 text-center text-sm text-slate-500">
            Wrong account?{' '}
            <button
              type="button"
              onClick={() => void logout().then(() => navigate('/login', { replace: true }))}
              className="font-semibold text-slate-700 underline-offset-2 hover:text-navy-900 hover:underline"
            >
              Sign out
            </button>
          </p>
        )}
      </div>
    </main>
  );
}
