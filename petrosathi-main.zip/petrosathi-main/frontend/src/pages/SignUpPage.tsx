import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Check, Eye, EyeOff, HardHat, MailCheck, X } from 'lucide-react';
import clsx from 'clsx';
import { AuthShell } from '../components/layout/AuthShell';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Alert } from '../components/ui/Alert';
import { api, toApiError, type ApiSuccess } from '../lib/api';
import { PREFERRED_LANGUAGE_OPTIONS } from '../lib/validation';
import { useAuthStore } from '../store/authStore';
import type { Session } from '../types/auth';

/** Mirrors the server's password policy (backend/src/utils/password.ts). */
const RULES = [
  { label: 'At least 10 characters', test: (p: string) => p.length >= 10 },
  { label: 'An upper-case letter', test: (p: string) => /[A-Z]/.test(p) },
  { label: 'A lower-case letter', test: (p: string) => /[a-z]/.test(p) },
  { label: 'A number', test: (p: string) => /\d/.test(p) },
];

const signUpSchema = z
  .object({
    name: z.string().trim().min(2, 'Enter your full name').max(100),
    email: z.email('Enter a valid email address'),
    password: z
      .string()
      .max(128, 'At most 128 characters')
      .refine((p) => RULES.every((r) => r.test(p)), 'Password does not meet the rules below'),
    confirm: z.string(),
    preferredLanguage: z.string(),
  })
  .refine((v) => v.password === v.confirm, { path: ['confirm'], message: 'Passwords do not match' });
type SignUpValues = z.infer<typeof signUpSchema>;

/** 0–4: rules met, plus a bonus for length / symbols once all rules pass. */
function strength(p: string) {
  if (!p) return 0;
  const met = RULES.filter((r) => r.test(p)).length;
  if (met < RULES.length) return Math.min(2, Math.max(1, met - 1));
  return p.length >= 14 || /[^A-Za-z0-9]/.test(p) ? 4 : 3;
}
const STRENGTH = [
  { label: '', bar: 'bg-slate-200' },
  { label: 'Weak', bar: 'bg-red-500' },
  { label: 'Fair', bar: 'bg-amber-500' },
  { label: 'Good', bar: 'bg-brand-500' },
  { label: 'Strong', bar: 'bg-emerald-500' },
];

export function SignUpPage() {
  const { token, user, setSession } = useAuthStore();
  const navigate = useNavigate();
  const [serverError, setServerError] = useState<{ message: string; exists: boolean } | null>(null);
  const [show, setShow] = useState(false);
  // Only bounce people who were already signed in when they opened the page — not the session this page creates.
  const [arrivedSignedIn] = useState(() => !!(token && user));
  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<SignUpValues>({
    resolver: zodResolver(signUpSchema),
    defaultValues: { preferredLanguage: 'en-IN', name: '', email: '', password: '', confirm: '' },
  });
  const password = useWatch({ control, name: 'password' }) ?? '';
  const score = strength(password);

  if (arrivedSignedIn) return <Navigate to="/" replace />;

  const onSubmit = async ({ name, email, password: pw, preferredLanguage }: SignUpValues) => {
    setServerError(null);
    try {
      const res = await api.post<ApiSuccess<Session>>('/auth/register', { name, email, password: pw, preferredLanguage });
      setSession(res.data.data);
      navigate('/verify-email', { replace: true });
    } catch (err) {
      const e = toApiError(err);
      setServerError({ message: e.message, exists: e.code === 'CONFLICT' });
    }
  };

  return (
    <AuthShell>
      <div className="mt-10 lg:mt-0">
        <p className="type-label flex items-center gap-2 text-slate-500">
          <span className="h-3 w-1 rounded-full bg-signal-400" aria-hidden /> Get started
        </p>
        <h2 className="type-display text-gradient-ink mt-2 text-[34px] font-bold leading-tight">Create your account</h2>
        <p className="mt-1.5 text-[15px] leading-relaxed text-slate-500">Report equipment faults by voice in minutes.</p>
      </div>

      {/* What happens next. */}
      <ol className="mt-6 grid grid-cols-2 gap-2 text-[13px]">
        <li className="flex items-center gap-2 rounded-xl border border-slate-200/80 bg-white/60 px-3 py-2 backdrop-blur">
          <HardHat className="size-4 shrink-0 text-brand-600" aria-hidden />
          <span className="text-slate-600">You join as a <span className="font-semibold text-navy-900">Field Operator</span></span>
        </li>
        <li className="flex items-center gap-2 rounded-xl border border-slate-200/80 bg-white/60 px-3 py-2 backdrop-blur">
          <MailCheck className="size-4 shrink-0 text-brand-600" aria-hidden />
          <span className="text-slate-600">Then confirm a <span className="font-semibold text-navy-900">6-digit email code</span></span>
        </li>
      </ol>

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="ring-gradient mt-5 space-y-4 rounded-2xl border border-slate-200/70 bg-white/80 p-5 shadow-raised backdrop-blur-xl sm:p-6"
      >
        <Input label="Full name" autoComplete="name" placeholder="e.g. Lakshmi Reddy" error={errors.name?.message} {...register('name')} />
        <Input label="Work email" type="email" autoComplete="email" placeholder="name@company.com" error={errors.email?.message} {...register('email')} />

        <div>
          <div className="relative">
            <Input
              label="Password"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              className="pr-11"
              error={errors.password?.message}
              {...register('password')}
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute right-1.5 top-[30px] flex size-8 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
              aria-label={show ? 'Hide password' : 'Show password'}
              aria-pressed={show}
            >
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>

          {/* Strength meter + live rules. */}
          <div className="mt-2.5" aria-live="polite">
            <div className="flex items-center gap-2">
              <div className="grid flex-1 grid-cols-4 gap-1" aria-hidden>
                {[1, 2, 3, 4].map((i) => (
                  <span
                    key={i}
                    className={clsx('h-1.5 rounded-full transition-colors duration-300', i <= score ? STRENGTH[score]!.bar : 'bg-slate-200')}
                  />
                ))}
              </div>
              <span className="w-12 text-right text-xs font-semibold text-slate-600">{STRENGTH[score]!.label}</span>
            </div>
            <ul className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
              {RULES.map((r) => {
                const ok = r.test(password);
                return (
                  <li key={r.label} className={clsx('flex items-center gap-1.5 transition-colors', ok ? 'text-emerald-700' : 'text-slate-500')}>
                    {ok ? <Check className="size-3.5" aria-hidden /> : <X className="size-3.5 text-slate-300" aria-hidden />}
                    {r.label}
                    <span className="sr-only">{ok ? '(met)' : '(not met)'}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <Input
          label="Confirm password"
          type={show ? 'text' : 'password'}
          autoComplete="new-password"
          error={errors.confirm?.message}
          {...register('confirm')}
        />
        <Select label="Preferred language" options={PREFERRED_LANGUAGE_OPTIONS} {...register('preferredLanguage')} />

        {serverError && (
          <Alert tone="error">
            {serverError.message}
            {serverError.exists && (
              <>
                {' '}
                <Link to="/login" className="font-semibold underline underline-offset-2">
                  Go to sign in
                </Link>
              </>
            )}
          </Alert>
        )}
        <Button type="submit" size="lg" loading={isSubmitting} className="w-full">
          Create account
        </Button>
      </form>

      <p className="mt-5 text-center text-sm text-slate-500">
        Already have an account?{' '}
        <Link to="/login" viewTransition className="font-semibold text-brand-700 underline-offset-2 hover:text-brand-600 hover:underline">
          Sign in
        </Link>
      </p>
    </AuthShell>
  );
}
