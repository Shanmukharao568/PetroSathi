import { useRef, useState, type ChangeEvent } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  BadgeCheck,
  Briefcase,
  Calendar,
  Camera,
  Clock,
  Factory,
  KeyRound,
  Languages,
  Mail,
  MailCheck,
  Phone,
  ShieldCheck,
  Trash2,
  UserRound,
  type LucideIcon,
} from 'lucide-react';
import clsx from 'clsx';
import { Card, CardHeader } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Textarea } from '../components/ui/Textarea';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { Avatar } from '../components/ui/Avatar';
import { PlantIllustration } from '../components/brand/PlantIllustration';
import { ChangePasswordForm } from '../features/account/ChangePasswordForm';
import { api, toApiError, type ApiSuccess } from '../lib/api';
import { AVATAR_ACCEPT, photoToAvatar } from '../lib/avatar';
import { formatDateTime } from '../lib/format';
import { languageLabel, PREFERRED_LANGUAGE_OPTIONS } from '../lib/validation';
import { useAuthStore } from '../store/authStore';
import { ROLE_LABEL, type User } from '../types/auth';

const BIO_MAX = 280;

const profileSchema = z.object({
  name: z.string().trim().min(2, 'At least 2 characters').max(100),
  preferredLanguage: z.string(),
  jobTitle: z.string().trim().max(80, 'At most 80 characters'),
  phone: z
    .string()
    .trim()
    .refine((v) => v === '' || /^\+?[0-9][0-9 ()-]{5,18}$/.test(v), 'Enter a valid phone number, e.g. +91 98765 43210'),
  site: z.string().trim().max(120, 'At most 120 characters'),
  bio: z.string().trim().max(BIO_MAX, `At most ${BIO_MAX} characters`),
});
type ProfileValues = z.infer<typeof profileSchema>;

const formValues = (u: User): ProfileValues => ({
  name: u.name,
  preferredLanguage: u.preferredLanguage,
  jobTitle: u.jobTitle ?? '',
  phone: u.phone ?? '',
  site: u.site ?? '',
  bio: u.bio ?? '',
});

/** Share of optional profile details that are filled in (photo counts as one). */
function completeness(u: User) {
  const parts = [u.avatar, u.jobTitle, u.phone, u.site, u.bio];
  return Math.round((parts.filter(Boolean).length / parts.length) * 100);
}

async function patchMe(id: string, body: Record<string, unknown>) {
  const res = await api.patch<ApiSuccess<User>>(`/users/${id}`, body);
  return res.data.data;
}

export function AccountPage() {
  const user = useAuthStore((s) => s.user)!;
  const setUser = useAuthStore((s) => s.setUser);
  const [message, setMessage] = useState<{ tone: 'success' | 'error'; text: string } | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting, isDirty },
    reset,
  } = useForm<ProfileValues>({ resolver: zodResolver(profileSchema), defaultValues: formValues(user) });

  const bioLength = useWatch({ control, name: 'bio' })?.length ?? 0;
  const pct = completeness(user);

  const onSubmit = async (values: ProfileValues) => {
    setMessage(null);
    try {
      const saved = await patchMe(user.id, values);
      setUser(saved);
      reset(formValues(saved));
      setMessage({ tone: 'success', text: 'Profile saved.' });
    } catch (err) {
      setMessage({ tone: 'error', text: toApiError(err).message });
    }
  };

  const onPhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow picking the same file again
    if (!file) return;
    setPhotoError(null);
    setPhotoBusy(true);
    try {
      setUser(await patchMe(user.id, { avatar: await photoToAvatar(file) }));
    } catch (err) {
      setPhotoError(err instanceof Error && !('isAxiosError' in err) ? err.message : toApiError(err).message);
    } finally {
      setPhotoBusy(false);
    }
  };

  const removePhoto = async () => {
    setPhotoError(null);
    setPhotoBusy(true);
    try {
      setUser(await patchMe(user.id, { avatar: null }));
    } catch (err) {
      setPhotoError(toApiError(err).message);
    } finally {
      setPhotoBusy(false);
    }
  };

  return (
    <>
      {/* Profile hero: cover band with the plant scene, photo, name and quick facts. */}
      <section className="relative mb-8 overflow-hidden rounded-2xl bg-white/80 shadow-card ring-1 ring-white/70 backdrop-blur-xl">
        <div className="relative h-36 overflow-hidden bg-gradient-to-br from-navy-800 via-navy-900 to-navy-950 sm:h-44">
          <div aria-hidden className="bg-blueprint-live absolute inset-0" />
          <div aria-hidden className="absolute -left-20 -top-24 size-80 animate-drift rounded-full bg-brand-500/30 blur-[90px]" />
          <div aria-hidden className="absolute -right-10 -top-10 size-72 animate-drift rounded-full bg-signal-500/20 blur-[90px] [animation-delay:-8s]" />
          <PlantIllustration tone="dark" className="absolute bottom-0 right-0 h-full w-auto max-w-none opacity-80" />
        </div>

        <div className="relative flex flex-col gap-5 px-5 pb-6 sm:flex-row sm:items-end sm:px-8">
          {/* Photo with change / remove controls. */}
          <div className="relative -mt-14 w-fit shrink-0 sm:-mt-16">
            <Avatar name={user.name} src={user.avatar} size="xl" className="ring-4 ring-white shadow-[0_12px_28px_-12px_rgb(7_17_19/0.55)]" />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={photoBusy}
              className="absolute bottom-1 right-1 flex size-9 items-center justify-center rounded-full bg-gradient-to-b from-brand-500 to-brand-700 text-white shadow-lg ring-2 ring-white transition-transform duration-300 ease-[var(--ease-spring)] hover:scale-110 disabled:opacity-60"
              aria-label={user.avatar ? 'Change profile photo' : 'Add profile photo'}
              title={user.avatar ? 'Change photo' : 'Add photo'}
            >
              {photoBusy ? <span className="size-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : <Camera className="size-4" />}
            </button>
            <input ref={fileRef} type="file" accept={AVATAR_ACCEPT} className="sr-only" tabIndex={-1} onChange={(e) => void onPhoto(e)} />
          </div>

          <div className="min-w-0 flex-1 animate-fade-up">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="type-display text-gradient-ink text-[26px] font-bold leading-tight sm:text-[30px]">{user.name}</h1>
              <span className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-semibold text-brand-800 ring-1 ring-inset ring-brand-200">
                <BadgeCheck className="size-3.5" aria-hidden /> {ROLE_LABEL[user.role]}
              </span>
            </div>
            <p className="mt-1 text-[15px] text-slate-600">
              {user.jobTitle || <span className="text-slate-400">Add your job title below</span>}
              {user.site && <span className="text-slate-400"> · {user.site}</span>}
            </p>
            <div className="mt-3 flex flex-wrap gap-2 text-[13px] text-slate-600">
              <Fact icon={Mail}>{user.email}</Fact>
              {user.phone && <Fact icon={Phone}>{user.phone}</Fact>}
              <Fact icon={Languages}>{languageLabel(user.preferredLanguage)}</Fact>
            </div>
          </div>

          {user.avatar && (
            <Button variant="ghost" size="sm" onClick={() => void removePhoto()} disabled={photoBusy} className="self-start sm:self-end">
              <Trash2 className="size-4" aria-hidden /> Remove photo
            </Button>
          )}
        </div>
        {photoError && (
          <div className="px-5 pb-5 sm:px-8">
            <Alert tone="error">{photoError}</Alert>
          </div>
        )}
      </section>

      <div className="stagger grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_24rem] [--stagger-step:100ms]">
        <Card>
          <CardHeader icon={<UserRound />} title="Personal details" description="Shown to engineers and administrators on your tickets." />
          <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 sm:p-6">
            <Input label="Full name" autoComplete="name" error={errors.name?.message} {...register('name')} />
            <Input label="Job title" placeholder="e.g. Shift Operator" error={errors.jobTitle?.message} {...register('jobTitle')} />
            <Input label="Phone" type="tel" autoComplete="tel" placeholder="+91 98765 43210" error={errors.phone?.message} {...register('phone')} />
            <Input label="Site / unit" placeholder="e.g. Demo Refinery Unit 1" error={errors.site?.message} {...register('site')} />
            <div className="sm:col-span-2">
              <Select label="Preferred language" options={PREFERRED_LANGUAGE_OPTIONS} {...register('preferredLanguage')} />
              <p className="mt-1.5 text-[13px] text-slate-500">Used for voice reporting and spoken prompts.</p>
            </div>
            <div className="sm:col-span-2">
              <Textarea
                label="About you"
                rows={3}
                placeholder="Areas you look after, shift pattern, anything colleagues should know."
                error={errors.bio?.message}
                {...register('bio')}
              />
              <p className={clsx('mt-1 text-right text-xs tabular-nums', bioLength > BIO_MAX ? 'text-red-700' : 'text-slate-400')}>
                {bioLength}/{BIO_MAX}
              </p>
            </div>
            {message && (
              <div className="sm:col-span-2">
                <Alert tone={message.tone}>{message.text}</Alert>
              </div>
            )}
            <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
              <Button type="submit" loading={isSubmitting} disabled={!isDirty}>
                Save profile
              </Button>
              {isDirty && (
                <Button type="button" variant="ghost" onClick={() => reset(formValues(user))}>
                  Discard changes
                </Button>
              )}
            </div>
          </form>
        </Card>

        <div className="stagger space-y-6 [--stagger-step:100ms]">
          <Card>
            <CardHeader icon={<ShieldCheck />} title="Profile strength" description="A complete profile helps engineers reach you." />
            <div className="p-5">
              <div className="flex items-end justify-between">
                <p className="type-display text-[32px] font-bold leading-none text-navy-900 tabular-nums">{pct}%</p>
                <p className="text-xs text-slate-500">{pct === 100 ? 'All set' : 'Add the missing details'}</p>
              </div>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Profile completeness">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-500 via-brand-400 to-signal-400 transition-[width] duration-700 ease-[var(--ease-out-expo)]"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <ul className="mt-4 grid grid-cols-2 gap-2 text-[13px]">
                {(
                  [
                    ['Photo', user.avatar],
                    ['Job title', user.jobTitle],
                    ['Phone', user.phone],
                    ['Site', user.site],
                    ['About', user.bio],
                  ] as const
                ).map(([label, v]) => (
                  <li key={label} className={clsx('flex items-center gap-1.5', v ? 'text-slate-700' : 'text-slate-400')}>
                    <span className={clsx('size-1.5 rounded-full', v ? 'bg-emerald-500' : 'bg-slate-300')} aria-hidden />
                    {label}
                    <span className="sr-only">{v ? '(done)' : '(missing)'}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Card>

          <Card>
            <CardHeader icon={<Clock />} title="Account" />
            <dl className="divide-y divide-slate-100 px-5 text-sm">
              <Row icon={Briefcase} label="Role" value={ROLE_LABEL[user.role]} />
              <Row icon={MailCheck} label="Email" value={user.emailVerified ? 'Verified' : 'Not verified'} />
              <Row icon={Factory} label="Site" value={user.site || '—'} />
              <Row icon={Calendar} label="Member since" value={formatDateTime(user.createdAt)} />
              <Row icon={Clock} label="Last sign-in" value={formatDateTime(user.lastLoginAt)} />
              <Row icon={KeyRound} label="Password changed" value={user.passwordChangedAt ? formatDateTime(user.passwordChangedAt) : 'Never'} />
            </dl>
          </Card>

          <Card>
            <CardHeader icon={<KeyRound />} title="Change password" description="Changing your password signs out all other sessions." />
            <div className="p-5">
              <ChangePasswordForm />
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}

function Fact({ icon: Icon, children }: { icon: LucideIcon; children: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100/80 px-2.5 py-1 ring-1 ring-inset ring-slate-200">
      <Icon className="size-3.5 text-brand-600" aria-hidden />
      {children}
    </span>
  );
}

function Row({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-3">
      <dt className="flex items-center gap-2 text-slate-500">
        <Icon className="size-4 text-slate-400" aria-hidden />
        {label}
      </dt>
      <dd className="text-right font-medium text-slate-800">{value}</dd>
    </div>
  );
}
