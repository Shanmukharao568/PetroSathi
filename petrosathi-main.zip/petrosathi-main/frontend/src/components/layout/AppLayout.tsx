import { Suspense, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router';
import {
  BarChart3,
  CalendarDays,
  HardHat,
  ClipboardList,
  FileText,
  Gauge,
  LogOut,
  Menu,
  Mic,
  ScrollText,
  ShieldCheck,
  UserRound,
  Users,
  Wrench,
  X,
  type LucideIcon,
} from 'lucide-react';
import clsx from 'clsx';
import { useAuthStore } from '../../store/authStore';
import { ROLE_LABEL, type Role } from '../../types/auth';
import { Logo, LogoMark } from '../brand/Logo';
import { SystemStatus } from '../SystemStatus';
import { PageSkeleton } from '../ui/Spinner';
import { Avatar } from '../ui/Avatar';
import { NotificationBell } from './NotificationBell';
import { useSpotlight } from '../../hooks/useMotion';

interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
}

const NAV: Record<Role, NavItem[]> = {
  operator: [
    { to: '/operator/dashboard', label: 'Dashboard', icon: Gauge },
    { to: '/operator/report', label: 'Report issue', icon: Mic },
    { to: '/operator/tickets', label: 'My tickets', icon: ClipboardList },
  ],
  engineer: [
    { to: '/engineer/dashboard', label: 'Dashboard', icon: Gauge },
    { to: '/engineer/tickets', label: 'Tickets', icon: ClipboardList },
  ],
  admin: [
    { to: '/admin/dashboard', label: 'Dashboard', icon: Gauge },
    { to: '/admin/users', label: 'Users', icon: Users },
    { to: '/engineer/tickets', label: 'Tickets', icon: ClipboardList },
    { to: '/admin/equipment', label: 'Equipment', icon: Wrench },
    { to: '/admin/documents', label: 'Documents', icon: FileText },
    { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/admin/audit-logs', label: 'Audit logs', icon: ScrollText },
  ],
};

const ROLE_ICON: Record<Role, LucideIcon> = { operator: HardHat, engineer: Wrench, admin: ShieldCheck };

/** Shown under every role's own items. */
const PROFILE_NAV: NavItem = { to: '/account', label: 'My profile', icon: UserRound };

export function AppLayout() {
  const user = useAuthStore((s) => s.user)!;
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const location = useLocation();
  const RoleIcon = ROLE_ICON[user.role];
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef<HTMLElement>(null);
  const mobileNavRef = useRef<HTMLElement>(null);
  const [pill, setPill] = useState<{ top: number; height: number } | null>(null);
  useSpotlight();

  // Header gains a hairline and shadow once content scrolls under it.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // The active-item pill slides between nav entries instead of jumping.
  useLayoutEffect(() => {
    const nav = mobileOpen ? mobileNavRef.current : navRef.current;
    const active = nav?.querySelector<HTMLElement>('a[aria-current="page"]');
    setPill(active ? { top: active.offsetTop, height: active.offsetHeight } : null);
  }, [location.pathname, mobileOpen]);
  const today = new Intl.DateTimeFormat(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date());

  const onLogout = async () => {
    setSigningOut(true);
    await logout();
    navigate('/login', { replace: true });
  };

  const sidebar = (ref: RefObject<HTMLElement | null>) => (
    <div className="relative flex h-full flex-col overflow-hidden bg-navy-900 text-slate-300">
      <div aria-hidden className="bg-blueprint pointer-events-none absolute inset-0 [mask-image:linear-gradient(to_bottom,black,transparent_55%)]" />
      <div aria-hidden className="pointer-events-none absolute -left-16 -top-24 size-64 animate-drift rounded-full bg-brand-500/20 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-24 -right-20 size-56 animate-drift rounded-full bg-signal-500/10 blur-3xl [animation-delay:-9s]" />
      <div className="relative flex h-16 items-center px-5">
        <Logo inverted />
      </div>
      <div className="relative mx-3 mt-3 flex items-center gap-2.5 rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2">
        <span className="flex size-7 items-center justify-center rounded-md bg-signal-400/15 text-signal-400" aria-hidden>
          <RoleIcon className="size-4" />
        </span>
        <div className="min-w-0 leading-tight">
          <p className="text-[10px] font-medium uppercase tracking-[0.14em] text-slate-500">Workspace</p>
          <p className="truncate text-[13px] font-semibold text-slate-100">{ROLE_LABEL[user.role]}</p>
        </div>
      </div>
      <p className="type-label relative px-5 pb-2 pt-6 text-[10px] text-slate-500">Navigate</p>
      <nav ref={ref} className="relative flex-1 space-y-0.5 overflow-y-auto px-3" aria-label="Main">
        {pill && (
          <span
            aria-hidden
            className="pointer-events-none absolute inset-x-3 rounded-lg bg-gradient-to-r from-white/[0.1] to-white/[0.03] ring-1 ring-inset ring-white/[0.08] transition-[transform,height] duration-500 ease-[var(--ease-out-expo)]"
            style={{ top: 0, height: pill.height, transform: `translateY(${pill.top}px)` }}
          >
            <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-signal-400 shadow-[0_0_12px_var(--color-signal-400)]" />
          </span>
        )}
        {[...NAV[user.role], PROFILE_NAV].map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            viewTransition
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              clsx(
                'group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors duration-200',
                isActive ? 'text-white' : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-100',
              )
            }
          >
            {({ isActive }) => (
              <>
                <Icon
                  className={clsx(
                    'size-[18px] transition-[color,transform] duration-300 ease-[var(--ease-spring)]',
                    isActive ? 'text-signal-400' : 'text-slate-500 group-hover:scale-110 group-hover:text-slate-300',
                  )}
                  strokeWidth={isActive ? 2.25 : 2}
                  aria-hidden
                />
                <span className="transition-transform duration-300 ease-[var(--ease-out-expo)] group-hover:translate-x-0.5">{label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="relative m-3 rounded-lg border border-white/[0.08] bg-navy-950/40 px-3 py-2.5">
        <SystemStatus />
      </div>
    </div>
  );

  return (
    <div className="relative min-h-screen lg:grid lg:grid-cols-[16.5rem_1fr]">
      <div aria-hidden className="app-backdrop" />
      <aside className="hidden lg:sticky lg:top-0 lg:block lg:h-screen">{sidebar(navRef)}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 animate-[backdrop-in_200ms_ease-out_both] bg-navy-950/60 backdrop-blur-[3px]" onClick={() => setMobileOpen(false)} aria-hidden />
          <div className="relative h-full w-[17rem] max-w-[85vw] animate-[slide-in_220ms_cubic-bezier(0.2,0.7,0.2,1)_both] shadow-2xl">{sidebar(mobileNavRef)}</div>
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            className="absolute right-4 top-4 rounded-lg bg-white/10 p-2.5 text-white backdrop-blur transition-colors hover:bg-white/20"
            aria-label="Close navigation"
          >
            <X className="size-5" />
          </button>
        </div>
      )}

      <div className="flex min-w-0 flex-col">
        <header
          className={clsx(
            'sticky top-0 z-30 flex h-16 items-center gap-3 border-b px-4 backdrop-blur-xl backdrop-saturate-150 transition-[background-color,border-color,box-shadow] duration-300 sm:px-8',
            scrolled
              ? 'border-slate-200/90 bg-white/75 shadow-[0_8px_24px_-16px_rgb(16_34_40/0.25)]'
              : 'border-transparent bg-white/30',
          )}
        >
          <button
            type="button"
            className="-ml-1 rounded-lg p-2.5 text-slate-600 transition-colors hover:bg-slate-200/60 lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
          >
            <Menu className="size-5" />
          </button>
          <LogoMark className="size-7 lg:hidden" />
          <p className="hidden items-center gap-2 font-mono text-xs text-slate-500 md:flex">
            <CalendarDays className="size-3.5 text-slate-400" aria-hidden />
            {today}
          </p>
          <div className="ml-auto flex items-center gap-1 sm:gap-2">
            <NotificationBell />
            <span className="mx-1 hidden h-6 w-px bg-slate-200 sm:block" aria-hidden />
            <NavLink
              to="/account"
              className={({ isActive }) =>
                clsx('group/acct flex items-center gap-2.5 rounded-lg py-1.5 pl-1.5 pr-2 transition-colors hover:bg-slate-200/60', isActive && 'bg-slate-200/60')
              }
              title="My profile"
            >
              <Avatar
                name={user.name}
                src={user.avatar}
                className="ring-2 ring-white shadow-[0_0_0_3px_var(--color-brand-100)] transition-shadow duration-300 group-hover/acct:shadow-[0_0_0_4px_var(--color-brand-200)]"
              />
              <span className="hidden text-left leading-tight sm:block">
                <span className="block text-[13px] font-semibold text-slate-900">{user.name}</span>
                <span className="block text-xs text-slate-500">{user.jobTitle || user.email}</span>
              </span>
            </NavLink>
            <button
              type="button"
              onClick={() => void onLogout()}
              disabled={signingOut}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-[13px] font-semibold text-slate-600 transition-colors hover:bg-slate-200/60 hover:text-slate-900 disabled:opacity-60"
              title="Sign out"
            >
              <LogOut className="size-4" aria-hidden />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-8 sm:py-9">
          <div className="mx-auto w-full max-w-[1400px]">
            <Suspense fallback={<PageSkeleton />}>
              <div key={location.pathname} className="page-stagger">
                <Outlet />
              </div>
            </Suspense>
          </div>
        </main>
      </div>
    </div>
  );
}
