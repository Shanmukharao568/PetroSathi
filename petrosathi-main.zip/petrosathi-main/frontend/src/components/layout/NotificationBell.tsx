import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { Bell, BellOff, CheckCheck } from 'lucide-react';
import clsx from 'clsx';
import { api, toApiError, type ApiSuccess } from '../../lib/api';
import { ticketBasePath, timeAgo } from '../../lib/format';
import { useAuthStore } from '../../store/authStore';
import type { AppNotification } from '../../types/domain';

const POLL_MS = 30_000;

export function NotificationBell() {
  const role = useAuthStore((s) => s.user!.role);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    try {
      const res = await api.get<ApiSuccess<AppNotification[]>>('/notifications', { params: { limit: 15 } });
      setItems(res.data.data);
      setUnread(Number(res.data.meta?.unread ?? 0));
      setError(null);
    } catch (err) {
      setError(toApiError(err).message);
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), POLL_MS);
    return () => window.clearInterval(t);
  }, [load]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const openItem = async (n: AppNotification) => {
    setOpen(false);
    if (!n.isRead) {
      await api.patch(`/notifications/${n.id}/read`).catch(() => undefined);
      void load();
    }
    if (n.ticketId) navigate(`${ticketBasePath(role)}/${n.ticketId}`);
  };

  const markAll = async () => {
    await api.patch('/notifications/read-all').catch(() => undefined);
    void load();
  };

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={clsx('relative rounded-lg p-2.5 text-slate-600 transition-colors hover:bg-slate-200/60 hover:text-slate-900', open && 'bg-slate-200/60 text-slate-900')}
        aria-label={unread ? `Notifications, ${unread} unread` : 'Notifications'}
        aria-expanded={open}
      >
        <Bell className="size-5" />
        {unread > 0 && (
          <span className="absolute right-1.5 top-1.5 flex min-w-4 items-center justify-center rounded-full bg-red-600 px-1 font-mono text-[10px] font-semibold leading-4 text-white ring-2 ring-slate-50">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute -right-24 z-40 mt-2 w-[min(23rem,calc(100vw-2rem))] origin-top-right animate-pop overflow-hidden rounded-xl border border-slate-200 bg-white shadow-raised sm:right-0">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
            <p className="text-sm font-semibold text-navy-900">
              Notifications
              {unread > 0 && <span className="ml-2 rounded-full bg-red-50 px-1.5 py-0.5 font-mono text-[11px] font-medium text-red-700 ring-1 ring-inset ring-red-200">{unread} new</span>}
            </p>
            {unread > 0 && (
              <button type="button" onClick={() => void markAll()} className="inline-flex items-center gap-1 text-xs font-medium text-brand-700 hover:text-brand-600">
                <CheckCheck className="size-3.5" aria-hidden /> Mark all read
              </button>
            )}
          </div>
          <ul className="max-h-96 divide-y divide-slate-100 overflow-y-auto">
            {error && <li className="p-4 text-sm text-red-600">{error}</li>}
            {!error && items.length === 0 && (
              <li className="flex flex-col items-center px-4 py-8 text-center">
                <BellOff className="size-5 text-slate-300" aria-hidden />
                <span className="mt-2 text-sm font-medium text-slate-700">You're all caught up.</span>
                <span className="text-xs text-slate-500">Ticket updates will appear here.</span>
              </li>
            )}
            {items.map((n) => (
              <li key={n.id}>
                <button type="button" onClick={() => void openItem(n)} className={clsx('flex w-full gap-3 px-4 py-3 text-left transition-colors hover:bg-slate-50', !n.isRead && 'bg-brand-50/50')}>
                  <span className={clsx('mt-1.5 size-2 shrink-0 rounded-full', n.isRead ? 'bg-transparent' : 'bg-brand-500')} aria-hidden />
                  <span className="min-w-0">
                    <span className={clsx('block text-sm', n.isRead ? 'text-slate-600' : 'font-medium text-slate-900')}>{n.message}</span>
                    <span className="block text-xs text-slate-500">{timeAgo(n.createdAt)}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
