import type { ReactNode } from 'react';
import { ClipboardList, Languages, Mic, ShieldCheck } from 'lucide-react';
import { Logo } from '../brand/Logo';
import { PlantIllustration } from '../brand/PlantIllustration';
import { SystemStatus } from '../SystemStatus';

const features = [
  { icon: Mic, title: 'Push-to-talk reporting', body: 'Report equipment faults by voice, in your language.' },
  { icon: Languages, title: 'Multilingual', body: 'Indian languages supported per verified provider capability.' },
  { icon: ClipboardList, title: 'Structured tickets', body: 'Complaints are reviewed and confirmed before a ticket exists.' },
  { icon: ShieldCheck, title: 'Reporting only', body: 'PetroSathi never authorizes shutdown, isolation or restart.' },
];

/**
 * Shared frame for the sign-in and sign-up pages: the animated plant panel on the left (large
 * screens) and the form column on the right over the aurora backdrop.
 */
export function AuthShell({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
      <aside className="relative hidden overflow-hidden bg-gradient-to-br from-navy-800 via-navy-900 to-navy-950 p-12 text-slate-300 lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col xl:p-16">
        <div aria-hidden className="bg-blueprint-live pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_30%_40%,black,transparent_75%)]" />
        <div aria-hidden className="pointer-events-none absolute -right-40 -top-40 size-[34rem] animate-drift rounded-full bg-brand-500/25 blur-[120px]" />
        <div aria-hidden className="pointer-events-none absolute -bottom-48 -left-24 size-[28rem] animate-drift rounded-full bg-signal-500/15 blur-[110px] [animation-delay:-8s]" />
        <div aria-hidden className="pointer-events-none absolute left-1/3 top-1/3 size-72 animate-drift rounded-full bg-sky-400/[0.06] blur-[90px] [animation-delay:-4s]" />
        <Logo inverted className="relative" />

        {/* Animated plant picture: grows into whatever height the panel has to spare. */}
        <div className="relative -mx-12 mt-4 flex min-h-0 flex-1 items-end xl:-mx-16">
          <PlantIllustration tone="dark" className="max-h-[22rem] min-h-0 w-full animate-fade-up" />
          {/* Live voice waveform floating over the plant. */}
          <div aria-hidden className="pointer-events-none absolute right-16 top-6 hidden h-14 items-center gap-[5px] xl:flex">
            {Array.from({ length: 28 }, (_, i) => {
              const h = 14 + Math.abs(Math.sin(i * 0.55) * Math.cos(i * 0.21)) * 86;
              return (
                <span
                  key={i}
                  className="w-1 animate-eq rounded-full bg-gradient-to-t from-brand-400/40 to-signal-300/50"
                  style={{ height: `${h}%`, animationDelay: `${(i % 12) * 95}ms`, animationDuration: `${1 + (i % 5) * 0.18}s` }}
                />
              );
            })}
          </div>
        </div>

        <div className="stagger relative mt-6 max-w-xl [--stagger-step:110ms]">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 font-mono text-[11px] uppercase tracking-[0.14em] text-signal-300">
            <span className="relative flex size-1.5" aria-hidden>
              <span className="absolute inset-0 animate-ping rounded-full bg-signal-400" />
              <span className="relative size-1.5 rounded-full bg-signal-400" />
            </span>{' '}
            Field operations
          </p>
          <h1 className="type-display text-[38px] font-bold leading-[1.05] text-white xl:text-[44px]">
            Report equipment issues by voice. <span className="text-gradient-signal">Track them to resolution.</span>
          </h1>
          {/* Compact feature chips; the full line shows as a tooltip and to screen readers. */}
          <ul className="stagger mt-6 grid grid-cols-2 gap-2.5 [--stagger-step:80ms]">
            {features.map(({ icon: Icon, title, body }) => (
              <li
                key={title}
                title={body}
                className="group flex items-center gap-2.5 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3 py-2.5 backdrop-blur transition-[background-color,border-color,transform] duration-300 ease-[var(--ease-out-expo)] hover:-translate-y-0.5 hover:border-signal-400/30 hover:bg-white/[0.06]"
              >
                <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-white/[0.06] text-signal-400 ring-1 ring-inset ring-white/10 transition-transform duration-300 ease-[var(--ease-spring)] group-hover:-rotate-6 group-hover:scale-110">
                  <Icon className="size-4" aria-hidden />
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-semibold text-white">{title}</span>
                  <span className="sr-only">{body}</span>
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-5 max-w-xs rounded-lg border border-white/[0.08] bg-navy-950/40 px-3 py-2.5">
            <SystemStatus />
          </div>
        </div>
      </aside>

      <main className="relative flex flex-col justify-center overflow-hidden px-5 pb-48 pt-12 sm:px-12 lg:pb-12">
        <div aria-hidden className="app-backdrop" />
        <PlantIllustration tone="light" className="pointer-events-none absolute inset-x-0 bottom-0 w-full opacity-70 lg:hidden" />
        <div className="stagger relative mx-auto w-full max-w-[420px] [--stagger-step:80ms]">
          <Logo className="lg:hidden" />
          {children}
          <p className="mt-6 flex items-start gap-2 text-xs leading-relaxed text-slate-500">
            <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-slate-400" aria-hidden />
            PetroSathi is for reporting only. It never authorizes shutdown, isolation or restart of equipment.
          </p>
          <div className="mt-8 rounded-xl bg-navy-900 px-4 py-3 lg:hidden">
            <SystemStatus />
          </div>
        </div>
      </main>
    </div>
  );
}
