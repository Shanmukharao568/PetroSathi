import type { ReactNode } from 'react';
import { Activity, Database, FlaskConical, Radio, RefreshCw, ServerCrash } from 'lucide-react';
import clsx from 'clsx';
import { useHealth } from '../hooks/useHealth';

type Tone = 'ok' | 'warn' | 'bad' | 'mock' | 'idle';

const dot: Record<Tone, string> = {
  ok: 'bg-emerald-400 shadow-[0_0_0_3px_rgb(52_211_153/0.18)]',
  warn: 'bg-signal-400 shadow-[0_0_0_3px_rgb(244_183_64/0.2)]',
  bad: 'bg-red-400 shadow-[0_0_0_3px_rgb(248_113_113/0.2)]',
  mock: 'bg-fuchsia-400 shadow-[0_0_0_3px_rgb(232_121_249/0.2)]',
  idle: 'bg-slate-500 animate-pulse',
};

function Row({ icon, label, value, tone }: { icon: ReactNode; label: string; value: string; tone: Tone }) {
  return (
    <li className="flex items-center gap-2 py-1">
      <span className="text-slate-500 [&>svg]:size-3.5" aria-hidden>
        {icon}
      </span>
      <span className="text-slate-400">{label}</span>
      <span
        className={clsx(
          'ml-auto inline-flex items-center gap-1.5 font-mono text-[11px] font-medium',
          tone === 'mock' ? 'uppercase tracking-wide text-fuchsia-300' : tone === 'bad' ? 'text-red-300' : 'text-slate-200',
        )}
      >
        {value}
        <span className={clsx('size-1.5 rounded-full', dot[tone])} aria-hidden />
      </span>
    </li>
  );
}

/** Live backend status from GET /api/v1/health. Shows MOCK clearly when providers are mocked. */
export function SystemStatus() {
  const { state, refresh } = useHealth();

  return (
    <div className="text-xs" aria-live="polite">
      <p className="type-label mb-1.5 text-[10px] text-slate-500">System status</p>
      {state.kind === 'loading' && (
        <ul>
          <Row icon={<Activity />} label="Server" value="Checking server…" tone="idle" />
        </ul>
      )}

      {state.kind === 'error' && (
        <div className="flex items-center gap-2">
          <ul className="flex-1">
            <Row icon={<ServerCrash />} label="API" value="API unreachable" tone="bad" />
          </ul>
          <button
            type="button"
            onClick={() => void refresh()}
            className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-slate-400 transition-colors hover:bg-white/5 hover:text-white"
          >
            <RefreshCw className="size-3.5" aria-hidden /> Retry
          </button>
        </div>
      )}

      {state.kind === 'ready' && (
        <ul>
          <Row icon={<Activity />} label="API" value={state.data.status} tone={state.data.status === 'ok' ? 'ok' : 'warn'} />
          <Row icon={<Database />} label="Database" value={state.data.database} tone={state.data.database === 'connected' ? 'ok' : 'bad'} />
          {state.data.aiProviderMode === 'mock' ? (
            <Row icon={<FlaskConical />} label="AI" value="mock providers" tone="mock" />
          ) : (
            <Row icon={<Radio />} label="AI" value="Gnani live" tone="ok" />
          )}
        </ul>
      )}
    </div>
  );
}
