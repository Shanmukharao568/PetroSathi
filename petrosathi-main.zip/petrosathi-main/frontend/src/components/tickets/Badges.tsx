import clsx from 'clsx';
import { AlertOctagon, ArrowUp, CircleHelp, Minus, ArrowDown } from 'lucide-react';
import type { Severity, TicketStatus } from '../../types/domain';
import { SEVERITY_LABEL, STATUS_LABEL } from '../../lib/format';

const statusStyle: Record<TicketStatus, { cls: string; dot: string }> = {
  OPEN: { cls: 'bg-sky-50 text-sky-800 ring-sky-200', dot: 'bg-sky-500' },
  UNDER_INSPECTION: { cls: 'bg-violet-50 text-violet-800 ring-violet-200', dot: 'bg-violet-500' },
  IN_PROGRESS: { cls: 'bg-amber-50 text-amber-900 ring-amber-200', dot: 'bg-signal-500' },
  RESOLVED: { cls: 'bg-emerald-50 text-emerald-800 ring-emerald-200', dot: 'bg-emerald-500' },
  CLOSED: { cls: 'bg-slate-100 text-slate-600 ring-slate-200', dot: 'bg-slate-400' },
};

export function StatusBadge({ status }: { status: TicketStatus }) {
  const { cls, dot } = statusStyle[status];
  return (
    <span className={clsx('inline-flex items-center gap-1.5 whitespace-nowrap rounded-full py-0.5 pl-2 pr-2.5 text-xs font-medium leading-5 ring-1 ring-inset', cls)}>
      <span className="relative flex size-1.5" aria-hidden>
        {/* Work that is actively moving gets a live pulse. */}
        {(status === 'IN_PROGRESS' || status === 'UNDER_INSPECTION') && (
          <span className={clsx('absolute inset-0 animate-ping rounded-full opacity-60 [animation-duration:2s]', dot)} />
        )}
        <span className={clsx('relative size-1.5 rounded-full', dot)} />
      </span>
      {STATUS_LABEL[status]}
    </span>
  );
}

const sevStyle: Record<Severity, { cls: string; Icon: typeof ArrowUp }> = {
  critical: { cls: 'bg-red-600 text-white ring-red-700 shadow-[0_1px_2px_rgb(185_28_28/0.35)]', Icon: AlertOctagon },
  high: { cls: 'bg-orange-50 text-orange-800 ring-orange-300', Icon: ArrowUp },
  medium: { cls: 'bg-amber-50 text-amber-900 ring-amber-200', Icon: Minus },
  low: { cls: 'bg-slate-50 text-slate-600 ring-slate-200', Icon: ArrowDown },
  unknown: { cls: 'bg-white text-slate-500 ring-slate-300 ring-dashed', Icon: CircleHelp },
};

/** Severity uses colour AND an icon + label, so it is not conveyed by colour alone. */
export function SeverityBadge({ severity }: { severity: Severity }) {
  const { cls, Icon } = sevStyle[severity];
  return (
    <span className={clsx('inline-flex items-center gap-1 whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-semibold leading-5 ring-1 ring-inset', cls)}>
      <Icon className={clsx('size-3.5', severity === 'critical' && 'animate-blink')} aria-hidden />
      {SEVERITY_LABEL[severity]}
    </span>
  );
}
