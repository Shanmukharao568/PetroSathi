import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CHART, nf } from './chartTheme';
import { TooltipBody } from './ChartTooltip';

export interface TrendSeries {
  key: string;
  name: string;
  /** Categorical slot index (fixed per entity, never by rank). */
  slot: number;
}

const monthLabel = (m: string) => new Intl.DateTimeFormat(undefined, { month: 'short', year: '2-digit' }).format(new Date(`${m}-15T00:00:00`));

/**
 * Multi-series line chart over months: 2px lines, legend always shown (≥ 2 series), end-point
 * direct labels, crosshair that snaps to the month with one tooltip listing every series.
 */
export function TrendChart({ data, series }: { data: Record<string, number | string>[]; series: TrendSeries[] }) {
  const last = data.length - 1;
  return (
    <div>
      <ul className="mb-2 flex flex-wrap gap-4 px-2 text-xs text-slate-600" aria-label="Legend">
        {series.map((s) => (
          <li key={s.key} className="inline-flex items-center gap-1.5">
            <span className="inline-block h-0.5 w-4 rounded-full" style={{ backgroundColor: CHART.series[s.slot] }} aria-hidden />
            {s.name}
          </li>
        ))}
      </ul>
      <ResponsiveContainer width="100%" height={260}>
        {/* Right margin leaves room for the longest end label ("9,999 resolved") so it is never clipped. */}
        <LineChart data={data} margin={{ top: 8, right: 96, bottom: 0, left: 0 }}>
          <CartesianGrid vertical={false} stroke={CHART.grid} strokeWidth={1} />
          <XAxis dataKey="month" tickFormatter={monthLabel} axisLine={{ stroke: CHART.axis }} tickLine={false} tick={{ fill: CHART.muted, fontSize: 11 }} interval="preserveStartEnd" minTickGap={16} />
          <YAxis allowDecimals={false} width={36} axisLine={false} tickLine={false} tick={{ fill: CHART.muted, fontSize: 11 }} tickFormatter={(v: number) => nf.format(v)} />
          <Tooltip
            cursor={{ stroke: CHART.axis, strokeWidth: 1 }}
            content={({ active, label }) => {
              if (!active || typeof label !== 'string') return null;
              const row = data.find((d) => d.month === label);
              return <TooltipBody title={monthLabel(label)} rows={series.map((s) => ({ name: s.name, value: Number(row?.[s.key] ?? 0), color: CHART.series[s.slot]! }))} />;
            }}
          />
          {series.map((s) => (
            <Line
              key={s.key}
              // Straight segments: monthly counts are discrete; a smoothed curve would overshoot
              // below zero and imply values between months.
              type="linear"
              dataKey={s.key}
              name={s.name}
              stroke={CHART.series[s.slot]}
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              isAnimationActive={false}
              dot={false}
              activeDot={{ r: 4, fill: CHART.series[s.slot], stroke: CHART.surface, strokeWidth: 2 }}
              label={({ x, y, index, value }: { x?: number | string; y?: number | string; index?: number; value?: unknown }) =>
                index === last && x != null && y != null ? (
                  <text x={Number(x) + 8} y={Number(y)} dy={4} fill={CHART.inkSecondary} fontSize={11}>
                    {`${nf.format(Number(value ?? 0))} ${s.name.toLowerCase()}`}
                  </text>
                ) : (
                  <g />
                )
              }
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
