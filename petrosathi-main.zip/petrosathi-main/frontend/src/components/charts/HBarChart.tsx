import { Bar, BarChart, CartesianGrid, Cell, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CHART, nf } from './chartTheme';
import { TooltipBody } from './ChartTooltip';

export interface BarDatum {
  label: string;
  value: number | null;
  /** Ordinal/neutral colour for this bar; defaults to categorical slot 1 (one series). */
  color?: string;
  /** Extra tooltip line, e.g. "2 active". */
  detail?: string;
}

/**
 * Horizontal bars for one series: ≤ 24px thick, 4px rounded data-end and square at the
 * baseline, value at the tip, hairline solid grid. The bar itself is the hover target.
 */
export function HBarChart({ data, unit, valueName = 'Tickets', emptyText = 'No data in this period.' }: { data: BarDatum[]; unit?: string; valueName?: string; emptyText?: string }) {
  const plotted = data.filter((d) => d.value !== null) as (BarDatum & { value: number })[];
  if (!plotted.length || plotted.every((d) => d.value === 0)) {
    return <p className="flex h-40 items-center justify-center text-sm text-slate-500">{emptyText}</p>;
  }
  const height = data.length * 32 + 28; // includes the x-axis band, so no nested scroll
  const longest = Math.max(...data.map((d) => d.label.length));

  return (
    <ResponsiveContainer width="100%" height={height}>
      {/* Right margin sized to the widest tip label so it never wraps or clips. */}
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: Math.max(40, Math.max(...plotted.map((d) => `${d.value}${unit ? ` ${unit}` : ''}`.length)) * 7 + 16), bottom: 0, left: 4 }} barCategoryGap={8}>
        <CartesianGrid horizontal={false} stroke={CHART.grid} strokeWidth={1} />
        <XAxis type="number" allowDecimals={false} axisLine={{ stroke: CHART.axis }} tickLine={false} tick={{ fill: CHART.muted, fontSize: 11 }} tickFormatter={(v: number) => nf.format(v)} />
        <YAxis type="category" dataKey="label" width={Math.min(150, Math.max(70, longest * 7))} axisLine={{ stroke: CHART.axis }} tickLine={false} tick={{ fill: CHART.inkSecondary, fontSize: 12 }} />
        <Tooltip
          cursor={{ fill: 'rgba(15,23,42,0.04)' }}
          content={({ active, payload }) => {
            const d = payload?.[0]?.payload as BarDatum | undefined;
            if (!active || !d) return null;
            return (
              <div>
                <TooltipBody title={d.label} rows={[{ name: valueName, value: d.value, color: d.color ?? CHART.series[0], unit }]} />
                {d.detail && <p className="mt-0.5 rounded-b-lg bg-white px-3 pb-2 text-xs text-slate-500">{d.detail}</p>}
              </div>
            );
          }}
        />
        <Bar dataKey="value" maxBarSize={20} radius={[0, 4, 4, 0]} isAnimationActive={false}>
          {data.map((d) => (
            <Cell key={d.label} fill={d.color ?? CHART.series[0]} />
          ))}
          <LabelList dataKey="value" position="right" fill={CHART.inkSecondary} fontSize={12} formatter={(v: unknown) => (v == null ? '' : `${nf.format(Number(v))}${unit ? ` ${unit}` : ''}`)} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
