import type { ReactNode } from 'react';
import { Link } from 'react-router';
import { ArrowUpRight, type LucideIcon } from 'lucide-react';
import clsx from 'clsx';
import { compact } from './chartTheme';
import { useCountUp } from '../../hooks/useMotion';

export type StatAccent = 'brand' | 'sky' | 'violet' | 'amber' | 'emerald' | 'rose' | 'slate';

/** Per-accent tile tint, icon chip and hover glow. Text stays navy so contrast never depends on the accent. */
const ACCENT: Record<StatAccent, { chip: string; glow: string; line: string }> = {
  brand: { chip: 'from-brand-400 to-brand-700 shadow-brand-700/30', glow: 'bg-brand-400/25', line: 'from-brand-500 to-brand-300' },
  sky: { chip: 'from-sky-400 to-sky-700 shadow-sky-700/30', glow: 'bg-sky-400/25', line: 'from-sky-500 to-sky-300' },
  violet: { chip: 'from-violet-400 to-violet-700 shadow-violet-700/30', glow: 'bg-violet-400/25', line: 'from-violet-500 to-violet-300' },
  amber: { chip: 'from-signal-300 to-signal-600 shadow-signal-600/30', glow: 'bg-signal-300/30', line: 'from-signal-500 to-signal-300' },
  emerald: { chip: 'from-emerald-400 to-emerald-700 shadow-emerald-700/30', glow: 'bg-emerald-400/25', line: 'from-emerald-500 to-emerald-300' },
  rose: { chip: 'from-rose-400 to-red-700 shadow-red-700/30', glow: 'bg-red-400/25', line: 'from-red-500 to-rose-300' },
  slate: { chip: 'from-slate-400 to-slate-700 shadow-slate-700/30', glow: 'bg-slate-400/20', line: 'from-slate-500 to-slate-300' },
};

/**
 * Stat tile: label · value (counts up, auto-compact) · optional note, with an optional
 * gradient icon chip (`glyph` + `accent`). `tone="alert"` adds an icon-bearing emphasis for
 * counts that need attention (never colour alone).
 */
export function StatTile({
  label,
  value,
  unit,
  note,
  to,
  icon,
  glyph: Glyph,
  accent = 'brand',
  tone = 'default',
}: {
  label: string;
  value: number | null;
  unit?: string;
  note?: ReactNode;
  to?: string;
  /** Small inline icon before the label (used for alerts). */
  icon?: ReactNode;
  /** Large decorative icon shown in a gradient chip. */
  glyph?: LucideIcon;
  accent?: StatAccent;
  tone?: 'default' | 'alert';
}) {
  const alerting = tone === 'alert' && !!value;
  const a = ACCENT[alerting ? 'rose' : accent];
  const shown = useCountUp(value);
  const body = (
    <div
      className={clsx(
        'spotlight group relative h-full overflow-hidden rounded-2xl border px-4 pb-4 pt-4 shadow-card backdrop-blur-xl transition-[border-color,box-shadow,transform] duration-300 ease-[var(--ease-out-expo)]',
        to && 'hover:-translate-y-1 hover:shadow-raised',
        alerting ? 'border-red-200 bg-gradient-to-b from-red-50/90 to-white/80' : 'border-white/70 bg-white/75 hover:border-slate-200',
      )}
    >
      {/* Soft accent glow in the corner, brighter on hover. */}
      <span
        aria-hidden
        className={clsx(
          'pointer-events-none absolute -right-8 -top-10 size-28 rounded-full blur-2xl transition-[opacity,transform] duration-500 group-hover:scale-125',
          a.glow,
          Glyph || alerting ? 'opacity-70 group-hover:opacity-100' : 'opacity-0 group-hover:opacity-70',
        )}
      />
      {alerting && <span className="absolute inset-x-0 top-0 h-[3px] animate-blink bg-red-500" aria-hidden />}
      {/* Accent line that draws in on hover. */}
      <span
        aria-hidden
        className={clsx(
          'absolute bottom-0 left-0 h-[3px] w-full origin-left scale-x-0 bg-gradient-to-r transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:scale-x-100',
          a.line,
        )}
      />
      <div className="relative flex items-start justify-between gap-2">
        <p className={clsx('type-label flex items-center gap-1.5 pt-0.5 leading-4', alerting ? 'text-red-700' : 'text-slate-500')}>
          {icon}
          {label}
        </p>
        {Glyph ? (
          <span
            aria-hidden
            className={clsx(
              'relative flex size-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow-lg ring-1 ring-inset ring-white/25',
              'transition-transform duration-500 ease-[var(--ease-spring)] group-hover:-rotate-6 group-hover:scale-110',
              a.chip,
            )}
          >
            <Glyph className="size-5" strokeWidth={2.2} />
            {to && (
              <span className="absolute -right-1.5 -top-1.5 flex size-4 items-center justify-center rounded-full bg-white text-slate-500 opacity-0 shadow ring-1 ring-slate-200 transition-opacity duration-200 group-hover:opacity-100">
                <ArrowUpRight className="size-3" />
              </span>
            )}
          </span>
        ) : (
          to && (
            <ArrowUpRight
              className="size-4 shrink-0 text-slate-300 transition-[color,transform] duration-200 group-hover:-translate-y-px group-hover:translate-x-px group-hover:text-brand-600"
              aria-hidden
            />
          )
        )}
      </div>
      <p className={clsx('type-display relative text-[30px] font-bold leading-none tabular-nums text-navy-900', Glyph ? 'mt-1' : 'mt-2.5')}>
        {shown === null ? <span className="text-slate-300">—</span> : compact(shown)}
        {value !== null && unit && <span className="ml-1 font-sans text-sm font-medium text-slate-500">{unit}</span>}
      </p>
      {note && <p className="relative mt-2 text-xs leading-snug text-slate-500">{note}</p>}
    </div>
  );
  return to ? (
    <Link to={to} className="block h-full rounded-2xl">
      {body}
    </Link>
  ) : (
    body
  );
}
