/**
 * Chart tokens — the dataviz reference palette, validated with validate_palette.js against the
 * app's white card surface (#ffffff):
 *   categorical slots 1–2: CVD ΔE 24.7, normal-vision ΔE 33.6, both ≥ 3:1 contrast
 *   severity ordinal ramp (low→critical): monotone, adjacent ΔL ≥ 0.06, light end 2.11:1
 * The app is light-only today; dark steps would be added here, not flipped automatically.
 */
export const CHART = {
  surface: '#ffffff',
  grid: '#e1e0d9',
  axis: '#c3c2b7',
  muted: '#898781',
  inkPrimary: '#0b0b0b',
  inkSecondary: '#52514e',
  series: ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'] as const,
  /** De-emphasis gray for "Not assessed" / context. */
  neutral: '#a8a7a1',
} as const;

/** Severity is ordered (low → critical): one-hue ordinal ramp; "unknown" is off-scale gray. */
export const SEVERITY_RAMP: Record<string, string> = {
  low: '#86b6ef',
  medium: '#5598e7',
  high: '#256abf',
  critical: '#104281',
  unknown: CHART.neutral,
};

export const nf = new Intl.NumberFormat(undefined);
export const compact = (n: number) => (Math.abs(n) >= 10_000 ? new Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 }).format(n) : nf.format(n));
