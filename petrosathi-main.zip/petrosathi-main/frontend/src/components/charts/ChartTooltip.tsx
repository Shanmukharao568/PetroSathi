import { nf } from './chartTheme';

interface Row {
  name: string;
  value: number | null | undefined;
  color: string;
  unit?: string;
}

/**
 * Shared tooltip body. Values lead (strong ink), series names follow (secondary);
 * series are keyed with a short line stroke, not a box. Text is rendered by React (escaped).
 */
export function TooltipBody({ title, rows }: { title?: string; rows: Row[] }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white/95 px-3 py-2 text-xs shadow-raised backdrop-blur">
      {title && <p className="mb-1 font-medium text-slate-500">{title}</p>}
      <ul className="space-y-0.5">
        {rows.map((r) => (
          <li key={r.name} className="flex items-center gap-2">
            <span className="inline-block h-0.5 w-3 rounded-full" style={{ backgroundColor: r.color }} aria-hidden />
            <span className="font-semibold tabular-nums text-slate-900">
              {r.value === null || r.value === undefined ? '—' : nf.format(r.value)}
              {r.unit && r.value != null ? ` ${r.unit}` : ''}
            </span>
            <span className="text-slate-500">{r.name}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
