import { useState, type ReactNode } from 'react';
import { BarChart3, Table2 } from 'lucide-react';
import { Card } from '../ui/Card';

export interface TableView {
  columns: string[];
  rows: (string | number)[][];
}

/**
 * Card for one chart with its table-view twin (the accessible equivalent: every value is
 * reachable without hovering). `busy` dims the previous render during refetch — no skeleton flash.
 */
export function ChartCard({
  title,
  description,
  table,
  busy,
  children,
}: {
  title: string;
  description?: string;
  table: TableView;
  busy?: boolean;
  children: ReactNode;
}) {
  const [asTable, setAsTable] = useState(false);
  return (
    <Card className="flex flex-col">
      <div className="flex items-start justify-between gap-3 px-5 pt-4.5">
        <div>
          <h2 className="text-[15px] font-semibold text-navy-900">{title}</h2>
          {description && <p className="mt-0.5 text-[13px] text-slate-500">{description}</p>}
        </div>
        <button
          type="button"
          onClick={() => setAsTable((v) => !v)}
          className="inline-flex shrink-0 items-center gap-1 rounded-md border border-slate-200 px-2 py-1 text-xs font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
          aria-pressed={asTable}
        >
          {asTable ? <BarChart3 className="size-3.5" aria-hidden /> : <Table2 className="size-3.5" aria-hidden />}
          {asTable ? 'Chart' : 'Table'}
        </button>
      </div>
      <div className={`flex-1 px-3 pb-4 pt-2 transition-opacity ${busy ? 'opacity-50' : ''}`}>
        {asTable ? (
          <div className="relative overflow-x-auto px-2">
            <table className="w-full text-left text-sm">
              <thead className="type-label text-slate-500">
                <tr>{table.columns.map((c) => <th key={c} scope="col" className="py-2 pr-4 font-medium">{c}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-slate-100 tabular-nums">
                {table.rows.map((r, i) => (
                  <tr key={i}>{r.map((v, j) => <td key={j} className="py-1.5 pr-4 text-slate-700">{v}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          children
        )}
      </div>
    </Card>
  );
}
