import { Loader2 } from 'lucide-react';
import clsx from 'clsx';
import { Logo } from '../brand/Logo';

export function Spinner({ className, label }: { className?: string; label?: string }) {
  return (
    <span role="status" className={clsx('inline-flex items-center gap-2 text-sm text-slate-500', className)}>
      <Loader2 className="size-4 animate-spin text-brand-600" aria-hidden />
      {label ?? <span className="sr-only">Loading</span>}
    </span>
  );
}

export function FullPageSpinner({ label }: { label?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-5">
      <Logo />
      <Spinner label={label} />
    </div>
  );
}

/** Shimmering placeholder block for loading layouts (keeps layout stable, no spinner jump). */
export function Skeleton({ className }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={clsx(
        'block animate-shimmer rounded-md bg-[linear-gradient(90deg,var(--color-slate-100)_25%,var(--color-slate-200)_37%,var(--color-slate-100)_63%)] bg-[length:400%_100%]',
        className,
      )}
    />
  );
}

/** Generic loading layout: a header line plus stat tiles and two panels. */
export function PageSkeleton({ label = 'Loading…' }: { label?: string }) {
  return (
    <div role="status" aria-label={label}>
      <span className="sr-only">{label}</span>
      <Skeleton className="h-3 w-28" />
      <Skeleton className="mt-3 h-8 w-64" />
      <Skeleton className="mt-2 h-4 w-80 max-w-full" />
      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }, (_, i) => (
          <Skeleton key={i} className="h-[92px] rounded-xl" />
        ))}
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <Skeleton className="h-72 rounded-xl" />
        <Skeleton className="h-72 rounded-xl" />
      </div>
    </div>
  );
}
