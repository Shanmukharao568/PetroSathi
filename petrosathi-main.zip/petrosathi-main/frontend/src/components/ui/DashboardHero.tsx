import type { ReactNode } from 'react';
import { PlantIllustration } from '../brand/PlantIllustration';

/**
 * Dashboard welcome banner: dark petrol surface with a panning blueprint grid, drifting light
 * and the animated refinery illustration. Same props as PageHeader so dashboards can swap it in.
 */
export function DashboardHero({
  title,
  description,
  actions,
  eyebrow,
  children,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
  eyebrow?: ReactNode;
  /** Optional strip under the text (e.g. quick facts). */
  children?: ReactNode;
}) {
  return (
    <section className="relative isolate mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-navy-800 via-navy-900 to-navy-950 text-white shadow-[0_24px_48px_-24px_rgb(7_17_19/0.6)] ring-1 ring-white/[0.06]">
      <div aria-hidden className="bg-blueprint-live absolute inset-0 -z-10 [mask-image:linear-gradient(to_right,black,transparent_85%)]" />
      <div aria-hidden className="absolute -left-24 -top-32 -z-10 size-96 animate-drift rounded-full bg-brand-500/30 blur-[90px]" />
      <div aria-hidden className="absolute -bottom-40 right-10 -z-10 size-96 animate-drift rounded-full bg-signal-500/15 blur-[100px] [animation-delay:-7s]" />
      <div aria-hidden className="absolute right-1/3 top-0 -z-10 size-72 animate-drift rounded-full bg-sky-400/10 blur-[90px] [animation-delay:-12s]" />

      {/* Illustration sits on the right and fades into the text side. */}
      <PlantIllustration
        tone="dark"
        className="pointer-events-none absolute bottom-0 right-0 -z-10 h-full w-auto max-w-none opacity-90 [mask-image:linear-gradient(to_right,transparent,black_35%)] max-md:opacity-40"
      />

      <div className="stagger relative flex min-h-[200px] flex-col justify-center gap-4 px-6 py-7 sm:px-9 sm:py-9 md:max-w-[58%] [--stagger-step:90ms]">
        {eyebrow && (
          <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-3 py-1 font-mono text-[11px] uppercase tracking-[0.14em] text-signal-300 backdrop-blur">
            <span className="relative flex size-1.5" aria-hidden>
              <span className="absolute inset-0 animate-ping rounded-full bg-signal-400" />
              <span className="relative size-1.5 rounded-full bg-signal-400" />
            </span>
            {eyebrow}
          </p>
        )}
        <h1 className="type-display text-[28px] font-bold leading-[1.1] sm:text-[36px]">
          <span className="text-gradient-signal">{title}</span>
        </h1>
        {description && <p className="max-w-xl text-[15px] leading-relaxed text-slate-300">{description}</p>}
        {actions && (
          <div className="flex flex-wrap items-center gap-2 [&_a]:text-signal-300 [&_a:hover]:text-signal-100">{actions}</div>
        )}
        {children}
      </div>
    </section>
  );
}
