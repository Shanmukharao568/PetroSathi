import clsx from 'clsx';

/** Shared field chrome for inputs, selects and textareas. */
export const fieldClass = (error?: string) =>
  clsx(
    'block w-full rounded-lg border bg-white/90 text-sm text-slate-900 shadow-field placeholder:text-slate-400',
    'transition-[border-color,box-shadow,background-color] duration-200',
    'focus:border-brand-500 focus:bg-white focus:shadow-[0_8px_22px_-14px_rgb(21_108_90/0.55)] focus:ring-4 focus:ring-brand-500/15 focus:outline-none',
    'disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500',
    error ? 'border-red-400 hover:border-red-500' : 'border-slate-300 hover:border-slate-400',
  );

export const labelClass = 'block text-[13px] font-semibold text-slate-700';

/** Text link used in card headers ("All tickets →"). */
export const cardLinkClass = (extra?: string) =>
  clsx(
    'group inline-flex items-center gap-1 rounded-md text-[13px] font-semibold text-brand-700 transition-colors hover:text-brand-600',
    extra,
  );

/** Segmented-control look shared by the tablists across the app. */
export const segmentGroupClass =
  'inline-flex max-w-full overflow-x-auto rounded-lg border border-slate-200 bg-slate-100/80 p-1 shadow-field';

export const segmentClass = (active: boolean) =>
  clsx(
    'inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-md px-3 py-1.5 text-[13px] font-semibold transition-all duration-150 disabled:cursor-not-allowed disabled:opacity-50',
    active
      ? 'bg-white text-navy-900 shadow-[0_1px_2px_rgb(16_34_40/0.08),0_0_0_1px_rgb(16_34_40/0.04)]'
      : 'text-slate-500 hover:text-slate-900',
  );

/** Arrow that nudges right when its `group` parent is hovered. */
export const nudgeArrowClass = 'size-4 transition-transform duration-150 group-hover:translate-x-0.5';
