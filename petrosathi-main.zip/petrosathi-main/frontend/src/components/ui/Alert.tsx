import type { ReactNode } from 'react';
import { AlertCircle, CheckCircle2, Info, TriangleAlert } from 'lucide-react';
import clsx from 'clsx';

type Tone = 'error' | 'success' | 'info' | 'warning';

const styles: Record<Tone, { box: string; icon: string; Icon: typeof Info }> = {
  error: { box: 'bg-red-50/80 text-red-800 border-red-200 before:bg-red-500', icon: 'text-red-600', Icon: AlertCircle },
  success: { box: 'bg-emerald-50/80 text-emerald-900 border-emerald-200 before:bg-emerald-500', icon: 'text-emerald-600', Icon: CheckCircle2 },
  info: { box: 'bg-sky-50/80 text-sky-900 border-sky-200 before:bg-sky-500', icon: 'text-sky-600', Icon: Info },
  warning: { box: 'bg-amber-50/80 text-amber-900 border-amber-200 before:bg-signal-500', icon: 'text-amber-600', Icon: TriangleAlert },
};

export function Alert({ tone = 'info', children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  const { box, icon, Icon } = styles[tone];
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={clsx(
        'relative flex gap-2.5 overflow-hidden rounded-lg border py-3 pl-4 pr-3 text-sm leading-snug',
        'before:absolute before:inset-y-0 before:left-0 before:w-[3px]',
        box,
        className,
      )}
    >
      <Icon className={clsx('mt-px size-4 shrink-0', icon)} aria-hidden />
      <div className="min-w-0">{children}</div>
    </div>
  );
}
