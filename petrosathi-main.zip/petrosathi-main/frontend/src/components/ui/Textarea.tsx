import { forwardRef, useId, type TextareaHTMLAttributes } from 'react';
import clsx from 'clsx';
import { FieldError } from './Input';
import { fieldClass, labelClass } from './styles';

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { label, error, hint, className, id, rows = 4, ...rest },
  ref,
) {
  const autoId = useId();
  const tid = id ?? autoId;
  return (
    <div className="space-y-1.5">
      {label && (
        <label htmlFor={tid} className={labelClass}>
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={tid}
        rows={rows}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${tid}-error` : hint ? `${tid}-hint` : undefined}
        className={clsx(fieldClass(error), 'px-3 py-2.5 leading-relaxed', className)}
        {...rest}
      />
      {error ? (
        <FieldError id={`${tid}-error`}>{error}</FieldError>
      ) : hint ? (
        <p id={`${tid}-hint`} className="text-[13px] text-slate-500">{hint}</p>
      ) : null}
    </div>
  );
});
