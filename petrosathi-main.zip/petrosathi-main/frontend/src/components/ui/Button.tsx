import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { Loader2 } from 'lucide-react';
import clsx from 'clsx';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}

const variants: Record<Variant, string> = {
  primary:
    'sheen bg-gradient-to-b from-brand-500 to-brand-700 text-white shadow-button hover:from-brand-600 hover:to-brand-800 hover:shadow-[0_1px_0_rgb(255_255_255/0.18)_inset,0_6px_16px_-6px_rgb(16_88_74/0.6)] active:to-brand-900 disabled:from-brand-600/55 disabled:to-brand-600/55 disabled:shadow-none',
  secondary:
    'bg-white text-slate-800 border border-slate-300 shadow-[0_1px_2px_rgb(16_34_40/0.06)] hover:border-slate-400 hover:bg-slate-50 active:bg-slate-100 disabled:text-slate-400 disabled:hover:border-slate-300 disabled:hover:bg-white',
  ghost: 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900 active:bg-slate-200 disabled:text-slate-400',
  danger:
    'sheen bg-gradient-to-b from-red-500 to-red-700 text-white shadow-button hover:from-red-600 hover:to-red-800 active:to-red-900 disabled:from-red-600/55 disabled:to-red-600/55 disabled:shadow-none',
};

const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-[13px] gap-1.5 rounded-md',
  md: 'h-10 px-4 text-sm gap-2 rounded-lg',
  lg: 'h-12 px-6 text-[15px] gap-2 rounded-lg',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', loading = false, disabled, className, children, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={clsx(
        'inline-flex select-none items-center justify-center whitespace-nowrap font-semibold tracking-[-0.005em]',
        'transition-[background-color,border-color,color,box-shadow,transform,--tw-gradient-from,--tw-gradient-to] duration-200 ease-out',
        'enabled:hover:-translate-y-px enabled:active:translate-y-0 enabled:active:scale-[0.98] disabled:cursor-not-allowed',
        variants[variant],
        sizes[size],
        className,
      )}
      {...rest}
    >
      {loading && <Loader2 className="size-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
});
