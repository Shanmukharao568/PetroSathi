import { useRef, type ClipboardEvent, type KeyboardEvent } from 'react';
import clsx from 'clsx';

/**
 * Segmented one-time-code field: one box per digit, auto-advance, Backspace/arrow navigation
 * and paste of the whole code into any box. `onComplete` fires when every box is filled.
 */
export function OtpInput({
  value,
  onChange,
  onComplete,
  length = 6,
  disabled,
  invalid,
  autoFocus,
}: {
  value: string;
  onChange: (v: string) => void;
  onComplete?: (v: string) => void;
  length?: number;
  disabled?: boolean;
  invalid?: boolean;
  autoFocus?: boolean;
}) {
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const digits = Array.from({ length }, (_, i) => value[i] ?? '');

  const focus = (i: number) => refs.current[Math.max(0, Math.min(length - 1, i))]?.focus();

  const commit = (next: string) => {
    const clean = next.replace(/\D/g, '').slice(0, length);
    onChange(clean);
    if (clean.length === length) onComplete?.(clean);
  };

  const setAt = (i: number, d: string) => {
    const arr = digits.slice();
    arr[i] = d;
    // Keep the code contiguous: typing into a later box fills the first gap.
    commit(arr.join(''));
  };

  const onInput = (i: number, raw: string) => {
    const d = raw.replace(/\D/g, '');
    if (!d) return;
    if (d.length > 1) {
      // Autofill / fast typing can deliver several digits at once.
      commit((value.slice(0, i) + d).slice(0, length));
      focus(i + d.length);
      return;
    }
    setAt(i, d);
    focus(i + 1);
  };

  const onKeyDown = (i: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      if (digits[i]) setAt(i, '');
      else if (i > 0) {
        setAt(i - 1, '');
        focus(i - 1);
      }
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      focus(i - 1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      focus(i + 1);
    }
  };

  const onPaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const d = e.clipboardData.getData('text').replace(/\D/g, '');
    if (!d) return;
    e.preventDefault();
    commit(d);
    focus(d.length);
  };

  return (
    <div className="flex justify-center gap-2 sm:gap-2.5" role="group" aria-label={`${length}-digit verification code`}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
          value={d}
          onChange={(e) => onInput(i, e.target.value)}
          onKeyDown={(e) => onKeyDown(i, e)}
          onPaste={onPaste}
          onFocus={(e) => e.target.select()}
          inputMode="numeric"
          autoComplete={i === 0 ? 'one-time-code' : 'off'}
          pattern="[0-9]*"
          maxLength={length}
          disabled={disabled}
          autoFocus={autoFocus && i === 0}
          aria-label={`Digit ${i + 1}`}
          aria-invalid={invalid || undefined}
          className={clsx(
            'size-12 rounded-xl border bg-white/90 text-center font-mono text-[22px] font-bold text-navy-900 shadow-field transition-[border-color,box-shadow,transform] duration-200 sm:size-14 sm:text-2xl',
            'focus:-translate-y-0.5 focus:border-brand-500 focus:bg-white focus:shadow-[0_10px_24px_-14px_rgb(21_108_90/0.6)] focus:ring-4 focus:ring-brand-500/15 focus:outline-none',
            'disabled:cursor-not-allowed disabled:opacity-60',
            invalid ? 'animate-[shake_380ms_ease-in-out] border-red-400' : d ? 'border-brand-400' : 'border-slate-300',
          )}
        />
      ))}
    </div>
  );
}
