import type { ReactNode } from 'react';
import clsx from 'clsx';

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div
      className={clsx(
        'spotlight rounded-2xl border border-white/70 bg-white/80 shadow-card backdrop-blur-xl transition-[box-shadow,border-color] duration-300 hover:border-slate-200 hover:shadow-raised',
        className,
      )}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  description,
  actions,
  icon,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  /** Optional lucide icon element shown in a small tile before the title. */
  icon?: ReactNode;
}) {
  return (
    <div className="group/header flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 px-5 py-4">
      <div className="flex min-w-0 items-start gap-3">
        {icon && (
          <span
            className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-brand-50 to-slate-100 text-brand-700 ring-1 ring-inset ring-brand-100 transition-transform duration-300 ease-[var(--ease-spring)] [&>svg]:size-4 [.spotlight:hover_&]:-rotate-6 [.spotlight:hover_&]:scale-110"
            aria-hidden
          >
            {icon}
          </span>
        )}
        <div className="min-w-0">
          <h2 className="text-[15px] font-semibold text-navy-900">{title}</h2>
          {description && <p className="mt-0.5 text-[13px] leading-snug text-slate-500">{description}</p>}
        </div>
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
  eyebrow,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
  /** Small uppercase context line above the title (section or date). */
  eyebrow?: ReactNode;
}) {
  return (
    <div className="stagger mb-8 flex flex-wrap items-end justify-between gap-4 [--stagger-step:70ms]">
      <div className="min-w-0">
        {eyebrow && (
          <p className="type-label mb-2.5 flex items-center gap-2 text-slate-500">
            <span className="relative flex size-2" aria-hidden>
              <span className="absolute inset-0 animate-ping rounded-full bg-signal-400/60 [animation-duration:2.4s]" />
              <span className="relative size-2 rounded-full bg-signal-400" />
            </span>
            {eyebrow}
          </p>
        )}
        <h1 className="type-display text-gradient-ink pb-0.5 text-[26px] font-bold leading-tight sm:text-[32px]">{title}</h1>
        {description && <p className="mt-1.5 max-w-2xl text-[15px] text-slate-500">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
