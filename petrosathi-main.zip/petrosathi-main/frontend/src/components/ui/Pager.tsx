import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './Button';
import type { Pagination } from '../../lib/api';

export function Pager({ pagination, noun, onPage }: { pagination: Pagination | null; noun: string; onPage: (p: number) => void }) {
  if (!pagination || pagination.total === 0) return null;
  const { page, totalPages, total } = pagination;
  return (
    <div className="flex items-center justify-between gap-3 border-t border-slate-100 px-4 py-3 text-[13px] text-slate-500">
      <span>
        <span className="font-semibold tabular-nums text-slate-800">{total}</span> {noun}
        {total === 1 ? '' : 's'}
        <span className="mx-1.5 text-slate-300">/</span>
        page <span className="tabular-nums text-slate-800">{page}</span> of <span className="tabular-nums">{totalPages}</span>
      </span>
      <div className="flex gap-1.5">
        <Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page" className="w-8 px-0">
          <ChevronLeft className="size-4" />
        </Button>
        <Button size="sm" variant="secondary" disabled={page >= totalPages} onClick={() => onPage(page + 1)} aria-label="Next page" className="w-8 px-0">
          <ChevronRight className="size-4" />
        </Button>
      </div>
    </div>
  );
}
