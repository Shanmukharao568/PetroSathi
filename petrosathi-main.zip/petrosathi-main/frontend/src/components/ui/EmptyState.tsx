import type { ReactNode } from 'react';
import clsx from 'clsx';

/**
 * Considered empty state: icon in a soft tile, a short title and one helpful line.
 * `compact` is for panels inside cards; the default is for full tables.
 */
export function EmptyState({
  icon,
  title,
  children,
  action,
  compact = false,
  className,
}: {
  icon: ReactNode;
  title: string;
  children?: ReactNode;
  action?: ReactNode;
  compact?: boolean;
  className?: string;
}) {
  return (
    <div className={clsx('flex animate-fade-up flex-col items-center text-center', compact ? 'px-5 py-7' : 'px-6 py-12', className)}>
      <span aria-hidden className="relative flex items-center justify-center">
        {/* Soft halo behind the floating icon tile. */}
        <span className={clsx('absolute rounded-full bg-brand-100/60 blur-xl', compact ? 'size-12' : 'size-16')} />
        <span
          className={clsx(
            'relative flex animate-float items-center justify-center rounded-xl bg-gradient-to-b from-white to-slate-50 text-brand-600 ring-1 ring-inset ring-slate-200',
            'shadow-[0_1px_0_white_inset,0_6px_14px_-8px_rgb(16_34_40/0.25)]',
            compact ? 'size-10 [&>svg]:size-5' : 'size-12 [&>svg]:size-6',
          )}
        >
          {icon}
        </span>
      </span>
      <p className={clsx('font-semibold text-slate-800', compact ? 'mt-3 text-sm' : 'mt-4 text-[15px]')}>{title}</p>
      {children && <div className="mt-1 max-w-sm text-[13px] leading-relaxed text-slate-500">{children}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
