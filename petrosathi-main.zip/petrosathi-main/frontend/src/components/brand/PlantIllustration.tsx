import clsx from 'clsx';

/**
 * Original, decorative refinery skyline: distillation columns, a flare stack with a live flame,
 * storage tanks, a rocking pump jack, venting steam, beacon lights and pipelines with product
 * flowing through them. Pure SVG + CSS animation (see `.plant-*` in index.css); reduced-motion
 * users get the still picture.
 *
 * `tone="dark"` is for dark petrol surfaces, `tone="light"` for light ones.
 */
export function PlantIllustration({ tone = 'dark', className }: { tone?: 'dark' | 'light'; className?: string }) {
  const dark = tone === 'dark';
  const ink = dark ? '#ffffff' : '#122427';
  const far = dark ? 0.06 : 0.06;
  const mid = dark ? 0.14 : 0.12;
  const near = dark ? 0.26 : 0.2;
  const pipe = dark ? '#4aa08b' : '#23826d';
  const glow = dark ? '#f4b740' : '#e69a10';

  return (
    <svg viewBox="0 0 800 320" className={clsx('block', className)} aria-hidden fill="none" preserveAspectRatio="xMidYMax meet">
      <defs>
        <linearGradient id="pi-flame" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#e69a10" />
          <stop offset="0.55" stopColor="#f8cd6e" />
          <stop offset="1" stopColor="#fff7e0" />
        </linearGradient>
        <radialGradient id="pi-glow">
          <stop offset="0" stopColor={glow} stopOpacity="0.55" />
          <stop offset="1" stopColor={glow} stopOpacity="0" />
        </radialGradient>
        <linearGradient id="pi-ground" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={ink} stopOpacity={mid} />
          <stop offset="1" stopColor={ink} stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Stars over the plant (dark tone only). */}
      {dark &&
        [
          [60, 40, 0], [180, 22, 0.6], [260, 70, 1.4], [380, 30, 0.3], [470, 58, 2.1], [560, 18, 1.1], [690, 46, 0.8], [760, 24, 1.9],
        ].map(([x, y, d]) => <circle key={`${x}`} className="plant-star" cx={x} cy={y} r="1.4" fill="#fff" style={{ animationDelay: `${d}s` }} />)}

      {/* Distant skyline. */}
      <g fill={ink} fillOpacity={far}>
        <rect x="20" y="210" width="60" height="90" />
        <rect x="90" y="190" width="26" height="110" />
        <rect x="235" y="200" width="44" height="100" />
        <rect x="350" y="215" width="70" height="85" />
        <rect x="540" y="196" width="34" height="104" />
        <rect x="640" y="222" width="80" height="78" />
        <rect x="730" y="205" width="50" height="95" />
      </g>

      {/* Distillation columns with platforms and ladders. */}
      <g fill={ink} fillOpacity={near}>
        <rect x="118" y="96" width="36" height="204" rx="18" />
        <rect x="170" y="140" width="26" height="160" rx="13" />
        <rect x="206" y="176" width="18" height="124" rx="9" />
      </g>
      <g stroke={ink} strokeOpacity={mid + 0.1} strokeWidth="2">
        {[130, 168, 206, 244].map((y) => (
          <line key={y} x1="112" y1={y} x2="160" y2={y} />
        ))}
        {[176, 214, 252].map((y) => (
          <line key={y} x1="165" y1={y} x2="201" y2={y} />
        ))}
        <line x1="157" y1="110" x2="157" y2="300" strokeDasharray="2 5" />
      </g>
      <circle className="plant-beacon" cx="136" cy="92" r="3" fill="#ef4444" />
      <circle className="plant-beacon" cx="183" cy="136" r="2.5" fill="#ef4444" style={{ animationDelay: '0.7s' }} />

      {/* Flare stack with live flame and glow. */}
      <rect x="296" y="70" width="8" height="230" fill={ink} fillOpacity={near} />
      <g stroke={ink} strokeOpacity={mid} strokeWidth="1.5">
        <line x1="300" y1="120" x2="270" y2="300" />
        <line x1="300" y1="120" x2="330" y2="300" />
      </g>
      <circle cx="300" cy="50" r="34" fill="url(#pi-glow)" className="animate-blink" style={{ animationDuration: '2.4s' }} />
      <path className="plant-flame" d="M300 30 C 292 44, 290 56, 300 70 C 310 56, 308 44, 300 30 Z" fill="url(#pi-flame)" />
      <path className="plant-flame" d="M300 44 C 296 52, 296 60, 300 68 C 304 60, 304 52, 300 44 Z" fill="#fff" fillOpacity="0.8" style={{ animationDuration: '0.6s' }} />

      {/* Storage tanks. */}
      <g fill={ink} fillOpacity={near}>
        <path d="M400 236 a46 10 0 0 1 92 0 v64 h-92 Z" />
        <path d="M506 250 a34 8 0 0 1 68 0 v50 h-68 Z" />
      </g>
      <g stroke={ink} strokeOpacity={mid} strokeWidth="1.5">
        <path d="M400 258 h92 M400 280 h92 M506 270 h68" />
      </g>

      {/* Process chimney venting steam. */}
      <rect x="608" y="150" width="16" height="150" fill={ink} fillOpacity={near} />
      {[0, 1.4, 2.8].map((d) => (
        <circle key={d} className="plant-steam" cx="616" cy="144" r="9" fill={ink} fillOpacity={dark ? 0.22 : 0.14} style={{ animationDelay: `${d}s` }} />
      ))}
      <circle className="plant-beacon" cx="616" cy="148" r="2.5" fill="#ef4444" style={{ animationDelay: '0.3s' }} />

      {/* Pump jack: rocking walking beam on an A-frame. */}
      <g fill={ink} fillOpacity={near}>
        <path d="M690 300 L708 236 L726 300 Z" />
        <rect x="738" y="276" width="34" height="24" rx="3" />
      </g>
      <g className="plant-beam">
        <rect x="664" y="230" width="90" height="9" rx="4.5" fill={ink} fillOpacity={near + 0.08} />
        <path d="M664 226 q-14 8 0 18 Z" fill={ink} fillOpacity={near + 0.08} />
      </g>
      <circle cx="708" cy="234" r="4" fill={glow} />

      {/* Pipe rack with product flowing through. */}
      <g strokeLinecap="round">
        <path d="M60 268 H760" stroke={ink} strokeOpacity={mid} strokeWidth="6" />
        <path d="M60 284 H760" stroke={ink} strokeOpacity={mid} strokeWidth="6" />
        <path className="plant-flow" d="M60 268 H760" stroke={pipe} strokeWidth="2.5" />
        <path className="plant-flow" d="M760 284 H60" stroke={glow} strokeOpacity="0.85" strokeWidth="2.5" style={{ animationDuration: '2.2s' }} />
        <path d="M137 268 V300 M300 268 V300 M446 268 V300 M616 268 V300" stroke={ink} strokeOpacity={mid} strokeWidth="3" />
      </g>

      {/* Ground. */}
      <rect x="0" y="298" width="800" height="22" fill="url(#pi-ground)" />
      <line x1="0" y1="300" x2="800" y2="300" stroke={ink} strokeOpacity={mid + 0.08} strokeWidth="1.5" />
    </svg>
  );
}
