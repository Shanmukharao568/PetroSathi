import clsx from 'clsx';

/** Brand mark: an amber oil drop carrying a three-bar voice waveform, on petrol ink. */
export function LogoMark({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  const ink = inverted ? '#122427' : '#0c1a1d';
  return (
    <svg viewBox="0 0 32 32" className={clsx('shrink-0', className)} aria-hidden>
      <rect width="32" height="32" rx="8" fill={ink} />
      {inverted && <rect x="0.5" y="0.5" width="31" height="31" rx="7.5" fill="none" stroke="rgb(255 255 255 / 0.12)" />}
      <path d="M16 5.5c-4 5-6.8 8.9-6.8 12.4a6.8 6.8 0 0 0 13.6 0c0-3.5-2.8-7.4-6.8-12.4Z" fill="#f4b740" />
      <g stroke={ink} strokeWidth="1.8" strokeLinecap="round">
        <path d="M13 17.5v3" />
        <path d="M16 15.5v7" />
        <path d="M19 17.5v3" />
      </g>
    </svg>
  );
}

export function Logo({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  return (
    <div className={clsx('flex items-center gap-2.5', className)}>
      <LogoMark className="size-9" inverted={inverted} />
      <div className="leading-none">
        <div className={clsx('type-display text-[19px] font-bold', inverted ? 'text-white' : 'text-navy-900')}>
          Petro<span className={inverted ? 'text-signal-400' : 'text-brand-600'}>Sathi</span>
        </div>
        <div className={clsx('mt-1 whitespace-nowrap font-mono text-[10px] font-medium uppercase tracking-[0.14em]', inverted ? 'text-slate-400' : 'text-slate-500')}>
          Maintenance · voice
        </div>
      </div>
    </div>
  );
}
