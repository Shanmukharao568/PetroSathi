import { useState } from 'react';
import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { OtpInput } from '../components/ui/OtpInput';

function Harness({ onComplete }: { onComplete: (v: string) => void }) {
  const [v, setV] = useState('');
  return (
    <>
      <OtpInput value={v} onChange={setV} onComplete={onComplete} />
      <output data-testid="value">{v}</output>
    </>
  );
}

describe('OtpInput', () => {
  it('advances box by box and completes after the sixth digit', async () => {
    const done = vi.fn();
    render(<Harness onComplete={done} />);
    await userEvent.click(screen.getByLabelText('Digit 1'));
    await userEvent.keyboard('12345');
    expect(screen.getByTestId('value').textContent).toBe('12345');
    expect(done).not.toHaveBeenCalled();
    await userEvent.keyboard('6');
    expect(done).toHaveBeenCalledWith('123456');
  });

  it('ignores letters, and Backspace steps back', async () => {
    render(<Harness onComplete={vi.fn()} />);
    await userEvent.click(screen.getByLabelText('Digit 1'));
    await userEvent.keyboard('1a2');
    expect(screen.getByTestId('value').textContent).toBe('12');
    // From the empty third box, Backspace removes the previous digit.
    await userEvent.keyboard('{Backspace}');
    expect(screen.getByTestId('value').textContent).toBe('1');
    await userEvent.keyboard('{Backspace}');
    expect(screen.getByTestId('value').textContent).toBe('');
  });

  it('fills every box from a pasted code, even with spaces', () => {
    const done = vi.fn();
    render(<Harness onComplete={done} />);
    fireEvent.paste(screen.getByLabelText('Digit 1'), { clipboardData: { getData: () => '987 654' } });
    expect(screen.getByTestId('value').textContent).toBe('987654');
    expect(done).toHaveBeenCalledWith('987654');
  });
});
