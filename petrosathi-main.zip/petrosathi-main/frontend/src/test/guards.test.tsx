import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { RequireAuth, RequireRole } from '../routes/guards';
import { useAuthStore } from '../store/authStore';
import type { Role } from '../types/auth';

function renderAt(path: string) {
  const router = createMemoryRouter(
    [
      { path: '/login', element: <p>login page</p> },
      { path: '/change-password', element: <p>change password page</p> },
      {
        element: <RequireAuth />,
        children: [
          { path: '/admin/users', element: <RequireRole roles={['admin']}><p>admin users</p></RequireRole> },
          { path: '/operator/dashboard', element: <RequireRole roles={['operator']}><p>operator home</p></RequireRole> },
          { path: '/engineer/dashboard', element: <RequireRole roles={['engineer']}><p>engineer home</p></RequireRole> },
        ],
      },
    ],
    { initialEntries: [path] },
  );
  render(<RouterProvider router={router} />);
  return router;
}

const signIn = (role: Role, mustChangePassword = false) =>
  useAuthStore.setState({
    token: 'token',
    status: 'ready',
    user: { id: 'u', name: 'U', email: 'u@example.test', role, preferredLanguage: 'en-IN', isActive: true, mustChangePassword, lastLoginAt: null, passwordChangedAt: null, createdAt: '', updatedAt: '' },
  });

describe('route guards (navigation only — the API enforces roles itself)', () => {
  it('sends anonymous users to login', () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    renderAt('/admin/users');
    expect(screen.getByText('login page')).toBeInTheDocument();
  });

  it('redirects an operator away from admin pages to their own dashboard', () => {
    signIn('operator');
    const router = renderAt('/admin/users');
    expect(router.state.location.pathname).toBe('/operator/dashboard');
    expect(screen.getByText('operator home')).toBeInTheDocument();
  });

  it('redirects an engineer away from operator pages', () => {
    signIn('engineer');
    renderAt('/operator/dashboard');
    expect(screen.getByText('engineer home')).toBeInTheDocument();
  });

  it('lets an admin through to admin pages', () => {
    signIn('admin');
    renderAt('/admin/users');
    expect(screen.getByText('admin users')).toBeInTheDocument();
  });

  it('forces a password change before anything else', () => {
    signIn('admin', true);
    renderAt('/admin/users');
    expect(screen.getByText('change password page')).toBeInTheDocument();
  });
});
