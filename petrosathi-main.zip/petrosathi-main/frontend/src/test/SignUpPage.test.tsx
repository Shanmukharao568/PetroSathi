import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AxiosError, AxiosHeaders } from 'axios';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { SignUpPage } from '../pages/SignUpPage';
import { api } from '../lib/api';
import { useAuthStore } from '../store/authStore';

function renderSignUp() {
  const router = createMemoryRouter(
    [
      { path: '/signup', element: <SignUpPage /> },
      { path: '/verify-email', element: <p>verify page</p> },
      { path: '/login', element: <p>login page</p> },
    ],
    { initialEntries: ['/signup'] },
  );
  render(<RouterProvider router={router} />);
  return router;
}

async function fill(password: string, confirm = password) {
  await userEvent.type(screen.getByLabelText('Full name'), 'Lakshmi Reddy');
  await userEvent.type(screen.getByLabelText('Work email'), 'lakshmi@example.test');
  await userEvent.type(screen.getByLabelText('Password'), password);
  await userEvent.type(screen.getByLabelText('Confirm password'), confirm);
}

describe('SignUpPage', () => {
  it('checks the password rules and the confirmation before calling the API', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    const post = vi.spyOn(api, 'post');
    renderSignUp();
    await fill('weakpass', 'different');
    await userEvent.click(screen.getByRole('button', { name: 'Create account' }));
    expect(await screen.findByText('Password does not meet the rules below')).toBeInTheDocument();
    expect(screen.getByText('Passwords do not match')).toBeInTheDocument();
    expect(screen.getByText(/At least 10 characters/).textContent).toContain('(not met)');
    expect(post).not.toHaveBeenCalled();
  });

  it('creates the account (never sending a role) and goes to email verification', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    const user = { id: 'u9', name: 'Lakshmi Reddy', email: 'lakshmi@example.test', role: 'operator', preferredLanguage: 'en-IN', isActive: true, mustChangePassword: false, emailVerificationRequired: true, lastLoginAt: null, passwordChangedAt: null, createdAt: '', updatedAt: '' };
    const post = vi.spyOn(api, 'post').mockResolvedValue({ data: { success: true, data: { token: 't', expiresAt: '', user } } });
    const router = renderSignUp();
    await fill('Correct-Horse-42');
    await userEvent.click(screen.getByRole('button', { name: 'Create account' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/verify-email'));
    const body = post.mock.calls[0]![1] as Record<string, unknown>;
    expect(body).toEqual({ name: 'Lakshmi Reddy', email: 'lakshmi@example.test', password: 'Correct-Horse-42', preferredLanguage: 'en-IN' });
    expect(useAuthStore.getState().user?.emailVerificationRequired).toBe(true);
  });

  it('offers sign-in when the email is already registered', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    const body = { success: false, error: { code: 'CONFLICT', message: 'An account with this email already exists. Sign in instead.' } };
    vi.spyOn(api, 'post').mockRejectedValue(
      new AxiosError('409', 'ERR_BAD_REQUEST', undefined, undefined, { status: 409, data: body, statusText: '', headers: {}, config: { headers: new AxiosHeaders() } }),
    );
    renderSignUp();
    await fill('Correct-Horse-42');
    await userEvent.click(screen.getByRole('button', { name: 'Create account' }));
    expect(await screen.findByRole('link', { name: 'Go to sign in' })).toBeInTheDocument();
  });
});
