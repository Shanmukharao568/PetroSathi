import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChartCard } from '../components/charts/ChartCard';
import { HBarChart } from '../components/charts/HBarChart';
import { rangeForPreset } from '../features/analytics/DateRangeFilter';

describe('ChartCard table view (every chart has an accessible table twin)', () => {
  it('toggles between chart and a table with the same values', async () => {
    render(
      <ChartCard title="Tickets by severity" table={{ columns: ['Severity', 'Tickets'], rows: [['Critical', 4], ['High', 9]] }}>
        <p>chart body</p>
      </ChartCard>,
    );
    expect(screen.getByText('chart body')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Table' }));
    expect(screen.queryByText('chart body')).not.toBeInTheDocument();
    expect(screen.getByRole('cell', { name: 'Critical' })).toBeInTheDocument();
    expect(screen.getByRole('cell', { name: '9' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Chart' }));
    expect(screen.getByText('chart body')).toBeInTheDocument();
  });
});

describe('HBarChart', () => {
  it('says so instead of drawing an empty chart', () => {
    render(<HBarChart data={[{ label: 'Open', value: 0 }]} emptyText="No tickets in this period." />);
    expect(screen.getByText('No tickets in this period.')).toBeInTheDocument();
  });
});

describe('date range presets', () => {
  it('computes inclusive local-day ranges', () => {
    const now = new Date(2026, 10, 8, 15, 0); // 8 Nov 2026
    expect(rangeForPreset('30d', now)).toEqual({ from: '2026-10-10', to: '2026-11-08' });
    expect(rangeForPreset('12m', now)).toEqual({ from: '2025-12-01', to: '2026-11-08' });
    expect(rangeForPreset('6m', now)).toEqual({ from: '2026-06-01', to: '2026-11-08' });
  });
});
