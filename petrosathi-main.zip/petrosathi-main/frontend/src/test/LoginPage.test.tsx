import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AxiosError, AxiosHeaders } from 'axios';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { LoginPage } from '../pages/LoginPage';
import { api } from '../lib/api';
import { useAuthStore } from '../store/authStore';

function renderLogin() {
  const router = createMemoryRouter(
    [
      { path: '/login', element: <LoginPage /> },
      { path: '/change-password', element: <p>change password page</p> },
      { path: '/operator/dashboard', element: <p>operator home</p> },
      { path: '/', element: <p>root</p> },
    ],
    { initialEntries: ['/login'] },
  );
  render(<RouterProvider router={router} />);
  return router;
}

const user = (over: Record<string, unknown> = {}) => ({
  id: 'u1', name: 'Ravi Kumar', email: 'ravi@example.test', role: 'operator', preferredLanguage: 'hi-IN',
  isActive: true, mustChangePassword: false, lastLoginAt: null, passwordChangedAt: null, createdAt: '', updatedAt: '', ...over,
});

describe('LoginPage', () => {
  it('validates fields before calling the API', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    const post = vi.spyOn(api, 'post');
    renderLogin();
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Enter a valid work email')).toBeInTheDocument();
    expect(screen.getByText('Password is required')).toBeInTheDocument();
    expect(post).not.toHaveBeenCalled();
  });

  it('shows the server error message on invalid credentials', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    const body = { success: false, error: { code: 'INVALID_CREDENTIALS', message: 'Invalid email or password' } };
    vi.spyOn(api, 'post').mockRejectedValue(
      new AxiosError('401', 'ERR_BAD_REQUEST', undefined, undefined, { status: 401, data: body, statusText: '', headers: {}, config: { headers: new AxiosHeaders() } }),
    );
    renderLogin();
    await userEvent.type(screen.getByLabelText('Work email'), 'ravi@example.test');
    await userEvent.type(screen.getByLabelText('Password'), 'wrong-password');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Invalid email or password');
  });

  it('sends users with a temporary password to the forced change screen', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    vi.spyOn(api, 'post').mockResolvedValue({ data: { success: true, data: { token: 't', expiresAt: '', user: user({ mustChangePassword: true }) } } });
    const router = renderLogin();
    await userEvent.type(screen.getByLabelText('Work email'), 'ravi@example.test');
    await userEvent.type(screen.getByLabelText('Password'), 'Temp-Pass-123');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/change-password'));
  });

  it('sends a signed-in operator to the operator dashboard', async () => {
    useAuthStore.setState({ token: null, user: null, status: 'ready' });
    vi.spyOn(api, 'post').mockResolvedValue({ data: { success: true, data: { token: 't', expiresAt: '', user: user() } } });
    const router = renderLogin();
    await userEvent.type(screen.getByLabelText('Work email'), 'ravi@example.test');
    await userEvent.type(screen.getByLabelText('Password'), 'Good-Pass-123');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/operator/dashboard'));
  });
});
