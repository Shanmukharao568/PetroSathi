import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { StatusActionPanel } from '../features/tickets/StatusActionPanel';
import * as ticketsApi from '../features/tickets/ticketsApi';
import type { Ticket, TicketStatus } from '../types/domain';

function ticket(status: TicketStatus, allowed: TicketStatus[], changeStatus = true): Ticket {
  return {
    id: 't1', ticketNumber: 'TKT-2026-00001', equipmentId: 'e1', equipmentCode: 'P-101', equipment: null,
    reportedBy: { id: 'u1', name: 'Op', email: 'op@example.test', role: 'operator' }, assignedTo: null,
    description: 'Vibration', symptoms: [], category: 'mechanical', severity: 'high', status, language: null, source: 'manual',
    resolution: null, resolvedAt: null, closedAt: null, createdAt: '', updatedAt: '',
    permissions: { view: true, comment: true, accept: false, assign: false, release: false, changeStatus, allowedTransitions: allowed },
  };
}

describe('StatusActionPanel', () => {
  it('offers only the transitions the server allows', () => {
    render(<StatusActionPanel ticket={ticket('OPEN', ['UNDER_INSPECTION', 'IN_PROGRESS'])} onChanged={() => {}} />);
    expect(screen.getByRole('button', { name: 'Start inspection' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Start work' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /resolved|close/i })).not.toBeInTheDocument();
  });

  it('renders nothing when the user may not change status', () => {
    const { container } = render(<StatusActionPanel ticket={ticket('OPEN', [], false)} onChanged={() => {}} />);
    expect(container).toBeEmptyDOMElement();
  });

  it('requires a resolution summary before resolving', async () => {
    const spy = vi.spyOn(ticketsApi, 'changeStatus').mockResolvedValue(ticket('RESOLVED', ['CLOSED']));
    const onChanged = vi.fn();
    render(<StatusActionPanel ticket={ticket('IN_PROGRESS', ['UNDER_INSPECTION', 'RESOLVED'])} onChanged={onChanged} />);
    await userEvent.click(screen.getByRole('button', { name: 'Mark resolved' }));
    const confirm = screen.getByRole('button', { name: 'Confirm' });
    expect(confirm).toBeDisabled();
    await userEvent.type(screen.getByLabelText('Resolution summary (required)'), 'Replaced the bearing');
    expect(confirm).toBeEnabled();
    await userEvent.click(confirm);
    expect(spy).toHaveBeenCalledWith('t1', expect.objectContaining({ status: 'RESOLVED', resolution: expect.objectContaining({ summary: 'Replaced the bearing' }) }));
    expect(onChanged).toHaveBeenCalled();
  });

  it('requires a reason to reopen a resolved ticket', async () => {
    render(<StatusActionPanel ticket={ticket('RESOLVED', ['CLOSED', 'IN_PROGRESS'])} onChanged={() => {}} />);
    await userEvent.click(screen.getByRole('button', { name: 'Reopen' }));
    const confirm = screen.getByRole('button', { name: 'Confirm' });
    expect(confirm).toBeDisabled();
    await userEvent.type(screen.getByLabelText('Reason for reopening (required)'), 'Leak returned');
    expect(confirm).toBeEnabled();
  });
});
