import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import { PushToTalkButton } from '../features/voice/PushToTalkButton';

const base = { level: 0, elapsedMs: 0, maxSeconds: 120 };

describe('PushToTalkButton (push-to-talk only — never always-on)', () => {
  it('starts on press and stops on release (pointer)', () => {
    const onStart = vi.fn();
    const onStop = vi.fn();
    render(<PushToTalkButton phase="idle" {...base} onStart={onStart} onStop={onStop} />);
    const btn = screen.getByRole('button', { name: /push to talk/i });
    fireEvent.pointerDown(btn, { button: 0, pointerId: 1 });
    expect(onStart).toHaveBeenCalledTimes(1);
    expect(onStop).not.toHaveBeenCalled();
    fireEvent.pointerUp(btn, { pointerId: 1 });
    expect(onStop).toHaveBeenCalledTimes(1);
  });

  it('supports hold-to-talk with Space for keyboard users, ignoring key repeat', () => {
    const onStart = vi.fn();
    const onStop = vi.fn();
    render(<PushToTalkButton phase="idle" {...base} onStart={onStart} onStop={onStop} />);
    const btn = screen.getByRole('button', { name: /push to talk/i });
    fireEvent.keyDown(btn, { key: ' ' });
    fireEvent.keyDown(btn, { key: ' ', repeat: true });
    expect(onStart).toHaveBeenCalledTimes(1);
    fireEvent.keyUp(btn, { key: ' ' });
    expect(onStop).toHaveBeenCalledTimes(1);
  });

  it('shows timer, remaining time and an explicit Stop button while recording', () => {
    const onStop = vi.fn();
    render(<PushToTalkButton phase="recording" level={0.5} elapsedMs={65_000} maxSeconds={120} onStart={() => {}} onStop={onStop} />);
    expect(screen.getByText('Release to finish')).toBeInTheDocument();
    expect(screen.getByText(/1:05/)).toBeInTheDocument();
    expect(screen.getByText(/0:55 left/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Stop' }));
    expect(onStop).toHaveBeenCalled();
  });

  it('is disabled while transcribing', () => {
    const onStart = vi.fn();
    render(<PushToTalkButton phase="finishing" {...base} onStart={onStart} onStop={() => {}} />);
    const btn = screen.getByRole('button', { name: /push to talk/i });
    expect(btn).toBeDisabled();
    fireEvent.pointerDown(btn, { button: 0, pointerId: 1 });
    expect(onStart).not.toHaveBeenCalled();
  });
});
