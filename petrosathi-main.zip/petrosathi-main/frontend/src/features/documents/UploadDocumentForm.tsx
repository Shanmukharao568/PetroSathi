import { useRef, useState } from 'react';
import { FileUp } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { equipmentTypeLabel, humanize } from '../../lib/format';
import { EQUIPMENT_TYPES, type EquipmentType } from '../../types/domain';
import { DOCUMENT_TYPES, uploadDocument, type DocumentType } from './documentsApi';

export function UploadDocumentForm({ maxMb, onUploaded }: { maxMb: number; onUploaded: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [documentType, setDocumentType] = useState<DocumentType>('manual');
  const [codes, setCodes] = useState('');
  const [types, setTypes] = useState<EquipmentType[]>([]);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const choose = (f: File | undefined) => {
    setError(null);
    setDone(null);
    if (!f) return;
    if (!f.name.toLowerCase().endsWith('.pdf')) return setError('Choose a PDF file.');
    if (f.size > maxMb * 1024 * 1024) return setError(`The file is larger than ${maxMb} MB.`);
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.pdf$/i, '').replace(/[-_]+/g, ' '));
  };

  const submit = async () => {
    if (!file) return;
    setError(null);
    setProgress(0);
    try {
      const d = await uploadDocument(file, { title: title.trim(), documentType, equipmentCodes: codes, equipmentTypes: types }, setProgress);
      setDone(`"${d.title}" uploaded. Processing has started; the status below updates automatically.`);
      setFile(null);
      setTitle('');
      setCodes('');
      setTypes([]);
      if (inputRef.current) inputRef.current.value = '';
      onUploaded();
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setProgress(null);
    }
  };

  const busy = progress !== null;

  return (
    <div className="space-y-4">
      <label className="flex cursor-pointer items-center gap-3 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50/60 px-4 py-4 hover:border-brand-500">
        <FileUp className="size-6 text-slate-400" aria-hidden />
        <span className="text-sm">
          <span className="font-medium text-slate-800">{file ? file.name : 'Choose an approved PDF'}</span>
          <span className="block text-xs text-slate-500">{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : `Text-based PDF, max ${maxMb} MB. Scanned images are not supported.`}</span>
        </span>
        <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="sr-only" onChange={(e) => choose(e.target.files?.[0])} disabled={busy} />
      </label>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-[minmax(0,1fr)_12rem]">
        <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
        <Select label="Document type" value={documentType} onChange={(e) => setDocumentType(e.target.value as DocumentType)} options={DOCUMENT_TYPES.map((t) => ({ value: t, label: humanize(t) }))} />
      </div>
      <Input label="Equipment tags (optional)" hint="Comma-separated, e.g. P-101, P-102. Must be registered equipment." value={codes} onChange={(e) => setCodes(e.target.value)} />
      <fieldset>
        <legend className="text-sm font-medium text-slate-700">Equipment types (optional)</legend>
        <div className="mt-2 flex flex-wrap gap-2">
          {EQUIPMENT_TYPES.map((t) => (
            <label key={t} className={`cursor-pointer rounded-md px-2.5 py-1 text-xs ring-1 ring-inset ${types.includes(t) ? 'bg-brand-50 text-brand-700 ring-brand-300' : 'text-slate-600 ring-slate-300 hover:bg-slate-50'}`}>
              <input type="checkbox" className="sr-only" checked={types.includes(t)} onChange={(e) => setTypes(e.target.checked ? [...types, t] : types.filter((x) => x !== t))} />
              {equipmentTypeLabel(t)}
            </label>
          ))}
        </div>
      </fieldset>

      {busy && (
        <div className="h-1.5 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuenow={progress ?? 0} aria-valuemin={0} aria-valuemax={100} aria-label="Upload progress">
          <div className="h-full bg-brand-600 transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}
      {error && <Alert tone="error">{error}</Alert>}
      {done && <Alert tone="success">{done}</Alert>}
      <Button onClick={() => void submit()} loading={busy} disabled={!file || title.trim().length < 3}>Upload and process</Button>
      <p className="text-xs text-slate-500">Upload only documents your organisation has approved for maintenance reference.</p>
    </div>
  );
}
