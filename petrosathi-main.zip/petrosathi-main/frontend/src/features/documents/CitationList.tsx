import { useState } from 'react';
import { ExternalLink, FileText } from 'lucide-react';
import { toApiError } from '../../lib/api';
import { openDocument, type Citation } from './documentsApi';

/**
 * Renders retrieved passages with exact citations. Excerpts are reference material shown
 * verbatim; they are not instructions and PetroSathi does not act on them.
 */
export function CitationList({ citations }: { citations: Citation[] }) {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const open = async (c: Citation) => {
    setError(null);
    try {
      await openDocument(c.documentId, c.pageNumber);
    } catch (err) {
      setError(toApiError(err).message);
    }
  };

  return (
    <div className="space-y-2">
      <ol className="space-y-2">
        {citations.map((c, i) => (
          <li key={`${c.documentId}:${c.chunkIndex}`} className="rounded-lg border border-slate-200 p-3">
            <div className="flex items-start gap-2">
              <FileText className="mt-0.5 size-4 shrink-0 text-brand-700" aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-navy-900">{c.documentName}</p>
                <p className="text-xs text-slate-500">
                  Page {c.pageNumber}
                  {c.section && <> · {c.section}</>}
                </p>
              </div>
              <button type="button" onClick={() => void open(c)} className="inline-flex shrink-0 items-center gap-1 text-xs font-medium text-brand-700 hover:text-brand-600" aria-label={`Open ${c.documentName} at page ${c.pageNumber}`}>
                Open <ExternalLink className="size-3" aria-hidden />
              </button>
            </div>
            <p className={`mt-2 whitespace-pre-wrap text-sm text-slate-700 ${expanded === i ? '' : 'line-clamp-3'}`}>{c.excerpt}</p>
            <button type="button" onClick={() => setExpanded(expanded === i ? null : i)} className="mt-1 text-xs text-slate-500 hover:text-slate-800">
              {expanded === i ? 'Show less' : 'Show more'}
            </button>
          </li>
        ))}
      </ol>
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
