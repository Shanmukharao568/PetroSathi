import { useCallback, useEffect, useMemo, useState } from 'react';
import { FileText, CircleAlert, ExternalLink, Loader2, RefreshCw, Search, Trash2 } from 'lucide-react';
import { EmptyState } from '../../components/ui/EmptyState';
import { Card, CardHeader, PageHeader } from '../../components/ui/Card';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { Modal } from '../../components/ui/Modal';
import { Spinner } from '../../components/ui/Spinner';
import { Pager } from '../../components/ui/Pager';
import { toApiError, type Pagination } from '../../lib/api';
import { formatDateTime, humanize } from '../../lib/format';
import { deleteDocument, listDocuments, openDocument, reprocessDocument, searchKnowledge, type IngestionStatus, type KnowledgeDocument, type SearchResult } from './documentsApi';
import { UploadDocumentForm } from './UploadDocumentForm';
import { CitationList } from './CitationList';

const STATUS_TONE: Record<IngestionStatus, BadgeTone> = { pending: 'neutral', processing: 'info', ready: 'success', failed: 'danger' };
const MAX_PDF_MB = 25;

export function DocumentsPage() {
  const [items, setItems] = useState<KnowledgeDocument[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<KnowledgeDocument | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await listDocuments({ page, limit: 20 });
      setItems(r.items);
      setPagination(r.pagination);
      setError(null);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => void load(), [load]);

  // Poll while anything is still being processed.
  const busy = items.some((d) => d.ingestionStatus === 'pending' || d.ingestionStatus === 'processing');
  useEffect(() => {
    if (!busy) return;
    const t = window.setInterval(() => void load(), 3000);
    return () => window.clearInterval(t);
  }, [busy, load]);

  const stats = useMemo(
    () => ({
      ready: items.filter((d) => d.ingestionStatus === 'ready').length,
      failed: items.filter((d) => d.ingestionStatus === 'failed').length,
      chunks: items.reduce((n, d) => n + (d.chunkCount ?? 0), 0),
      model: items.find((d) => d.embeddingModel)?.embeddingModel ?? '—',
    }),
    [items],
  );

  const act = async (fn: () => Promise<unknown>) => {
    setActionError(null);
    try {
      await fn();
      await load();
    } catch (err) {
      setActionError(toApiError(err).message);
    }
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    setDeleteBusy(true);
    await act(() => deleteDocument(deleting.id));
    setDeleteBusy(false);
    setDeleting(null);
  };

  const runSearch = async () => {
    if (query.trim().length < 2) return;
    setSearching(true);
    setActionError(null);
    try {
      setSearchResult(await searchKnowledge(query.trim()));
    } catch (err) {
      setActionError(toApiError(err).message);
    } finally {
      setSearching(false);
    }
  };

  return (
    <>
      <PageHeader eyebrow="Knowledge base" title="Technical documents" description="Approved manuals and procedures used for document search and ticket references." />

      <div className="mb-6 grid gap-4 sm:grid-cols-4">
        {[
          ['Documents', pagination?.total ?? 0],
          ['Ready for search', stats.ready],
          ['Failed', stats.failed],
          ['Indexed passages', stats.chunks],
        ].map(([label, value]) => (
          <Card key={label as string} className="p-4">
            <p className="type-label text-slate-500">{label}</p>
            <p className="mt-1 text-2xl font-semibold text-navy-900">{value}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <Card>
          <CardHeader title="Knowledge base" description={`Embedding model: ${stats.model}`} />
          {error && <div className="p-4"><Alert tone="error">{error}</Alert></div>}
          {actionError && <div className="px-4 pt-4"><Alert tone="error">{actionError}</Alert></div>}
          <div className="relative overflow-x-auto">
            <table className="data-table w-full text-left text-sm">
              <thead>
                <tr>
                  <th scope="col" className="px-4 py-3">Document</th>
                  <th scope="col" className="px-4 py-3">Status</th>
                  <th scope="col" className="px-4 py-3">Pages / passages</th>
                  <th scope="col" className="px-4 py-3">Added</th>
                  <th scope="col" className="px-4 py-3"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
                {loading ? (
                  <tr><td colSpan={5} className="px-4 py-10 text-center"><Spinner label="Loading documents…" /></td></tr>
                ) : items.length === 0 ? (
                  <tr><td colSpan={5}><EmptyState icon={<FileText />} title="No documents yet.">Upload an approved PDF, or run <code>npm run kb:ingest</code> for the knowledge-base folder.</EmptyState></td></tr>
                ) : (
                  items.map((d) => (
                    <tr key={d.id} className="align-top hover:bg-slate-50/80">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{d.title}</p>
                        <div className="mt-1 flex flex-wrap gap-1">
                          <Badge>{humanize(d.documentType)}</Badge>
                          <Badge tone={d.source === 'preloaded' ? 'info' : 'neutral'}>{d.source === 'preloaded' ? 'Knowledge base' : 'Uploaded'}</Badge>
                          {d.equipmentIds.map((e) => <Badge key={e.equipmentCode} tone="neutral">{e.equipmentCode}</Badge>)}
                          {d.equipmentTypes.map((t) => <Badge key={t} tone="neutral">{humanize(t)}</Badge>)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge tone={STATUS_TONE[d.ingestionStatus]}>
                          {d.ingestionStatus === 'processing' && <Loader2 className="size-3 animate-spin" aria-hidden />}
                          {humanize(d.ingestionStatus)}
                        </Badge>
                        {d.ingestionError && (
                          <p className="mt-1 flex max-w-xs items-start gap-1 text-xs text-red-700">
                            <CircleAlert className="mt-0.5 size-3 shrink-0" aria-hidden /> {d.ingestionError}
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-600">{d.pageCount ?? '—'} / {d.chunkCount ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-600">
                        {formatDateTime(d.createdAt)}
                        {d.uploadedBy && <div className="text-xs text-slate-500">{d.uploadedBy.name}</div>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          <Button size="sm" variant="ghost" onClick={() => void act(() => openDocument(d.id))} aria-label={`Open ${d.title}`}><ExternalLink className="size-4" aria-hidden /></Button>
                          <Button size="sm" variant="ghost" disabled={d.ingestionStatus === 'pending' || d.ingestionStatus === 'processing'} onClick={() => void act(() => reprocessDocument(d.id))} aria-label={`Reprocess ${d.title}`}>
                            <RefreshCw className="size-4" aria-hidden />
                          </Button>
                          <Button size="sm" variant="ghost" disabled={d.ingestionStatus === 'processing'} onClick={() => setDeleting(d)} aria-label={`Delete ${d.title}`}>
                            <Trash2 className="size-4 text-red-600" aria-hidden />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <Pager pagination={pagination} noun="document" onPage={setPage} />
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader title="Upload a document" />
            <div className="p-5"><UploadDocumentForm maxMb={MAX_PDF_MB} onUploaded={() => void load()} /></div>
          </Card>
          <Card>
            <CardHeader title="Test search" description="Ask in any supported language." />
            <div className="space-y-3 p-5">
              <form
                className="flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  void runSearch();
                }}
              >
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. पंप में कंपन" aria-label="Search query"
                  className="h-10 flex-1 rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
                <Button type="submit" loading={searching} aria-label="Search"><Search className="size-4" aria-hidden /></Button>
              </form>
              {searchResult && (searchResult.noResults ? <Alert tone="info">{searchResult.message}</Alert> : <CitationList citations={searchResult.results} />)}
            </div>
          </Card>
        </div>
      </div>

      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title={`Delete "${deleting?.title ?? ''}"?`}
        description="Its search passages are removed and it will no longer be cited. This cannot be undone."
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button variant="danger" loading={deleteBusy} onClick={() => void confirmDelete()}>Delete document</Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">{deleting?.source === 'preloaded' ? 'The original file in knowledge-base/ is kept; re-run kb:ingest to add it again.' : 'The uploaded file is deleted from the server.'}</p>
      </Modal>
    </>
  );
}
