import { useState } from 'react';
import { BookOpen, Search } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { ticketReferences, type SearchResult } from './documentsApi';
import { CitationList } from './CitationList';

const SCOPE_TEXT = {
  equipment: 'Documents tagged for this equipment',
  equipmentType: 'Documents for this type of equipment',
  all: 'All approved documents',
} as const;

/** On-demand retrieval for a ticket (documents are not searched on every page view). */
export function ManualReferences({ ticketId }: { ticketId: string }) {
  const [result, setResult] = useState<SearchResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const find = async () => {
    setBusy(true);
    setError(null);
    try {
      setResult(await ticketReferences(ticketId));
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      {!result && (
        <>
          <p className="text-sm text-slate-500">Search the approved manuals for sections relevant to this complaint.</p>
          <Button size="sm" variant="secondary" loading={busy} onClick={() => void find()}>
            <Search className="size-4" aria-hidden /> Find relevant sections
          </Button>
        </>
      )}
      {error && <Alert tone="error">{error}</Alert>}
      {result &&
        (result.noResults ? (
          <Alert tone="info">{result.message ?? 'No suitable documentation was found.'}</Alert>
        ) : (
          <>
            <p className="inline-flex items-center gap-1.5 text-xs text-slate-500">
              <BookOpen className="size-3.5" aria-hidden /> {result.scope ? SCOPE_TEXT[result.scope] : 'Search results'}
            </p>
            <CitationList citations={result.results} />
            <p className="text-xs text-slate-500">Reference material only. Follow approved procedures and permits; PetroSathi does not authorize work.</p>
          </>
        ))}
      {result && (
        <Button size="sm" variant="ghost" loading={busy} onClick={() => void find()}>
          Search again
        </Button>
      )}
    </div>
  );
}
