import { api, type ApiSuccess, type Pagination } from '../../lib/api';
import type { EquipmentType } from '../../types/domain';

export const DOCUMENT_TYPES = ['manual', 'safety', 'troubleshooting', 'inspection', 'other'] as const;
export type DocumentType = (typeof DOCUMENT_TYPES)[number];
export type IngestionStatus = 'pending' | 'processing' | 'ready' | 'failed';

export interface KnowledgeDocument {
  id: string;
  title: string;
  fileName: string;
  documentType: DocumentType;
  equipmentIds: { id?: string; _id?: string; equipmentCode: string; name: string }[];
  equipmentTypes: EquipmentType[];
  uploadedBy: { name: string } | null;
  source: 'preloaded' | 'upload';
  sizeBytes: number;
  ingestionStatus: IngestionStatus;
  ingestionError: string | null;
  pageCount: number | null;
  chunkCount: number | null;
  sections: string[];
  embeddingModel: string | null;
  ingestedAt: string | null;
  createdAt: string;
}

export interface Citation {
  documentId: string;
  documentName: string;
  documentType: string;
  pageNumber: number;
  section: string;
  chunkIndex: number;
  score: number;
  excerpt: string;
}

export interface SearchResult {
  results: Citation[];
  noResults: boolean;
  message?: string;
  embeddingModel: string;
  minRelevance: number;
  scope?: 'equipment' | 'equipmentType' | 'all';
}

export async function listDocuments(params: { page: number; limit: number; status?: IngestionStatus; documentType?: DocumentType; search?: string }) {
  const res = await api.get<ApiSuccess<KnowledgeDocument[]>>('/documents', { params });
  return { items: res.data.data, pagination: res.data.meta?.pagination as Pagination };
}

export async function uploadDocument(
  file: File,
  fields: { title: string; documentType: DocumentType; equipmentCodes: string; equipmentTypes: EquipmentType[] },
  onProgress: (pct: number) => void,
) {
  const form = new FormData();
  form.append('title', fields.title);
  form.append('documentType', fields.documentType);
  if (fields.equipmentCodes.trim()) form.append('equipmentCodes', fields.equipmentCodes);
  if (fields.equipmentTypes.length) form.append('equipmentTypes', fields.equipmentTypes.join(','));
  form.append('file', file);
  const res = await api.post<ApiSuccess<KnowledgeDocument>>('/documents', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 300_000,
    onUploadProgress: (e) => e.total && onProgress(Math.round((e.loaded / e.total) * 100)),
  });
  return res.data.data;
}

export async function reprocessDocument(id: string) {
  return (await api.post<ApiSuccess<KnowledgeDocument>>(`/documents/${id}/reprocess`)).data.data;
}
export async function deleteDocument(id: string) {
  await api.delete(`/documents/${id}`);
}

/** Opens the protected PDF (auth header required) in a new tab, optionally at a page. */
export async function openDocument(id: string, page?: number) {
  const tab = window.open('', '_blank');
  const res = await api.get(`/documents/${id}/file`, { responseType: 'blob' });
  const url = URL.createObjectURL(res.data as Blob);
  const target = page ? `${url}#page=${page}` : url;
  if (tab) tab.location.href = target;
  else window.location.href = target;
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export async function searchKnowledge(query: string, filters: Record<string, string> = {}) {
  return (await api.post<ApiSuccess<SearchResult>>('/knowledge/search', { query, filters })).data.data;
}

export async function ticketReferences(ticketId: string) {
  return (await api.get<ApiSuccess<SearchResult>>(`/tickets/${ticketId}/references`)).data.data;
}
