import { useState } from 'react';
import { Send } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { formatDateTime } from '../../lib/format';
import { ROLE_LABEL } from '../../types/auth';
import type { TicketComment } from '../../types/domain';
import { addComment } from './ticketsApi';

export function CommentThread({ ticketId, comments, canComment, onAdded }: { ticketId: string; comments: TicketComment[]; canComment: boolean; onAdded: () => void }) {
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    if (!body.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await addComment(ticketId, body.trim());
      setBody('');
      onAdded();
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {comments.length === 0 ? (
        <p className="text-sm text-slate-500">No comments yet.</p>
      ) : (
        <ul className="space-y-3">
          {comments.map((c) => (
            <li key={c._id} className="rounded-lg bg-slate-50 p-3">
              <div className="flex flex-wrap items-baseline gap-x-2 text-xs text-slate-500">
                <span className="text-sm font-medium text-slate-900">{c.author?.name ?? 'Unknown'}</span>
                {c.author && <span>{ROLE_LABEL[c.author.role]}</span>}
                <time dateTime={c.createdAt}>{formatDateTime(c.createdAt)}</time>
              </div>
              <p className="mt-1 whitespace-pre-wrap text-sm text-slate-800">{c.body}</p>
            </li>
          ))}
        </ul>
      )}
      {canComment ? (
        <div className="space-y-2">
          <label htmlFor="new-comment" className="sr-only">Add a comment</label>
          <textarea
            id="new-comment"
            rows={3}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={4000}
            placeholder="Add a comment…"
            className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none"
          />
          {error && <Alert tone="error">{error}</Alert>}
          <Button size="sm" loading={busy} disabled={!body.trim()} onClick={() => void submit()}>
            <Send className="size-4" aria-hidden /> Post comment
          </Button>
        </div>
      ) : (
        <p className="text-xs text-slate-500">This ticket is closed to new comments.</p>
      )}
    </div>
  );
}
