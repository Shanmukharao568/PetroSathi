import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useParams } from 'react-router';
import { ArrowLeft, BookOpen, CalendarClock, FileAudio, FileText, History, MapPin, MessageSquare, Mic, Keyboard, CheckCircle2, Users, Wrench, Zap } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Alert } from '../../components/ui/Alert';
import { PageSkeleton } from '../../components/ui/Spinner';
import { Badge } from '../../components/ui/Badge';
import { SeverityBadge, StatusBadge } from '../../components/tickets/Badges';
import { toApiError } from '../../lib/api';
import { CATEGORY_LABEL, EQUIPMENT_STATUS_LABEL, equipmentTypeLabel, formatDateTime, humanize, ticketBasePath } from '../../lib/format';
import { languageLabel } from '../../lib/validation';
import { useAuthStore } from '../../store/authStore';
import type { Ticket } from '../../types/domain';
import { getTicket } from './ticketsApi';
import { HistoryTimeline } from './HistoryTimeline';
import { StatusActionPanel } from './StatusActionPanel';
import { AssignmentPanel } from './AssignmentPanel';
import { CommentThread } from './CommentThread';
import { ManualReferences } from '../documents/ManualReferences';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <dt className="type-label text-slate-500">{label}</dt>
      <dd className="mt-1 text-sm text-slate-900">{children}</dd>
    </div>
  );
}

export function TicketDetailPage() {
  const { id } = useParams<{ id: string }>();
  const user = useAuthStore((s) => s.user)!;
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setTicket(await getTicket(id!));
      setError(null);
    } catch (err) {
      setError(toApiError(err).message);
    }
  }, [id]);

  useEffect(() => void load(), [load]);

  const back = (
    <Link to={ticketBasePath(user.role)} className="group mb-5 inline-flex items-center gap-1.5 rounded-md text-[13px] font-semibold text-slate-500 transition-colors hover:text-navy-900">
      <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-0.5" aria-hidden /> Back to tickets
    </Link>
  );

  if (error) return <>{back}<Alert tone="error">{error}</Alert></>;
  if (!ticket) return <PageSkeleton label="Loading ticket…" />;

  const eq = ticket.equipment;
  const isStaff = user.role !== 'operator';

  return (
    <>
      {back}
      <div className="relative mb-7 overflow-hidden rounded-2xl border border-slate-200/90 bg-white px-5 py-5 shadow-card sm:px-6">
        <span aria-hidden className={`absolute inset-y-0 left-0 w-1 ${ticket.severity === 'critical' ? 'bg-red-500' : ticket.severity === 'high' ? 'bg-orange-500' : 'bg-signal-400'}`} />
        <p className="type-label flex items-center gap-2 text-slate-500">
          Ticket
          <span className="rounded bg-slate-100 px-1.5 py-px font-mono text-[11px] normal-case tracking-normal text-slate-600">{ticket.equipmentCode}</span>
        </p>
        <div className="mt-1.5 flex flex-wrap items-center gap-2.5">
          <h1 className="mr-1 font-mono text-[26px] font-semibold tracking-tight text-navy-900">{ticket.ticketNumber}</h1>
          <StatusBadge status={ticket.status} />
          <SeverityBadge severity={ticket.severity} />
        </div>
        <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-slate-500">
          <span className="inline-flex items-center gap-1.5"><Users className="size-3.5 text-slate-400" aria-hidden />Reported by <span className="font-medium text-slate-700">{ticket.reportedBy.name}</span></span>
          <span className="inline-flex items-center gap-1.5"><CalendarClock className="size-3.5 text-slate-400" aria-hidden />{formatDateTime(ticket.createdAt)}</span>
          <span className="inline-flex items-center gap-1.5">
            {ticket.source === 'voice' ? <Mic className="size-3.5 text-slate-400" aria-hidden /> : <Keyboard className="size-3.5 text-slate-400" aria-hidden />}
            {ticket.source === 'voice' ? 'Voice report' : 'Manual report'}
          </span>
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="space-y-6">
          <Card>
            <CardHeader icon={<FileText />} title="Complaint" actions={<Badge>{CATEGORY_LABEL[ticket.category]}</Badge>} />
            <div className="space-y-4 p-5">
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-800">{ticket.description}</p>
              {ticket.symptoms.length > 0 && (
                <div>
                  <p className="type-label text-slate-500">Symptoms</p>
                  <ul className="mt-1.5 flex flex-wrap gap-1.5">
                    {ticket.symptoms.map((s) => <li key={s}><Badge tone="neutral">{s}</Badge></li>)}
                  </ul>
                </div>
              )}
            </div>
          </Card>

          <Card>
            <CardHeader icon={<FileAudio />} title="Original transcript"
              description={ticket.language ? `Language: ${languageLabel(ticket.language)}` : undefined} />
            <div className="p-5">
              {ticket.transcript ? (
                <blockquote className="whitespace-pre-wrap rounded-r-lg border-l-[3px] border-signal-400 bg-slate-50 px-4 py-3.5 leading-relaxed text-sm text-slate-800">{ticket.transcript}</blockquote>
              ) : (
                <p className="text-sm text-slate-500">This ticket was submitted through the manual form, so there is no voice transcript.</p>
              )}
            </div>
          </Card>

          {ticket.resolution && (
            <Card className="border-emerald-200">
              <CardHeader icon={<CheckCircle2 />} title="Resolution" description={`${ticket.resolution.resolvedBy?.name ?? ''} · ${formatDateTime(ticket.resolution.resolvedAt)}`} />
              <dl className="grid grid-cols-1 gap-4 p-5">
                <Field label="Summary"><span className="whitespace-pre-wrap">{ticket.resolution.summary}</span></Field>
                {ticket.resolution.rootCause && <Field label="Root cause">{ticket.resolution.rootCause}</Field>}
                {ticket.resolution.actionsTaken && <Field label="Actions taken"><span className="whitespace-pre-wrap">{ticket.resolution.actionsTaken}</span></Field>}
              </dl>
            </Card>
          )}

          <Card>
            <CardHeader icon={<MessageSquare />} title="Comments" />
            <div className="p-5">
              <CommentThread ticketId={ticket.id} comments={ticket.comments ?? []} canComment={ticket.permissions.comment} onAdded={() => void load()} />
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          {(ticket.permissions.changeStatus || ticket.permissions.accept || ticket.permissions.assign || ticket.permissions.release) && (
            <Card className="ring-1 ring-brand-500/10">
              <CardHeader icon={<Zap />} title="Actions" />
              <div className="space-y-4 p-5">
                <AssignmentPanel ticket={ticket} onChanged={setTicket} />
                <StatusActionPanel ticket={ticket} onChanged={setTicket} />
              </div>
            </Card>
          )}

          <Card>
            <CardHeader icon={<Users />} title="People" />
            <dl className="grid grid-cols-1 gap-3 p-5">
              <Field label="Reporter">{ticket.reportedBy.name}</Field>
              <Field label="Assigned engineer">{ticket.assignedTo?.name ?? <span className="text-slate-500">Not yet assigned</span>}</Field>
            </dl>
          </Card>

          <Card>
            <CardHeader icon={<Wrench />} title="Equipment" />
            {eq ? (
              <dl className="grid grid-cols-1 gap-3 p-5">
                <Field label="Tag"><span className="font-mono">{eq.equipmentCode}</span></Field>
                <Field label="Name">{eq.name}</Field>
                <Field label="Type">{equipmentTypeLabel(eq.type)}</Field>
                <Field label="Location"><span className="inline-flex items-start gap-1"><MapPin className="mt-0.5 size-3.5 text-slate-400" aria-hidden />{eq.plant}{eq.location && ` — ${eq.location}`}</span></Field>
                <div className="flex gap-2">
                  <Badge>{humanize(eq.criticality)} criticality</Badge>
                  <Badge>{EQUIPMENT_STATUS_LABEL[eq.status]}</Badge>
                </div>
              </dl>
            ) : (
              <p className="p-5 text-sm text-slate-500">Equipment {ticket.equipmentCode} is no longer in the register.</p>
            )}
          </Card>

          {isStaff && (
            <Card>
              <CardHeader icon={<BookOpen />} title="Manual references" />
              <div className="p-5"><ManualReferences ticketId={ticket.id} /></div>
            </Card>
          )}

          <Card>
            <CardHeader icon={<History />} title="History" />
            <div className="p-5 pl-8">
              <HistoryTimeline history={ticket.history ?? []} />
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
