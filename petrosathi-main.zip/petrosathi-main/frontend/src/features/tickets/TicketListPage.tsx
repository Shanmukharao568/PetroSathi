import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { Mic, Search, SearchX } from 'lucide-react';
import clsx from 'clsx';
import { segmentClass, segmentGroupClass } from '../../components/ui/styles';
import { Card, PageHeader } from '../../components/ui/Card';
import { Select } from '../../components/ui/Select';
import { Alert } from '../../components/ui/Alert';
import { Spinner } from '../../components/ui/Spinner';
import { Pager } from '../../components/ui/Pager';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { SeverityBadge, StatusBadge } from '../../components/tickets/Badges';
import { toApiError, type Pagination } from '../../lib/api';
import { CATEGORY_LABEL, SEVERITY_LABEL, STATUS_LABEL, ticketBasePath, timeAgo } from '../../lib/format';
import { useDebounced } from '../../hooks/useDebounced';
import { useAuthStore } from '../../store/authStore';
import { COMPLAINT_CATEGORIES, SEVERITIES, TICKET_STATUSES, type ComplaintCategory, type Severity, type Ticket, type TicketStatus } from '../../types/domain';
import { listTickets, type TicketQuery } from './ticketsApi';

type Scope = NonNullable<TicketQuery['scope']>;
const ACTIVE: TicketStatus[] = ['OPEN', 'UNDER_INSPECTION', 'IN_PROGRESS'];

const STATUS_PRESETS: { key: string; label: string; value: TicketStatus[] | undefined }[] = [
  { key: 'active', label: 'Active', value: ACTIVE },
  { key: 'all', label: 'All', value: undefined },
  ...TICKET_STATUSES.map((s) => ({ key: s, label: STATUS_LABEL[s], value: [s] })),
];

/** Shared by operators (own tickets only — enforced server-side) and engineers/admins. */
export function TicketListPage() {
  const user = useAuthStore((s) => s.user)!;
  const isOperator = user.role === 'operator';
  const base = ticketBasePath(user.role);

  const [items, setItems] = useState<Ticket[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [page, setPage] = useState(1);
  const [scope, setScope] = useState<Scope>(user.role === 'engineer' ? 'assigned' : 'all');
  const [statusKey, setStatusKey] = useState(isOperator ? 'all' : 'active');
  const [severity, setSeverity] = useState<'' | Severity>('');
  const [category, setCategory] = useState<'' | ComplaintCategory>('');
  const [sort, setSort] = useState<'newest' | 'severity'>(isOperator ? 'newest' : 'severity');
  const [searchInput, setSearchInput] = useState('');
  const search = useDebounced(searchInput.trim());

  useEffect(() => setPage(1), [scope, statusKey, severity, category, sort, search]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const status = STATUS_PRESETS.find((p) => p.key === statusKey)?.value;
      const r = await listTickets({
        page, limit: 20, sort,
        ...(!isOperator && { scope }),
        ...(status && { status }),
        ...(severity && { severity: [severity] }),
        ...(category && { category }),
        ...(search && { search }),
      });
      setItems(r.items);
      setPagination(r.pagination);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setLoading(false);
    }
  }, [page, scope, statusKey, severity, category, sort, search, isOperator]);

  useEffect(() => void load(), [load]);

  return (
    <>
      <PageHeader
        eyebrow="Maintenance"
        title={isOperator ? 'My tickets' : 'Maintenance tickets'}
        description={isOperator ? 'Issues you have reported and their current status.' : 'Assigned and available tickets across all equipment.'}
        actions={isOperator ? <Link to="/operator/report"><Button><Mic className="size-4" aria-hidden /> Report issue</Button></Link> : undefined}
      />

      {!isOperator && (
        <div className={clsx(segmentGroupClass, 'mb-4')} role="tablist" aria-label="Ticket scope">
          {(['assigned', 'unassigned', 'all'] as Scope[]).map((s) => (
            <button
              key={s}
              role="tab"
              aria-selected={scope === s}
              onClick={() => setScope(s)}
              className={segmentClass(scope === s)}
            >
              {s === 'assigned' ? 'Assigned to me' : s === 'unassigned' ? 'Unassigned' : 'All tickets'}
            </button>
          ))}
        </div>
      )}

      <Card>
        <div className="grid grid-cols-2 items-end gap-3 border-b border-slate-100 bg-slate-50/40 p-4 sm:flex sm:flex-wrap">
          <label className="relative col-span-2 min-w-52 flex-1">
            <span className="sr-only">Search tickets</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <input type="search" value={searchInput} onChange={(e) => setSearchInput(e.target.value)} placeholder="Ticket no., equipment tag, description"
              className="h-11 w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
          </label>
          <div className="sm:w-40"><Select aria-label="Status" value={statusKey} onChange={(e) => setStatusKey(e.target.value)} options={STATUS_PRESETS.map((p) => ({ value: p.key, label: p.key === 'all' ? 'All statuses' : p.label }))} /></div>
          <div className="sm:w-40"><Select aria-label="Severity" value={severity} onChange={(e) => setSeverity(e.target.value as '' | Severity)} options={[{ value: '', label: 'All severities' }, ...SEVERITIES.map((s) => ({ value: s, label: SEVERITY_LABEL[s] }))]} /></div>
          <div className="sm:w-44"><Select aria-label="Category" value={category} onChange={(e) => setCategory(e.target.value as '' | ComplaintCategory)} options={[{ value: '', label: 'All categories' }, ...COMPLAINT_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_LABEL[c] }))]} /></div>
          <div className="sm:w-40"><Select aria-label="Sort" value={sort} onChange={(e) => setSort(e.target.value as 'newest' | 'severity')} options={[{ value: 'severity', label: 'Most severe first' }, { value: 'newest', label: 'Newest first' }]} /></div>
        </div>

        {error && <div className="p-4"><Alert tone="error">{error}</Alert></div>}

        <div className="relative overflow-x-auto">
          <table className="data-table w-full text-left text-sm">
            <thead>
              <tr>
                <th scope="col" className="px-4 py-3">Ticket</th>
                <th scope="col" className="px-4 py-3">Equipment</th>
                <th scope="col" className="px-4 py-3">Severity</th>
                <th scope="col" className="px-4 py-3">Status</th>
                <th scope="col" className="px-4 py-3">{isOperator ? 'Engineer' : 'Assignee'}</th>
                <th scope="col" className="px-4 py-3">Reported</th>
              </tr>
            </thead>
            <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
              {loading && items.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center"><Spinner label="Loading tickets…" /></td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={6}><EmptyState icon={<SearchX />} title="No tickets match these filters.">Try a different status or severity, or clear the search.</EmptyState></td></tr>
              ) : (
                items.map((t) => (
                  <tr key={t.id} className={clsx('hover:bg-brand-50/50', t.severity === 'critical' && t.status !== 'CLOSED' && 'bg-red-50/40 shadow-[inset_3px_0_0_var(--color-red-500)]')}>
                    <td className="px-4 py-3">
                      <Link to={`${base}/${t.id}`} className="whitespace-nowrap font-mono text-[13px] font-semibold text-brand-700 hover:text-brand-600 hover:underline">{t.ticketNumber}</Link>
                      <p className="mt-0.5 line-clamp-1 min-w-56 max-w-sm text-slate-600">{t.description}</p>
                    </td>
                    <td className="px-4 py-3">
                      <div className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-b from-white to-slate-100 px-2 py-0.5 font-mono text-[13px] font-semibold text-navy-900 ring-1 ring-inset ring-slate-200"><span className="size-1.5 rounded-full bg-brand-500" aria-hidden />{t.equipmentCode}</div>
                      <div className="min-w-32 text-xs text-slate-500">{t.equipment?.name}</div>
                    </td>
                    <td className="px-4 py-3"><SeverityBadge severity={t.severity} /></td>
                    <td className="px-4 py-3"><StatusBadge status={t.status} /></td>
                    <td className="min-w-32 px-4 py-3 text-slate-600">{t.assignedTo?.name ?? <span className="text-slate-400">Unassigned</span>}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-500" title={t.createdAt}>
                      {timeAgo(t.createdAt)}
                      {!isOperator && <div className="text-xs">{t.reportedBy.name}</div>}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <Pager pagination={pagination} noun="ticket" onPage={setPage} />
      </Card>
    </>
  );
}
