import { useEffect, useState } from 'react';
import { UserCheck, UserMinus } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Select';
import { Alert } from '../../components/ui/Alert';
import { api, toApiError, type ApiSuccess } from '../../lib/api';
import { useAuthStore } from '../../store/authStore';
import type { User } from '../../types/auth';
import type { Ticket } from '../../types/domain';
import { assignTicket } from './ticketsApi';

/** Accept / release (engineers) and assign / reassign (admins), per server-provided permissions. */
export function AssignmentPanel({ ticket, onChanged }: { ticket: Ticket; onChanged: (t: Ticket) => void }) {
  const me = useAuthStore((s) => s.user)!;
  const { permissions: p } = ticket;
  const [engineers, setEngineers] = useState<User[]>([]);
  const [selected, setSelected] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!p.assign) return;
    api
      .get<ApiSuccess<User[]>>('/users', { params: { role: 'engineer', isActive: true, limit: 100 } })
      .then((r) => setEngineers(r.data.data))
      .catch((err) => setError(toApiError(err).message));
  }, [p.assign]);

  const run = async (assigneeId: string | null) => {
    setBusy(true);
    setError(null);
    try {
      onChanged(await assignTicket(ticket.id, assigneeId));
      setSelected('');
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  if (!p.accept && !p.release && !p.assign) return null;

  return (
    <div className="space-y-2">
      {p.accept && (
        <Button size="sm" className="w-full" loading={busy} onClick={() => void run(me.id)}>
          <UserCheck className="size-4" aria-hidden /> Accept this ticket
        </Button>
      )}
      {p.release && (
        <Button size="sm" variant="secondary" className="w-full" loading={busy} onClick={() => void run(null)}>
          <UserMinus className="size-4" aria-hidden /> Release to queue
        </Button>
      )}
      {p.assign && (
        <div className="flex items-end gap-2">
          <div className="flex-1">
            <Select
              label={ticket.assignedTo ? 'Reassign to' : 'Assign to'}
              value={selected}
              onChange={(e) => setSelected(e.target.value)}
              options={[
                { value: '', label: 'Select engineer…' },
                ...engineers.filter((e) => e.id !== ticket.assignedTo?.id).map((e) => ({ value: e.id, label: e.name })),
              ]}
            />
          </div>
          <Button size="md" disabled={!selected} loading={busy} onClick={() => void run(selected)}>Assign</Button>
        </div>
      )}
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}
