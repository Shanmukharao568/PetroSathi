import { api, type ApiSuccess, type Pagination } from '../../lib/api';
import type { ComplaintCategory, HistoryEntry, Severity, Ticket, TicketComment, TicketStatus } from '../../types/domain';

export interface TicketQuery {
  page: number;
  limit: number;
  scope?: 'all' | 'assigned' | 'unassigned' | 'reported';
  status?: TicketStatus[];
  severity?: Severity[];
  category?: ComplaintCategory;
  search?: string;
  sort?: 'newest' | 'oldest' | 'severity';
}

export async function listTickets(q: TicketQuery) {
  const params = { ...q, status: q.status?.join(',') || undefined, severity: q.severity?.join(',') || undefined };
  const res = await api.get<ApiSuccess<Ticket[]>>('/tickets', { params });
  return { items: res.data.data, pagination: res.data.meta?.pagination as Pagination };
}

export async function getTicket(id: string) {
  return (await api.get<ApiSuccess<Ticket>>(`/tickets/${id}`)).data.data;
}

export async function getHistory(id: string) {
  return (await api.get<ApiSuccess<HistoryEntry[]>>(`/tickets/${id}/history`)).data.data;
}

export interface CreateTicketInput {
  equipmentId: string;
  description: string;
  symptoms: string[];
  category: ComplaintCategory;
  severity: Severity;
}

/** The same idempotency key must be reused for retries of one submission. */
export async function createTicket(body: CreateTicketInput, idempotencyKey: string) {
  const res = await api.post<ApiSuccess<Ticket>>('/tickets', body, { headers: { 'Idempotency-Key': idempotencyKey } });
  return res.data.data;
}

export async function assignTicket(id: string, assigneeId: string | null, comment?: string) {
  return (await api.patch<ApiSuccess<Ticket>>(`/tickets/${id}/assign`, { assigneeId, ...(comment ? { comment } : {}) })).data.data;
}

export async function changeStatus(
  id: string,
  body: { status: TicketStatus; comment?: string; resolution?: { summary: string; rootCause?: string; actionsTaken?: string } },
) {
  return (await api.patch<ApiSuccess<Ticket>>(`/tickets/${id}/status`, body)).data.data;
}

export async function addComment(id: string, body: string) {
  return (await api.post<ApiSuccess<TicketComment>>(`/tickets/${id}/comments`, { body })).data.data;
}
