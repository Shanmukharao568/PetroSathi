import { useState } from 'react';
import { Button } from '../../components/ui/Button';
import { Textarea } from '../../components/ui/Textarea';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { STATUS_LABEL } from '../../lib/format';
import type { Ticket, TicketStatus } from '../../types/domain';
import { changeStatus } from './ticketsApi';

const ACTION_LABEL: Partial<Record<TicketStatus, string>> = {
  UNDER_INSPECTION: 'Start inspection',
  IN_PROGRESS: 'Start work',
  RESOLVED: 'Mark resolved',
  CLOSED: 'Close ticket',
};

/** Only offers transitions the server says this user may perform right now. */
export function StatusActionPanel({ ticket, onChanged }: { ticket: Ticket; onChanged: (t: Ticket) => void }) {
  const [target, setTarget] = useState<TicketStatus | null>(null);
  const [comment, setComment] = useState('');
  const [summary, setSummary] = useState('');
  const [rootCause, setRootCause] = useState('');
  const [actionsTaken, setActionsTaken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const allowed = ticket.permissions.allowedTransitions;
  if (!ticket.permissions.changeStatus || allowed.length === 0) return null;

  const reopening = ticket.status === 'RESOLVED' && target === 'IN_PROGRESS';
  const resolving = target === 'RESOLVED';

  const reset = () => {
    setTarget(null); setComment(''); setSummary(''); setRootCause(''); setActionsTaken(''); setError(null);
  };

  const submit = async () => {
    if (!target) return;
    setBusy(true);
    setError(null);
    try {
      const t = await changeStatus(ticket.id, {
        status: target,
        ...(comment.trim() && { comment: comment.trim() }),
        ...(resolving && { resolution: { summary: summary.trim(), rootCause: rootCause.trim() || undefined, actionsTaken: actionsTaken.trim() || undefined } }),
      });
      reset();
      onChanged(t);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const canSubmit = !busy && (!resolving || summary.trim().length >= 5) && (!reopening || comment.trim().length > 0);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {allowed.map((s) => (
          <Button
            key={s}
            size="sm"
            variant={target === s ? 'primary' : 'secondary'}
            onClick={() => setTarget(target === s ? null : s)}
            aria-pressed={target === s}
          >
            {ticket.status === 'RESOLVED' && s === 'IN_PROGRESS' ? 'Reopen' : ticket.status === 'IN_PROGRESS' && s === 'UNDER_INSPECTION' ? 'Back to inspection' : ACTION_LABEL[s] ?? STATUS_LABEL[s]}
          </Button>
        ))}
      </div>

      {target && (
        <div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3">
          <p className="text-sm text-slate-700">
            Move from <strong>{STATUS_LABEL[ticket.status]}</strong> to <strong>{STATUS_LABEL[target]}</strong>
          </p>
          {resolving && (
            <>
              <Textarea label="Resolution summary (required)" rows={3} value={summary} onChange={(e) => setSummary(e.target.value)} placeholder="What was done to resolve the issue?" />
              <Textarea label="Root cause" rows={2} value={rootCause} onChange={(e) => setRootCause(e.target.value)} />
              <Textarea label="Actions taken" rows={2} value={actionsTaken} onChange={(e) => setActionsTaken(e.target.value)} />
            </>
          )}
          <Textarea
            label={reopening ? 'Reason for reopening (required)' : 'Comment (optional)'}
            rows={2}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          {error && <Alert tone="error">{error}</Alert>}
          <div className="flex gap-2">
            <Button size="sm" loading={busy} disabled={!canSubmit} onClick={() => void submit()}>Confirm</Button>
            <Button size="sm" variant="ghost" onClick={reset}>Cancel</Button>
          </div>
        </div>
      )}
    </div>
  );
}
