import { ArrowRight, CirclePlus, UserCheck, UserMinus, RefreshCw } from 'lucide-react';
import type { HistoryEntry } from '../../types/domain';
import { STATUS_LABEL, formatDateTime } from '../../lib/format';

function describe(h: HistoryEntry) {
  switch (h.type) {
    case 'created':
      return { Icon: CirclePlus, text: <>Ticket created</> };
    case 'assigned':
      return {
        Icon: UserCheck,
        text: h.fromAssignee ? (
          <>Reassigned from <strong>{h.fromAssignee.name}</strong> to <strong>{h.toAssignee?.name}</strong></>
        ) : h.toAssignee?.id === h.actor.id ? (
          <>Accepted the ticket</>
        ) : (
          <>Assigned to <strong>{h.toAssignee?.name}</strong></>
        ),
      };
    case 'unassigned':
      return { Icon: UserMinus, text: <>Unassigned {h.fromAssignee && <strong>{h.fromAssignee.name}</strong>}</> };
    case 'status_changed':
      return {
        Icon: RefreshCw,
        text: (
          <span className="inline-flex flex-wrap items-center gap-1">
            {h.fromStatus && STATUS_LABEL[h.fromStatus]} <ArrowRight className="size-3.5 text-slate-400" aria-hidden />
            <strong>{h.toStatus && STATUS_LABEL[h.toStatus]}</strong>
          </span>
        ),
      };
    default:
      return { Icon: RefreshCw, text: <>Updated</> };
  }
}

export function HistoryTimeline({ history }: { history: HistoryEntry[] }) {
  return (
    <ol className="relative space-y-4 border-l border-slate-200 pl-5">
      {[...history].reverse().map((h) => {
        const { Icon, text } = describe(h);
        return (
          <li key={h._id} className="relative">
            <span className="absolute -left-[1.85rem] flex size-6 items-center justify-center rounded-full bg-white ring-1 ring-slate-200">
              <Icon className="size-3.5 text-brand-700" aria-hidden />
            </span>
            <p className="text-sm text-slate-800">{text}</p>
            <p className="text-xs text-slate-500">
              {h.actor?.name ?? 'Unknown'} · <time dateTime={h.at}>{formatDateTime(h.at)}</time>
            </p>
            {h.comment && <p className="mt-1 rounded-md bg-slate-50 px-2 py-1 text-sm text-slate-700">“{h.comment}”</p>}
          </li>
        );
      })}
    </ol>
  );
}
