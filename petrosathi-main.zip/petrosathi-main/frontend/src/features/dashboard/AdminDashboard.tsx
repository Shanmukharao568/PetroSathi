import { DashboardHero } from '../../components/ui/DashboardHero';
import type { ReactNode } from 'react';
import { Link } from 'react-router';
import { Activity, AlertOctagon, ArrowRight, BookOpen, Cog, FilePen, ScrollText, Siren, Timer, TrendingUp, UserX, Users } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { EmptyState } from '../../components/ui/EmptyState';
import { cardLinkClass, nudgeArrowClass } from '../../components/ui/styles';
import { StatTile } from '../../components/charts/StatTile';
import { humanize, timeAgo } from '../../lib/format';
import { ActivityFeed } from './ActivityFeed';
import { greeting, todayLabel } from './greeting';
import type { AdminDashboardData } from './dashboardApi';

function Row({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2 text-sm">
      <span className="text-slate-600">{label}</span>
      <span className="font-semibold tabular-nums text-slate-900">{value}</span>
    </div>
  );
}

function Manage({ to, children = 'Manage' }: { to: string; children?: ReactNode }) {
  return (
    <Link to={to} className={cardLinkClass()}>
      {children} <ArrowRight className={nudgeArrowClass} aria-hidden />
    </Link>
  );
}

export function AdminDashboard({ data, firstName }: { data: AdminDashboardData; firstName: string }) {
  const s = data.summary;
  const critical = s.tickets.activeBySeverity.critical;
  return (
    <>
      <DashboardHero
        eyebrow={todayLabel()}
        title={`${greeting()}, ${firstName}`}
        description="System overview from live data."
        actions={
          <Link to="/admin/analytics" className={cardLinkClass('text-sm')}>
            Analytics <ArrowRight className={nudgeArrowClass} aria-hidden />
          </Link>
        }
      />

      <div className="stagger mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        <StatTile glyph={Activity} accent="sky" label="Active tickets" value={s.tickets.active} to="/engineer/tickets" />
        <StatTile glyph={Siren} accent="rose" label="Critical, active" value={critical} tone="alert" icon={critical ? <AlertOctagon className="size-3.5 text-red-600" aria-hidden /> : undefined} />
        <StatTile glyph={UserX} accent="amber" label="Unassigned" value={s.tickets.unassignedActive} to="/engineer/tickets" />
        <StatTile glyph={TrendingUp} accent="violet" label="Created, last 12 months" value={s.tickets.createdInRange} />
        <StatTile glyph={Timer} accent="brand" label="Avg. resolution" value={s.resolution.averageHours} unit="h" note={s.resolution.resolvedCount ? `${s.resolution.resolvedCount} resolved` : 'Nothing resolved yet'} />
        <StatTile glyph={FilePen} accent="slate" label="Unfinished reports" value={s.openComplaintDrafts} />
      </div>

      <div className="stagger grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3 [--stagger-step:80ms]">
        <Card>
          <CardHeader icon={<Users />} title="People" actions={<Manage to="/admin/users" />} />
          <div className="divide-y divide-slate-100 px-5 py-1.5">
            {(['operator', 'engineer', 'admin'] as const).map((r) => (
              <Row
                key={r}
                label={`${humanize(r)}s`}
                value={
                  <>
                    {s.users[r].active} active
                    {s.users[r].inactive ? <span className="font-normal text-slate-500"> · {s.users[r].inactive} deactivated</span> : null}
                  </>
                }
              />
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader icon={<Cog />} title="Equipment" actions={<Manage to="/admin/equipment" />} />
          <div className="divide-y divide-slate-100 px-5 py-1.5">
            <Row label="Registered" value={s.equipment.total} />
            {Object.entries(s.equipment.byStatus).map(([k, v]) => <Row key={k} label={humanize(k)} value={v} />)}
          </div>
        </Card>
        <Card className="md:col-span-2 xl:col-span-1">
          <CardHeader icon={<BookOpen />} title="Knowledge base" actions={<Manage to="/admin/documents" />} />
          <div className="divide-y divide-slate-100 px-5 py-1.5">
            <Row label="Ready documents" value={s.documents.byStatus.ready} />
            <Row label="Indexed passages" value={s.documents.indexedPassages} />
            <Row label="Processing / pending" value={s.documents.byStatus.processing + s.documents.byStatus.pending} />
            <Row label="Failed" value={s.documents.byStatus.failed ? <span className="text-red-700">{s.documents.byStatus.failed}</span> : 0} />
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader icon={<Activity />} title="Recent ticket activity" />
          <ActivityFeed items={data.recentActivity} linkBase="/engineer/tickets" />
        </Card>
        <Card>
          <CardHeader icon={<ScrollText />} title="Latest audit entries" actions={<Manage to="/admin/audit-logs">All entries</Manage>} />
          {data.recentAudit.length === 0 ? (
            <EmptyState compact icon={<ScrollText />} title="No audit entries yet" />
          ) : (
            <ul className="stagger divide-y divide-slate-100 [--stagger-step:45ms]">
              {data.recentAudit.map((a) => (
                <li key={a.id} className="flex items-start justify-between gap-3 px-5 py-3 text-sm">
                  <div className="min-w-0">
                    <span className="inline-block rounded bg-navy-900/[0.04] px-1.5 py-0.5 font-mono text-xs font-medium text-navy-900 ring-1 ring-inset ring-navy-900/10">{a.action}</span>
                    <span className="mt-1 block truncate text-slate-600">{a.actorId?.name ?? 'System / anonymous'}</span>
                  </div>
                  <span className="shrink-0 whitespace-nowrap text-xs tabular-nums text-slate-500">{timeAgo(a.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
