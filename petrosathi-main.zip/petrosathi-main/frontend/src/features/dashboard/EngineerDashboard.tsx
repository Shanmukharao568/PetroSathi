import { DashboardHero } from '../../components/ui/DashboardHero';
import { Link } from 'react-router';
import { Activity, AlertOctagon, ArrowRight, CheckCircle2, CircleDot, ListChecks, Search, Siren, UserCheck, Wrench } from 'lucide-react';
import clsx from 'clsx';
import { Card, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/ui/EmptyState';
import { cardLinkClass, nudgeArrowClass } from '../../components/ui/styles';
import { StatTile } from '../../components/charts/StatTile';
import { SeverityBadge, StatusBadge } from '../../components/tickets/Badges';
import { timeAgo } from '../../lib/format';
import { ActivityFeed } from './ActivityFeed';
import { greeting, todayLabel } from './greeting';
import type { EngineerDashboardData } from './dashboardApi';

export function EngineerDashboard({ data, firstName }: { data: EngineerDashboardData; firstName: string }) {
  const c = data.counts;
  return (
    <>
      <DashboardHero
        eyebrow={todayLabel()}
        title={`${greeting()}, ${firstName}`}
        description="Your maintenance work at a glance."
        actions={
          <Link to="/engineer/tickets" className={cardLinkClass('text-sm')}>
            All tickets <ArrowRight className={nudgeArrowClass} aria-hidden />
          </Link>
        }
      />

      <div className="stagger mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        <StatTile glyph={UserCheck} accent="brand" label="Assigned to me" value={c.assignedTotal} to="/engineer/tickets" />
        <StatTile glyph={CircleDot} accent="sky" label="Open" value={c.open} />
        <StatTile glyph={Search} accent="violet" label="Under inspection" value={c.underInspection} />
        <StatTile glyph={Wrench} accent="amber" label="In progress" value={c.inProgress} />
        <StatTile glyph={CheckCircle2} accent="emerald" label="Resolved" value={c.resolved} note={`${c.resolvedByMeLast30Days} by you in 30 days`} />
        <StatTile glyph={Siren} accent="rose" label="Critical (mine, active)" value={c.criticalAssigned} tone="alert" icon={c.criticalAssigned ? <AlertOctagon className="size-3.5 text-red-600" aria-hidden /> : undefined} />
      </div>

      <div className="stagger grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_22rem] [--stagger-step:120ms]">
        <Card>
          <CardHeader
            icon={<ListChecks />}
            title="Work queue"
            description="Your active tickets and unassigned tickets, most severe first."
            actions={
              <Badge tone={c.unassignedCritical ? 'danger' : c.unassigned ? 'warning' : 'neutral'}>
                {c.unassigned} unassigned{c.unassignedCritical ? ` · ${c.unassignedCritical} critical` : ''}
              </Badge>
            }
          />
          {data.queue.length === 0 ? (
            <EmptyState icon={<CheckCircle2 />} title="Nothing in your queue.">
              New and unassigned tickets will appear here, most severe first.
            </EmptyState>
          ) : (
            <div className="relative overflow-x-auto">
              <table className="data-table w-full text-left text-sm">
                <thead>
                  <tr>
                    <th scope="col" className="px-5 py-2.5">Ticket</th>
                    <th scope="col" className="px-4 py-2.5">Severity</th>
                    <th scope="col" className="px-4 py-2.5">Status</th>
                    <th scope="col" className="px-4 py-2.5">Owner</th>
                    <th scope="col" className="px-4 py-2.5">Age</th>
                  </tr>
                </thead>
                <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
                  {data.queue.map((t) => (
                    <tr key={t.id} className={clsx('hover:bg-slate-50/80', t.severity === 'critical' && 'shadow-[inset_3px_0_0_var(--color-red-500)]')}>
                      <td className="px-5 py-3">
                        <Link to={`/engineer/tickets/${t.id}`} className="font-mono text-[13px] font-semibold text-brand-700 hover:underline">{t.ticketNumber}</Link>
                        <span className="ml-2 rounded bg-slate-100 px-1.5 py-px font-mono text-xs text-slate-600">{t.equipmentCode}</span>
                        <p className="mt-0.5 max-w-xs truncate text-xs text-slate-600">{t.description}</p>
                      </td>
                      <td className="px-4 py-3"><SeverityBadge severity={t.severity} /></td>
                      <td className="px-4 py-3"><StatusBadge status={t.status} /></td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-600">
                        {t.assignedToMe ? 'You' : <span className="font-medium text-amber-700">Unassigned</span>}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-xs tabular-nums text-slate-500">{timeAgo(t.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader icon={<Activity />} title="Recent ticket activity" />
          <ActivityFeed items={data.recentActivity} linkBase="/engineer/tickets" />
        </Card>
      </div>
    </>
  );
}
