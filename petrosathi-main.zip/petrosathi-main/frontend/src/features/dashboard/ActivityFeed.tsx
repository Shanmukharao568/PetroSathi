import { Link } from 'react-router';
import { ArrowRight, CircleDot, FileCheck2, History, PlusCircle, RefreshCcw, UserCheck, UserMinus, type LucideIcon } from 'lucide-react';
import { EmptyState } from '../../components/ui/EmptyState';
import { STATUS_LABEL, timeAgo } from '../../lib/format';
import type { ActivityItem } from './dashboardApi';

function describe(a: ActivityItem) {
  switch (a.type) {
    case 'created':
      return 'reported';
    case 'assigned':
      return 'assigned';
    case 'unassigned':
      return 'returned to the queue';
    case 'status_changed':
      return (
        <span className="inline-flex flex-wrap items-center gap-1">
          {a.fromStatus && STATUS_LABEL[a.fromStatus]} <ArrowRight className="size-3 text-slate-400" aria-hidden /> {a.toStatus && STATUS_LABEL[a.toStatus]}
        </span>
      );
    default:
      return 'updated';
  }
}

const ICON: Record<string, { Icon: LucideIcon; cls: string }> = {
  created: { Icon: PlusCircle, cls: 'bg-sky-50 text-sky-600 ring-sky-200' },
  assigned: { Icon: UserCheck, cls: 'bg-brand-50 text-brand-600 ring-brand-200' },
  unassigned: { Icon: UserMinus, cls: 'bg-amber-50 text-amber-600 ring-amber-200' },
  status_changed: { Icon: RefreshCcw, cls: 'bg-violet-50 text-violet-600 ring-violet-200' },
  resolution_updated: { Icon: FileCheck2, cls: 'bg-emerald-50 text-emerald-600 ring-emerald-200' },
};

export function ActivityFeed({ items, linkBase }: { items: ActivityItem[]; linkBase: string }) {
  if (!items.length)
    return (
      <EmptyState compact icon={<History />} title="No recent ticket activity">
        Reports, assignments and status changes will show up here.
      </EmptyState>
    );
  return (
    <ol className="relative px-5 py-3">
      <span aria-hidden className="absolute bottom-6 left-[34px] top-6 w-px bg-slate-200" />
      {items.map((a, i) => {
        const { Icon, cls } = ICON[a.type] ?? { Icon: CircleDot, cls: 'bg-slate-50 text-slate-500 ring-slate-200' };
        return (
          <li key={`${a.ticketId}-${i}`} className="relative flex gap-3 py-2 text-sm">
            <span className={`relative z-10 mt-0.5 flex size-[30px] shrink-0 items-center justify-center rounded-full ring-1 ring-inset ${cls}`} aria-hidden>
              <Icon className="size-3.5" />
            </span>
            <div className="min-w-0">
              <p className="leading-snug">
                <Link to={`${linkBase}/${a.ticketId}`} className="font-mono text-xs font-semibold text-brand-700 hover:underline">{a.ticketNumber}</Link>
                <span className="mx-1.5 rounded bg-slate-100 px-1 py-px font-mono text-[11px] text-slate-600">{a.equipmentCode}</span>
                <span className="text-slate-700">{describe(a)}</span>
              </p>
              <p className="mt-0.5 text-xs text-slate-500">{a.actorName} · {timeAgo(a.at)}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
