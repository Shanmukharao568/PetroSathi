import { api, type ApiSuccess } from '../../lib/api';
import type { AppNotification, Severity, Ticket, TicketStatus } from '../../types/domain';
import type { DraftState } from '../complaints/complaintsApi';

export interface ActivityItem {
  ticketId: string;
  ticketNumber: string;
  equipmentCode: string;
  type: 'created' | 'status_changed' | 'assigned' | 'unassigned' | 'resolution_updated';
  at: string;
  fromStatus: TicketStatus | null;
  toStatus: TicketStatus | null;
  actorName: string;
  comment: string | null;
}

export interface OperatorDashboardData {
  role: 'operator';
  counts: { total: number; active: number; resolved: number; byStatus: Record<TicketStatus, number> };
  recentTickets: (Pick<Ticket, 'id' | 'ticketNumber' | 'equipmentCode' | 'description' | 'severity' | 'status' | 'createdAt' | 'updatedAt'> & { assignedTo: { name: string } | null })[];
  openDrafts: { id: string; state: DraftState; equipmentCode: string | null; description: string; updatedAt: string; expiresAt: string }[];
  notifications: AppNotification[];
}

export interface EngineerDashboardData {
  role: 'engineer';
  counts: {
    assignedTotal: number;
    open: number;
    underInspection: number;
    inProgress: number;
    resolved: number;
    closed: number;
    criticalAssigned: number;
    unassigned: number;
    unassignedCritical: number;
    resolvedByMeLast30Days: number;
  };
  queue: { id: string; ticketNumber: string; equipmentCode: string; description: string; severity: Severity; status: TicketStatus; assignedToMe: boolean; createdAt: string }[];
  recentActivity: ActivityItem[];
  notifications: AppNotification[];
}

export interface OverviewData {
  tickets: {
    total: number;
    active: number;
    byStatus: Record<TicketStatus, number>;
    activeBySeverity: Record<Severity, number>;
    unassignedActive: number;
    createdInRange: number;
    resolvedInRange: number;
    bySource: { voice: number; manual: number };
  };
  resolution: { averageHours: number | null; resolvedCount: number; bySeverity: { severity: Severity; averageHours: number | null; resolvedCount: number }[] };
  users: Record<'operator' | 'engineer' | 'admin', { active: number; inactive: number }>;
  equipment: { total: number; byStatus: Record<string, number> };
  documents: { byStatus: Record<'pending' | 'processing' | 'ready' | 'failed', number>; indexedPassages: number };
  openComplaintDrafts: number;
}

export interface AuditEntry {
  id: string;
  action: string;
  entityType: string;
  entityId: string | null;
  metadata: Record<string, unknown>;
  ip: string | null;
  createdAt: string;
  actorId: { id?: string; _id?: string; name: string; email?: string; role?: string } | null;
}

export interface AdminDashboardData {
  role: 'admin';
  summary: OverviewData;
  recentAudit: AuditEntry[];
  recentActivity: ActivityItem[];
}

export type DashboardData = OperatorDashboardData | EngineerDashboardData | AdminDashboardData;

export async function getDashboard() {
  return (await api.get<ApiSuccess<DashboardData>>('/dashboard')).data.data;
}
