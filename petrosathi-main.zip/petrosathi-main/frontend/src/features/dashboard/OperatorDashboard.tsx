import { DashboardHero } from '../../components/ui/DashboardHero';
import { Link } from 'react-router';
import { Activity, ArrowRight, Bell, BellOff, CheckCircle2, ChevronRight, ClipboardList, FilePen } from 'lucide-react';
import clsx from 'clsx';
import { Card, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/ui/EmptyState';
import { cardLinkClass, nudgeArrowClass } from '../../components/ui/styles';
import { StatTile } from '../../components/charts/StatTile';
import { SeverityBadge, StatusBadge } from '../../components/tickets/Badges';
import { timeAgo } from '../../lib/format';
import { VoiceReportCard } from '../voice/VoiceReportCard';
import { STATE_LABEL } from '../complaints/complaintsApi';
import { greeting, todayLabel } from './greeting';
import type { OperatorDashboardData } from './dashboardApi';

export function OperatorDashboard({ data, firstName }: { data: OperatorDashboardData; firstName: string }) {
  const { counts } = data;
  return (
    <>
      <DashboardHero
        eyebrow={todayLabel()}
        title={`${greeting()}, ${firstName}`}
        description="Report equipment problems by voice and follow your tickets."
      />
      <div className="stagger grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_22rem] [--stagger-step:120ms]">
        <div className="stagger space-y-6 [--stagger-step:90ms]">
          <VoiceReportCard title="Report an issue" />

          <Card>
            <CardHeader
              icon={<ClipboardList />}
              title="Your tickets"
              description="Latest updates on what you have reported."
              actions={
                <Link to="/operator/tickets" className={cardLinkClass()}>
                  All tickets <ArrowRight className={nudgeArrowClass} aria-hidden />
                </Link>
              }
            />
            {data.recentTickets.length === 0 ? (
              <EmptyState compact icon={<ClipboardList />} title="You have not reported any issues yet.">
                Hold the microphone above and describe the fault. A ticket is created once you confirm it.
              </EmptyState>
            ) : (
              <ul className="stagger divide-y divide-slate-100 [--stagger-step:45ms]">
                {data.recentTickets.map((t) => (
                  <li key={t.id}>
                    <Link
                      to={`/operator/tickets/${t.id}`}
                      className="group flex flex-wrap items-center gap-x-3 gap-y-1.5 px-5 py-3.5 text-sm transition-colors hover:bg-slate-50/80"
                    >
                      <span className="font-mono text-[13px] font-semibold text-brand-700">{t.ticketNumber}</span>
                      <span className="rounded bg-slate-100 px-1.5 py-px font-mono text-xs text-slate-600">{t.equipmentCode}</span>
                      <span className="min-w-0 basis-full truncate text-slate-700 sm:basis-auto sm:flex-1">{t.description}</span>
                      <SeverityBadge severity={t.severity} />
                      <StatusBadge status={t.status} />
                      <span className="w-16 text-right text-xs tabular-nums text-slate-500">{timeAgo(t.updatedAt)}</span>
                      <ChevronRight className="hidden size-4 text-slate-300 transition-transform group-hover:translate-x-0.5 group-hover:text-slate-500 sm:block" aria-hidden />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="stagger space-y-6 [--stagger-step:90ms]">
          <div className="stagger grid grid-cols-1 gap-3 sm:grid-cols-3 xl:grid-cols-1">
            <StatTile glyph={Activity} accent="sky" label="Open tickets" value={counts.active} to="/operator/tickets" note="Being handled by maintenance" />
            <StatTile glyph={CheckCircle2} accent="emerald" label="Resolved" value={counts.resolved} to="/operator/tickets" />
            <StatTile glyph={ClipboardList} accent="violet" label="Reported in total" value={counts.total} />
          </div>

          {data.openDrafts.length > 0 && (
            <Card className="border-amber-200/80">
              <CardHeader icon={<FilePen />} title="Unfinished reports" description="Pick up where you left off." />
              <ul className="stagger divide-y divide-slate-100 [--stagger-step:45ms]">
                {data.openDrafts.map((d) => (
                  <li key={d.id}>
                    <Link to={`/operator/drafts/${d.id}`} className="block px-5 py-3 text-sm transition-colors hover:bg-slate-50/80">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[13px] font-semibold text-navy-900">{d.equipmentCode ?? '—'}</span>
                        <Badge tone={d.state === 'READY_FOR_CONFIRMATION' ? 'success' : 'warning'}>{STATE_LABEL[d.state]}</Badge>
                      </div>
                      <p className="mt-1 truncate text-slate-600">{d.description}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          <Card>
            <CardHeader icon={<Bell />} title="Recent activity" />
            {data.notifications.length === 0 ? (
              <EmptyState compact icon={<BellOff />} title="No updates yet.">
                You will be notified when an engineer picks up or resolves your ticket.
              </EmptyState>
            ) : (
              <ul className="stagger divide-y divide-slate-100 [--stagger-step:45ms]">
                {data.notifications.map((n) => (
                  <li key={n.id} className="flex gap-3 px-5 py-3 text-sm">
                    <span className={clsx('mt-1.5 size-2 shrink-0 rounded-full', n.isRead ? 'bg-slate-200' : 'bg-brand-500 shadow-[0_0_0_3px_var(--color-brand-100)]')} aria-hidden />
                    <span className="min-w-0">
                      <span className={n.isRead ? 'text-slate-600' : 'font-medium text-slate-900'}>{n.message}</span>
                      <span className="mt-0.5 block text-xs text-slate-500">{timeAgo(n.createdAt)}</span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
