import { useCallback, useEffect, useState } from 'react';
import { Activity, AlertOctagon, CheckCircle2, FilePlus2, Siren, Timer } from 'lucide-react';
import { Card, CardHeader, PageHeader } from '../../components/ui/Card';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Spinner } from '../../components/ui/Spinner';
import { ChartCard } from '../../components/charts/ChartCard';
import { StatTile } from '../../components/charts/StatTile';
import { HBarChart, type BarDatum } from '../../components/charts/HBarChart';
import { TrendChart } from '../../components/charts/TrendChart';
import { CHART, SEVERITY_RAMP } from '../../components/charts/chartTheme';
import { toApiError } from '../../lib/api';
import { CATEGORY_LABEL, SEVERITY_LABEL, STATUS_LABEL, equipmentTypeLabel, formatDateTime, humanize } from '../../lib/format';
import { COMPLAINT_CATEGORIES, TICKET_STATUSES, type EquipmentType, type Severity } from '../../types/domain';
import { getEquipmentAnalytics, getOverview, getTicketAnalytics, type EquipmentAnalytics, type TicketAnalytics } from './analyticsApi';
import type { OverviewData } from '../dashboard/dashboardApi';
import { DateRangeFilter, rangeForPreset, type PresetKey } from './DateRangeFilter';

/** Ordered high → low so the most severe reads first; "Not assessed" is off-scale and last. */
const SEVERITY_ORDER: Severity[] = ['critical', 'high', 'medium', 'low', 'unknown'];

export function AnalyticsPage() {
  const [filter, setFilter] = useState<{ preset: PresetKey; range: { from: string; to: string } }>({ preset: '12m', range: rangeForPreset('12m') });
  const [tickets, setTickets] = useState<TicketAnalytics | null>(null);
  const [equipment, setEquipment] = useState<EquipmentAnalytics | null>(null);
  const [overview, setOverview] = useState<OverviewData | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const [t, e, o] = await Promise.all([getTicketAnalytics(filter.range), getEquipmentAnalytics(filter.range), getOverview(filter.range)]);
      setTickets(t);
      setEquipment(e);
      setOverview(o);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  }, [filter.range]);

  useEffect(() => void load(), [load]);

  if (!tickets || !equipment || !overview) {
    return (
      <>
        <PageHeader eyebrow="Insights" title="Analytics" />
        {error ? <Alert tone="error">{error}</Alert> : <Spinner label="Loading analytics…" />}
      </>
    );
  }

  const created = tickets.monthly.reduce((n, m) => n + m.created, 0);
  const resolved = tickets.monthly.reduce((n, m) => n + m.resolved, 0);

  const statusBars: BarDatum[] = TICKET_STATUSES.map((s) => ({ label: STATUS_LABEL[s], value: tickets.byStatus[s] }));
  const severityBars: BarDatum[] = SEVERITY_ORDER.map((s) => ({ label: SEVERITY_LABEL[s], value: tickets.bySeverity[s], color: SEVERITY_RAMP[s] }));
  const categoryBars: BarDatum[] = [...COMPLAINT_CATEGORIES]
    .map((c) => ({ label: CATEGORY_LABEL[c], value: tickets.byCategory[c] }))
    .sort((a, b) => (b.value ?? 0) - (a.value ?? 0));
  const equipmentBars: BarDatum[] = equipment.topEquipment.map((e) => ({ label: e.equipmentCode, value: e.total, detail: `${e.name ?? ''} · ${e.active} active · ${e.critical} critical` }));
  const resolutionBars: BarDatum[] = SEVERITY_ORDER.map((s) => {
    const r = tickets.resolution.bySeverity.find((x) => x.severity === s);
    return { label: SEVERITY_LABEL[s], value: r?.averageHours ?? null, color: SEVERITY_RAMP[s], detail: r?.resolvedCount ? `${r.resolvedCount} resolved` : 'None resolved' };
  });
  const noResolution = resolutionBars.filter((b) => b.value === null).map((b) => b.label);

  return (
    <>
      <PageHeader eyebrow="Insights" title="Analytics" description={`Computed live from tickets and equipment. Months in ${tickets.timezone}.`} />
      <DateRangeFilter value={filter} onChange={setFilter} />
      {error && <Alert tone="error" className="mb-4">{error}</Alert>}

      <div className={`mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5 transition-opacity ${busy ? 'opacity-50' : ''}`}>
        <StatTile glyph={FilePlus2} accent="sky" label="Tickets created" value={created} note="In the selected period" />
        <StatTile glyph={CheckCircle2} accent="emerald" label="Tickets resolved" value={resolved} note="In the selected period" />
        <StatTile glyph={Timer} accent="brand" label="Average resolution" value={tickets.resolution.averageHours} unit="h" note={tickets.resolution.resolvedCount ? `Across ${tickets.resolution.resolvedCount} resolved` : 'Nothing resolved in this period'} />
        <StatTile glyph={Activity} accent="violet" label="Active now" value={overview.tickets.active} note={`${overview.tickets.unassignedActive} unassigned`} />
        <StatTile glyph={Siren} accent="rose" label="Critical, active now" value={overview.tickets.activeBySeverity.critical} tone="alert" icon={overview.tickets.activeBySeverity.critical ? <AlertOctagon className="size-3.5 text-red-600" aria-hidden /> : undefined} />
      </div>

      <div className="space-y-6">
        <ChartCard
          title="Monthly ticket trend"
          description="Tickets created and resolved per month"
          busy={busy}
          table={{ columns: ['Month', 'Created', 'Resolved'], rows: tickets.monthly.map((m) => [m.month, m.created, m.resolved]) }}
        >
          <TrendChart
            data={tickets.monthly}
            series={[
              { key: 'created', name: 'Created', slot: 0 },
              { key: 'resolved', name: 'Resolved', slot: 1 },
            ]}
          />
        </ChartCard>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <ChartCard title="Tickets by status" description="Current status of tickets created in the period" busy={busy} table={{ columns: ['Status', 'Tickets'], rows: statusBars.map((b) => [b.label, b.value ?? 0]) }}>
            <HBarChart data={statusBars} />
          </ChartCard>
          <ChartCard title="Tickets by severity" description="Darker = more severe; grey = not assessed" busy={busy} table={{ columns: ['Severity', 'Tickets'], rows: severityBars.map((b) => [b.label, b.value ?? 0]) }}>
            <HBarChart data={severityBars} />
          </ChartCard>
          <ChartCard title="Complaints by category" busy={busy} table={{ columns: ['Category', 'Tickets'], rows: categoryBars.map((b) => [b.label, b.value ?? 0]) }}>
            <HBarChart data={categoryBars} />
          </ChartCard>
          <ChartCard
            title="Average resolution time by severity"
            description={noResolution.length ? `No resolved tickets for: ${noResolution.join(', ')}` : 'Hours from report to resolution'}
            busy={busy}
            table={{ columns: ['Severity', 'Average hours', 'Resolved'], rows: tickets.resolution.bySeverity.map((r) => [SEVERITY_LABEL[r.severity], r.averageHours ?? '—', r.resolvedCount]) }}
          >
            <HBarChart data={resolutionBars} unit="h" valueName="Average" emptyText="No tickets were resolved in this period." />
          </ChartCard>
          <ChartCard
            title="Complaints per equipment"
            description="Top 10 by tickets in the period"
            busy={busy}
            table={{ columns: ['Equipment', 'Name', 'Tickets', 'Active', 'Critical'], rows: equipment.topEquipment.map((e) => [e.equipmentCode, e.name ?? '—', e.total, e.active, e.critical]) }}
          >
            <HBarChart data={equipmentBars} />
          </ChartCard>
          <ChartCard
            title="Complaints by equipment type"
            busy={busy}
            table={{ columns: ['Type', 'Tickets'], rows: equipment.byEquipmentType.map((t) => [t.type === 'unknown' ? 'Unknown' : equipmentTypeLabel(t.type as EquipmentType), t.count]) }}
          >
            <HBarChart data={equipment.byEquipmentType.map((t) => ({ label: t.type === 'unknown' ? 'Unknown' : equipmentTypeLabel(t.type as EquipmentType), value: t.count }))} />
          </ChartCard>
        </div>

        <Card className={busy ? 'opacity-50' : ''}>
          <CardHeader title="Recurring equipment issues" description="Equipment reported two or more times in the period" />
          {equipment.recurringIssues.length === 0 ? (
            <p className="px-5 py-6 text-sm text-slate-500">No equipment was reported more than once in this period.</p>
          ) : (
            <div className="relative overflow-x-auto">
              <table className="data-table w-full text-left text-sm">
                <thead>
                  <tr>
                    <th scope="col" className="px-4 py-2">Equipment</th>
                    <th scope="col" className="px-4 py-2">Complaints</th>
                    <th scope="col" className="px-4 py-2">Most reported symptoms</th>
                    <th scope="col" className="px-4 py-2">Categories</th>
                    <th scope="col" className="px-4 py-2">Last reported</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {equipment.recurringIssues.map((r) => (
                    <tr key={r.equipmentId}>
                      <td className="px-4 py-2.5">
                        <span className="font-mono font-medium text-navy-900">{r.equipmentCode}</span>
                        {r.name && <span className="block text-xs text-slate-500">{r.name}</span>}
                      </td>
                      <td className="px-4 py-2.5 tabular-nums">{r.count}</td>
                      <td className="px-4 py-2.5">
                        <div className="flex flex-wrap gap-1">
                          {r.topSymptoms.length ? r.topSymptoms.map((s) => <Badge key={s.symptom}>{s.symptom} × {s.count}</Badge>) : <span className="text-slate-400">—</span>}
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-slate-600">{r.categories.map((c) => humanize(c)).join(', ')}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatDateTime(r.lastReportedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
        <p className="text-xs text-slate-500">
          Severity colours use a single-hue ramp (<span style={{ color: CHART.inkSecondary }}>light = low, dark = critical</span>); every chart has a table view.
        </p>
      </div>
    </>
  );
}
