import { api, type ApiSuccess, type Pagination } from '../../lib/api';
import type { ComplaintCategory, Severity, TicketStatus } from '../../types/domain';
import type { AuditEntry, OverviewData } from '../dashboard/dashboardApi';

export interface TicketAnalytics {
  timezone: string;
  monthly: { month: string; created: number; resolved: number }[];
  byStatus: Record<TicketStatus, number>;
  bySeverity: Record<Severity, number>;
  byCategory: Record<ComplaintCategory, number>;
  resolution: OverviewData['resolution'];
}

export interface EquipmentAnalytics {
  topEquipment: { equipmentId: string; equipmentCode: string; name?: string; type?: string; total: number; active: number; critical: number }[];
  recurringIssues: { equipmentId: string; equipmentCode: string; name?: string; type?: string; count: number; lastReportedAt: string; categories: ComplaintCategory[]; topSymptoms: { symptom: string; count: number }[] }[];
  byEquipmentType: { type: string; count: number }[];
}

export interface RangeParams {
  from: string;
  to: string;
}

export async function getTicketAnalytics(p: RangeParams) {
  return (await api.get<ApiSuccess<TicketAnalytics>>('/analytics/tickets', { params: p })).data.data;
}
export async function getEquipmentAnalytics(p: RangeParams) {
  return (await api.get<ApiSuccess<EquipmentAnalytics>>('/analytics/equipment', { params: { ...p, limit: 10 } })).data.data;
}
export async function getOverview(p: RangeParams) {
  return (await api.get<ApiSuccess<OverviewData>>('/analytics/overview', { params: p })).data.data;
}

export interface AuditQuery {
  page: number;
  limit: number;
  action?: string;
  entityType?: string;
  from?: string;
  to?: string;
}
export async function listAuditLogs(q: AuditQuery) {
  const res = await api.get<ApiSuccess<AuditEntry[]>>('/audit-logs', { params: q });
  return { items: res.data.data, pagination: res.data.meta?.pagination as Pagination };
}
export async function getAuditFacets() {
  return (await api.get<ApiSuccess<{ actions: string[]; entityTypes: string[] }>>('/audit-logs/facets')).data.data;
}
