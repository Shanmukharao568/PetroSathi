import { useCallback, useEffect, useState } from 'react';
import { ScrollText, ChevronDown, ChevronRight } from 'lucide-react';
import { EmptyState } from '../../components/ui/EmptyState';
import { Card, PageHeader } from '../../components/ui/Card';
import { Select } from '../../components/ui/Select';
import { Alert } from '../../components/ui/Alert';
import { Spinner } from '../../components/ui/Spinner';
import { Pager } from '../../components/ui/Pager';
import { Button } from '../../components/ui/Button';
import { toApiError, type Pagination } from '../../lib/api';
import { formatDateTime, humanize } from '../../lib/format';
import type { AuditEntry } from '../dashboard/dashboardApi';
import { getAuditFacets, listAuditLogs, type AuditQuery } from './analyticsApi';

/** Short, human-readable metadata summary; the full JSON is available on expand. */
function summarise(meta: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(meta ?? {})) {
    if (v === null || v === undefined) continue;
    if (typeof v === 'object') parts.push(`${k}: …`);
    else parts.push(`${k}: ${String(v)}`);
    if (parts.length >= 3) break;
  }
  return parts.join(' · ');
}

export function AuditLogsPage() {
  const [facets, setFacets] = useState<{ actions: string[]; entityTypes: string[] }>({ actions: [], entityTypes: [] });
  const [items, setItems] = useState<AuditEntry[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [q, setQ] = useState<AuditQuery>({ page: 1, limit: 25 });
  const [draft, setDraft] = useState({ action: '', entityType: '', from: '', to: '' });

  useEffect(() => {
    getAuditFacets().then(setFacets).catch(() => undefined);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await listAuditLogs(q);
      setItems(r.items);
      setPagination(r.pagination);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setLoading(false);
    }
  }, [q]);

  useEffect(() => void load(), [load]);

  const prefixes = [...new Set(facets.actions.map((a) => `${a.split('.')[0]}.`))];
  const apply = () =>
    setQ({
      page: 1,
      limit: 25,
      ...(draft.action && { action: draft.action }),
      ...(draft.entityType && { entityType: draft.entityType }),
      ...(draft.from && { from: draft.from }),
      ...(draft.to && { to: draft.to }),
    });
  const invalidRange = !!draft.from && !!draft.to && draft.from > draft.to;

  return (
    <>
      <PageHeader eyebrow="Administration" title="Audit logs" description="Who did what, and when. Entries cannot be edited." />
      <div className="mb-6 flex flex-wrap items-end gap-3">
        <div className="w-56">
          <Select
            label="Action"
            value={draft.action}
            onChange={(e) => setDraft({ ...draft, action: e.target.value })}
            options={[
              { value: '', label: 'All actions' },
              ...prefixes.map((p) => ({ value: p, label: `All ${humanize(p.slice(0, -1))} actions` })),
              ...facets.actions.map((a) => ({ value: a, label: a })),
            ]}
          />
        </div>
        <div className="w-44">
          <Select label="Entity" value={draft.entityType} onChange={(e) => setDraft({ ...draft, entityType: e.target.value })} options={[{ value: '', label: 'All entities' }, ...facets.entityTypes.map((t) => ({ value: t, label: t }))]} />
        </div>
        <label className="text-sm">
          <span className="mb-1.5 block font-medium text-slate-700">From</span>
          <input type="date" value={draft.from} onChange={(e) => setDraft({ ...draft, from: e.target.value })} className="h-10 rounded-lg border border-slate-300 px-3 text-sm shadow-sm" />
        </label>
        <label className="text-sm">
          <span className="mb-1.5 block font-medium text-slate-700">To</span>
          <input type="date" value={draft.to} onChange={(e) => setDraft({ ...draft, to: e.target.value })} className="h-10 rounded-lg border border-slate-300 px-3 text-sm shadow-sm" />
        </label>
        <Button onClick={apply} disabled={invalidRange}>Apply</Button>
        <Button
          variant="ghost"
          onClick={() => {
            setDraft({ action: '', entityType: '', from: '', to: '' });
            setQ({ page: 1, limit: 25 });
          }}
        >
          Reset
        </Button>
      </div>
      {invalidRange && <Alert tone="warning" className="mb-4">"From" must be on or before "To".</Alert>}

      <Card>
        {error && <div className="p-4"><Alert tone="error">{error}</Alert></div>}
        <div className={`relative overflow-x-auto ${loading && items.length ? 'opacity-50' : ''}`}>
          <table className="data-table w-full text-left text-sm">
            <thead>
              <tr>
                <th scope="col" className="w-8 px-2 py-3" />
                <th scope="col" className="px-3 py-3">Time</th>
                <th scope="col" className="px-3 py-3">Actor</th>
                <th scope="col" className="px-3 py-3">Action</th>
                <th scope="col" className="px-3 py-3">Entity</th>
                <th scope="col" className="px-3 py-3">Details</th>
              </tr>
            </thead>
            <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
              {loading && !items.length ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center"><Spinner label="Loading audit log…" /></td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={6}><EmptyState icon={<ScrollText />} title="No entries match these filters." /></td></tr>
              ) : (
                items.flatMap((a) => {
                  const open = expanded === a.id;
                  const rows = [
                    <tr key={a.id} className="align-top hover:bg-slate-50/80">
                      <td className="px-2 py-2.5">
                        <button type="button" onClick={() => setExpanded(open ? null : a.id)} className="rounded p-0.5 text-slate-400 hover:bg-slate-100" aria-expanded={open} aria-label="Show details">
                          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                        </button>
                      </td>
                      <td className="whitespace-nowrap px-3 py-2.5 tabular-nums text-slate-600">{formatDateTime(a.createdAt)}</td>
                      <td className="px-3 py-2.5">
                        {a.actorId ? (
                          <>
                            <span className="text-slate-900">{a.actorId.name}</span>
                            {a.actorId.role && <span className="block text-xs text-slate-500">{humanize(a.actorId.role)}</span>}
                          </>
                        ) : (
                          <span className="text-slate-500">Anonymous / system</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-xs text-navy-900">{a.action}</td>
                      <td className="px-3 py-2.5 text-slate-600">
                        {a.entityType}
                        {a.entityId && <span className="block font-mono text-xs text-slate-400">…{a.entityId.slice(-6)}</span>}
                      </td>
                      <td className="max-w-md px-3 py-2.5 text-xs text-slate-600">{summarise(a.metadata) || '—'}</td>
                    </tr>,
                  ];
                  if (open) {
                    rows.push(
                      <tr key={`${a.id}-d`} className="bg-slate-50/60">
                        <td />
                        <td colSpan={5} className="px-3 py-3">
                          <pre className="relative overflow-x-auto whitespace-pre-wrap break-all rounded-md bg-white p-3 text-xs text-slate-700 ring-1 ring-slate-200">
                            {JSON.stringify({ entityId: a.entityId, ip: a.ip, metadata: a.metadata }, null, 2)}
                          </pre>
                        </td>
                      </tr>,
                    );
                  }
                  return rows;
                })
              )}
            </tbody>
          </table>
        </div>
        <Pager pagination={pagination} noun="entry" onPage={(page) => setQ({ ...q, page })} />
      </Card>
    </>
  );
}
