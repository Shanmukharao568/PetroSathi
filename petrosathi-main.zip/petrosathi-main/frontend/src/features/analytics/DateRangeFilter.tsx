import { useState } from 'react';
import { Select } from '../../components/ui/Select';
import { Button } from '../../components/ui/Button';
import type { RangeParams } from './analyticsApi';

/** Local calendar date "YYYY-MM-DD" (the server interprets it in ANALYTICS_TIMEZONE). */
export const isoDay = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export const PRESETS = [
  { key: '30d', label: 'Last 30 days', days: 30 },
  { key: '90d', label: 'Last 90 days', days: 90 },
  { key: '6m', label: 'Last 6 months', months: 6 },
  { key: '12m', label: 'Last 12 months', months: 12 },
  { key: 'custom', label: 'Custom range…' },
] as const;
export type PresetKey = (typeof PRESETS)[number]['key'];

export function rangeForPreset(key: Exclude<PresetKey, 'custom'>, now = new Date()): RangeParams {
  const p = PRESETS.find((x) => x.key === key)!;
  const from = new Date(now);
  if ('days' in p) from.setDate(from.getDate() - (p.days - 1));
  else if ('months' in p) from.setMonth(from.getMonth() - (p.months - 1), 1);
  return { from: isoDay(from), to: isoDay(now) };
}

/** Single filter row above everything it scopes: presets first, custom range behind the last option. */
export function DateRangeFilter({ value, onChange }: { value: { preset: PresetKey; range: RangeParams }; onChange: (v: { preset: PresetKey; range: RangeParams }) => void }) {
  const [from, setFrom] = useState(value.range.from);
  const [to, setTo] = useState(value.range.to);
  const invalid = !from || !to || from > to;

  return (
    <div className="mb-6 flex flex-wrap items-end gap-3">
      <div className="w-48">
        <Select
          label="Period"
          value={value.preset}
          onChange={(e) => {
            const preset = e.target.value as PresetKey;
            if (preset === 'custom') onChange({ preset, range: value.range });
            else onChange({ preset, range: rangeForPreset(preset) });
          }}
          options={PRESETS.map((p) => ({ value: p.key, label: p.label }))}
        />
      </div>
      {value.preset === 'custom' && (
        <>
          <label className="text-sm">
            <span className="mb-1.5 block font-medium text-slate-700">From</span>
            <input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} className="h-11 rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
          </label>
          <label className="text-sm">
            <span className="mb-1.5 block font-medium text-slate-700">To</span>
            <input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} className="h-11 rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
          </label>
          <Button disabled={invalid} onClick={() => onChange({ preset: 'custom', range: { from, to } })}>Apply</Button>
        </>
      )}
      <p className="pb-2 text-xs text-slate-500">
        {value.range.from} → {value.range.to}
      </p>
    </div>
  );
}
