import { useCallback, useEffect, useState } from 'react';
import { Users, ChevronLeft, ChevronRight, Pencil, Plus, Search } from 'lucide-react';
import { EmptyState } from '../../../components/ui/EmptyState';
import { Card, PageHeader } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import { Badge } from '../../../components/ui/Badge';
import { Select } from '../../../components/ui/Select';
import { Alert } from '../../../components/ui/Alert';
import { Spinner } from '../../../components/ui/Spinner';
import { toApiError, type Pagination } from '../../../lib/api';
import { languageLabel } from '../../../lib/validation';
import { useAuthStore } from '../../../store/authStore';
import { ROLE_LABEL, ROLES, type Role, type User } from '../../../types/auth';
import { listUsers } from './usersApi';
import { CreateUserModal } from './CreateUserModal';
import { EditUserModal } from './EditUserModal';

const PAGE_SIZE = 20;

const roleTone: Record<Role, 'info' | 'neutral' | 'warning'> = { admin: 'warning', engineer: 'info', operator: 'neutral' };

function formatDate(iso: string | null) {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso));
}

export function UsersPage() {
  const me = useAuthStore((s) => s.user)!;
  const [items, setItems] = useState<User[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [role, setRole] = useState<'' | Role>('');
  const [status, setStatus] = useState<'' | 'true' | 'false'>('');

  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<User | null>(null);

  // Debounce search input
  useEffect(() => {
    const t = window.setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 300);
    return () => window.clearTimeout(t);
  }, [searchInput]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await listUsers({
        page,
        limit: PAGE_SIZE,
        ...(role ? { role } : {}),
        ...(status ? { isActive: status === 'true' } : {}),
        ...(search ? { search } : {}),
      });
      setItems(r.items);
      setPagination(r.pagination);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setLoading(false);
    }
  }, [page, role, status, search]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <PageHeader
        eyebrow="Administration"
        title="Users"
        description="Create accounts, manage roles and access. People who sign up themselves join as Field Operators."
        actions={
          <Button onClick={() => setCreating(true)}>
            <Plus className="size-4" aria-hidden /> Create user
          </Button>
        }
      />

      <Card>
        <div className="flex flex-wrap items-end gap-3 border-b border-slate-100 p-4">
          <label className="relative min-w-56 flex-1">
            <span className="sr-only">Search users</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search name or email"
              className="h-11 w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none"
            />
          </label>
          <div className="w-44">
            <Select
              aria-label="Filter by role"
              value={role}
              onChange={(e) => {
                setRole(e.target.value as '' | Role);
                setPage(1);
              }}
              options={[{ value: '', label: 'All roles' }, ...ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] }))]}
            />
          </div>
          <div className="w-40">
            <Select
              aria-label="Filter by status"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value as '' | 'true' | 'false');
                setPage(1);
              }}
              options={[
                { value: '', label: 'All statuses' },
                { value: 'true', label: 'Active' },
                { value: 'false', label: 'Deactivated' },
              ]}
            />
          </div>
        </div>

        {error && (
          <div className="p-4">
            <Alert tone="error">{error}</Alert>
          </div>
        )}

        <div className="relative overflow-x-auto">
          <table className="data-table w-full text-left text-sm">
            <thead>
              <tr>
                <th scope="col" className="px-4 py-3">User</th>
                <th scope="col" className="px-4 py-3">Role</th>
                <th scope="col" className="px-4 py-3">Language</th>
                <th scope="col" className="px-4 py-3">Status</th>
                <th scope="col" className="px-4 py-3">Last sign-in</th>
                <th scope="col" className="px-4 py-3"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
              {loading && items.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center">
                    <Spinner label="Loading users…" />
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={6}><EmptyState icon={<Users />} title="No users match these filters." /></td>
                </tr>
              ) : (
                items.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/80">
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">
                        {u.name} {u.id === me.id && <span className="text-xs font-normal text-slate-400">(you)</span>}
                      </div>
                      <div className="text-slate-500">{u.email}</div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={roleTone[u.role]}>{ROLE_LABEL[u.role]}</Badge>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{languageLabel(u.preferredLanguage)}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        <Badge tone={u.isActive ? 'success' : 'danger'}>{u.isActive ? 'Active' : 'Deactivated'}</Badge>
                        {u.mustChangePassword && <Badge tone="warning">Temp password</Badge>}
                        {u.emailVerified === false && <Badge tone="neutral">Email not verified</Badge>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{formatDate(u.lastLoginAt)}</td>
                    <td className="px-4 py-3 text-right">
                      <Button size="sm" variant="ghost" onClick={() => setEditing(u)} aria-label={`Edit ${u.name}`}>
                        <Pencil className="size-4" aria-hidden /> Edit
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {pagination && pagination.total > 0 && (
          <div className="flex items-center justify-between gap-3 border-t border-slate-100 px-4 py-3 text-sm text-slate-600">
            <span>
              {pagination.total} user{pagination.total === 1 ? '' : 's'} · page {pagination.page} of {pagination.totalPages}
            </span>
            <div className="flex gap-1">
              <Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} aria-label="Previous page">
                <ChevronLeft className="size-4" />
              </Button>
              <Button
                size="sm"
                variant="secondary"
                disabled={page >= pagination.totalPages}
                onClick={() => setPage((p) => p + 1)}
                aria-label="Next page"
              >
                <ChevronRight className="size-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      <CreateUserModal open={creating} onClose={() => setCreating(false)} onCreated={() => void load()} />
      <EditUserModal user={editing} isSelf={editing?.id === me.id} onClose={() => setEditing(null)} onSaved={() => void load()} />
    </>
  );
}
