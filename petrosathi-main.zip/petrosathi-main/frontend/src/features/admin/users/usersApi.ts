import { api, type ApiSuccess, type Pagination } from '../../../lib/api';
import type { Role, User } from '../../../types/auth';

export interface UserListParams {
  page: number;
  limit: number;
  role?: Role;
  isActive?: boolean;
  search?: string;
}

export async function listUsers(params: UserListParams) {
  const res = await api.get<ApiSuccess<User[]>>('/users', { params });
  return { items: res.data.data, pagination: res.data.meta?.pagination as Pagination };
}

export async function createUser(body: { name: string; email: string; role: Role; preferredLanguage: string }) {
  const res = await api.post<ApiSuccess<{ user: User; temporaryPassword: string }>>('/users', body);
  return res.data.data;
}

export async function updateUser(id: string, body: Partial<Pick<User, 'name' | 'role' | 'isActive' | 'preferredLanguage'>>) {
  const res = await api.patch<ApiSuccess<User>>(`/users/${id}`, body);
  return res.data.data;
}

export async function resetPassword(id: string) {
  const res = await api.patch<ApiSuccess<{ user: User; temporaryPassword: string }>>(`/users/${id}/password`, {});
  return res.data.data;
}
