import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { KeyRound } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import { Button } from '../../../components/ui/Button';
import { Alert } from '../../../components/ui/Alert';
import { toApiError } from '../../../lib/api';
import { PREFERRED_LANGUAGE_OPTIONS } from '../../../lib/validation';
import { ROLE_LABEL, ROLES, type User } from '../../../types/auth';
import { resetPassword, updateUser } from './usersApi';
import { TemporaryPasswordNotice } from './TemporaryPasswordNotice';

const schema = z.object({
  name: z.string().trim().min(2, 'At least 2 characters').max(100),
  role: z.enum(ROLES),
  preferredLanguage: z.string(),
  isActive: z.enum(['true', 'false']),
});
type Values = z.infer<typeof schema>;

export function EditUserModal({
  user,
  isSelf,
  onClose,
  onSaved,
}: {
  user: User | null;
  isSelf: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [serverError, setServerError] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<Values>({ resolver: zodResolver(schema) });

  useEffect(() => {
    if (user) {
      reset({ name: user.name, role: user.role, preferredLanguage: user.preferredLanguage, isActive: String(user.isActive) as 'true' | 'false' });
      setServerError(null);
      setConfirmReset(false);
      setTempPassword(null);
    }
  }, [user, reset]);

  if (!user) return null;

  const onSubmit = async (v: Values) => {
    setServerError(null);
    try {
      const body: Parameters<typeof updateUser>[1] = { name: v.name, preferredLanguage: v.preferredLanguage };
      // Only send admin-only fields when they changed (server rejects self role/status changes).
      if (v.role !== user.role) body.role = v.role;
      if ((v.isActive === 'true') !== user.isActive) body.isActive = v.isActive === 'true';
      await updateUser(user.id, body);
      onSaved();
      onClose();
    } catch (err) {
      setServerError(toApiError(err).message);
    }
  };

  const onReset = async () => {
    setResetting(true);
    setServerError(null);
    try {
      const r = await resetPassword(user.id);
      setTempPassword(r.temporaryPassword);
      onSaved();
    } catch (err) {
      setServerError(toApiError(err).message);
    } finally {
      setResetting(false);
      setConfirmReset(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={tempPassword ? 'Password reset' : `Edit ${user.name}`}
      description={tempPassword ? undefined : user.email}
      footer={
        tempPassword ? (
          <Button onClick={onClose}>Done</Button>
        ) : (
          <>
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" form="edit-user-form" loading={isSubmitting} disabled={!isDirty}>
              Save changes
            </Button>
          </>
        )
      }
    >
      {tempPassword ? (
        <TemporaryPasswordNotice email={user.email} password={tempPassword} />
      ) : (
        <form id="edit-user-form" onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
          <Input label="Full name" error={errors.name?.message} {...register('name')} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Select
              label="Role"
              disabled={isSelf}
              options={ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] }))}
              {...register('role')}
            />
            <Select
              label="Status"
              disabled={isSelf}
              options={[
                { value: 'true', label: 'Active' },
                { value: 'false', label: 'Deactivated' },
              ]}
              {...register('isActive')}
            />
          </div>
          <Select label="Preferred language" options={PREFERRED_LANGUAGE_OPTIONS} {...register('preferredLanguage')} />
          {isSelf && <p className="text-xs text-slate-500">You cannot change your own role or status.</p>}

          {!isSelf && (
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-sm font-medium text-slate-900">Reset password</p>
              <p className="mt-0.5 text-xs text-slate-500">
                Issues a new temporary password and signs the user out everywhere.
              </p>
              {confirmReset ? (
                <div className="mt-3 flex gap-2">
                  <Button size="sm" variant="danger" loading={resetting} onClick={() => void onReset()}>
                    Confirm reset
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setConfirmReset(false)}>
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button size="sm" variant="secondary" className="mt-3" onClick={() => setConfirmReset(true)}>
                  <KeyRound className="size-4" aria-hidden /> Reset password
                </Button>
              )}
            </div>
          )}

          {serverError && <Alert tone="error">{serverError}</Alert>}
        </form>
      )}
    </Modal>
  );
}
