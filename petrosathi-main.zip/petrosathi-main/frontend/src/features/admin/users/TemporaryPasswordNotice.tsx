import { useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { Alert } from '../../../components/ui/Alert';

/** Displays a one-time password. It is not stored anywhere client-side and cannot be shown again. */
export function TemporaryPasswordNotice({ email, password }: { email: string; password: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(password);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-3">
      <Alert tone="warning">
        This temporary password is shown <strong>only once</strong>. Share it with the user through a secure channel.
        They will be asked to set their own password at first sign-in.
      </Alert>
      <dl className="grid grid-cols-[6rem_1fr] gap-y-2 text-sm">
        <dt className="text-slate-500">Email</dt>
        <dd className="font-medium text-slate-900">{email}</dd>
        <dt className="self-center text-slate-500">Password</dt>
        <dd className="flex items-center gap-2">
          <code className="rounded-md bg-slate-100 px-2 py-1 font-mono text-sm text-navy-900 select-all">{password}</code>
          <button
            type="button"
            onClick={() => void copy()}
            className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-brand-700 hover:bg-brand-50"
          >
            {copied ? <Check className="size-3.5" aria-hidden /> : <Copy className="size-3.5" aria-hidden />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </dd>
      </dl>
    </div>
  );
}
