import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../../../components/ui/Modal';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import { Button } from '../../../components/ui/Button';
import { Alert } from '../../../components/ui/Alert';
import { toApiError } from '../../../lib/api';
import { PREFERRED_LANGUAGE_OPTIONS } from '../../../lib/validation';
import { ROLE_LABEL, ROLES } from '../../../types/auth';
import { createUser } from './usersApi';
import { TemporaryPasswordNotice } from './TemporaryPasswordNotice';

const schema = z.object({
  name: z.string().trim().min(2, 'At least 2 characters').max(100),
  email: z.email('Enter a valid email'),
  role: z.enum(ROLES),
  preferredLanguage: z.string(),
});
type Values = z.infer<typeof schema>;

export function CreateUserModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [serverError, setServerError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ email: string; password: string } | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { role: 'operator', preferredLanguage: 'en-IN' },
  });

  const close = () => {
    setCreated(null);
    setServerError(null);
    reset();
    onClose();
  };

  const onSubmit = async (values: Values) => {
    setServerError(null);
    try {
      const result = await createUser(values);
      setCreated({ email: result.user.email, password: result.temporaryPassword });
      onCreated();
    } catch (err) {
      setServerError(toApiError(err).message);
    }
  };

  return (
    <Modal
      open={open}
      onClose={close}
      title={created ? 'User created' : 'Create user'}
      description={created ? undefined : 'A one-time temporary password will be generated.'}
      footer={
        created ? (
          <Button onClick={close}>Done</Button>
        ) : (
          <>
            <Button variant="secondary" onClick={close}>
              Cancel
            </Button>
            <Button type="submit" form="create-user-form" loading={isSubmitting}>
              Create user
            </Button>
          </>
        )
      }
    >
      {created ? (
        <TemporaryPasswordNotice email={created.email} password={created.password} />
      ) : (
        <form id="create-user-form" onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
          <Input label="Full name" autoComplete="off" error={errors.name?.message} {...register('name')} />
          <Input label="Work email" type="email" autoComplete="off" error={errors.email?.message} {...register('email')} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Select label="Role" options={ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] }))} {...register('role')} />
            <Select label="Preferred language" options={PREFERRED_LANGUAGE_OPTIONS} {...register('preferredLanguage')} />
          </div>
          {serverError && <Alert tone="error">{serverError}</Alert>}
        </form>
      )}
    </Modal>
  );
}
