import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Alert } from '../../components/ui/Alert';
import { api, toApiError, type ApiSuccess } from '../../lib/api';
import { passwordPolicy } from '../../lib/validation';
import { useAuthStore } from '../../store/authStore';
import type { Session } from '../../types/auth';

const schema = z
  .object({
    currentPassword: z.string().min(1, 'Enter your current password'),
    newPassword: passwordPolicy,
    confirmPassword: z.string(),
  })
  .refine((v) => v.newPassword === v.confirmPassword, { path: ['confirmPassword'], message: 'Passwords do not match' })
  .refine((v) => v.newPassword !== v.currentPassword, { path: ['newPassword'], message: 'Choose a different password' });
type Values = z.infer<typeof schema>;

/** Calls PATCH /users/:id/password; the server revokes old sessions and returns a new token. */
export function ChangePasswordForm({ onDone, currentLabel = 'Current password' }: { onDone?: () => void; currentLabel?: string }) {
  const user = useAuthStore((s) => s.user)!;
  const setSession = useAuthStore((s) => s.setSession);
  const [serverError, setServerError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<Values>({ resolver: zodResolver(schema) });

  const onSubmit = async ({ currentPassword, newPassword }: Values) => {
    setServerError(null);
    setSuccess(false);
    try {
      const res = await api.patch<ApiSuccess<Session>>(`/users/${user.id}/password`, { currentPassword, newPassword });
      setSession(res.data.data);
      reset();
      setSuccess(true);
      onDone?.();
    } catch (err) {
      setServerError(toApiError(err).message);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      <Input label={currentLabel} type="password" autoComplete="current-password" error={errors.currentPassword?.message} {...register('currentPassword')} />
      <Input
        label="New password"
        type="password"
        autoComplete="new-password"
        hint="At least 10 characters, with upper-case, lower-case and a digit."
        error={errors.newPassword?.message}
        {...register('newPassword')}
      />
      <Input label="Confirm new password" type="password" autoComplete="new-password" error={errors.confirmPassword?.message} {...register('confirmPassword')} />
      {serverError && <Alert tone="error">{serverError}</Alert>}
      {success && <Alert tone="success">Password updated. Other sessions have been signed out.</Alert>}
      <Button type="submit" loading={isSubmitting}>
        Update password
      </Button>
    </form>
  );
}
