import { useEffect, useRef, useState } from 'react';
import { Volume2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { toApiError } from '../../lib/api';
import { draftSpeech } from './complaintsApi';

/**
 * Plays a server-generated spoken prompt (Gnani Timbre). Only rendered when TTS is available.
 * If speech fails, the text on screen remains the source of truth.
 */
export function SpeakButton({ draftId, target, label }: { draftId: string; target: 'questions' | 'confirmation'; label: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const urlRef = useRef<string | null>(null);

  useEffect(
    () => () => {
      audioRef.current?.pause();
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    },
    [],
  );

  const play = async () => {
    setBusy(true);
    setError(null);
    try {
      const blob = await draftSpeech(draftId, target);
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      urlRef.current = URL.createObjectURL(blob);
      audioRef.current?.pause();
      audioRef.current = new Audio(urlRef.current);
      await audioRef.current.play();
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <Button size="sm" variant="secondary" loading={busy} onClick={() => void play()}>
        <Volume2 className="size-4" aria-hidden /> {label}
      </Button>
      {error && <span className="text-xs text-slate-500">{error}</span>}
    </span>
  );
}
