import { useState } from 'react';
import { MessageCircleQuestion } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { Textarea } from '../../components/ui/Textarea';
import { toApiError } from '../../lib/api';
import type { Equipment } from '../../types/domain';
import { EquipmentPicker } from '../report/EquipmentPicker';
import { answerQuestions, type ComplaintDraft, type RequiredField } from './complaintsApi';
import { SpeakButton } from './SpeakButton';

export function FollowUpQuestions({ draft, ttsAvailable, onUpdated }: { draft: ComplaintDraft; ttsAvailable: boolean; onUpdated: (d: ComplaintDraft) => void }) {
  const [text, setText] = useState<Partial<Record<RequiredField, string>>>({});
  const [equipment, setEquipment] = useState<Equipment | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!draft.questions.length) return null;

  const answers = draft.questions
    .map((q) => ({ field: q.field, answer: q.inputType === 'equipment' ? equipment?.equipmentCode ?? '' : (text[q.field] ?? '').trim() }))
    .filter((a) => a.answer);

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const d = await answerQuestions(draft.id, answers);
      setText({});
      setEquipment(null);
      onUpdated(d);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="inline-flex items-center gap-2 text-sm text-slate-600">
          <MessageCircleQuestion className="size-4 text-brand-700" aria-hidden /> A few details are missing before this can become a ticket.
        </p>
        {ttsAvailable && <SpeakButton draftId={draft.id} target="questions" label="Listen" />}
      </div>

      {draft.questions.map((q) => (
        <div key={q.field} className="space-y-2 rounded-lg border border-amber-200 bg-amber-50/40 p-4">
          <p className="text-sm font-medium text-navy-900" lang={q.promptLanguage}>{q.prompt}</p>
          {q.inputType === 'equipment' ? (
            <EquipmentPicker value={equipment} onChange={setEquipment} />
          ) : q.inputType === 'symptoms' ? (
            <input
              aria-label={q.prompt}
              value={text.symptoms ?? ''}
              onChange={(e) => setText({ ...text, symptoms: e.target.value })}
              placeholder="e.g. vibration, leak"
              maxLength={2000}
              className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none"
            />
          ) : (
            <Textarea aria-label={q.prompt} rows={3} value={text.description ?? ''} onChange={(e) => setText({ ...text, description: e.target.value })} maxLength={2000} />
          )}
        </div>
      ))}

      {error && <Alert tone="error">{error}</Alert>}
      <Button onClick={() => void submit()} loading={busy} disabled={!answers.length}>
        Submit answers
      </Button>
    </div>
  );
}
