import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router';
import { ArrowLeft, CheckCircle2, ClipboardCheck, FlaskConical, MessageCircleQuestion, ShieldAlert, Trash2 } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Alert } from '../../components/ui/Alert';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { PageSkeleton } from '../../components/ui/Spinner';
import { SeverityBadge } from '../../components/tickets/Badges';
import { toApiError } from '../../lib/api';
import { CATEGORY_LABEL, formatDateTime, timeAgo } from '../../lib/format';
import type { Ticket } from '../../types/domain';
import { getLanguageCatalog, type LanguageCatalog } from '../voice/voiceApi';
import { confirmDraft, deleteDraft, getDraft, STATE_LABEL, type ComplaintDraft, type DraftState } from './complaintsApi';
import { FollowUpQuestions } from './FollowUpQuestions';
import { DraftDetailsForm } from './DraftDetailsForm';
import { SpeakButton } from './SpeakButton';

const STATE_TONE: Record<DraftState, BadgeTone> = {
  DRAFT: 'warning',
  NEEDS_INFORMATION: 'warning',
  READY_FOR_CONFIRMATION: 'success',
  CONFIRMED: 'info',
  EXPIRED: 'neutral',
};

const MOCK_PREFIX = '[MOCK TRANSCRIPT]';

function languageName(catalog: LanguageCatalog | null, code: string) {
  return catalog?.languages.find((l) => l.code === code)?.displayName ?? code;
}

export function DraftPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [draft, setDraft] = useState<ComplaintDraft | null>(null);
  const [catalog, setCatalog] = useState<LanguageCatalog | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [confirmError, setConfirmError] = useState<string | null>(null);
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    try {
      setDraft(await getDraft(id!));
    } catch (err) {
      setError(toApiError(err).message);
    }
  }, [id]);

  useEffect(() => {
    void load();
    getLanguageCatalog().then(setCatalog).catch(() => setCatalog(null));
  }, [load]);

  const onConfirm = async () => {
    if (!draft) return;
    setConfirming(true);
    setConfirmError(null);
    try {
      setTicket(await confirmDraft(draft.id));
      void load();
    } catch (err) {
      // Retrying is safe: the server reuses this draft's idempotency key.
      setConfirmError(toApiError(err).message);
      void load();
    } finally {
      setConfirming(false);
    }
  };

  const onDelete = async () => {
    if (!draft) return;
    setDeleting(true);
    try {
      await deleteDraft(draft.id);
      navigate('/operator/report', { replace: true });
    } catch (err) {
      setError(toApiError(err).message);
      setDeleteOpen(false);
    } finally {
      setDeleting(false);
    }
  };

  const back = (
    <Link to="/operator/report" className="group mb-5 inline-flex items-center gap-1.5 rounded-md text-[13px] font-semibold text-slate-500 transition-colors hover:text-navy-900">
      <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-0.5" aria-hidden /> Back to report
    </Link>
  );

  if (error) return <>{back}<Alert tone="error">{error}</Alert></>;
  if (!draft) return <PageSkeleton label="Loading complaint…" />;

  if (ticket || (draft.state === 'CONFIRMED' && draft.ticketId)) {
    return (
      <>
        {back}
        <Card className="relative mx-auto max-w-xl overflow-hidden p-8 text-center sm:p-10">
          <span aria-hidden className="absolute inset-x-0 top-0 h-1 bg-emerald-500" />
          <span className="mx-auto flex size-16 items-center justify-center rounded-full bg-emerald-50 ring-8 ring-emerald-50/60">
            <CheckCircle2 className="size-9 text-emerald-600" aria-hidden />
          </span>
          <h1 className="type-display mt-5 text-2xl font-bold text-navy-900">Ticket created</h1>
          {ticket && <p className="mt-2 inline-block rounded-lg bg-slate-50 px-3 py-1 font-mono text-2xl font-semibold text-brand-700 ring-1 ring-inset ring-slate-200">{ticket.ticketNumber}</p>}
          <p className="mt-2 text-sm text-slate-500">Maintenance engineers have been notified. You can follow its status in My tickets.</p>
          <div className="mt-7 flex flex-wrap justify-center gap-2">
            <Link to={`/operator/tickets/${ticket?.id ?? draft.ticketId}`}><Button>View ticket</Button></Link>
            <Link to="/operator/report"><Button variant="secondary">Report another issue</Button></Link>
          </div>
        </Card>
      </>
    );
  }

  const readOnly = draft.state === 'EXPIRED';
  const mockTranscript = draft.transcript.startsWith(MOCK_PREFIX);
  const mockExtractor = draft.extraction.provider === 'mock';
  const tts = !!catalog?.tts && 'available' in catalog.tts && catalog.tts.available;

  return (
    <>
      {back}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="type-display text-[26px] font-bold leading-tight text-navy-900 sm:text-[30px]">Review your complaint</h1>
            <Badge tone={STATE_TONE[draft.state]}>{STATE_LABEL[draft.state]}</Badge>
          </div>
          <p className="mt-1.5 text-sm text-slate-500">
            {draft.source === 'voice' ? 'Voice report' : 'Typed report'} · {languageName(catalog, draft.language)} · started {timeAgo(draft.createdAt)}
            {!readOnly && <> · expires {formatDateTime(draft.expiresAt)}</>}
          </p>
        </div>
        {!readOnly && (
          <Button variant="ghost" onClick={() => setDeleteOpen(true)}>
            <Trash2 className="size-4 text-red-600" aria-hidden /> Discard
          </Button>
        )}
      </div>

      {readOnly && <Alert tone="warning" className="mb-6">This draft expired before it was confirmed. No ticket was created. Please start a new report.</Alert>}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <div className="space-y-6">
          <Card>
            <CardHeader
              title={draft.source === 'voice' ? 'Original transcript' : 'Your report'}
              actions={mockTranscript ? <Badge tone="mock" className="normal-case"><FlaskConical className="size-3.5" aria-hidden /> Mock transcript</Badge> : undefined}
            />
            <blockquote lang={draft.language} className="m-5 whitespace-pre-wrap rounded-r-lg border-l-[3px] border-signal-400 bg-slate-50 px-4 py-3.5 text-sm leading-relaxed text-slate-900">
              {draft.transcript}
            </blockquote>
          </Card>

          {!readOnly && draft.questions.length > 0 && (
            <Card className="border-amber-200">
              <CardHeader icon={<MessageCircleQuestion />} title="Follow-up questions" />
              <div className="p-5">
                <FollowUpQuestions draft={draft} ttsAvailable={tts} onUpdated={setDraft} />
              </div>
            </Card>
          )}

          <Card>
            <CardHeader
              title="Complaint details"
              description="Check what was understood and correct anything that is wrong."
              actions={mockExtractor ? <Badge tone="mock" className="normal-case"><FlaskConical className="size-3.5" aria-hidden /> Mock extractor — keyword rules, not Gnani Evon</Badge> : undefined}
            />
            <div className="space-y-4 p-5">
              {draft.extraction.status === 'unsupported_language' && (
                <Alert tone="info">Automatic understanding is not available for {languageName(catalog, draft.language)}. Please fill in the details below.</Alert>
              )}
              {draft.extraction.status === 'failed' && (
                <Alert tone="warning">The complaint could not be analysed automatically. Please fill in the details below.</Alert>
              )}
              {readOnly ? (
                <dl className="grid grid-cols-1 gap-3 text-sm">
                  <div><dt className="text-slate-500">Equipment</dt><dd className="font-mono">{draft.fields.equipmentCode ?? '—'}</dd></div>
                  <div><dt className="text-slate-500">Description</dt><dd className="whitespace-pre-wrap">{draft.fields.description}</dd></div>
                </dl>
              ) : (
                <DraftDetailsForm draft={draft} onUpdated={setDraft} />
              )}
            </div>
          </Card>

          {draft.answers.length > 0 && (
            <Card>
              <CardHeader title="Your answers" />
              <ul className="divide-y divide-slate-100 px-5">
                {draft.answers.map((a, i) => (
                  <li key={i} className="py-3 text-sm">
                    <p className="text-slate-500">{a.question}</p>
                    <p className="mt-0.5 text-slate-900">{a.answer}</p>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>

        {!readOnly && (
          <div className="space-y-6">
            <Card className="xl:sticky xl:top-24">
              <CardHeader icon={<ClipboardCheck />} title="Confirm and create ticket" />
              <div className="space-y-4 p-5">
                <dl className="grid grid-cols-1 gap-3 text-sm">
                  <div>
                    <dt className="type-label text-slate-500">Equipment</dt>
                    <dd className="mt-0.5">
                      {draft.equipment ? <><span className="font-mono font-medium">{draft.equipment.equipmentCode}</span> — {draft.equipment.name}</> : <span className="text-amber-700">Not identified yet</span>}
                    </dd>
                  </div>
                  <div>
                    <dt className="type-label text-slate-500">Symptoms</dt>
                    <dd className="mt-1 flex flex-wrap gap-1">{draft.fields.symptoms.length ? draft.fields.symptoms.map((s) => <Badge key={s}>{s}</Badge>) : <span className="text-amber-700">None yet</span>}</dd>
                  </div>
                  <div className="flex gap-6">
                    <div>
                      <dt className="type-label text-slate-500">Category</dt>
                      <dd className="mt-1">{CATEGORY_LABEL[draft.fields.category]}</dd>
                    </div>
                    <div>
                      <dt className="type-label text-slate-500">Severity</dt>
                      <dd className="mt-1"><SeverityBadge severity={draft.fields.severity} /></dd>
                    </div>
                  </div>
                </dl>

                {draft.fields.severity === 'critical' && (
                  <Alert tone="warning">
                    <span className="inline-flex items-start gap-1.5">
                      <ShieldAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
                      Follow your site emergency procedure and inform your supervisor now. PetroSathi only records the report — it does not authorize shutdown, isolation, repair or restart.
                    </span>
                  </Alert>
                )}

                {!draft.canConfirm && (
                  <p className="text-sm text-amber-700">Answer the follow-up questions or complete the details to continue.</p>
                )}
                {confirmError && <Alert tone="error">{confirmError} Retrying is safe — only one ticket will be created.</Alert>}
                <Button className="w-full" size="lg" disabled={!draft.canConfirm} loading={confirming} onClick={() => void onConfirm()}>
                  Confirm and create ticket
                </Button>
                {tts && draft.canConfirm && <SpeakButton draftId={draft.id} target="confirmation" label="Hear summary prompt" />}
                <p className="text-xs text-slate-500">A ticket is created only when you press confirm.</p>
              </div>
            </Card>
          </div>
        )}
      </div>

      <Modal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        title="Discard this report?"
        description="The draft will be deleted and no ticket will be created. This cannot be undone."
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteOpen(false)}>Keep it</Button>
            <Button variant="danger" loading={deleting} onClick={() => void onDelete()}>Discard report</Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">{draft.fields.description.slice(0, 160)}</p>
      </Modal>
    </>
  );
}
