import { useEffect, useState, type KeyboardEvent } from 'react';
import { CheckCircle2, CircleAlert, Plus, X } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Select';
import { Textarea } from '../../components/ui/Textarea';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { CATEGORY_LABEL, SEVERITY_LABEL } from '../../lib/format';
import { COMPLAINT_CATEGORIES, SEVERITIES, type ComplaintCategory, type Equipment, type Severity } from '../../types/domain';
import { EquipmentPicker } from '../report/EquipmentPicker';
import { updateDraft, type ComplaintDraft } from './complaintsApi';

const CHECK_TEXT: Record<ComplaintDraft['equipmentCheck'], string> = {
  found: 'Registered equipment',
  not_found: 'Not in the equipment register',
  decommissioned: 'Equipment is decommissioned',
  not_provided: 'No equipment selected',
};

/** Operator edits of the complaint. Nothing here invents data: unknown severity stays "Not assessed". */
export function DraftDetailsForm({ draft, onUpdated }: { draft: ComplaintDraft; onUpdated: (d: ComplaintDraft) => void }) {
  const [description, setDescription] = useState(draft.fields.description);
  const [symptoms, setSymptoms] = useState(draft.fields.symptoms);
  const [symptomInput, setSymptomInput] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>(draft.fields.category);
  const [severity, setSeverity] = useState<Severity>(draft.fields.severity);
  const [changingEquipment, setChangingEquipment] = useState(false);
  const [newEquipment, setNewEquipment] = useState<Equipment | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  // Server is the source of truth: resync after answers or saves.
  useEffect(() => {
    setDescription(draft.fields.description);
    setSymptoms(draft.fields.symptoms);
    setCategory(draft.fields.category);
    setSeverity(draft.fields.severity);
  }, [draft]);

  const dirty =
    description !== draft.fields.description ||
    JSON.stringify(symptoms) !== JSON.stringify(draft.fields.symptoms) ||
    category !== draft.fields.category ||
    severity !== draft.fields.severity ||
    !!newEquipment;

  const addSymptom = () => {
    const s = symptomInput.trim();
    if (s && !symptoms.includes(s)) setSymptoms([...symptoms, s].slice(0, 20));
    setSymptomInput('');
  };
  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addSymptom();
    }
  };

  const save = async () => {
    setBusy(true);
    setError(null);
    setSaved(false);
    try {
      const d = await updateDraft(draft.id, {
        description,
        symptoms,
        category,
        severity,
        ...(newEquipment ? { equipmentCode: newEquipment.equipmentCode } : {}),
      });
      setNewEquipment(null);
      setChangingEquipment(false);
      setSaved(true);
      onUpdated(d);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const ok = draft.equipmentCheck === 'found';

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <p className="text-sm font-medium text-slate-700">Equipment</p>
        <div className="flex flex-wrap items-center gap-3">
          <span className={`inline-flex items-center gap-1.5 text-sm ${ok ? 'text-emerald-700' : 'text-amber-700'}`}>
            {ok ? <CheckCircle2 className="size-4" aria-hidden /> : <CircleAlert className="size-4" aria-hidden />}
            {draft.fields.equipmentCode ? <span className="font-mono font-medium">{draft.fields.equipmentCode}</span> : null}
            {draft.equipment && <span className="text-slate-600">— {draft.equipment.name}</span>}
            <span className="text-xs text-slate-500">({CHECK_TEXT[draft.equipmentCheck]})</span>
          </span>
          <Button size="sm" variant="ghost" onClick={() => setChangingEquipment((v) => !v)}>
            {changingEquipment ? 'Cancel' : draft.fields.equipmentCode ? 'Change' : 'Select equipment'}
          </Button>
        </div>
        {changingEquipment && <EquipmentPicker value={newEquipment} onChange={setNewEquipment} />}
      </div>

      <Textarea label="Description" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={4000} />

      <div className="space-y-1.5">
        <label htmlFor="draft-symptom" className="block text-sm font-medium text-slate-700">Symptoms</label>
        <div className="flex gap-2">
          <input id="draft-symptom" value={symptomInput} onChange={(e) => setSymptomInput(e.target.value)} onKeyDown={onKey} maxLength={200} placeholder="Add a symptom"
            className="h-10 flex-1 rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
          <Button variant="secondary" onClick={addSymptom} disabled={!symptomInput.trim()}><Plus className="size-4" aria-hidden /> Add</Button>
        </div>
        {symptoms.length > 0 && (
          <ul className="flex flex-wrap gap-1.5 pt-1">
            {symptoms.map((s) => (
              <li key={s}>
                <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 py-0.5 pl-2 pr-1 text-xs text-slate-700">
                  {s}
                  <button type="button" onClick={() => setSymptoms(symptoms.filter((x) => x !== s))} className="rounded p-0.5 hover:bg-slate-200" aria-label={`Remove ${s}`}>
                    <X className="size-3" />
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Select label="Category" value={category} onChange={(e) => setCategory(e.target.value as ComplaintCategory)} options={COMPLAINT_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_LABEL[c] }))} />
        <Select
          label="Severity"
          value={severity}
          onChange={(e) => setSeverity(e.target.value as Severity)}
          options={SEVERITIES.map((s) => ({ value: s, label: s === 'unknown' ? 'Not assessed — engineer will assess' : SEVERITY_LABEL[s] }))}
        />
      </div>

      {error && <Alert tone="error">{error}</Alert>}
      {saved && !dirty && <Alert tone="success">Changes saved.</Alert>}
      <Button onClick={() => void save()} loading={busy} disabled={!dirty}>Save changes</Button>
    </div>
  );
}
