import { api, type ApiSuccess } from '../../lib/api';
import type { ComplaintCategory, Equipment, Severity, Ticket } from '../../types/domain';

export type DraftState = 'DRAFT' | 'NEEDS_INFORMATION' | 'READY_FOR_CONFIRMATION' | 'CONFIRMED' | 'EXPIRED';
export type RequiredField = 'equipmentCode' | 'symptoms' | 'description';

export interface FollowUpQuestion {
  field: RequiredField;
  prompt: string;
  promptLanguage: string;
  inputType: 'equipment' | 'symptoms' | 'text';
}

export interface ComplaintDraft {
  id: string;
  state: DraftState;
  source: 'voice' | 'text';
  transcript: string;
  language: string;
  conversationId: string | null;
  extraction: { status: 'completed' | 'unsupported_language' | 'failed' | 'not_run'; provider: 'gnani-evon' | 'mock' | null; error: string | null; result: { confidence?: number } | null };
  fields: {
    equipmentCode: string | null;
    equipmentId: string | null;
    description: string;
    symptoms: string[];
    category: ComplaintCategory;
    severity: Severity;
    inspectionRequired: boolean;
  };
  equipmentCheck: 'not_provided' | 'found' | 'not_found' | 'decommissioned';
  equipment: Pick<Equipment, 'id' | 'equipmentCode' | 'name' | 'type' | 'plant' | 'location' | 'status'> | null;
  missingInformation: RequiredField[];
  answers: { field: string; question: string; answer: string; at: string }[];
  questions: FollowUpQuestion[];
  canConfirm: boolean;
  expiresAt: string;
  ticketId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface DraftSummary {
  id: string;
  state: DraftState;
  source: 'voice' | 'text';
  language: string;
  fields: ComplaintDraft['fields'];
  missingInformation: RequiredField[];
  expiresAt: string;
  updatedAt: string;
}

export async function createDraft(body: { conversationId: string } | { transcript: string; language: string }) {
  return (await api.post<ApiSuccess<ComplaintDraft>>('/complaints/drafts', body)).data.data;
}
export async function getDraft(id: string) {
  return (await api.get<ApiSuccess<ComplaintDraft>>(`/complaints/drafts/${id}`)).data.data;
}
export async function listOpenDrafts() {
  return (await api.get<ApiSuccess<DraftSummary[]>>('/complaints/drafts')).data.data;
}
export async function updateDraft(id: string, body: Partial<Pick<ComplaintDraft['fields'], 'equipmentCode' | 'description' | 'symptoms' | 'category' | 'severity'>>) {
  return (await api.patch<ApiSuccess<ComplaintDraft>>(`/complaints/drafts/${id}`, body)).data.data;
}
export async function answerQuestions(id: string, answers: { field: RequiredField; answer: string }[]) {
  return (await api.post<ApiSuccess<ComplaintDraft>>(`/complaints/drafts/${id}/questions`, { answers })).data.data;
}
/** Safe to retry: the server uses the draft's own idempotency key, so only one ticket is created. */
export async function confirmDraft(id: string) {
  return (await api.post<ApiSuccess<Ticket>>(`/complaints/drafts/${id}/confirm`)).data.data;
}
export async function deleteDraft(id: string) {
  await api.delete(`/complaints/drafts/${id}`);
}
export async function draftSpeech(id: string, target: 'questions' | 'confirmation'): Promise<Blob> {
  const res = await api.post(`/complaints/drafts/${id}/speech`, { target }, { responseType: 'blob' });
  return res.data as Blob;
}

export const STATE_LABEL: Record<DraftState, string> = {
  DRAFT: 'Needs your input',
  NEEDS_INFORMATION: 'Needs more information',
  READY_FOR_CONFIRMATION: 'Ready to confirm',
  CONFIRMED: 'Confirmed',
  EXPIRED: 'Expired',
};
