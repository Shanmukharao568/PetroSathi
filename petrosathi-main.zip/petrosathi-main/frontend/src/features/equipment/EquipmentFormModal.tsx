import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { EQUIPMENT_STATUS_LABEL, equipmentTypeLabel, humanize } from '../../lib/format';
import { EQUIPMENT_CRITICALITY, EQUIPMENT_STATUS, EQUIPMENT_TYPES, type Equipment } from '../../types/domain';
import { createEquipment, updateEquipment } from './equipmentApi';

const schema = z.object({
  equipmentCode: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z0-9]{1,6}-[A-Z0-9]{1,10}$/, 'Use a tag like P-101 or HX-301A'),
  name: z.string().trim().min(2, 'At least 2 characters').max(150),
  type: z.enum(EQUIPMENT_TYPES),
  plant: z.string().trim().min(1, 'Plant is required').max(100),
  location: z.string().trim().max(200),
  manufacturer: z.string().trim().max(100),
  model: z.string().trim().max(100),
  criticality: z.enum(EQUIPMENT_CRITICALITY),
  status: z.enum(EQUIPMENT_STATUS),
});
type Values = z.infer<typeof schema>;

const EMPTY: Values = {
  equipmentCode: '', name: '', type: 'pump', plant: '', location: '', manufacturer: '', model: '',
  criticality: 'medium', status: 'operational',
};

/** Create (equipment === 'new') or edit an existing record. */
export function EquipmentFormModal({ equipment, onClose, onSaved }: { equipment: Equipment | 'new' | null; onClose: () => void; onSaved: () => void }) {
  const [serverError, setServerError] = useState<string | null>(null);
  const isNew = equipment === 'new';
  const { register, handleSubmit, reset, formState: { errors, isSubmitting, isDirty } } = useForm<Values>({ resolver: zodResolver(schema) });

  useEffect(() => {
    if (!equipment) return;
    setServerError(null);
    reset(equipment === 'new' ? EMPTY : {
      equipmentCode: equipment.equipmentCode, name: equipment.name, type: equipment.type, plant: equipment.plant,
      location: equipment.location, manufacturer: equipment.manufacturer, model: equipment.model,
      criticality: equipment.criticality, status: equipment.status,
    });
  }, [equipment, reset]);

  if (!equipment) return null;

  const onSubmit = async (v: Values) => {
    setServerError(null);
    try {
      if (isNew) await createEquipment(v);
      else await updateEquipment(equipment.id, v);
      onSaved();
      onClose();
    } catch (err) {
      setServerError(toApiError(err).message);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={isNew ? 'Add equipment' : `Edit ${equipment.equipmentCode}`}
      description={isNew ? 'Register a tagged asset so operators can report issues against it.' : equipment.name}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" form="equipment-form" loading={isSubmitting} disabled={!isNew && !isDirty}>
            {isNew ? 'Add equipment' : 'Save changes'}
          </Button>
        </>
      }
    >
      <form id="equipment-form" onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-[10rem_1fr]">
          <Input label="Equipment tag" placeholder="P-101" className="font-mono uppercase" error={errors.equipmentCode?.message} {...register('equipmentCode')} />
          <Input label="Name" placeholder="Crude transfer pump A" error={errors.name?.message} {...register('name')} />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Select label="Type" options={EQUIPMENT_TYPES.map((t) => ({ value: t, label: equipmentTypeLabel(t) }))} {...register('type')} />
          <Input label="Plant / unit" error={errors.plant?.message} {...register('plant')} />
        </div>
        <Input label="Location" placeholder="Tank farm, pump bay 2" error={errors.location?.message} {...register('location')} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input label="Manufacturer" error={errors.manufacturer?.message} {...register('manufacturer')} />
          <Input label="Model" error={errors.model?.message} {...register('model')} />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Select label="Criticality" options={EQUIPMENT_CRITICALITY.map((c) => ({ value: c, label: humanize(c) }))} {...register('criticality')} />
          <Select label="Status" options={EQUIPMENT_STATUS.map((s) => ({ value: s, label: EQUIPMENT_STATUS_LABEL[s] }))} {...register('status')} />
        </div>
        {serverError && <Alert tone="error">{serverError}</Alert>}
      </form>
    </Modal>
  );
}
