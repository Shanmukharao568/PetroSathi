import { api, type ApiSuccess, type Pagination } from '../../lib/api';
import type { Equipment, EquipmentCriticality, EquipmentStatus, EquipmentType } from '../../types/domain';

export interface EquipmentQuery {
  page: number;
  limit: number;
  search?: string;
  type?: EquipmentType;
  status?: EquipmentStatus;
  criticality?: EquipmentCriticality;
}

export type EquipmentInput = Pick<Equipment, 'equipmentCode' | 'name' | 'type' | 'plant' | 'location' | 'manufacturer' | 'model' | 'criticality' | 'status'>;

export async function listEquipment(params: EquipmentQuery) {
  const res = await api.get<ApiSuccess<Equipment[]>>('/equipment', { params });
  return { items: res.data.data, pagination: res.data.meta?.pagination as Pagination };
}
export async function createEquipment(body: EquipmentInput) {
  return (await api.post<ApiSuccess<Equipment>>('/equipment', body)).data.data;
}
export async function updateEquipment(id: string, body: Partial<EquipmentInput>) {
  return (await api.patch<ApiSuccess<Equipment>>(`/equipment/${id}`, body)).data.data;
}
export async function deleteEquipment(id: string) {
  await api.delete(`/equipment/${id}`);
}
