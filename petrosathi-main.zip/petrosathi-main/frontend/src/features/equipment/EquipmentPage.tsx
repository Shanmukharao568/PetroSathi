import { useCallback, useEffect, useState } from 'react';
import { Cog, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { EmptyState } from '../../components/ui/EmptyState';
import { Card, PageHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { Select } from '../../components/ui/Select';
import { Alert } from '../../components/ui/Alert';
import { Spinner } from '../../components/ui/Spinner';
import { Modal } from '../../components/ui/Modal';
import { Pager } from '../../components/ui/Pager';
import { toApiError, type Pagination } from '../../lib/api';
import { EQUIPMENT_STATUS_LABEL, equipmentTypeLabel, humanize } from '../../lib/format';
import { useDebounced } from '../../hooks/useDebounced';
import { EQUIPMENT_STATUS, EQUIPMENT_TYPES, type Equipment, type EquipmentStatus, type EquipmentType } from '../../types/domain';
import { deleteEquipment, listEquipment } from './equipmentApi';
import { EquipmentFormModal } from './EquipmentFormModal';

const statusTone: Record<EquipmentStatus, BadgeTone> = {
  operational: 'success', degraded: 'warning', down: 'danger', under_maintenance: 'info', decommissioned: 'neutral',
};
const critTone = { low: 'neutral', medium: 'info', high: 'warning', critical: 'danger' } as const;

export function EquipmentPage() {
  const [items, setItems] = useState<Equipment[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const search = useDebounced(searchInput.trim());
  const [type, setType] = useState<'' | EquipmentType>('');
  const [status, setStatus] = useState<'' | EquipmentStatus>('');
  const [editing, setEditing] = useState<Equipment | 'new' | null>(null);
  const [deleting, setDeleting] = useState<Equipment | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => setPage(1), [search, type, status]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await listEquipment({ page, limit: 20, ...(search && { search }), ...(type && { type }), ...(status && { status }) });
      setItems(r.items);
      setPagination(r.pagination);
    } catch (err) {
      setError(toApiError(err).message);
    } finally {
      setLoading(false);
    }
  }, [page, search, type, status]);

  useEffect(() => void load(), [load]);

  const confirmDelete = async () => {
    if (!deleting) return;
    setDeleteBusy(true);
    setDeleteError(null);
    try {
      await deleteEquipment(deleting.id);
      setDeleting(null);
      void load();
    } catch (err) {
      setDeleteError(toApiError(err).message);
    } finally {
      setDeleteBusy(false);
    }
  };

  return (
    <>
      <PageHeader
        eyebrow="Asset register"
        title="Equipment"
        description="Tagged assets that operators can report issues against."
        actions={<Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden /> Add equipment</Button>}
      />
      <Card>
        <div className="flex flex-wrap items-end gap-3 border-b border-slate-100 p-4">
          <label className="relative min-w-56 flex-1">
            <span className="sr-only">Search equipment</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search tag, name, location"
              className="h-11 w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none"
            />
          </label>
          <div className="w-44">
            <Select aria-label="Filter by type" value={type} onChange={(e) => setType(e.target.value as '' | EquipmentType)}
              options={[{ value: '', label: 'All types' }, ...EQUIPMENT_TYPES.map((t) => ({ value: t, label: equipmentTypeLabel(t) }))]} />
          </div>
          <div className="w-48">
            <Select aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value as '' | EquipmentStatus)}
              options={[{ value: '', label: 'All statuses' }, ...EQUIPMENT_STATUS.map((s) => ({ value: s, label: EQUIPMENT_STATUS_LABEL[s] }))]} />
          </div>
        </div>

        {error && <div className="p-4"><Alert tone="error">{error}</Alert></div>}

        <div className="relative overflow-x-auto">
          <table className="data-table w-full text-left text-sm">
            <thead>
              <tr>
                <th scope="col" className="px-4 py-3">Tag</th>
                <th scope="col" className="px-4 py-3">Equipment</th>
                <th scope="col" className="px-4 py-3">Plant / location</th>
                <th scope="col" className="px-4 py-3">Criticality</th>
                <th scope="col" className="px-4 py-3">Status</th>
                <th scope="col" className="px-4 py-3"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody className="stagger divide-y divide-slate-100 [--stagger-step:35ms]">
              {loading && items.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center"><Spinner label="Loading equipment…" /></td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={6}><EmptyState icon={<Cog />} title="No equipment matches these filters." /></td></tr>
              ) : (
                items.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50/80">
                    <td className="px-4 py-3 font-mono text-sm font-medium text-navy-900">{e.equipmentCode}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">{e.name}</div>
                      <div className="text-slate-500">{equipmentTypeLabel(e.type)}{e.manufacturer && ` · ${e.manufacturer}`}{e.model && ` ${e.model}`}</div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      <div>{e.plant}</div>
                      {e.location && <div className="text-slate-500">{e.location}</div>}
                    </td>
                    <td className="px-4 py-3"><Badge tone={critTone[e.criticality]}>{humanize(e.criticality)}</Badge></td>
                    <td className="px-4 py-3"><Badge tone={statusTone[e.status]}>{EQUIPMENT_STATUS_LABEL[e.status]}</Badge></td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="ghost" onClick={() => setEditing(e)} aria-label={`Edit ${e.equipmentCode}`}><Pencil className="size-4" aria-hidden /></Button>
                        <Button size="sm" variant="ghost" onClick={() => { setDeleteError(null); setDeleting(e); }} aria-label={`Delete ${e.equipmentCode}`}>
                          <Trash2 className="size-4 text-red-600" aria-hidden />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <Pager pagination={pagination} noun="item" onPage={setPage} />
      </Card>

      <EquipmentFormModal equipment={editing} onClose={() => setEditing(null)} onSaved={() => void load()} />

      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title={`Delete ${deleting?.equipmentCode ?? ''}?`}
        description="This cannot be undone. Equipment that has tickets cannot be deleted; set its status to Decommissioned instead."
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button variant="danger" loading={deleteBusy} onClick={() => void confirmDelete()}>Delete permanently</Button>
          </>
        }
      >
        {deleteError ? <Alert tone="error">{deleteError}</Alert> : <p className="text-sm text-slate-600">{deleting?.name}</p>}
      </Modal>
    </>
  );
}
