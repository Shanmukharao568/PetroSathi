import { useRef, type KeyboardEvent, type PointerEvent } from 'react';
import { Loader2, Mic, Square } from 'lucide-react';
import clsx from 'clsx';
import type { PttPhase } from './usePushToTalk';

const LABEL: Record<PttPhase, string> = {
  idle: 'Hold to talk',
  requesting_mic: 'Allow microphone…',
  connecting: 'Connecting…',
  recording: 'Release to finish',
  finishing: 'Transcribing…',
  done: 'Hold to record again',
  error: 'Hold to try again',
};

function fmt(ms: number) {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/**
 * Large push-to-talk control: press & hold (pointer or Space/Enter), release to stop.
 * An explicit Stop button is also shown while recording.
 */
export function PushToTalkButton({
  phase,
  level,
  elapsedMs,
  maxSeconds,
  disabled,
  onStart,
  onStop,
}: {
  phase: PttPhase;
  level: number;
  elapsedMs: number;
  maxSeconds: number;
  disabled?: boolean;
  onStart: () => void;
  onStop: () => void;
}) {
  const holding = useRef(false);
  const busy = phase === 'finishing';
  const live = phase === 'recording';
  const warming = phase === 'requesting_mic' || phase === 'connecting';

  const down = () => {
    if (disabled || busy || holding.current) return;
    holding.current = true;
    onStart();
  };
  const up = () => {
    if (!holding.current) return;
    holding.current = false;
    onStop();
  };

  const onPointerDown = (e: PointerEvent<HTMLButtonElement>) => {
    if (e.button !== 0 || disabled || busy) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    down();
  };
  const onKeyDown = (e: KeyboardEvent<HTMLButtonElement>) => {
    if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) {
      e.preventDefault();
      down();
    }
  };
  const onKeyUp = (e: KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      up();
    }
  };

  const remaining = Math.max(0, maxSeconds * 1000 - elapsedMs);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative flex size-48 items-center justify-center">
        {/* Static guide rings */}
        <span aria-hidden className={clsx('absolute inset-0 rounded-full border border-dashed transition-colors', live ? 'border-red-300' : 'border-slate-300')} />
        <span aria-hidden className={clsx('absolute inset-4 rounded-full transition-colors', live ? 'bg-red-50' : 'bg-slate-100/80')} />
        {/* Audio level ring */}
        <span
          aria-hidden
          className={clsx('absolute inset-0 rounded-full transition-transform duration-75', live ? 'bg-red-500/20' : 'bg-transparent')}
          style={{ transform: `scale(${live ? 0.72 + level * 0.3 : 0.72})` }}
        />
        {/* Expanding ripples while recording. */}
        {live &&
          [0, 600, 1200].map((d) => (
            <span
              key={d}
              aria-hidden
              className="absolute inset-6 animate-ripple rounded-full border-2 border-red-400/60"
              style={{ animationDelay: `${d}ms` }}
            />
          ))}
        <button
          type="button"
          disabled={disabled || busy}
          onPointerDown={onPointerDown}
          onPointerUp={up}
          onPointerCancel={up}
          onLostPointerCapture={up}
          onKeyDown={onKeyDown}
          onKeyUp={onKeyUp}
          onContextMenu={(e) => e.preventDefault()}
          aria-pressed={live}
          aria-label={live ? 'Recording. Release to finish.' : 'Push to talk. Press and hold while speaking.'}
          className={clsx(
            'relative flex size-32 touch-none select-none items-center justify-center rounded-full text-white transition-all duration-200',
            'shadow-[0_1px_0_rgb(255_255_255/0.25)_inset,0_-6px_14px_rgb(0_0_0/0.18)_inset,0_10px_24px_-8px_rgb(7_17_19/0.55)]',
            'focus-visible:outline-4 focus-visible:outline-offset-4',
            live
              ? 'scale-105 bg-gradient-to-b from-red-500 to-red-700 focus-visible:outline-red-300'
              : 'bg-gradient-to-b from-brand-500 to-brand-700 hover:scale-[1.03] hover:from-brand-500 hover:to-brand-800 enabled:active:scale-95 focus-visible:outline-brand-300',
            (phase === 'idle' || phase === 'done') && !disabled && 'animate-breathe',
            (disabled || busy) && 'cursor-not-allowed opacity-60',
          )}
        >
          {busy || warming ? <Loader2 className="size-12 animate-spin" aria-hidden /> : <Mic className="size-12" aria-hidden />}
        </button>
      </div>

      <div className="text-center" aria-live="polite">
        <p className={clsx('text-[15px] font-semibold', live ? 'text-red-700' : 'text-navy-900')}>{LABEL[phase]}</p>
        {phase === 'idle' && <p className="mt-0.5 text-xs text-slate-500">or hold Space while the button is focused</p>}
        {live && (
          <div aria-hidden className="mx-auto mt-2 flex h-6 items-end justify-center gap-[3px]">
            {Array.from({ length: 9 }, (_, i) => (
              <span
                key={i}
                className="w-[3px] origin-bottom animate-eq rounded-full bg-gradient-to-t from-red-600 to-red-400"
                style={{
                  height: `${30 + Math.min(1, level * 1.6) * 70 * (1 - Math.abs(i - 4) / 6)}%`,
                  animationDelay: `${i * 90}ms`,
                }}
              />
            ))}
          </div>
        )}
        {live && (
          <p className="mt-1 font-mono text-sm text-slate-600">
            <span className="mr-1.5 inline-block size-2 animate-pulse rounded-full bg-red-600 align-middle" aria-hidden />
            {fmt(elapsedMs)} <span className="text-slate-400">· {fmt(remaining)} left</span>
          </p>
        )}
      </div>

      {live && (
        <button
          type="button"
          onClick={() => {
            holding.current = false;
            onStop();
          }}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-slate-700 shadow-[0_1px_2px_rgb(16_34_40/0.06)] transition-colors hover:bg-slate-50"
        >
          <Square className="size-3.5 fill-current" aria-hidden /> Stop
        </button>
      )}
    </div>
  );
}
