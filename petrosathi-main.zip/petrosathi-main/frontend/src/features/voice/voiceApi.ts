import { api, API_BASE_URL, type ApiSuccess } from '../../lib/api';

export type SupportLevel = 'full_voice' | 'speech_recognition_only' | 'text_response' | 'tts' | 'unsupported';

export interface LanguageCapability {
  code: string;
  displayName: string;
  nativeName: string;
  prismaSTT: boolean;
  prismaStreaming: boolean;
  evonInput: boolean;
  evonOutput: boolean;
  timbreTTS: boolean;
  autoDetection: boolean;
  supportLevel: SupportLevel;
}

export interface LanguageCatalog {
  providerMode: 'mock' | 'real';
  extractionMode: 'mock' | 'real';
  tts: { available: true; provider: string; model: string; voice: string } | { available: false };
  autoDetection: boolean;
  defaultLanguage: string;
  maxUploadSeconds: number;
  maxUploadMb: number;
  maxStreamSeconds: number;
  languages: LanguageCapability[];
}

export interface VoiceResult {
  conversationId: string | null;
  transcript: string;
  language: string | null;
  requestedLanguage?: string;
  provider: 'gnani-prisma' | 'mock';
  model?: string | null;
  truncated?: boolean;
  audioMode: 'upload' | 'stream';
  audioDurationMs: number | null;
  segmentCount?: number;
}

export async function getLanguageCatalog() {
  return (await api.get<ApiSuccess<LanguageCatalog>>('/voice/languages')).data.data;
}

export async function transcribeAudioFile(file: File, language: string, onProgress: (pct: number) => void, signal?: AbortSignal) {
  const form = new FormData();
  form.append('language', language);
  form.append('audio', file);
  const res = await api.post<ApiSuccess<VoiceResult>>('/voice/transcribe', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120_000,
    signal,
    onUploadProgress: (e) => {
      if (e.total) onProgress(Math.round((e.loaded / e.total) * 100));
    },
  });
  return res.data.data;
}

/** ws(s)://host/api/v1/voice/stream derived from the REST base URL. */
export function voiceStreamUrl(): string {
  const u = new URL(API_BASE_URL, window.location.href);
  u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
  u.pathname = `${u.pathname.replace(/\/$/, '')}/voice/stream`;
  return u.toString();
}

export const VOICE_PROTOCOL = 'petrosathi.voice.v1';
