import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { VOICE_PROTOCOL, voiceStreamUrl, type VoiceResult } from './voiceApi';

export type PttPhase = 'idle' | 'requesting_mic' | 'connecting' | 'recording' | 'finishing' | 'done' | 'error';

interface ServerMsg {
  type: 'session_ready' | 'transcript' | 'completed' | 'error';
  [k: string]: unknown;
}

const WORKLET_URL = '/worklets/pcm-capture.js';
const MIN_HOLD_MS = 400;

function micErrorMessage(err: unknown): string {
  const name = (err as { name?: string })?.name;
  if (name === 'NotAllowedError' || name === 'SecurityError') {
    return 'Microphone access was blocked. Allow microphone access for this site in your browser settings, or upload an MP3 instead.';
  }
  if (name === 'NotFoundError' || name === 'OverconstrainedError') return 'No microphone was found on this device. Upload an MP3 instead.';
  if (name === 'NotReadableError') return 'The microphone is being used by another application.';
  return 'Could not start the microphone.';
}

/**
 * Push-to-talk capture → PetroSathi WebSocket → Gnani Prisma (via backend proxy).
 * Never listens continuously: audio flows only between start() and stop().
 */
export function usePushToTalk() {
  const token = useAuthStore((s) => s.token);
  const [phase, setPhase] = useState<PttPhase>('idle');
  const [level, setLevel] = useState(0);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [maxSeconds, setMaxSeconds] = useState(120);
  const [segments, setSegments] = useState<string[]>([]);
  const [provider, setProvider] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<VoiceResult | null>(null);

  const ws = useRef<WebSocket | null>(null);
  const ctx = useRef<AudioContext | null>(null);
  const node = useRef<AudioWorkletNode | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const queue = useRef<ArrayBuffer[]>([]);
  const ready = useRef(false);
  const stopRequested = useRef(false);
  const startedAt = useRef(0);
  const timer = useRef<number | null>(null);
  const phaseRef = useRef<PttPhase>('idle');

  const go = (p: PttPhase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  /** Releases the microphone and audio graph (always safe to call). */
  const releaseAudio = useCallback(() => {
    if (timer.current) window.clearInterval(timer.current);
    timer.current = null;
    node.current?.port.close();
    node.current?.disconnect();
    node.current = null;
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    if (ctx.current && ctx.current.state !== 'closed') void ctx.current.close();
    ctx.current = null;
    setLevel(0);
  }, []);

  const closeSocket = useCallback((code = 1000) => {
    const s = ws.current;
    ws.current = null;
    if (s && (s.readyState === WebSocket.OPEN || s.readyState === WebSocket.CONNECTING)) s.close(code);
  }, []);

  const fail = useCallback(
    (message: string) => {
      releaseAudio();
      closeSocket();
      setError(message);
      go('error');
    },
    [releaseAudio, closeSocket],
  );

  /** Flush the worklet's last partial frame, then tell the server we are done. */
  const finishCapture = useCallback(() => {
    const n = node.current;
    const sendStop = () => {
      releaseAudio();
      if (ws.current?.readyState === WebSocket.OPEN) ws.current.send(JSON.stringify({ type: 'stop' }));
    };
    if (!n) return sendStop();
    let done = false;
    const fallback = window.setTimeout(() => {
      if (!done) {
        done = true;
        sendStop();
      }
    }, 300);
    n.port.addEventListener('message', (e: MessageEvent) => {
      if ((e.data as { type?: string }).type === 'flushed' && !done) {
        done = true;
        window.clearTimeout(fallback);
        // Let the final 'pcm' message (posted before 'flushed') be sent first.
        window.setTimeout(sendStop, 0);
      }
    });
    n.port.postMessage('flush');
  }, [releaseAudio]);

  const stop = useCallback(() => {
    const p = phaseRef.current;
    if (p === 'requesting_mic' || p === 'connecting') {
      stopRequested.current = true; // handled once the session is ready
      return;
    }
    if (p !== 'recording') return;
    go('finishing');
    // A tap shorter than MIN_HOLD_MS is treated as a cancel, not a recording.
    if (Date.now() - startedAt.current < MIN_HOLD_MS) {
      releaseAudio();
      closeSocket();
      setNotice('Hold the button down while you speak, then release.');
      go('idle');
      return;
    }
    finishCapture();
  }, [finishCapture, releaseAudio, closeSocket]);

  const start = useCallback(
    async (language: string) => {
      if (!['idle', 'done', 'error'].includes(phaseRef.current)) return;
      if (!token) return fail('Your session has expired. Sign in again.');
      setError(null);
      setNotice(null);
      setResult(null);
      setSegments([]);
      setElapsedMs(0);
      setProvider(null);
      queue.current = [];
      ready.current = false;
      stopRequested.current = false;
      go('requesting_mic');

      // 1. Microphone (mono, with the browser's speech processing)
      try {
        stream.current = await navigator.mediaDevices.getUserMedia({
          audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        });
      } catch (err) {
        return fail(micErrorMessage(err));
      }
      if (stopRequested.current) {
        releaseAudio();
        setNotice('Hold the button down while you speak, then release.');
        return go('idle');
      }

      // 2. Audio graph → PCM16LE 16 kHz frames
      try {
        let ac: AudioContext;
        let source: MediaStreamAudioSourceNode;
        try {
          ac = new AudioContext({ sampleRate: 16000 });
          source = ac.createMediaStreamSource(stream.current);
        } catch {
          // Firefox cannot connect a mic to a context at a different rate: resample in the worklet.
          ac = new AudioContext();
          source = ac.createMediaStreamSource(stream.current);
        }
        ctx.current = ac;
        await ac.audioWorklet.addModule(WORKLET_URL);
        const worklet = new AudioWorkletNode(ac, 'pcm-capture', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1 });
        node.current = worklet;
        worklet.port.onmessage = (e: MessageEvent<{ type: string; buffer?: ArrayBuffer; rms?: number }>) => {
          if (e.data.type === 'level') setLevel(Math.min(1, (e.data.rms ?? 0) * 4));
          if (e.data.type === 'pcm' && e.data.buffer) {
            if (ready.current && ws.current?.readyState === WebSocket.OPEN) ws.current.send(e.data.buffer);
            else if (queue.current.length < 30) queue.current.push(e.data.buffer);
          }
        };
        // A muted sink keeps the graph pulling audio without playing anything back.
        const mute = ac.createGain();
        mute.gain.value = 0;
        source.connect(worklet).connect(mute).connect(ac.destination);
        // Audio is captured (and queued) from here on, even before the socket is ready.
        startedAt.current = Date.now();
      } catch {
        return fail('This browser cannot process microphone audio. Upload an MP3 instead.');
      }

      // 3. Socket (token in the subprotocol — browsers cannot set WebSocket headers)
      go('connecting');
      const socket = new WebSocket(voiceStreamUrl(), [VOICE_PROTOCOL, `bearer.${token}`]);
      socket.binaryType = 'arraybuffer';
      ws.current = socket;

      socket.onopen = () => socket.send(JSON.stringify({ type: 'start', language }));
      socket.onmessage = (ev) => {
        if (typeof ev.data !== 'string') return;
        const msg = JSON.parse(ev.data) as ServerMsg;
        switch (msg.type) {
          case 'session_ready':
            ready.current = true;
            setProvider(String(msg.provider));
            setMaxSeconds(Number(msg.maxSeconds) || 120);
            for (const b of queue.current) socket.send(b);
            queue.current = [];
            go('recording');
            timer.current = window.setInterval(() => {
              const ms = Date.now() - startedAt.current;
              setElapsedMs(ms);
              if (ms >= (Number(msg.maxSeconds) || 120) * 1000) {
                setNotice('Maximum recording length reached.');
                stop();
              }
            }, 100);
            if (stopRequested.current) stop();
            break;
          case 'transcript':
            setSegments((s) => [...s, String(msg.text)]);
            break;
          case 'completed':
            releaseAudio();
            setResult(msg as unknown as VoiceResult);
            go('done');
            closeSocket();
            break;
          case 'error':
            if (msg.recoverable) setNotice(String(msg.message));
            else fail(String(msg.message));
            break;
        }
      };
      socket.onclose = (ev) => {
        if (ws.current !== socket) return; // we closed it deliberately
        ws.current = null;
        const p = phaseRef.current;
        if (p === 'done' || p === 'error' || p === 'idle') return;
        fail(
          ev.code === 1006 && !ready.current
            ? 'Could not connect to the voice service. Check your connection and try again.'
            : 'The voice connection was lost. Please try again.',
        );
      };
    },
    [token, fail, releaseAudio, closeSocket, stop],
  );

  const reset = useCallback(() => {
    releaseAudio();
    closeSocket();
    setSegments([]);
    setResult(null);
    setError(null);
    setNotice(null);
    setElapsedMs(0);
    go('idle');
  }, [releaseAudio, closeSocket]);

  // Never leave the microphone or socket open when the component goes away.
  useEffect(
    () => () => {
      releaseAudio();
      closeSocket();
    },
    [releaseAudio, closeSocket],
  );

  return { phase, level, elapsedMs, maxSeconds, segments, provider, notice, error, result, start, stop, reset };
}
