import { useEffect, useRef, useState } from 'react';
import { FileAudio, Upload, X } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { transcribeAudioFile, type VoiceResult } from './voiceApi';

const ACCEPT = '.mp3,audio/mpeg,.wav,audio/wav,.m4a,audio/mp4';
const ALLOWED_EXT = ['.mp3', '.wav', '.m4a'];

type Phase = 'idle' | 'uploading' | 'processing' | 'error';

export function AudioUpload({
  language,
  maxMb,
  maxSeconds,
  disabled,
  onResult,
}: {
  language: string;
  maxMb: number;
  maxSeconds: number;
  disabled?: boolean;
  onResult: (r: VoiceResult) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [phase, setPhase] = useState<Phase>('idle');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => () => abortRef.current?.abort(), []);

  const choose = (f: File | undefined) => {
    setError(null);
    if (!f) return;
    const ext = f.name.slice(f.name.lastIndexOf('.')).toLowerCase();
    if (!ALLOWED_EXT.includes(ext)) {
      setFile(null);
      return setError('Choose an MP3 recording (WAV and M4A are also accepted).');
    }
    if (f.size > maxMb * 1024 * 1024) {
      setFile(null);
      return setError(`The file is larger than ${maxMb} MB.`);
    }
    if (f.size === 0) {
      setFile(null);
      return setError('The file is empty.');
    }
    setFile(f);
  };

  const send = async () => {
    if (!file) return;
    setError(null);
    setProgress(0);
    setPhase('uploading');
    const ac = new AbortController();
    abortRef.current = ac;
    try {
      const r = await transcribeAudioFile(
        file,
        language,
        (pct) => {
          setProgress(pct);
          if (pct >= 100) setPhase('processing');
        },
        ac.signal,
      );
      setPhase('idle');
      setFile(null);
      if (inputRef.current) inputRef.current.value = '';
      onResult(r);
    } catch (err) {
      if (ac.signal.aborted) return setPhase('idle');
      setError(toApiError(err).message);
      setPhase('error');
    }
  };

  const busy = phase === 'uploading' || phase === 'processing';

  return (
    <div className="space-y-3">
      <label
        className={
          'flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50/60 px-4 py-6 text-center hover:border-brand-500 hover:bg-brand-50/40' +
          (disabled || busy ? ' pointer-events-none opacity-60' : '')
        }
      >
        <Upload className="size-6 text-slate-400" aria-hidden />
        <span className="text-sm font-medium text-slate-800">Choose an MP3 recording</span>
        <span className="text-xs text-slate-500">Up to {maxSeconds} seconds of speech · max {maxMb} MB</span>
        <input ref={inputRef} type="file" accept={ACCEPT} className="sr-only" onChange={(e) => choose(e.target.files?.[0])} disabled={disabled || busy} />
      </label>

      {file && (
        <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-3">
          <FileAudio className="size-5 shrink-0 text-brand-700" aria-hidden />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-slate-900">{file.name}</p>
            <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
            {busy && (
              <div className="mt-2">
                <div className="h-1.5 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Upload progress">
                  <div className="h-full bg-brand-600 transition-all" style={{ width: `${phase === 'processing' ? 100 : progress}%` }} />
                </div>
                <p className="mt-1 text-xs text-slate-500" aria-live="polite">{phase === 'processing' ? 'Transcribing…' : `Uploading ${progress}%`}</p>
              </div>
            )}
          </div>
          {busy ? (
            <Button size="sm" variant="ghost" onClick={() => abortRef.current?.abort()}>Cancel</Button>
          ) : (
            <>
              <Button size="sm" onClick={() => void send()}>Transcribe</Button>
              <button type="button" onClick={() => setFile(null)} className="rounded p-1 text-slate-400 hover:bg-slate-100" aria-label="Remove file">
                <X className="size-4" />
              </button>
            </>
          )}
        </div>
      )}
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}
