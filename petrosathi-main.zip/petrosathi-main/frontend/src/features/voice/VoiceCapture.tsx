import { useEffect, useState } from 'react';
import { FlaskConical, Mic, RotateCcw, Upload } from 'lucide-react';
import clsx from 'clsx';
import { segmentClass, segmentGroupClass } from '../../components/ui/styles';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Spinner } from '../../components/ui/Spinner';
import { toApiError } from '../../lib/api';
import { useAuthStore } from '../../store/authStore';
import { getLanguageCatalog, type LanguageCatalog, type VoiceResult } from './voiceApi';
import { usePushToTalk } from './usePushToTalk';
import { PushToTalkButton } from './PushToTalkButton';
import { LanguagePicker } from './LanguagePicker';
import { AudioUpload } from './AudioUpload';

type Mode = 'ptt' | 'upload';

function languageName(catalog: LanguageCatalog, code: string | null) {
  if (!code) return 'Unknown';
  return catalog.languages.find((l) => l.code === code)?.displayName ?? code;
}

/**
 * Voice input: push-to-talk or MP3 upload → original transcript.
 * The transcript is shown read-only here; the parent decides how to use it.
 */
export function VoiceCapture({ result, onResult, onClear }: { result: VoiceResult | null; onResult: (r: VoiceResult) => void; onClear: () => void }) {
  const preferred = useAuthStore((s) => s.user?.preferredLanguage);
  const [catalog, setCatalog] = useState<LanguageCatalog | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [language, setLanguage] = useState('');
  const [mode, setMode] = useState<Mode>('ptt');
  const ptt = usePushToTalk();

  useEffect(() => {
    getLanguageCatalog()
      .then((c) => {
        setCatalog(c);
        const supported = (code?: string) => !!code && c.languages.some((l) => l.code === code);
        setLanguage(supported(preferred) ? preferred! : supported(c.defaultLanguage) ? c.defaultLanguage : c.languages[0]?.code ?? 'en-IN');
      })
      .catch((err) => setLoadError(toApiError(err).message));
  }, [preferred]);

  // Hand finished push-to-talk results to the parent.
  useEffect(() => {
    if (ptt.phase === 'done' && ptt.result) onResult(ptt.result);
  }, [ptt.phase, ptt.result, onResult]);

  if (loadError) return <Alert tone="error">Voice input is unavailable: {loadError}</Alert>;
  if (!catalog) return <Spinner label="Loading voice settings…" />;

  const recording = !['idle', 'done', 'error'].includes(ptt.phase);
  const micSupported = typeof window !== 'undefined' && !!navigator.mediaDevices?.getUserMedia && typeof AudioWorkletNode !== 'undefined';

  if (result) {
    return (
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-sm font-semibold text-navy-900">Original transcript</p>
          {result.provider === 'mock' ? (
            <Badge tone="mock" className="normal-case"><FlaskConical className="size-3.5" aria-hidden /> Mock — no real speech recognition</Badge>
          ) : (
            <Badge tone="info">Gnani Prisma</Badge>
          )}
          <Badge>{result.audioMode === 'stream' ? 'Push-to-talk' : 'MP3 upload'}</Badge>
          <Badge>Language: {languageName(catalog, result.language)}</Badge>
        </div>
        {result.transcript ? (
          <blockquote className="whitespace-pre-wrap rounded-lg rounded-r-lg border-l-[3px] border-signal-400 bg-slate-50 px-4 py-3.5 text-sm leading-relaxed text-slate-900" lang={result.language ?? undefined}>
            {result.transcript}
          </blockquote>
        ) : (
          <Alert tone="warning">No speech was detected. Try again, speaking closer to the microphone.</Alert>
        )}
        {result.truncated && <Alert tone="warning">The speech service reported that this transcript was truncated.</Alert>}
        <p className="text-xs text-slate-500">This original transcript is stored with your ticket exactly as recognised. Edit the description below if anything was misheard.</p>
        <Button size="sm" variant="secondary" onClick={() => { ptt.reset(); onClear(); }}>
          <RotateCcw className="size-4" aria-hidden /> Record again
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-[minmax(0,1fr)_16rem]">
      <div>
        <div className={clsx(segmentGroupClass, 'mb-4')} role="tablist" aria-label="Voice input method">
          {(
            [
              ['ptt', 'Push-to-talk', Mic],
              ['upload', 'Upload MP3', Upload],
            ] as const
          ).map(([m, label, Icon]) => (
            <button
              key={m}
              role="tab"
              aria-selected={mode === m}
              disabled={recording}
              onClick={() => setMode(m)}
              className={segmentClass(mode === m)}
            >
              <Icon className="size-4" aria-hidden /> {label}
            </button>
          ))}
        </div>

        {mode === 'ptt' ? (
          micSupported ? (
            <div className="space-y-4">
              <PushToTalkButton
                phase={ptt.phase}
                level={ptt.level}
                elapsedMs={ptt.elapsedMs}
                maxSeconds={ptt.maxSeconds || catalog.maxStreamSeconds}
                onStart={() => void ptt.start(language)}
                onStop={ptt.stop}
              />
              {ptt.segments.length > 0 && ptt.phase !== 'done' && (
                <p className="rounded-lg bg-slate-50 p-3 text-sm text-slate-700" aria-live="polite">{ptt.segments.join(' ')}</p>
              )}
              {ptt.notice && <Alert tone="info">{ptt.notice}</Alert>}
              {ptt.error && <Alert tone="error">{ptt.error}</Alert>}
              {ptt.phase === 'done' && ptt.result && !ptt.result.transcript && (
                <Alert tone="warning">No speech was detected. Hold the button and speak clearly, then release.</Alert>
              )}
            </div>
          ) : (
            <Alert tone="warning">This browser does not support microphone capture. Upload an MP3 recording instead.</Alert>
          )
        ) : (
          <AudioUpload language={language} maxMb={catalog.maxUploadMb} maxSeconds={catalog.maxUploadSeconds} onResult={onResult} />
        )}
      </div>

      <div className="space-y-3">
        <LanguagePicker catalog={catalog} value={language} onChange={setLanguage} disabled={recording} />
        {catalog.providerMode === 'mock' && (
          <Alert tone="warning" className="text-xs">
            Mock mode: transcripts are fixed demonstration text and do not reflect what you say.
          </Alert>
        )}
      </div>
    </div>
  );
}
