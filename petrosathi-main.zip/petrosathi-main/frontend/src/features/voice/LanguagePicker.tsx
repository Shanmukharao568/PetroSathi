import { Check, Minus } from 'lucide-react';
import clsx from 'clsx';
import { Select } from '../../components/ui/Select';
import type { LanguageCatalog, SupportLevel } from './voiceApi';

export const SUPPORT_LABEL: Record<SupportLevel, string> = {
  full_voice: 'Full voice support',
  speech_recognition_only: 'Speech recognition only',
  text_response: 'Text responses only',
  tts: 'Spoken replies only',
  unsupported: 'Not supported',
};

function Cap({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li className={clsx('inline-flex items-center gap-1', ok ? 'text-emerald-700' : 'text-slate-400')}>
      {ok ? <Check className="size-3.5" aria-hidden /> : <Minus className="size-3.5" aria-hidden />}
      <span>{label}</span>
      <span className="sr-only">{ok ? 'available' : 'not available'}</span>
    </li>
  );
}

/** Language selector driven entirely by the server's verified capability registry. */
export function LanguagePicker({ catalog, value, onChange, disabled }: { catalog: LanguageCatalog; value: string; onChange: (v: string) => void; disabled?: boolean }) {
  const options = [
    ...(catalog.autoDetection ? [{ value: 'auto', label: 'Auto-detect language' }] : []),
    ...catalog.languages.map((l) => ({ value: l.code, label: l.nativeName === l.displayName ? l.displayName : `${l.nativeName} · ${l.displayName}` })),
  ];
  const selected = catalog.languages.find((l) => l.code === value);

  return (
    <div className="space-y-2">
      <Select label="Spoken language" value={value} onChange={(e) => onChange(e.target.value)} options={options} disabled={disabled} />
      {selected ? (
        <div className="text-xs">
          <p className="font-medium text-slate-600">{SUPPORT_LABEL[selected.supportLevel]}</p>
          <ul className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
            <Cap ok={selected.prismaStreaming} label="Push-to-talk" />
            <Cap ok={selected.prismaSTT} label="MP3 upload" />
            <Cap ok={selected.evonInput} label="AI complaint extraction" />
            <Cap ok={selected.timbreTTS} label="Spoken replies" />
          </ul>
        </div>
      ) : value === 'auto' ? (
        <p className="text-xs text-slate-500">The speech service will detect which supported Indian language you speak.</p>
      ) : null}
    </div>
  );
}
