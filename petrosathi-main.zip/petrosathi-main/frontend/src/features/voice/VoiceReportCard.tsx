import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowRight, Mic } from 'lucide-react';
import { Card, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { toApiError } from '../../lib/api';
import { createDraft } from '../complaints/complaintsApi';
import { VoiceCapture } from './VoiceCapture';
import type { VoiceResult } from './voiceApi';

/**
 * Push-to-talk / MP3 → transcript → "Continue" creates a complaint draft and opens it.
 * Shared by the operator dashboard and the report page. Nothing is submitted here.
 */
export function VoiceReportCard({ onResult, title = 'Report by voice' }: { onResult?: (r: VoiceResult | null) => void; title?: string }) {
  const navigate = useNavigate();
  const [voice, setVoice] = useState<VoiceResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleResult = useCallback(
    (r: VoiceResult) => {
      setVoice(r);
      onResult?.(r);
    },
    [onResult],
  );
  const handleClear = useCallback(() => {
    setVoice(null);
    onResult?.(null);
  }, [onResult]);

  const continueWithVoice = async (conversationId: string) => {
    setBusy(true);
    setError(null);
    try {
      const d = await createDraft({ conversationId });
      navigate(`/operator/drafts/${d.id}`);
    } catch (err) {
      setError(toApiError(err).message);
      setBusy(false);
    }
  };

  return (
    <Card className="ring-gradient">
      <CardHeader icon={<Mic />} title={title} description="Speak the problem in your language. You will review it before anything is submitted." />
      <div className="space-y-4 p-5 sm:p-6">
        <VoiceCapture result={voice} onResult={handleResult} onClear={handleClear} />
        {voice?.transcript && voice.conversationId && (
          <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 pt-4">
            <Button size="lg" loading={busy} onClick={() => void continueWithVoice(voice.conversationId!)}>
              Continue <ArrowRight className="size-4" aria-hidden />
            </Button>
            <p className="text-xs text-slate-500">Next: check the details, answer any follow-up questions, then confirm.</p>
          </div>
        )}
        {error && <Alert tone="error">{error}</Alert>}
      </div>
    </Card>
  );
}
