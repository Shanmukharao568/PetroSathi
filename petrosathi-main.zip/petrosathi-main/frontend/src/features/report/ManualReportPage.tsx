import { useCallback, useEffect, useState, type KeyboardEvent } from 'react';
import { Link } from 'react-router';
import { CheckCircle2, ClipboardCheck, Plus, X } from 'lucide-react';
import { listOpenDrafts, STATE_LABEL, type DraftSummary } from '../complaints/complaintsApi';
import { timeAgo } from '../../lib/format';
import { VoiceReportCard } from '../voice/VoiceReportCard';
import type { VoiceResult } from '../voice/voiceApi';
import { Card, CardHeader, PageHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Select';
import { Textarea } from '../../components/ui/Textarea';
import { Alert } from '../../components/ui/Alert';
import { Badge } from '../../components/ui/Badge';
import { SeverityBadge } from '../../components/tickets/Badges';
import { toApiError } from '../../lib/api';
import { CATEGORY_LABEL, SEVERITY_LABEL } from '../../lib/format';
import { COMPLAINT_CATEGORIES, SEVERITIES, type ComplaintCategory, type Equipment, type Severity, type Ticket } from '../../types/domain';
import { createTicket } from '../tickets/ticketsApi';
import { EquipmentPicker } from './EquipmentPicker';

type Step = 'edit' | 'review' | 'done';

/**
 * Complaint reporting.
 *  - Voice: record/upload → transcript → complaint draft (extraction, follow-up questions,
 *    review) → explicit confirmation on the draft page.
 *  - Typed: the form below → review → explicit confirmation.
 * In both paths a ticket is created ONLY after the operator explicitly confirms.
 */
export function ManualReportPage() {
  const [step, setStep] = useState<Step>('edit');
  const [openDrafts, setOpenDrafts] = useState<DraftSummary[]>([]);

  useEffect(() => {
    listOpenDrafts().then(setOpenDrafts).catch(() => setOpenDrafts([]));
  }, []);

  const [voice, setVoice] = useState<VoiceResult | null>(null);
  const [equipment, setEquipment] = useState<Equipment | null>(null);
  const [description, setDescription] = useState('');
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [symptomInput, setSymptomInput] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>('other');
  const [severity, setSeverity] = useState<Severity>('unknown');
  const [errors, setErrors] = useState<{ equipment?: string; description?: string }>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  // One key per confirmed submission: retries after a network error reuse it, so no duplicate ticket.
  const [idempotencyKey, setIdempotencyKey] = useState<string | null>(null);
  const [created, setCreated] = useState<Ticket | null>(null);

  const onVoiceResult = useCallback((r: VoiceResult | null) => {
    setVoice(r);
    // Pre-fill the editable description only if the operator has not typed one yet.
    if (r?.transcript) setDescription((d) => (d.trim() ? d : r.transcript));
  }, []);

  const addSymptom = () => {
    const s = symptomInput.trim();
    if (s && !symptoms.includes(s) && symptoms.length < 20) setSymptoms([...symptoms, s]);
    setSymptomInput('');
  };
  const onSymptomKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addSymptom();
    }
  };

  const toReview = () => {
    const errs: typeof errors = {};
    if (!equipment) errs.equipment = 'Select the affected equipment';
    if (description.trim().length < 10) errs.description = 'Describe the problem in at least 10 characters';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setIdempotencyKey(crypto.randomUUID());
    setSubmitError(null);
    setStep('review');
  };

  const confirm = async () => {
    if (!equipment || !idempotencyKey) return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      const t = await createTicket(
        {
          equipmentId: equipment.id,
          description: description.trim(),
          symptoms,
          category,
          severity,
          ...(voice?.conversationId && voice.transcript ? { conversationId: voice.conversationId } : {}),
        },
        idempotencyKey,
      );
      setCreated(t);
      setStep('done');
    } catch (err) {
      setSubmitError(toApiError(err).message);
    } finally {
      setSubmitting(false);
    }
  };

  const startOver = () => {
    setStep('edit'); setEquipment(null); setDescription(''); setSymptoms([]); setCategory('other'); setSeverity('unknown'); setVoice(null);
    setIdempotencyKey(null); setCreated(null); setErrors({});
  };

  if (step === 'done' && created) {
    return (
      <>
        <PageHeader eyebrow="New report" title="Report an issue" />
        <Card className="mx-auto max-w-xl p-8 text-center">
          <CheckCircle2 className="mx-auto size-12 text-emerald-600" aria-hidden />
          <h2 className="mt-4 text-xl font-semibold text-navy-900">Ticket created</h2>
          <p className="mt-1 font-mono text-2xl font-semibold text-brand-700">{created.ticketNumber}</p>
          <p className="mt-2 text-sm text-slate-500">Maintenance engineers have been notified. You can follow its status in My tickets.</p>
          <div className="mt-6 flex justify-center gap-2">
            <Link to={`/operator/tickets/${created.id}`}><Button>View ticket</Button></Link>
            <Button variant="secondary" onClick={startOver}>Report another issue</Button>
          </div>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="New report" title="Report an issue" description="Speak or type the equipment problem. You will review it before a ticket is created." />

      {step === 'edit' && (
        <div className="max-w-3xl space-y-6">
        {openDrafts.length > 0 && (
          <Card>
            <CardHeader title="Unfinished reports" description="Continue where you left off. Unconfirmed reports expire automatically." />
            <ul className="divide-y divide-slate-100">
              {openDrafts.map((d) => (
                <li key={d.id}>
                  <Link to={`/operator/drafts/${d.id}`} className="flex items-center gap-3 px-5 py-3 text-sm hover:bg-slate-50">
                    <span className="w-20 shrink-0 font-mono font-medium text-navy-900">{d.fields.equipmentCode ?? '—'}</span>
                    <span className="min-w-0 flex-1 truncate text-slate-700">{d.fields.description}</span>
                    <Badge tone={d.state === 'READY_FOR_CONFIRMATION' ? 'success' : 'warning'}>{STATE_LABEL[d.state]}</Badge>
                    <span className="hidden text-xs text-slate-500 sm:inline">{timeAgo(d.updatedAt)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
        <VoiceReportCard onResult={onVoiceResult} />
        <Card>
          <CardHeader title="Or type the details yourself" />
          <div className="space-y-5 p-5 sm:p-6">
            <EquipmentPicker value={equipment} onChange={setEquipment} error={errors.equipment} />
            {equipment && (
              <p className="text-sm text-slate-600">Selected: <span className="font-mono font-medium text-navy-900">{equipment.equipmentCode}</span> — {equipment.name}</p>
            )}
            <Textarea label={voice?.transcript ? "Complaint description (pre-filled from your voice — edit if needed)" : "What is the problem?"} rows={5} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={4000}
              placeholder="e.g. Loud grinding noise and strong vibration from the pump bearing since the morning shift." error={errors.description} />
            <div className="space-y-1.5">
              <label htmlFor="symptom" className="block text-sm font-medium text-slate-700">Symptoms <span className="font-normal text-slate-400">(optional)</span></label>
              <div className="flex gap-2">
                <input id="symptom" value={symptomInput} onChange={(e) => setSymptomInput(e.target.value)} onKeyDown={onSymptomKey} maxLength={200}
                  placeholder="e.g. vibration, leak, overheating"
                  className="h-10 flex-1 rounded-lg border border-slate-300 bg-white px-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 hover:border-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none" />
                <Button variant="secondary" onClick={addSymptom} disabled={!symptomInput.trim()}><Plus className="size-4" aria-hidden /> Add</Button>
              </div>
              {symptoms.length > 0 && (
                <ul className="flex flex-wrap gap-1.5 pt-1">
                  {symptoms.map((s) => (
                    <li key={s}>
                      <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 py-0.5 pl-2 pr-1 text-xs text-slate-700">
                        {s}
                        <button type="button" onClick={() => setSymptoms(symptoms.filter((x) => x !== s))} className="rounded p-0.5 hover:bg-slate-200" aria-label={`Remove ${s}`}>
                          <X className="size-3" />
                        </button>
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Select label="Category" value={category} onChange={(e) => setCategory(e.target.value as ComplaintCategory)}
                options={COMPLAINT_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_LABEL[c] }))} />
              <Select label="Severity" value={severity} onChange={(e) => setSeverity(e.target.value as Severity)}
                options={SEVERITIES.map((s) => ({ value: s, label: s === 'unknown' ? 'Not sure — let the engineer assess' : SEVERITY_LABEL[s] }))} />
            </div>
            <p className="text-xs text-slate-500">
              PetroSathi records your report for maintenance. It does not authorize shutdown, isolation, repair or restart — follow site procedures and your supervisor's instructions for any immediate safety action.
            </p>
            <div className="flex justify-end">
              <Button onClick={toReview}><ClipboardCheck className="size-4" aria-hidden /> Review report</Button>
            </div>
          </div>
        </Card>
        </div>
      )}

      {step === 'review' && equipment && (
        <Card className="max-w-3xl">
          <CardHeader title="Review your report" description="Check the details. A ticket is created only when you confirm." />
          <dl className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 sm:p-6">
            <div className="sm:col-span-2">
              <dt className="type-label text-slate-500">Equipment</dt>
              <dd className="mt-0.5 text-sm"><span className="font-mono font-medium text-navy-900">{equipment.equipmentCode}</span> — {equipment.name}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="type-label text-slate-500">Problem</dt>
              <dd className="mt-0.5 whitespace-pre-wrap text-sm text-slate-800">{description.trim()}</dd>
            </div>
            {voice?.transcript && (
              <div className="sm:col-span-2">
                <dt className="flex items-center gap-2 type-label text-slate-500">
                  Original voice transcript {voice.provider === 'mock' && <Badge tone="mock">Mock</Badge>}
                </dt>
                <dd className="mt-1 whitespace-pre-wrap rounded-r-lg border-l-[3px] border-signal-400 bg-slate-50 px-4 py-3.5 leading-relaxed text-sm text-slate-700">{voice.transcript}</dd>
              </div>
            )}
            <div>
              <dt className="type-label text-slate-500">Symptoms</dt>
              <dd className="mt-1 flex flex-wrap gap-1">{symptoms.length ? symptoms.map((s) => <Badge key={s}>{s}</Badge>) : <span className="text-sm text-slate-500">None listed</span>}</dd>
            </div>
            <div className="flex gap-6">
              <div>
                <dt className="type-label text-slate-500">Category</dt>
                <dd className="mt-1 text-sm">{CATEGORY_LABEL[category]}</dd>
              </div>
              <div>
                <dt className="type-label text-slate-500">Severity</dt>
                <dd className="mt-1"><SeverityBadge severity={severity} /></dd>
              </div>
            </div>
          </dl>
          <div className="space-y-3 border-t border-slate-100 bg-slate-50 px-5 py-4 sm:px-6">
            {submitError && <Alert tone="error">{submitError} Retrying is safe: the same report will not be filed twice.</Alert>}
            <div className="flex flex-wrap justify-end gap-2">
              <Button variant="secondary" onClick={() => setStep('edit')} disabled={submitting}>Edit</Button>
              <Button onClick={() => void confirm()} loading={submitting}>Confirm and create ticket</Button>
            </div>
          </div>
        </Card>
      )}
    </>
  );
}
