import { useEffect, useId, useState } from 'react';
import { Check, Search } from 'lucide-react';
import clsx from 'clsx';
import { useDebounced } from '../../hooks/useDebounced';
import { toApiError } from '../../lib/api';
import { equipmentTypeLabel } from '../../lib/format';
import type { Equipment } from '../../types/domain';
import { listEquipment } from '../equipment/equipmentApi';
import { Spinner } from '../../components/ui/Spinner';

/** Searches the real equipment register. Decommissioned equipment is shown but not selectable. */
export function EquipmentPicker({ value, onChange, error }: { value: Equipment | null; onChange: (e: Equipment | null) => void; error?: string }) {
  const id = useId();
  const [query, setQuery] = useState('');
  const q = useDebounced(query.trim(), 250);
  const [results, setResults] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    listEquipment({ page: 1, limit: 8, ...(q && { search: q }) })
      .then((r) => !cancelled && (setResults(r.items), setLoadError(null)))
      .catch((err) => !cancelled && setLoadError(toApiError(err).message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [q]);

  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-slate-700">Equipment</label>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
        <input
          id={id}
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by tag (e.g. P-101) or name"
          aria-invalid={error ? true : undefined}
          className={clsx(
            'h-11 w-full rounded-lg border bg-white pl-9 pr-3 text-sm shadow-field transition-[border-color,box-shadow] placeholder:text-slate-400 focus:border-brand-500 focus:ring-[3px] focus:ring-brand-500/15 focus:outline-none',
            error ? 'border-red-400' : 'border-slate-300 hover:border-slate-400',
          )}
        />
      </div>
      <ul className="max-h-64 divide-y divide-slate-100 overflow-y-auto rounded-lg border border-slate-200 bg-white" role="listbox" aria-label="Equipment results">
        {loading && results.length === 0 && <li className="p-3"><Spinner label="Searching…" /></li>}
        {!loading && results.length === 0 && <li className="p-3 text-sm text-slate-500">{loadError ?? 'No registered equipment matches. Check the tag on the equipment nameplate.'}</li>}
        {results.map((e) => {
          const disabled = e.status === 'decommissioned';
          const selected = value?.id === e.id;
          return (
            <li key={e.id} role="option" aria-selected={selected} aria-disabled={disabled}>
              <button
                type="button"
                disabled={disabled}
                onClick={() => onChange(selected ? null : e)}
                className={clsx('flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm', selected ? 'bg-brand-50' : 'hover:bg-slate-50', disabled && 'cursor-not-allowed opacity-50')}
              >
                <span className="w-20 shrink-0 font-mono font-medium text-navy-900">{e.equipmentCode}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-slate-900">{e.name}</span>
                  <span className="block truncate text-xs text-slate-500">{equipmentTypeLabel(e.type)} · {e.plant}{e.location && ` · ${e.location}`}{disabled && ' · decommissioned'}</span>
                </span>
                {selected && <Check className="size-4 text-brand-700" aria-hidden />}
              </button>
            </li>
          );
        })}
      </ul>
      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  );
}
