import { useCallback, useEffect, useState } from 'react';
import { api, toApiError, type ApiSuccess } from '../lib/api';

export interface HealthData {
  status: 'ok' | 'degraded';
  service: string;
  database: string;
  aiProviderMode: 'mock' | 'real';
  timestamp: string;
}

type State =
  | { kind: 'loading' }
  | { kind: 'ready'; data: HealthData }
  | { kind: 'error'; message: string };

/** Polls the real backend /health endpoint. */
export function useHealth(intervalMs = 30_000) {
  const [state, setState] = useState<State>({ kind: 'loading' });

  const refresh = useCallback(async () => {
    try {
      const res = await api.get<ApiSuccess<HealthData>>('/health');
      setState({ kind: 'ready', data: res.data.data });
    } catch (err) {
      setState({ kind: 'error', message: toApiError(err).message });
    }
  }, []);

  useEffect(() => {
    void refresh();
    const id = window.setInterval(() => void refresh(), intervalMs);
    return () => window.clearInterval(id);
  }, [refresh, intervalMs]);

  return { state, refresh };
}
