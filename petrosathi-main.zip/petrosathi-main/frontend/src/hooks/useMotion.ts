import { useEffect, useRef, useState } from 'react';

/** True when the operator asked the OS for less motion (always true under tests, so values are final). */
export function prefersReducedMotion(): boolean {
  if (import.meta.env.MODE === 'test') return true;
  return typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Animates a number from its previous value to `target` (ease-out cubic). Starts from 0 on
 * first render so dashboard figures "count up". Reduced motion → jumps straight to the value.
 */
export function useCountUp(target: number | null, durationMs = 900): number | null {
  const reduced = prefersReducedMotion() || typeof requestAnimationFrame === 'undefined';
  const [value, setValue] = useState(0);
  const from = useRef(0);

  useEffect(() => {
    if (target === null || reduced) {
      if (target !== null) from.current = target;
      return;
    }
    const start = from.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / durationMs);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(start + (target - start) * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
      else from.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs, reduced]);

  if (target === null) return null;
  return reduced ? target : value;
}

/**
 * Installs one document-level pointer listener that feeds `--mx/--my` to the `.spotlight`
 * surface under the cursor. Cheap: one listener, one style write per frame at most.
 */
export function useSpotlight() {
  useEffect(() => {
    if (prefersReducedMotion() || !window.matchMedia?.('(hover: hover)').matches) return;
    let raf = 0;
    let last: PointerEvent | null = null;
    const apply = () => {
      raf = 0;
      const e = last;
      if (!e) return;
      const el = (e.target as Element | null)?.closest?.('.spotlight') as HTMLElement | null;
      if (!el) return;
      const r = el.getBoundingClientRect();
      el.style.setProperty('--mx', `${e.clientX - r.left}px`);
      el.style.setProperty('--my', `${e.clientY - r.top}px`);
    };
    const onMove = (e: PointerEvent) => {
      last = e;
      if (!raf) raf = requestAnimationFrame(apply);
    };
    document.addEventListener('pointermove', onMove, { passive: true });
    return () => {
      document.removeEventListener('pointermove', onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
}
