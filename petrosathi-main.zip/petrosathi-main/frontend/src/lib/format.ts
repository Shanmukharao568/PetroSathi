import type { ComplaintCategory, EquipmentStatus, EquipmentType, Severity, TicketStatus } from '../types/domain';
import type { Role } from '../types/auth';

export const STATUS_LABEL: Record<TicketStatus, string> = {
  OPEN: 'Open',
  UNDER_INSPECTION: 'Under inspection',
  IN_PROGRESS: 'In progress',
  RESOLVED: 'Resolved',
  CLOSED: 'Closed',
};

export const SEVERITY_LABEL: Record<Severity, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
  unknown: 'Not assessed',
};

export const CATEGORY_LABEL: Record<ComplaintCategory, string> = {
  mechanical: 'Mechanical',
  electrical: 'Electrical',
  instrumentation: 'Instrumentation',
  process: 'Process',
  safety: 'Safety',
  other: 'Other',
};

export const EQUIPMENT_STATUS_LABEL: Record<EquipmentStatus, string> = {
  operational: 'Operational',
  degraded: 'Degraded',
  down: 'Down',
  under_maintenance: 'Under maintenance',
  decommissioned: 'Decommissioned',
};

export const humanize = (s: string) => s.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
export const equipmentTypeLabel = (t: EquipmentType) => humanize(t);

export function formatDateTime(iso: string | null | undefined) {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso));
}

export function timeAgo(iso: string) {
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  const d = Math.round(h / 24);
  if (d < 30) return `${d} d ago`;
  return formatDateTime(iso);
}

/** Base path for ticket routes per role. Admins use the engineer ticket views. */
export function ticketBasePath(role: Role) {
  return role === 'operator' ? '/operator/tickets' : '/engineer/tickets';
}
