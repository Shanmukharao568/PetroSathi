import { z } from 'zod';

/** Mirrors backend/src/utils/password.ts — the server remains the source of truth. */
export const passwordPolicy = z
  .string()
  .min(10, 'At least 10 characters')
  .max(128, 'At most 128 characters')
  .refine((p) => /[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p), {
    message: 'Must include upper-case, lower-case letters and a digit',
  });

/**
 * Preferred UI/report language for a user profile.
 * NOTE: this is a *preference* list only. Which languages actually work for speech, extraction
 * and TTS comes from the backend capability registry (Phase 4) and is shown separately.
 */
export const PREFERRED_LANGUAGE_OPTIONS = [
  { value: 'en-IN', label: 'English (India)' },
  { value: 'hi-IN', label: 'हिन्दी · Hindi' },
  { value: 'te-IN', label: 'తెలుగు · Telugu' },
  { value: 'ta-IN', label: 'தமிழ் · Tamil' },
  { value: 'kn-IN', label: 'ಕನ್ನಡ · Kannada' },
  { value: 'ml-IN', label: 'മലയാളം · Malayalam' },
  { value: 'mr-IN', label: 'मराठी · Marathi' },
  { value: 'gu-IN', label: 'ગુજરાતી · Gujarati' },
  { value: 'bn-IN', label: 'বাংলা · Bengali' },
  { value: 'pa-IN', label: 'ਪੰਜਾਬੀ · Punjabi' },
  { value: 'or-IN', label: 'ଓଡ଼ିଆ · Odia' },
];

export function languageLabel(tag: string) {
  return PREFERRED_LANGUAGE_OPTIONS.find((o) => o.value === tag)?.label ?? tag;
}
