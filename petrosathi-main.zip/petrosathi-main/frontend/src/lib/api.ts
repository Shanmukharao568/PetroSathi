import axios, { AxiosError } from 'axios';

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:5000/api/v1';

/** Mirrors the backend envelope in backend/src/utils/response.ts. */
export interface ApiSuccess<T> {
  success: true;
  data: T;
  meta?: { pagination?: Pagination } & Record<string, unknown>;
}
export interface ApiFailure {
  success: false;
  error: { code: string; message: string; details?: unknown };
}
export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30_000,
  headers: { 'Content-Type': 'application/json' },
});

/**
 * Auth wiring is injected by the auth store (avoids a circular import).
 * - getToken: current bearer token, if any
 * - onAuthFailure: called when the server rejects the session or requires a password change
 */
interface AuthHooks {
  getToken: () => string | null;
  onAuthFailure: (reason: 'expired' | 'revoked' | 'password_change' | 'email_verification') => void;
}
let authHooks: AuthHooks | null = null;
export function registerAuthHooks(hooks: AuthHooks) {
  authHooks = hooks;
}

api.interceptors.request.use((config) => {
  const token = authHooks?.getToken();
  if (token) config.headers.set('Authorization', `Bearer ${token}`);
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err: unknown) => {
    if (err instanceof AxiosError && err.response && authHooks?.getToken()) {
      const body = err.response.data as ApiFailure | undefined;
      const code = body?.error?.code;
      const isLogin = err.config?.url?.includes('/auth/login');
      if (err.response.status === 401 && !isLogin) {
        authHooks.onAuthFailure(code === 'TOKEN_EXPIRED' ? 'expired' : 'revoked');
      } else if (code === 'PASSWORD_CHANGE_REQUIRED') {
        authHooks.onAuthFailure('password_change');
      } else if (code === 'EMAIL_VERIFICATION_REQUIRED') {
        authHooks.onAuthFailure('email_verification');
      }
    }
    return Promise.reject(err);
  },
);

export interface FieldIssue {
  location?: string;
  path: string;
  message: string;
}

/** Turns any thrown value into a user-presentable message + stable code. */
export function toApiError(err: unknown): { code: string; message: string; status?: number; issues?: FieldIssue[] } {
  if (err instanceof AxiosError) {
    const body = err.response?.data as ApiFailure | undefined;
    if (body && body.success === false) {
      const issues = Array.isArray(body.error.details) ? (body.error.details as FieldIssue[]) : undefined;
      const message =
        body.error.code === 'VALIDATION_ERROR' && issues?.length
          ? issues.map((i) => (i.path ? `${i.path}: ${i.message}` : i.message)).join('; ')
          : body.error.message;
      return { code: body.error.code, message, status: err.response?.status, issues };
    }
    if (!err.response) {
      return { code: 'NETWORK_ERROR', message: 'Cannot reach the PetroSathi server. Check that the API is running.' };
    }
    return { code: 'HTTP_ERROR', message: err.message, status: err.response.status };
  }
  return { code: 'UNKNOWN', message: err instanceof Error ? err.message : 'Unexpected error' };
}
