/** Must stay in step with AVATAR_MAX_CHARS in backend/src/config/constants.ts. */
export const AVATAR_MAX_CHARS = 120_000;
export const AVATAR_ACCEPT = 'image/png,image/jpeg,image/webp';
const MAX_INPUT_BYTES = 8 * 1024 * 1024;
const SIDE = 256;

/**
 * Turns a picked photo into a small square JPEG data URL (centre-cropped to 256×256) that fits
 * the server's size limit. Runs entirely in the browser; the original file never leaves it.
 */
export async function photoToAvatar(file: File): Promise<string> {
  if (!AVATAR_ACCEPT.split(',').includes(file.type)) throw new Error('Choose a PNG, JPEG or WebP photo.');
  if (file.size > MAX_INPUT_BYTES) throw new Error('That photo is larger than 8 MB. Choose a smaller one.');

  const bitmap = await createImageBitmap(file);
  try {
    const crop = Math.min(bitmap.width, bitmap.height);
    const canvas = document.createElement('canvas');
    canvas.width = SIDE;
    canvas.height = SIDE;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Your browser could not process this photo.');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bitmap, (bitmap.width - crop) / 2, (bitmap.height - crop) / 2, crop, crop, 0, 0, SIDE, SIDE);

    for (const quality of [0.86, 0.75, 0.62, 0.5]) {
      const url = canvas.toDataURL('image/jpeg', quality);
      if (url.length <= AVATAR_MAX_CHARS) return url;
    }
    throw new Error('Could not make this photo small enough. Try a different one.');
  } finally {
    bitmap.close();
  }
}
