/**
 * Writes the clearly-labelled DEMONSTRATION PDFs into knowledge-base/<folder>/ together with a
 * sidecar <file>.meta.json used by `npm run kb:ingest`.  Usage: npm run kb:demo
 */
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEMO_DOCUMENTS } from '../rag/demoContent.js';
import { buildDemoPdf } from '../rag/demoPdf.js';

const kbRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../knowledge-base');

for (const doc of DEMO_DOCUMENTS) {
  const dir = path.join(kbRoot, doc.folder);
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, doc.fileName);
  await writeFile(file, await buildDemoPdf(doc));
  await writeFile(
    `${file}.meta.json`,
    JSON.stringify({ title: doc.title, documentType: doc.documentType, equipmentTypes: doc.equipmentTypes, equipmentCodes: [], demo: true }, null, 2) + '\n',
  );
  console.log(`wrote ${path.relative(kbRoot, file)}`);
}
