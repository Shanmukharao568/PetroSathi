/**
 * Ingests approved PDFs placed in knowledge-base/{manuals,safety,troubleshooting,inspection}/.
 * Usage: npm run kb:ingest   (requires MongoDB and the vector store from VECTOR_STORE)
 *
 * Optional sidecar "<file>.pdf.meta.json":
 *   { "title": "...", "documentType": "manual", "equipmentCodes": ["P-101"], "equipmentTypes": ["pump"] }
 * Unchanged files (same checksum + embedding model) are skipped; changed files are re-ingested.
 * Each PDF is copied into MongoDB GridFS, so the server does not need knowledge-base/ on disk.
 * Point MONGODB_URI at Atlas (with VECTOR_STORE=mongo) to load a hosted deployment from your PC.
 */
import { readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { connectDatabase, disconnectDatabase } from '../config/db.js';
import { DocumentModel, DOCUMENT_TYPES, type DocumentType } from '../modules/documents/document.model.js';
import { sha256 } from '../modules/documents/document.service.js';
import { EquipmentModel } from '../modules/equipment/equipment.model.js';
import { EQUIPMENT_TYPES } from '../config/constants.js';
import { ingestDocument } from '../rag/ingestion.js';
import { getVectorStore, vectorStoreLabel } from '../rag/vectorStore/index.js';
import { deleteStoredFile, isGridFsRef, saveFile } from '../modules/documents/fileStore.js';
import { getEmbeddingProvider } from '../rag/embeddings/index.js';
import { env } from '../config/env.js';

const kbRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../knowledge-base');
const FOLDER_TYPE: Record<string, DocumentType> = { manuals: 'manual', safety: 'safety', troubleshooting: 'troubleshooting', inspection: 'inspection' };

const metaSchema = z
  .object({
    title: z.string().min(3).max(200).optional(),
    documentType: z.enum(DOCUMENT_TYPES).optional(),
    equipmentCodes: z.array(z.string()).default([]),
    equipmentTypes: z.array(z.enum(EQUIPMENT_TYPES)).default([]),
    demo: z.boolean().optional(),
  })
  .passthrough();

async function readMeta(file: string) {
  try {
    return metaSchema.parse(JSON.parse(await readFile(`${file}.meta.json`, 'utf8')));
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return metaSchema.parse({});
    throw new Error(`Invalid ${path.basename(file)}.meta.json: ${(err as Error).message}`);
  }
}

async function main() {
  await connectDatabase();
  try {
    await getVectorStore().health();
  } catch (err) {
    const hint = env.VECTOR_STORE === 'mongo' ? (err as Error).message : `Start it with "npm run chroma" (${env.CHROMA_URL}).`;
    throw new Error(`${vectorStoreLabel()} is not usable. ${hint}`);
  }
  const model = getEmbeddingProvider().model;
  console.log(`Embedding model: ${model}`);

  let created = 0;
  let updated = 0;
  let skipped = 0;
  let failed = 0;
  for (const [folder, defaultType] of Object.entries(FOLDER_TYPE)) {
    const dir = path.join(kbRoot, folder);
    const files = (await readdir(dir).catch(() => [] as string[])).filter((f) => f.toLowerCase().endsWith('.pdf'));
    for (const name of files) {
      const file = path.join(dir, name);
      const buf = await readFile(file);
      const checksum = sha256(buf);
      const meta = await readMeta(file);

      const codes = meta.equipmentCodes.map((c) => c.toUpperCase());
      const equipment = codes.length ? await EquipmentModel.find({ equipmentCode: { $in: codes } }).select('_id equipmentCode') : [];
      const unknown = codes.filter((c) => !equipment.some((e) => e.equipmentCode === c));
      if (unknown.length) console.warn(`  ! ${name}: unknown equipment codes ignored: ${unknown.join(', ')}`);

      const kbPath = `${folder}/${name}`;
      let doc = await DocumentModel.findOne({ source: 'preloaded', $or: [{ kbPath }, { storagePath: file }] });
      const duplicate = await DocumentModel.findOne({ checksum, ...(doc ? { _id: { $ne: doc._id } } : {}) }).select('title');
      if (duplicate) {
        console.warn(`  ! ${name}: identical to already-ingested "${duplicate.title}", skipped`);
        skipped++;
        continue;
      }
      if (doc && doc.checksum === checksum && doc.ingestionStatus === 'ready' && doc.embeddingModel === model && isGridFsRef(doc.storagePath)) {
        console.log(`  = ${folder}/${name} (unchanged)`);
        skipped++;
        continue;
      }
      const oldRef = doc?.storagePath;
      const storagePath = await saveFile(buf, name);
      const fields = {
        title: meta.title ?? name.replace(/\.pdf$/i, '').replace(/[-_]+/g, ' '),
        fileName: name,
        documentType: meta.documentType ?? defaultType,
        equipmentIds: equipment.map((e) => e._id),
        equipmentTypes: meta.equipmentTypes,
        source: 'preloaded' as const,
        storagePath,
        kbPath,
        sizeBytes: (await stat(file)).size,
        checksum,
        ingestionStatus: 'pending' as const,
        ingestionError: null,
      };
      if (doc) {
        doc.set(fields);
        await doc.save();
        if (oldRef && oldRef !== storagePath) await deleteStoredFile(oldRef);
        updated++;
      } else {
        doc = await DocumentModel.create({ ...fields, uploadedBy: null });
        created++;
      }
      await ingestDocument(String(doc._id));
      const after = await DocumentModel.findById(doc._id);
      if (after?.ingestionStatus === 'ready') console.log(`  + ${folder}/${name}: ${after.pageCount} pages, ${after.chunkCount} chunks`);
      else {
        failed++;
        console.log(`  x ${folder}/${name}: ${after?.ingestionError}`);
      }
    }
  }
  console.log(`\nDone: ${created} new, ${updated} updated, ${skipped} unchanged/skipped, ${failed} failed.`);
  if (failed) process.exitCode = 1;
}

main()
  .catch((err) => {
    console.error(`Knowledge-base ingestion failed: ${err instanceof Error ? err.message : String(err)}`);
    process.exitCode = 1;
  })
  .finally(() => disconnectDatabase());
