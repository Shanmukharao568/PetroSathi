/**
 * Embedding model benchmark for PetroSathi RAG.  Usage: npm run rag:benchmark
 *
 * Corpus: the demo knowledge base, run through the SAME extraction and chunking pipeline as
 * production. Queries: benchmarkQueries.ts (en / hi / te / ta / hi-en code-mix). Metrics per model
 * and language: Recall@5, MRR@5, mean top-1 score, query latency; plus ingest time, model size,
 * and a recommended "no relevant documentation" threshold from positive vs negative top-1 scores.
 * Writes docs/EMBEDDING_BENCHMARK.md and docs/embedding-benchmark.json.
 */
import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEMO_DOCUMENTS } from '../rag/demoContent.js';
import { buildDemoPdf } from '../rag/demoPdf.js';
import { extractPdfPages } from '../rag/pdf.js';
import { chunkPages } from '../rag/chunker.js';
import { createLocalEmbedding } from '../rag/embeddings/localEmbedding.js';
import { LOCAL_MODELS } from '../rag/embeddings/types.js';
import { createMemoryStore } from '../rag/vectorStore/memoryStore.js';
import { BENCH_INTENTS, BENCH_NEGATIVES, type BenchLang } from '../rag/benchmarkQueries.js';
import { env } from '../config/env.js';

const HISTORY = `## History

- First run (2026-11-08), before a chunker fix: e5-small Recall@5 0.857 / MRR@5 0.492; MiniLM Recall@5
  0.750 / MRR@5 0.606. Many queries' top hit was a **title-only chunk**, a document title emitted as its
  own chunk because it was followed directly by another heading. The chunker now carries body-less
  headings into the next chunk. That pipeline bug affected both models; the numbers above are after the fix.
`;

const LANGS: BenchLang[] = ['en', 'hi', 'te', 'ta', 'hi-en'];
const K = 5;
const docsDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../docs');

interface Chunk {
  id: string;
  text: string;
  docKey: string;
  sectionKey: string;
  pageNumber: number;
  section: string;
}

async function buildCorpus(): Promise<Chunk[]> {
  const out: Chunk[] = [];
  for (const doc of DEMO_DOCUMENTS) {
    const { pages } = await extractPdfPages(Buffer.from(await buildDemoPdf(doc)));
    const { chunks } = chunkPages(pages, env.RAG_CHUNK_SIZE, env.RAG_CHUNK_OVERLAP);
    for (const c of chunks) {
      const sec = doc.sections.find((s) => c.section.startsWith(s.heading));
      out.push({ id: `${doc.key}:${c.chunkIndex}`, text: c.text, docKey: doc.key, sectionKey: sec?.key ?? 'title', pageNumber: c.pageNumber, section: c.section });
    }
  }
  return out;
}

const pct = (xs: number[], p: number) => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))]!;
};
const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);

async function run() {
  const corpus = await buildCorpus();
  console.log(`Corpus: ${DEMO_DOCUMENTS.length} demo documents, ${corpus.length} chunks`);

  const results: Record<string, unknown>[] = [];
  for (const spec of Object.values(LOCAL_MODELS)) {
    console.log(`\n=== ${spec.model} ===`);
    const emb = createLocalEmbedding(spec.model, env.MODEL_CACHE_DIR);

    const loadStart = Date.now();
    await emb.embedQuery('warm up'); // includes first-time download + model load
    const loadMs = Date.now() - loadStart;

    const ingestStart = Date.now();
    const vectors = await emb.embedDocuments(corpus.map((c) => c.text));
    const ingestMs = Date.now() - ingestStart;

    const store = createMemoryStore();
    await store.upsert(
      corpus.map((c, i) => ({
        id: c.id,
        embedding: vectors[i]!,
        text: c.text,
        metadata: { documentId: c.docKey, documentName: c.docKey, documentType: 'x', pageNumber: c.pageNumber, section: c.sectionKey, equipmentIds: [], equipmentCodes: [], equipmentTypes: [], source: 'preloaded', chunkIndex: i, embeddingModel: spec.model },
      })),
    );

    const perLang: Record<string, { n: number; hits: number; rr: number; top1: number[]; latency: number[] }> = {};
    const positivesTop1: number[] = [];
    for (const intent of BENCH_INTENTS) {
      for (const lang of LANGS) {
        const q = intent.queries[lang];
        if (!q) continue;
        const t0 = performance.now();
        const qv = await emb.embedQuery(q);
        const latency = performance.now() - t0;
        const hits = await store.query(qv, K);
        const rank = hits.findIndex((h) => h.metadata.section === intent.expected);
        const bucket = (perLang[lang] ??= { n: 0, hits: 0, rr: 0, top1: [], latency: [] });
        bucket.n += 1;
        if (rank >= 0) {
          bucket.hits += 1;
          bucket.rr += 1 / (rank + 1);
        }
        bucket.top1.push(hits[0]?.score ?? 0);
        bucket.latency.push(latency);
        positivesTop1.push(hits[0]?.score ?? 0);
        if (rank !== 0) console.log(`  [${lang}] ${rank < 0 ? 'MISS' : `rank ${rank + 1}`} ${intent.expected} ← ${q.slice(0, 60)} (top: ${hits[0]?.metadata.section})`);
      }
    }

    const negativesTop1: number[] = [];
    for (const q of BENCH_NEGATIVES) negativesTop1.push((await store.query(await emb.embedQuery(q), 1))[0]?.score ?? 0);

    // Threshold: midway between the 90th percentile of off-topic scores and the 10th percentile of on-topic scores.
    const negHigh = pct(negativesTop1, 0.9);
    const posLow = pct(positivesTop1, 0.1);
    const threshold = Number(((negHigh + posLow) / 2).toFixed(3));
    const separated = posLow > negHigh;

    const langRows = LANGS.map((l) => {
      const b = perLang[l]!;
      return { language: l, queries: b.n, recallAt5: b.hits / b.n, mrrAt5: b.rr / b.n, meanTop1: mean(b.top1), meanLatencyMs: mean(b.latency) };
    });
    const all = Object.values(perLang);
    const n = all.reduce((a, b) => a + b.n, 0);
    const overall = {
      queries: n,
      recallAt5: all.reduce((a, b) => a + b.hits, 0) / n,
      mrrAt5: all.reduce((a, b) => a + b.rr, 0) / n,
      meanLatencyMs: mean(all.flatMap((b) => b.latency)),
    };
    const crossLingual = langRows.filter((r) => r.language !== 'en');
    const result = {
      model: spec.model,
      dimensions: spec.dimensions,
      approxSizeMb: spec.approxSizeMb,
      firstLoadMs: loadMs,
      ingestMs,
      ingestMsPerChunk: ingestMs / corpus.length,
      overall,
      crossLingualRecallAt5: mean(crossLingual.map((r) => r.recallAt5)),
      crossLingualMrrAt5: mean(crossLingual.map((r) => r.mrrAt5)),
      languages: langRows,
      scores: { positiveTop1P10: posLow, negativeTop1P90: negHigh, negativeTop1Max: Math.max(...negativesTop1), suggestedMinRelevance: threshold, separated },
    };
    console.log(JSON.stringify({ overall, crossLingual: result.crossLingualRecallAt5, scores: result.scores }, null, 2));
    results.push(result);
  }

  // Choice: best overall MRR@5, tie-break on cross-lingual recall, then latency.
  const ranked = [...results].sort(
    (a, b) =>
      (b.overall as { mrrAt5: number }).mrrAt5 - (a.overall as { mrrAt5: number }).mrrAt5 ||
      (b.crossLingualRecallAt5 as number) - (a.crossLingualRecallAt5 as number) ||
      (a.overall as { meanLatencyMs: number }).meanLatencyMs - (b.overall as { meanLatencyMs: number }).meanLatencyMs,
  );
  const winner = ranked[0]!;

  const ranAt = new Date().toISOString();
  await writeFile(path.join(docsDir, 'embedding-benchmark.json'), JSON.stringify({ ranAt, corpusChunks: corpus.length, k: K, results, chosen: winner.model }, null, 2) + '\n');

  const f = (x: number) => x.toFixed(3);
  const lines: string[] = [
    '# Embedding model benchmark',
    '',
    `Generated by \`npm run rag:benchmark\` on ${ranAt}. Machine: local CPU (no GPU). Quantized (q8) ONNX models via transformers.js.`,
    '',
    `**Corpus:** ${DEMO_DOCUMENTS.length} demonstration documents (English), ${corpus.length} chunks, produced by the production extraction and chunking pipeline (chunk ${env.RAG_CHUNK_SIZE} / overlap ${env.RAG_CHUNK_OVERLAP}).`,
    `**Queries:** ${(results[0] as { overall: { queries: number } }).overall.queries} petroleum-maintenance questions across English, Hindi, Telugu, Tamil and code-mixed Hinglish (hi-en), plus ${BENCH_NEGATIVES.length} off-topic queries. A hit means a chunk from the expected section appears in the top ${K}.`,
    '',
    '> Caveats: the corpus is small and synthetic, and the queries were written for this benchmark. The results compare candidates; they do not measure production accuracy. Re-run on your approved manuals before relying on the threshold.',
    '',
    '## Summary',
    '',
    '| Model | Dim | Size | Recall@5 | MRR@5 | Cross-lingual Recall@5 | Query latency (ms) | Ingest (ms/chunk) | Suggested min score |',
    '|---|---|---|---|---|---|---|---|---|',
    ...results.map((r) => {
      const o = r.overall as { recallAt5: number; mrrAt5: number; meanLatencyMs: number };
      const s = r.scores as { suggestedMinRelevance: number; separated: boolean };
      return `| ${r.model} | ${r.dimensions} | ~${r.approxSizeMb} MB | ${f(o.recallAt5)} | ${f(o.mrrAt5)} | ${f(r.crossLingualRecallAt5 as number)} | ${(o.meanLatencyMs).toFixed(1)} | ${(r.ingestMsPerChunk as number).toFixed(1)} | ${s.suggestedMinRelevance}${s.separated ? '' : ' (overlap!)'} |`;
    }),
    '',
    '## Per language',
    '',
    ...results.flatMap((r) => [
      `### ${r.model}`,
      '',
      '| Language | Queries | Recall@5 | MRR@5 | Mean top-1 score |',
      '|---|---|---|---|---|',
      ...(r.languages as { language: string; queries: number; recallAt5: number; mrrAt5: number; meanTop1: number }[]).map(
        (l) => `| ${l.language} | ${l.queries} | ${f(l.recallAt5)} | ${f(l.mrrAt5)} | ${f(l.meanTop1)} |`,
      ),
      '',
      `Score separation: on-topic top-1 10th percentile ${f((r.scores as { positiveTop1P10: number }).positiveTop1P10)}, off-topic top-1 90th percentile ${f((r.scores as { negativeTop1P90: number }).negativeTop1P90)}.`,
      '',
    ]),
    '## Cost and deployment',
    '',
    '- Both candidates run locally on CPU inside the Node API: no API key, no per-query cost, and no document text leaves the server.',
    '- First use downloads the quantized weights from Hugging Face into `MODEL_CACHE_DIR`. After that the server works offline.',
    '- Memory: roughly 200–400 MB of RAM per loaded model.',
    '',
    ...HISTORY.split('\n'),
    '## Decision',
    '',
    `**Chosen: \`${winner.model}\`.** It ranks first on overall MRR@5, with cross-lingual recall as the tie-break, then latency. Set \`EMBEDDING_MODEL\` to override. Changing the model requires reprocessing documents, because each model has its own Chroma collection.`,
    '',
  ];
  await writeFile(path.join(docsDir, 'EMBEDDING_BENCHMARK.md'), lines.join('\n'));
  console.log(`\nChosen: ${winner.model}\nWrote docs/EMBEDDING_BENCHMARK.md and docs/embedding-benchmark.json`);
}

await run();
