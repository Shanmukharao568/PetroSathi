/**
 * Development seed. Idempotent: existing emails are skipped, never overwritten.
 *
 *   npm run seed
 *
 * - Administrator: SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD from .env (never in source control).
 * - Demo operators/engineers: password from SEED_DEMO_USER_PASSWORD, or a random one printed once.
 * - Every seeded account must change its password at first login.
 * - Refuses to run with NODE_ENV=production.
 */
import { env, isProd } from '../config/env.js';
import { connectDatabase, disconnectDatabase } from '../config/db.js';
import { UserModel } from '../modules/users/user.model.js';
import { EquipmentModel } from '../modules/equipment/equipment.model.js';
import { generateTemporaryPassword, hashPassword, passwordSchema } from '../utils/password.js';
import type { Role } from '../config/constants.js';

interface SeedUser {
  name: string;
  email: string;
  role: Role;
  preferredLanguage: string;
}

const DEMO_USERS: SeedUser[] = [
  { name: 'Ravi Kumar (Demo Operator)', email: 'operator1@petrosathi.test', role: 'operator', preferredLanguage: 'hi-IN' },
  { name: 'Lakshmi Reddy (Demo Operator)', email: 'operator2@petrosathi.test', role: 'operator', preferredLanguage: 'te-IN' },
  { name: 'Arun Iyer (Demo Engineer)', email: 'engineer1@petrosathi.test', role: 'engineer', preferredLanguage: 'en-IN' },
  { name: 'Meena Sharma (Demo Engineer)', email: 'engineer2@petrosathi.test', role: 'engineer', preferredLanguage: 'en-IN' },
];

/**
 * Demonstration equipment. P-101 is intentionally NOT seeded: the acceptance scenario has the
 * administrator add it. Manufacturer/model are left blank — no real vendor data is invented.
 */
const DEMO_EQUIPMENT = [
  { equipmentCode: 'P-102', name: 'Crude Transfer Pump B (Demo)', type: 'pump', plant: 'Demo Refinery Unit 1', location: 'Tank farm, pump bay 2', criticality: 'high' },
  { equipmentCode: 'P-201', name: 'Cooling Water Pump (Demo)', type: 'pump', plant: 'Demo Refinery Unit 1', location: 'Cooling tower basin', criticality: 'medium' },
  { equipmentCode: 'C-301', name: 'Gas Compressor (Demo)', type: 'compressor', plant: 'Demo Gas Processing', location: 'Compressor house', criticality: 'critical' },
  { equipmentCode: 'HX-401', name: 'Feed/Effluent Heat Exchanger (Demo)', type: 'heat_exchanger', plant: 'Demo Refinery Unit 1', location: 'CDU structure, level 2', criticality: 'high' },
  { equipmentCode: 'V-501', name: 'Three-Phase Separator (Demo)', type: 'separator', plant: 'Demo Production Pad', location: 'Wellhead manifold area', criticality: 'high' },
  { equipmentCode: 'FV-601', name: 'Flow Control Valve (Demo)', type: 'valve', plant: 'Demo Refinery Unit 1', location: 'Feed line to HX-401', criticality: 'medium' },
  { equipmentCode: 'M-701', name: 'Pump Drive Motor (Demo)', type: 'motor', plant: 'Demo Refinery Unit 1', location: 'Tank farm, pump bay 2', criticality: 'medium' },
  { equipmentCode: 'PT-801', name: 'Discharge Pressure Transmitter (Demo)', type: 'instrument', plant: 'Demo Gas Processing', location: 'C-301 discharge header', criticality: 'low' },
] as const;

async function upsertUser(user: SeedUser, password: string): Promise<'created' | 'skipped'> {
  if (await UserModel.exists({ email: user.email })) return 'skipped';
  await UserModel.create({ ...user, passwordHash: await hashPassword(password), mustChangePassword: true });
  return 'created';
}

async function main() {
  if (isProd) throw new Error('Refusing to seed demo data with NODE_ENV=production');

  const adminEmail = env.SEED_ADMIN_EMAIL;
  const adminPassword = env.SEED_ADMIN_PASSWORD;
  if (!adminEmail || !adminPassword) {
    throw new Error('Set SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD in backend/.env before seeding');
  }
  const check = passwordSchema.safeParse(adminPassword);
  if (!check.success) throw new Error(`SEED_ADMIN_PASSWORD: ${check.error.issues[0]?.message}`);

  await connectDatabase();

  const adminResult = await upsertUser(
    { name: 'Site Administrator', email: adminEmail.toLowerCase(), role: 'admin', preferredLanguage: env.DEFAULT_LANGUAGE },
    adminPassword,
  );
  console.log(`admin     ${adminEmail.toLowerCase().padEnd(30)} ${adminResult}`);

  const demoPassword = env.SEED_DEMO_USER_PASSWORD ?? generateTemporaryPassword();
  const generated = !env.SEED_DEMO_USER_PASSWORD;
  let anyCreated = false;
  for (const u of DEMO_USERS) {
    const r = await upsertUser(u, demoPassword);
    anyCreated ||= r === 'created';
    console.log(`${u.role.padEnd(9)} ${u.email.padEnd(30)} ${r}`);
  }
  if (anyCreated && generated) {
    console.log(`\nGenerated temporary password for newly created demo users (shown once): ${demoPassword}`);
  }
  console.log('\nAll seeded accounts must change their password at first sign-in.\n');

  for (const eq of DEMO_EQUIPMENT) {
    const exists = await EquipmentModel.exists({ equipmentCode: eq.equipmentCode });
    if (!exists) await EquipmentModel.create(eq);
    console.log(`equipment ${eq.equipmentCode.padEnd(30)} ${exists ? 'skipped' : 'created'}`);
  }
}

main()
  .catch((err) => {
    console.error(`Seed failed: ${err instanceof Error ? err.message : String(err)}`);
    process.exitCode = 1;
  })
  .finally(() => disconnectDatabase());
