/**
 * Creates (or updates) the MongoDB Atlas Vector Search index used when VECTOR_STORE=mongo.
 * Usage: npm run vector:index    (MONGODB_URI must point at an Atlas cluster; M0 free tier works)
 * Safe to run again: an existing index is updated to the current definition.
 */
import mongoose from 'mongoose';
import { connectDatabase, disconnectDatabase } from '../config/db.js';
import { env } from '../config/env.js';
import { getEmbeddingProvider } from '../rag/embeddings/index.js';
import { vectorCollectionName } from '../rag/vectorStore/index.js';
import { vectorIndexDefinition } from '../rag/vectorStore/mongoStore.js';

async function main() {
  await connectDatabase();
  const db = mongoose.connection.db!;
  const name = vectorCollectionName();
  const definition = vectorIndexDefinition(getEmbeddingProvider().dimensions);

  if (!(await db.listCollections({ name }).hasNext())) await db.createCollection(name);
  const coll = db.collection(name);

  const existing = await coll.listSearchIndexes(env.MONGO_VECTOR_INDEX).toArray();
  if (existing.length) {
    await coll.updateSearchIndex(env.MONGO_VECTOR_INDEX, definition);
    console.log(`Updated vector index "${env.MONGO_VECTOR_INDEX}" on "${name}".`);
  } else {
    await coll.createSearchIndex({ name: env.MONGO_VECTOR_INDEX, type: 'vectorSearch', definition });
    console.log(`Created vector index "${env.MONGO_VECTOR_INDEX}" on "${name}".`);
  }

  // Atlas builds the index in the background; wait until it can be queried.
  for (let i = 0; i < 60; i++) {
    const [idx] = (await coll.listSearchIndexes(env.MONGO_VECTOR_INDEX).toArray()) as { queryable?: boolean }[];
    if (idx?.queryable) {
      console.log('Index is ready.');
      return;
    }
    await new Promise((r) => setTimeout(r, 5000));
  }
  console.log('Index is still building; it will become usable in a few minutes (check Atlas → Search & Vector Search).');
}

main()
  .catch((err) => {
    console.error(`Creating the vector index failed: ${err instanceof Error ? err.message : String(err)}`);
    process.exitCode = 1;
  })
  .finally(() => disconnectDatabase());
