/**
 * Measures retrieval quality of the CONFIGURED embedding provider (EMBEDDING_PROVIDER) on the demo
 * corpus and suggests RAG_MIN_RELEVANCE_SCORE. Writes nothing; prints the result.
 * Usage: npm run rag:calibrate     (with gemini: about 80 API requests, within the free tier)
 *
 * Same method as the Phase 6 benchmark: the threshold sits midway between the 90th percentile
 * of off-topic top-1 scores and the 10th percentile of on-topic top-1 scores.
 */
import { DEMO_DOCUMENTS } from '../rag/demoContent.js';
import { buildDemoPdf } from '../rag/demoPdf.js';
import { extractPdfPages } from '../rag/pdf.js';
import { chunkPages } from '../rag/chunker.js';
import { getEmbeddingProvider } from '../rag/embeddings/index.js';
import { createMemoryStore } from '../rag/vectorStore/memoryStore.js';
import { BENCH_INTENTS, BENCH_NEGATIVES, type BenchLang } from '../rag/benchmarkQueries.js';
import { env } from '../config/env.js';

const LANGS: BenchLang[] = ['en', 'hi', 'te', 'ta', 'hi-en'];
const K = 5;
const pct = (xs: number[], p: number) => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))]!;
};

async function main() {
  const emb = getEmbeddingProvider();
  console.log(`Provider: ${emb.id}`);

  const store = createMemoryStore();
  const corpus: { id: string; text: string; section: string; pageNumber: number; doc: string }[] = [];
  for (const doc of DEMO_DOCUMENTS) {
    const { pages } = await extractPdfPages(Buffer.from(await buildDemoPdf(doc)));
    for (const c of chunkPages(pages, env.RAG_CHUNK_SIZE, env.RAG_CHUNK_OVERLAP).chunks) {
      const sec = doc.sections.find((s) => c.section.startsWith(s.heading));
      corpus.push({ id: `${doc.key}:${c.chunkIndex}`, text: c.text, section: sec?.key ?? 'title', pageNumber: c.pageNumber, doc: doc.key });
    }
  }
  const vectors = await emb.embedDocuments(corpus.map((c) => c.text));
  await store.upsert(
    corpus.map((c, i) => ({
      id: c.id,
      embedding: vectors[i]!,
      text: c.text,
      metadata: { documentId: c.doc, documentName: c.doc, documentType: 'x', pageNumber: c.pageNumber, section: c.section, equipmentIds: [], equipmentCodes: [], equipmentTypes: [], source: 'preloaded', chunkIndex: i, embeddingModel: emb.model },
    })),
  );
  console.log(`Corpus: ${corpus.length} chunks embedded`);

  let n = 0;
  let hits = 0;
  let rr = 0;
  const positives: number[] = [];
  for (const intent of BENCH_INTENTS) {
    for (const lang of LANGS) {
      const q = intent.queries[lang];
      if (!q) continue;
      const res = await store.query(await emb.embedQuery(q), K);
      const rank = res.findIndex((h) => h.metadata.section === intent.expected);
      n++;
      if (rank >= 0) {
        hits++;
        rr += 1 / (rank + 1);
      }
      positives.push(res[0]?.score ?? 0);
      if (rank !== 0) console.log(`  [${lang}] ${rank < 0 ? 'MISS' : `rank ${rank + 1}`} ${intent.expected} <- ${q.slice(0, 60)}`);
    }
  }
  const negatives: number[] = [];
  for (const q of BENCH_NEGATIVES) negatives.push((await store.query(await emb.embedQuery(q), 1))[0]?.score ?? 0);

  const posLow = pct(positives, 0.1);
  const negHigh = pct(negatives, 0.9);
  const threshold = Number(((posLow + negHigh) / 2).toFixed(3));
  console.log(`\nQueries: ${n}  Recall@${K}: ${(hits / n).toFixed(3)}  MRR@${K}: ${(rr / n).toFixed(3)}`);
  console.log(`On-topic top-1 (10th percentile): ${posLow.toFixed(3)}   Off-topic top-1 (90th percentile): ${negHigh.toFixed(3)}`);
  console.log(posLow > negHigh ? `\nSuggested: RAG_MIN_RELEVANCE_SCORE=${threshold}` : `\nScores overlap; ${threshold} is a compromise. Check results on your real manuals.`);
}

main().catch((err) => {
  console.error(`Calibration failed: ${err instanceof Error ? err.message : String(err)}`);
  process.exitCode = 1;
});
