import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { rateLimit } from 'express-rate-limit';
import { pinoHttp } from 'pino-http';
import swaggerUi from 'swagger-ui-express';
import { env, isTest, type Env } from './config/env.js';
import { logger } from './utils/logger.js';
import { apiRouter } from './routes/index.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { openApiDocument } from './docs/openapi.js';

/** API docs: on by default outside production; in production only when ENABLE_API_DOCS=true. */
export function apiDocsEnabled(e: Pick<Env, 'NODE_ENV' | 'ENABLE_API_DOCS'>): boolean {
  return e.ENABLE_API_DOCS ?? e.NODE_ENV !== 'production';
}

export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  // Only trust X-Forwarded-For when a known number of proxies sits in front (TRUST_PROXY).
  // Trusting it without a proxy lets clients forge their IP and dodge rate limits.
  app.set('trust proxy', env.TRUST_PROXY);

  app.use(helmet());
  app.use(
    cors({
      origin: env.CLIENT_URL,
      credentials: true,
      methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    }),
  );
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: false, limit: '1mb' }));

  if (!isTest) {
    app.use(
      pinoHttp({
        logger,
        // Never log bodies (may contain passwords/transcripts); only method/url/status/latency.
        serializers: {
          req: (req: { method: string; url: string }) => ({ method: req.method, url: req.url }),
          res: (res: { statusCode: number }) => ({ statusCode: res.statusCode }),
        },
      }),
    );
  }

  app.use(
    '/api',
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: isTest ? 10_000 : 600,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      handler: (_req, res) =>
        res.status(429).json({
          success: false,
          error: { code: 'RATE_LIMITED', message: 'Too many requests, please try again later' },
        }),
    }),
  );

  if (apiDocsEnabled(env)) {
    // Swagger UI needs inline scripts/styles; relax CSP for this path only.
    app.use(
      '/api/docs',
      helmet({ contentSecurityPolicy: false }),
      swaggerUi.serve,
      swaggerUi.setup(openApiDocument),
    );
    app.get('/api/docs.json', (_req, res) => res.json(openApiDocument));
  }

  app.use('/api/v1', apiRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
