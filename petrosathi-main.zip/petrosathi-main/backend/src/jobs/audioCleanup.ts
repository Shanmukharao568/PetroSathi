import { mkdir, readdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

export function audioDir(): string {
  return path.resolve(env.AUDIO_UPLOAD_DIR);
}

export async function ensureAudioDir(): Promise<void> {
  await mkdir(audioDir(), { recursive: true });
}

/** Deletes one temporary audio file; never throws (cleanup must not mask the real error). */
export async function deleteAudio(filePath: string | undefined | null): Promise<void> {
  if (!filePath) return;
  try {
    await rm(filePath, { force: true });
  } catch (err) {
    logger.error({ err: (err as Error).message }, 'Failed to delete temporary audio file');
  }
}

/**
 * Removes abandoned temporary audio older than maxAgeMs (e.g. after a crash mid-request).
 * Normal requests delete their own file in a finally block; this is the safety net.
 */
export async function sweepAudioDir(dir = audioDir(), maxAgeMs = env.AUDIO_RETENTION_MINUTES * 60_000): Promise<number> {
  let removed = 0;
  let entries: string[];
  try {
    entries = await readdir(dir);
  } catch {
    return 0;
  }
  const cutoff = Date.now() - maxAgeMs;
  for (const name of entries) {
    const full = path.join(dir, name);
    try {
      const s = await stat(full);
      if (s.isFile() && s.mtimeMs < cutoff) {
        await rm(full, { force: true });
        removed += 1;
      }
    } catch {
      // vanished between readdir and stat — fine
    }
  }
  if (removed) logger.info({ removed }, 'Removed abandoned temporary audio files');
  return removed;
}

let timer: NodeJS.Timeout | null = null;

export function startAudioSweeper(intervalMs = 5 * 60_000): void {
  if (timer) return;
  void sweepAudioDir();
  timer = setInterval(() => void sweepAudioDir(), intervalMs);
  timer.unref();
}

export function stopAudioSweeper(): void {
  if (timer) clearInterval(timer);
  timer = null;
}
