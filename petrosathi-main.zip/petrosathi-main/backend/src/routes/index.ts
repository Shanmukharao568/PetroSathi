import { Router } from 'express';
import { healthRouter } from './health.routes.js';
import { authRouter } from '../modules/auth/auth.routes.js';
import { userRouter } from '../modules/users/user.routes.js';
import { equipmentRouter } from '../modules/equipment/equipment.routes.js';
import { ticketRouter } from '../modules/tickets/ticket.routes.js';
import { notificationRouter } from '../modules/notifications/notification.routes.js';
import { voiceRouter } from '../modules/voice/voice.routes.js';
import { conversationRouter } from '../modules/conversations/conversation.routes.js';
import { complaintRouter } from '../modules/complaints/complaint.routes.js';
import { documentRouter } from '../modules/documents/document.routes.js';
import { knowledgeRouter } from '../modules/knowledge/knowledge.routes.js';
import { analyticsRouter, dashboardRouter } from '../modules/analytics/analytics.routes.js';
import { auditRouter } from '../modules/audit/audit.routes.js';

/** Mounted at /api/v1. Feature modules register their routers here as phases land. */
export const apiRouter = Router();

apiRouter.use('/health', healthRouter);
apiRouter.use('/auth', authRouter);
apiRouter.use('/users', userRouter);
apiRouter.use('/equipment', equipmentRouter);
apiRouter.use('/tickets', ticketRouter);
apiRouter.use('/notifications', notificationRouter);
apiRouter.use('/voice', voiceRouter);
apiRouter.use('/conversations', conversationRouter);
apiRouter.use('/complaints', complaintRouter);
apiRouter.use('/documents', documentRouter);
apiRouter.use('/knowledge', knowledgeRouter);
apiRouter.use('/analytics', analyticsRouter);
apiRouter.use('/dashboard', dashboardRouter);
apiRouter.use('/audit-logs', auditRouter);
