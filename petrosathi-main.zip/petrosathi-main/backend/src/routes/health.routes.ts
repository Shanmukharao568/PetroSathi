import { Router } from 'express';
import { databaseState } from '../config/db.js';
import { env } from '../config/env.js';
import { sendSuccess } from '../utils/response.js';

export const healthRouter = Router();

/**
 * @openapi
 * /health:
 *   get:
 *     tags: [System]
 *     summary: Liveness and dependency status
 */
healthRouter.get('/', (_req, res) => {
  const db = databaseState();
  sendSuccess(res, {
    status: db === 'connected' ? 'ok' : 'degraded',
    service: 'petrosathi-api',
    database: db,
    // Mode is exposed so the UI can label mock responses; no credentials are revealed.
    aiProviderMode: env.AI_PROVIDER_MODE,
    timestamp: new Date().toISOString(),
  });
});
