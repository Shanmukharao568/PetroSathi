import { env } from '../config/env.js';

/**
 * OpenAPI 3.1 document. Extended per module as endpoints are implemented,
 * so the spec only ever describes endpoints that actually exist.
 */

const json = (schema: object) => ({ 'application/json': { schema } });
const ok = (description: string, data: object = {}) => ({
  description,
  content: json({ type: 'object', properties: { success: { const: true }, data } }),
});
const err = (description: string) => ({ description, content: json({ $ref: '#/components/schemas/Error' }) });
const idParam = { name: 'id', in: 'path', required: true, schema: { type: 'string', pattern: '^[a-f0-9]{24}$' } };
const secured = [{ bearerAuth: [] }];
const common401 = { 401: err('Missing, invalid, expired or revoked token') };
const role = { type: 'string', enum: ['operator', 'engineer', 'admin'] };
const pageParams = [
  { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1, default: 1 } },
  { name: 'limit', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 100, default: 20 } },
];
const list = (description: string, ref: string) => ({
  description,
  content: json({
    type: 'object',
    properties: { success: { const: true }, data: { type: 'array', items: { $ref: ref } }, meta: { type: 'object' } },
  }),
});

export const openApiDocument = {
  openapi: '3.1.0',
  info: {
    title: 'PetroSathi API',
    version: '0.7.0',
    description:
      'Multilingual voice-based maintenance complaint management. All responses use the envelope ' +
      '`{ success, data, meta? }` or `{ success: false, error: { code, message, details? } }`.\n\n' +
      'Accounts with a temporary password receive `403 PASSWORD_CHANGE_REQUIRED` on every route except ' +
      '`GET /auth/me`, `POST /auth/logout` and `PATCH /users/{id}/password` (self).',
  },
  servers: [{ url: env.API_BASE_URL }],
  components: {
    securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    schemas: {
      Error: {
        type: 'object',
        properties: {
          success: { const: false },
          error: {
            type: 'object',
            required: ['code', 'message'],
            properties: { code: { type: 'string' }, message: { type: 'string' }, details: {} },
          },
        },
      },
      User: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          name: { type: 'string' },
          email: { type: 'string', format: 'email' },
          role,
          preferredLanguage: { type: 'string', examples: ['en-IN'] },
          phone: { type: ['string', 'null'] },
          jobTitle: { type: ['string', 'null'] },
          site: { type: ['string', 'null'] },
          bio: { type: ['string', 'null'] },
          avatar: { type: ['string', 'null'], description: 'Profile photo as a PNG/JPEG/WebP data URL' },
          isActive: { type: 'boolean' },
          mustChangePassword: { type: 'boolean' },
          emailVerified: { type: 'boolean' },
          emailVerifiedAt: { type: ['string', 'null'], format: 'date-time' },
          emailVerificationRequired: { type: 'boolean', description: 'Only on /auth/login, /auth/me and /auth/email/verify: true while the user must still verify their email' },
          lastLoginAt: { type: ['string', 'null'], format: 'date-time' },
          passwordChangedAt: { type: ['string', 'null'], format: 'date-time' },
          createdAt: { type: 'string', format: 'date-time' },
          updatedAt: { type: 'string', format: 'date-time' },
        },
      },
      Session: {
        type: 'object',
        properties: {
          token: { type: 'string' },
          expiresAt: { type: 'string', format: 'date-time' },
          user: { $ref: '#/components/schemas/User' },
        },
      },
      EquipmentInput: {
        type: 'object',
        required: ['equipmentCode', 'name', 'type', 'plant'],
        additionalProperties: false,
        properties: {
          equipmentCode: { type: 'string', pattern: '^[A-Za-z0-9]{1,6}-[A-Za-z0-9]{1,10}$', examples: ['P-101'] },
          name: { type: 'string' },
          type: { type: 'string', enum: ['pump', 'compressor', 'heat_exchanger', 'valve', 'motor', 'turbine', 'separator', 'tank', 'vessel', 'pipeline', 'instrument', 'generator', 'other'] },
          plant: { type: 'string' },
          location: { type: 'string' },
          manufacturer: { type: 'string' },
          model: { type: 'string' },
          criticality: { type: 'string', enum: ['low', 'medium', 'high', 'critical'] },
          status: { type: 'string', enum: ['operational', 'degraded', 'down', 'under_maintenance', 'decommissioned'] },
        },
      },
      Equipment: {
        allOf: [
          { $ref: '#/components/schemas/EquipmentInput' },
          { type: 'object', properties: { id: { type: 'string' }, createdAt: { type: 'string' }, updatedAt: { type: 'string' } } },
        ],
      },
      Ticket: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          ticketNumber: { type: 'string', examples: ['TKT-2026-00001'] },
          equipmentId: { type: 'string' },
          equipmentCode: { type: 'string' },
          equipment: { type: ['object', 'null'] },
          reportedBy: { type: 'object' },
          assignedTo: { type: ['object', 'null'] },
          description: { type: 'string' },
          symptoms: { type: 'array', items: { type: 'string' } },
          category: { type: 'string' },
          severity: { type: 'string' },
          status: { type: 'string' },
          transcript: { type: ['string', 'null'] },
          source: { type: 'string', enum: ['manual', 'voice'] },
          resolution: { type: ['object', 'null'] },
          history: { type: 'array', items: { type: 'object' } },
          comments: { type: 'array', items: { type: 'object' } },
          permissions: {
            type: 'object',
            description: 'What the current user may do with this ticket',
            properties: {
              view: { type: 'boolean' }, comment: { type: 'boolean' }, accept: { type: 'boolean' }, assign: { type: 'boolean' },
              release: { type: 'boolean' }, changeStatus: { type: 'boolean' }, allowedTransitions: { type: 'array', items: { type: 'string' } },
            },
          },
        },
      },
      UserWithTemporaryPassword: {
        type: 'object',
        properties: {
          user: { $ref: '#/components/schemas/User' },
          temporaryPassword: { type: 'string', description: 'Shown exactly once; never stored in plain text.' },
        },
      },
    },
  },
  tags: [{ name: 'System' }, { name: 'Auth' }, { name: 'Users' }, { name: 'Equipment' }, { name: 'Tickets' }, { name: 'Notifications' }, { name: 'Voice' }, { name: 'Conversations' }, { name: 'Complaints' }, { name: 'Documents' }, { name: 'Knowledge' }, { name: 'Analytics' }, { name: 'Audit' }],
  paths: {
    '/health': {
      get: {
        tags: ['System'],
        summary: 'Liveness and dependency status',
        responses: {
          200: ok('Service status', {
            type: 'object',
            properties: {
              status: { enum: ['ok', 'degraded'] },
              service: { type: 'string' },
              database: { type: 'string' },
              aiProviderMode: { enum: ['mock', 'real'] },
              timestamp: { type: 'string', format: 'date-time' },
            },
          }),
        },
      },
    },
    '/auth/login': {
      post: {
        tags: ['Auth'],
        summary: 'Sign in with email and password',
        description: 'Rate-limited. There is no public registration endpoint.',
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            required: ['email', 'password'],
            properties: { email: { type: 'string', format: 'email' }, password: { type: 'string' } },
          }),
        },
        responses: {
          200: ok('Signed in', { $ref: '#/components/schemas/Session' }),
          400: err('Validation error'),
          401: err('INVALID_CREDENTIALS'),
          403: err('ACCOUNT_DISABLED'),
          429: err('RATE_LIMITED'),
        },
      },
    },
    '/auth/me': {
      get: {
        tags: ['Auth'],
        summary: 'Current user',
        security: secured,
        responses: { 200: ok('Current user', { $ref: '#/components/schemas/User' }), ...common401 },
      },
    },
    '/auth/logout': {
      post: {
        tags: ['Auth'],
        summary: 'Sign out and revoke all tokens issued to this user',
        security: secured,
        responses: { 204: { description: 'Signed out' }, ...common401 },
      },
    },
    '/auth/register': {
      post: {
        tags: ['Auth'],
        summary: 'Sign up (always a Field Operator) and get a session',
        description:
          'Public self sign-up (SELF_REGISTRATION_ENABLED, default true). The account is always a Field Operator — the body ' +
          'cannot carry a role. The returned session works only for email verification until the 6-digit code is confirmed ' +
          '(POST /auth/email/send-code, then /auth/email/verify). Rate-limited per IP.',
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            required: ['name', 'email', 'password'],
            additionalProperties: false,
            properties: {
              name: { type: 'string', minLength: 2, maxLength: 100 },
              email: { type: 'string', format: 'email' },
              password: { type: 'string', minLength: 10, description: 'Upper-case, lower-case and a digit' },
              preferredLanguage: { type: 'string', examples: ['te-IN'] },
            },
          }),
        },
        responses: {
          201: ok('Account created and signed in', { $ref: '#/components/schemas/Session' }),
          400: err('Validation failed (weak password, bad email, unknown field such as role)'),
          403: err('Sign-up is turned off'),
          409: err('Email already registered'),
          429: err('Too many sign-ups from this network'),
        },
      },
    },
    '/auth/email/send-code': {
      post: {
        tags: ['Auth'],
        summary: 'Email a 6-digit verification code to the signed-in user',
        description:
          'Required once per account (when EMAIL_VERIFICATION_REQUIRED=true): until the email is verified, every other endpoint ' +
          'answers 403 EMAIL_VERIFICATION_REQUIRED. Codes expire after EMAIL_OTP_TTL_MINUTES; a new code can be requested after ' +
          'EMAIL_OTP_RESEND_SECONDS (earlier requests get 429 with `retryAfterSeconds`). Without SMTP in development the code is ' +
          'written to the server log (`delivery: "server-log"`).',
        security: secured,
        responses: {
          200: ok('Code sent', {
            type: 'object',
            properties: {
              sentTo: { type: 'string', description: 'Masked address, e.g. ra••••@example.com' },
              expiresAt: { type: 'string', format: 'date-time' },
              resendAvailableAt: { type: 'string', format: 'date-time' },
              delivery: { enum: ['email', 'server-log'] },
            },
          }),
          ...common401,
          403: err('Temporary password must be changed first'),
          409: err('Email already verified'),
          429: err('A code was sent recently (see details.retryAfterSeconds)'),
          503: err('Email could not be sent'),
        },
      },
    },
    '/auth/email/verify': {
      post: {
        tags: ['Auth'],
        summary: 'Confirm the email address with the emailed code',
        description: `Wrong codes count towards EMAIL_OTP_MAX_ATTEMPTS (default 5); then a new code is needed. Returns the updated user.`,
        security: secured,
        requestBody: {
          required: true,
          content: json({ type: 'object', required: ['code'], additionalProperties: false, properties: { code: { type: 'string', pattern: '^\\d{6}$' } } }),
        },
        responses: {
          200: ok('Verified', { $ref: '#/components/schemas/User' }),
          400: err('OTP_INVALID (wrong code, details.attemptsLeft) or OTP_EXPIRED (expired, used up, or none sent)'),
          ...common401,
          403: err('Temporary password must be changed first'),
          429: err('Too many attempts'),
        },
      },
    },
    '/users': {
      post: {
        tags: ['Users'],
        summary: 'Create a user (admin only)',
        security: secured,
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            required: ['name', 'email', 'role'],
            additionalProperties: false,
            properties: {
              name: { type: 'string', minLength: 2, maxLength: 100 },
              email: { type: 'string', format: 'email' },
              role,
              preferredLanguage: { type: 'string' },
            },
          }),
        },
        responses: {
          201: ok('Created; temporary password returned once', { $ref: '#/components/schemas/UserWithTemporaryPassword' }),
          400: err('Validation error'),
          ...common401,
          403: err('Not an administrator'),
          409: err('Email already exists'),
        },
      },
      get: {
        tags: ['Users'],
        summary: 'List users (admin only)',
        security: secured,
        parameters: [
          { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1, default: 1 } },
          { name: 'limit', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 100, default: 20 } },
          { name: 'role', in: 'query', schema: role },
          { name: 'isActive', in: 'query', schema: { type: 'string', enum: ['true', 'false'] } },
          { name: 'search', in: 'query', schema: { type: 'string', maxLength: 100 } },
        ],
        responses: {
          200: {
            description: 'Paginated users',
            content: json({
              type: 'object',
              properties: {
                success: { const: true },
                data: { type: 'array', items: { $ref: '#/components/schemas/User' } },
                meta: { type: 'object', properties: { pagination: { type: 'object' } } },
              },
            }),
          },
          ...common401,
          403: err('Not an administrator'),
        },
      },
    },
    '/users/{id}': {
      get: {
        tags: ['Users'],
        summary: 'Get a user (admin, or the user themself)',
        security: secured,
        parameters: [idParam],
        responses: { 200: ok('User', { $ref: '#/components/schemas/User' }), ...common401, 403: err('Forbidden'), 404: err('Not found') },
      },
      patch: {
        tags: ['Users'],
        summary: 'Update a user',
        description:
          'Self: `name`, `preferredLanguage`, and profile fields `phone`, `jobTitle`, `site`, `bio`, `avatar` (empty string or null clears). ' +
          'Admin: also `role` and `isActive` (not on themselves). ' +
          'Role change or deactivation revokes the target user\'s sessions. The last active admin cannot be removed.',
        security: secured,
        parameters: [idParam],
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            additionalProperties: false,
            properties: {
              name: { type: 'string' },
              preferredLanguage: { type: 'string' },
              phone: { type: ['string', 'null'] },
              jobTitle: { type: ['string', 'null'], maxLength: 80 },
              site: { type: ['string', 'null'], maxLength: 120 },
              bio: { type: ['string', 'null'], maxLength: 280 },
              avatar: { type: ['string', 'null'], description: 'data:image/(png|jpeg|webp);base64,…' },
              role,
              isActive: { type: 'boolean' },
            },
          }),
        },
        responses: {
          200: ok('Updated user', { $ref: '#/components/schemas/User' }),
          400: err('Validation error'),
          ...common401,
          403: err('Forbidden'),
          404: err('Not found'),
          409: err('Self role/status change or last-admin protection'),
        },
      },
    },
    '/users/{id}/password': {
      patch: {
        tags: ['Users'],
        summary: 'Change own password, or (admin) reset another user\'s password',
        description:
          'Self: send `currentPassword` and `newPassword`; returns a new session (old tokens revoked). ' +
          'Admin on another user: send `{}`; returns a new one-time temporary password.',
        security: secured,
        parameters: [idParam],
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            additionalProperties: false,
            properties: { currentPassword: { type: 'string' }, newPassword: { type: 'string', minLength: 10 } },
          }),
        },
        responses: {
          200: ok('Session (self) or user + temporaryPassword (admin reset)'),
          400: err('Validation error / incorrect current password'),
          ...common401,
          403: err('Forbidden'),
          404: err('Not found'),
        },
      },
    },

    // ---------------------------------------------------------------- Equipment
    '/equipment': {
      get: {
        tags: ['Equipment'],
        summary: 'List equipment (any signed-in role)',
        security: secured,
        parameters: [
          ...pageParams,
          { name: 'search', in: 'query', schema: { type: 'string' } },
          { name: 'code', in: 'query', schema: { type: 'string', examples: ['P-101'] } },
          { name: 'type', in: 'query', schema: { type: 'string' } },
          { name: 'plant', in: 'query', schema: { type: 'string' } },
          { name: 'status', in: 'query', schema: { type: 'string' } },
          { name: 'criticality', in: 'query', schema: { type: 'string' } },
        ],
        responses: { 200: list('Paginated equipment', '#/components/schemas/Equipment'), ...common401 },
      },
      post: {
        tags: ['Equipment'],
        summary: 'Create equipment (admin)',
        security: secured,
        requestBody: { required: true, content: json({ $ref: '#/components/schemas/EquipmentInput' }) },
        responses: { 201: ok('Created', { $ref: '#/components/schemas/Equipment' }), 400: err('Validation error'), ...common401, 403: err('Not an administrator'), 409: err('Duplicate equipment code') },
      },
    },
    '/equipment/{id}': {
      get: { tags: ['Equipment'], summary: 'Get equipment with ticket counts', security: secured, parameters: [idParam], responses: { 200: ok('Equipment', { $ref: '#/components/schemas/Equipment' }), ...common401, 404: err('Not found') } },
      patch: {
        tags: ['Equipment'], summary: 'Update equipment (admin)', security: secured, parameters: [idParam],
        requestBody: { required: true, content: json({ $ref: '#/components/schemas/EquipmentInput' }) },
        responses: { 200: ok('Updated', { $ref: '#/components/schemas/Equipment' }), 400: err('Validation error'), ...common401, 403: err('Not an administrator'), 404: err('Not found'), 409: err('Duplicate code') },
      },
      delete: {
        tags: ['Equipment'], summary: 'Delete equipment never referenced by a ticket (admin)', security: secured, parameters: [idParam],
        responses: { 204: { description: 'Deleted' }, ...common401, 403: err('Not an administrator'), 404: err('Not found'), 409: err('Referenced by tickets — decommission instead') },
      },
    },

    // ---------------------------------------------------------------- Tickets
    '/tickets': {
      post: {
        tags: ['Tickets'],
        summary: 'Create a ticket from a confirmed manual complaint',
        description: 'Requires an `Idempotency-Key` header. Replaying the same key returns the original ticket with 200 and `meta.idempotentReplay: true`.',
        security: secured,
        parameters: [{ name: 'Idempotency-Key', in: 'header', required: true, schema: { type: 'string', minLength: 8, maxLength: 128 } }],
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            required: ['description'],
            description: 'Exactly one of equipmentId or equipmentCode.',
            properties: {
              equipmentId: { type: 'string' }, equipmentCode: { type: 'string' },
              description: { type: 'string', minLength: 10 }, symptoms: { type: 'array', items: { type: 'string' } },
              category: { type: 'string', enum: ['mechanical', 'electrical', 'instrumentation', 'process', 'safety', 'other'] },
              severity: { type: 'string', enum: ['low', 'medium', 'high', 'critical', 'unknown'] },
            },
          }),
        },
        responses: { 201: ok('Created', { $ref: '#/components/schemas/Ticket' }), 200: ok('Idempotent replay', { $ref: '#/components/schemas/Ticket' }), 400: err('Validation error / unknown or decommissioned equipment'), ...common401 },
      },
      get: {
        tags: ['Tickets'],
        summary: 'List tickets (operators: own tickets only)',
        security: secured,
        parameters: [
          ...pageParams,
          { name: 'scope', in: 'query', schema: { type: 'string', enum: ['all', 'assigned', 'unassigned', 'reported'] } },
          { name: 'status', in: 'query', description: 'Comma-separated', schema: { type: 'string', examples: ['OPEN,IN_PROGRESS'] } },
          { name: 'severity', in: 'query', description: 'Comma-separated', schema: { type: 'string' } },
          { name: 'category', in: 'query', schema: { type: 'string' } },
          { name: 'equipmentId', in: 'query', schema: { type: 'string' } },
          { name: 'assignedTo', in: 'query', schema: { type: 'string' } },
          { name: 'search', in: 'query', schema: { type: 'string' } },
          { name: 'sort', in: 'query', schema: { type: 'string', enum: ['newest', 'oldest', 'severity'] } },
        ],
        responses: { 200: list('Paginated tickets (without history/comments/transcript)', '#/components/schemas/Ticket'), ...common401 },
      },
    },
    '/tickets/{id}': {
      get: { tags: ['Tickets'], summary: 'Ticket detail incl. history, comments and per-user permissions', security: secured, parameters: [idParam], responses: { 200: ok('Ticket', { $ref: '#/components/schemas/Ticket' }), ...common401, 404: err('Not found or not visible') } },
    },
    '/tickets/{id}/history': {
      get: { tags: ['Tickets'], summary: 'Status/assignment history', security: secured, parameters: [idParam], responses: { 200: ok('History entries'), ...common401, 404: err('Not found or not visible') } },
    },
    '/tickets/{id}/assign': {
      patch: {
        tags: ['Tickets'],
        summary: 'Assign / accept / release',
        description: 'Engineer: `assigneeId` = self on an unassigned ticket (accept) or `null` on own OPEN ticket (release). Admin: any active engineer, or `null` while OPEN.',
        security: secured,
        parameters: [idParam],
        requestBody: { required: true, content: json({ type: 'object', required: ['assigneeId'], properties: { assigneeId: { type: ['string', 'null'] }, comment: { type: 'string' } } }) },
        responses: { 200: ok('Updated ticket', { $ref: '#/components/schemas/Ticket' }), 400: err('Assignee is not an active engineer'), ...common401, 403: err('Not permitted'), 404: err('Not found'), 409: err('Conflict / concurrent change') },
      },
    },
    '/tickets/{id}/status': {
      patch: {
        tags: ['Tickets'],
        summary: 'Change status (assigned engineer or admin)',
        description:
          'Allowed: OPEN→UNDER_INSPECTION|IN_PROGRESS; UNDER_INSPECTION→IN_PROGRESS|RESOLVED; IN_PROGRESS→UNDER_INSPECTION|RESOLVED; RESOLVED→CLOSED|IN_PROGRESS (reopen, comment required). RESOLVED requires `resolution.summary`. CLOSED is terminal.',
        security: secured,
        parameters: [idParam],
        requestBody: {
          required: true,
          content: json({
            type: 'object',
            required: ['status'],
            properties: {
              status: { type: 'string', enum: ['OPEN', 'UNDER_INSPECTION', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'] },
              comment: { type: 'string' },
              resolution: { type: 'object', properties: { summary: { type: 'string' }, rootCause: { type: 'string' }, actionsTaken: { type: 'string' } } },
            },
          }),
        },
        responses: { 200: ok('Updated ticket', { $ref: '#/components/schemas/Ticket' }), 400: err('Missing resolution / reopen reason'), ...common401, 403: err('Not permitted'), 404: err('Not found'), 409: err('INVALID_STATUS_TRANSITION, unassigned ticket, or concurrent change') },
      },
    },
    '/tickets/{id}/comments': {
      post: {
        tags: ['Tickets'], summary: 'Add a comment (reporter, engineers, admins; not on CLOSED)', security: secured, parameters: [idParam],
        requestBody: { required: true, content: json({ type: 'object', required: ['body'], properties: { body: { type: 'string', maxLength: 4000 } } }) },
        responses: { 201: ok('Comment'), ...common401, 404: err('Not found or not visible'), 409: err('Ticket closed') },
      },
    },

    // ---------------------------------------------------------------- Notifications
    '/notifications': {
      get: {
        tags: ['Notifications'], summary: "Current user's notifications", security: secured,
        parameters: [...pageParams, { name: 'unreadOnly', in: 'query', schema: { type: 'string', enum: ['true', 'false'] } }],
        responses: { 200: ok('Notifications; meta.unread holds the unread count'), ...common401 },
      },
    },
    '/notifications/{id}/read': {
      patch: { tags: ['Notifications'], summary: 'Mark one as read', security: secured, parameters: [idParam], responses: { 200: ok('Notification'), ...common401, 404: err('Not found (or not yours)') } },
    },
    '/notifications/read-all': {
      patch: { tags: ['Notifications'], summary: 'Mark all as read', security: secured, responses: { 200: ok('Count updated'), ...common401 } },
    },
    // ---------------------------------------------------------------- Voice
    '/voice/languages': {
      get: {
        tags: ['Voice'],
        summary: 'Verified language capability registry and voice limits',
        security: secured,
        responses: { 200: ok('providerMode, autoDetection, maxUploadSeconds, maxStreamSeconds, languages[] with supportLevel'), ...common401 },
      },
    },
    '/voice/transcribe': {
      post: {
        tags: ['Voice'],
        summary: 'Transcribe an uploaded recording (MP3; WAV/OGG/FLAC/M4A/AAC also accepted)',
        description:
          'Multipart field `audio` (≤ MAX_AUDIO_SIZE_MB; Gnani REST limit 30 s of audio) and optional `language` ("auto" or e.g. "hi-IN"). ' +
          'Content is verified by signature. The temporary file is deleted after processing in every case. ' +
          'In mock mode the transcript is prefixed with "[MOCK TRANSCRIPT]" and provider is "mock".\n\n' +
          '**Push-to-talk WebSocket** (not expressible in OpenAPI): `ws(s)://<host>/api/v1/voice/stream` with ' +
          'Sec-WebSocket-Protocol `petrosathi.voice.v1, bearer.<JWT>`. Client: `{"type":"start","language"}`, binary PCM s16le mono 16 kHz ' +
          '(even length, ≤ 32 KB per frame), `{"type":"stop"}`. Server: `session_ready`, `transcript` (final segments), `completed`, ' +
          '`error {code,message,recoverable}`. Close codes: 1000 done, 1007 invalid audio frame, 1008 protocol/language error, 1009 frame too large, 1011 provider error.',
        security: secured,
        requestBody: {
          required: true,
          content: { 'multipart/form-data': { schema: { type: 'object', required: ['audio'], properties: { audio: { type: 'string', format: 'binary' }, language: { type: 'string' } } } } },
        },
        responses: {
          201: ok('conversationId, transcript, language, provider, model, truncated, audioMode'),
          400: err('Missing file / unsupported language'),
          ...common401,
          413: err('File too large'),
          415: err('Not an audio file'),
          422: err('AUDIO_REJECTED by the speech service (e.g. longer than 30 s)'),
          429: err('Rate limited'),
          502: err('Speech service error'),
          503: err('Speech service busy'),
          504: err('Speech service timeout'),
        },
      },
    },
    '/conversations': {
      get: {
        tags: ['Conversations'], summary: 'Own voice conversations (admin: ?userId=)', security: secured,
        parameters: [...pageParams, { name: 'userId', in: 'query', schema: { type: 'string' } }],
        responses: { 200: ok('Conversations'), ...common401, 403: err('Not permitted') },
      },
    },
    '/conversations/{id}': {
      get: { tags: ['Conversations'], summary: 'One conversation (owner or admin)', security: secured, parameters: [idParam], responses: { 200: ok('Conversation'), ...common401, 404: err('Not found') } },
    },
    // ---------------------------------------------------------------- Complaints
    '/complaints/extract': {
      post: {
        tags: ['Complaints'],
        summary: 'Stateless extraction preview (operator/admin)',
        description: 'Runs the configured extractor (currently the labelled mock; Gnani Evon has no public API). Severity is "unknown" unless the text gives evidence.',
        security: secured,
        requestBody: { required: true, content: json({ type: 'object', required: ['transcript', 'language'], properties: { transcript: { type: 'string' }, language: { type: 'string', examples: ['hi-IN'] } } }) },
        responses: { 200: ok('provider, extraction (ComplaintExtraction), equipmentCheck'), 400: err('Validation error'), ...common401, 403: err('Not an operator/admin'), 422: err('Language not supported by the extractor') },
      },
    },
    '/complaints/drafts': {
      post: {
        tags: ['Complaints'],
        summary: 'Create a complaint draft from a voice conversation or typed text',
        description: 'Exactly one of `conversationId` (transcript is taken from the server record) or `transcript`. Re-using a recording with an open draft returns that draft (200).',
        security: secured,
        requestBody: { required: true, content: json({ type: 'object', properties: { conversationId: { type: 'string' }, transcript: { type: 'string', minLength: 10 }, language: { type: 'string' } } }) },
        responses: { 201: ok('Draft with state, fields, equipmentCheck, missingInformation, questions, canConfirm'), 200: ok('Existing open draft for this recording'), 400: err('Validation / unknown conversation'), ...common401, 403: err('Forbidden'), 409: err('Recording already used for a ticket') },
      },
      get: {
        tags: ['Complaints'], summary: 'Own drafts (open only unless includeClosed=true)', security: secured,
        parameters: [{ name: 'includeClosed', in: 'query', schema: { type: 'string', enum: ['true', 'false'] } }, { name: 'limit', in: 'query', schema: { type: 'integer', maximum: 50 } }],
        responses: { 200: ok('Draft summaries'), ...common401 },
      },
    },
    '/complaints/drafts/{id}': {
      get: { tags: ['Complaints'], summary: 'Draft detail (owner; admin read)', security: secured, parameters: [idParam], responses: { 200: ok('Draft'), ...common401, 404: err('Not found') } },
      patch: {
        tags: ['Complaints'], summary: 'Edit draft fields (recomputes missing info and state)', security: secured, parameters: [idParam],
        requestBody: { required: true, content: json({ type: 'object', properties: { equipmentCode: { type: ['string', 'null'] }, description: { type: 'string' }, symptoms: { type: 'array', items: { type: 'string' } }, category: { type: 'string' }, severity: { type: 'string' } } }) },
        responses: { 200: ok('Draft'), 400: err('Validation error'), ...common401, 404: err('Not found'), 409: err('Confirmed or expired') },
      },
      delete: { tags: ['Complaints'], summary: 'Discard an unconfirmed draft', security: secured, parameters: [idParam], responses: { 204: { description: 'Deleted' }, ...common401, 404: err('Not found'), 409: err('Already confirmed') } },
    },
    '/complaints/drafts/{id}/questions': {
      post: {
        tags: ['Complaints'], summary: 'Answer follow-up questions', security: secured, parameters: [idParam],
        requestBody: { required: true, content: json({ type: 'object', required: ['answers'], properties: { answers: { type: 'array', items: { type: 'object', properties: { field: { enum: ['equipmentCode', 'symptoms', 'description'] }, answer: { type: 'string' } } } } } }) },
        responses: { 200: ok('Updated draft'), 400: err('Validation error'), ...common401, 404: err('Not found'), 409: err('Confirmed or expired') },
      },
    },
    '/complaints/drafts/{id}/confirm': {
      post: {
        tags: ['Complaints'],
        summary: 'Explicitly confirm → create exactly one maintenance ticket',
        description: 'Only from READY_FOR_CONFIRMATION. Idempotent via a server-side key: repeats return the same ticket with 200 and meta.idempotentReplay=true.',
        security: secured,
        parameters: [idParam],
        responses: { 201: ok('Ticket', { $ref: '#/components/schemas/Ticket' }), 200: ok('Ticket (replay)', { $ref: '#/components/schemas/Ticket' }), ...common401, 404: err('Not found'), 409: err('Missing information or expired') },
      },
    },
    '/complaints/drafts/{id}/speech': {
      post: {
        tags: ['Complaints'],
        summary: 'Spoken follow-up questions or confirmation prompt (Gnani Timbre, audio/mpeg)',
        description: 'Text is generated server-side from fixed templates. 503 when TTS is not configured (always in mock mode) or the voice does not speak the draft language.',
        security: secured,
        parameters: [idParam],
        requestBody: { required: true, content: json({ type: 'object', required: ['target'], properties: { target: { enum: ['questions', 'confirmation'] } } }) },
        responses: { 200: { description: 'MP3 audio', content: { 'audio/mpeg': { schema: { type: 'string', format: 'binary' } } } }, ...common401, 404: err('Not found'), 503: err('TTS unavailable') },
      },
    },
    // ---------------------------------------------------------------- Documents & knowledge (RAG)
    '/documents': {
      post: {
        tags: ['Documents'],
        summary: 'Upload an approved PDF (admin) — ingested in the background',
        description: 'Multipart: `file` (PDF, ≤ MAX_PDF_SIZE_MB), `title`, `documentType`, optional `equipmentCodes` and `equipmentTypes` (comma-separated). Duplicate content (same SHA-256) → 409. Returns 202; poll GET /documents/{id}/status.',
        security: secured,
        requestBody: { required: true, content: { 'multipart/form-data': { schema: { type: 'object', required: ['file', 'title', 'documentType'], properties: { file: { type: 'string', format: 'binary' }, title: { type: 'string' }, documentType: { type: 'string' }, equipmentCodes: { type: 'string' }, equipmentTypes: { type: 'string' } } } } } },
        responses: { 202: ok('Document (ingestionStatus=pending)'), 400: err('Validation / unknown equipment'), ...common401, 403: err('Not an administrator'), 409: err('Duplicate document'), 413: err('Too large'), 415: err('Not a PDF') },
      },
      get: {
        tags: ['Documents'], summary: 'List documents (admin: all; engineer: ready only)', security: secured,
        parameters: [...pageParams, { name: 'status', in: 'query', schema: { enum: ['pending', 'processing', 'ready', 'failed'] } }, { name: 'documentType', in: 'query', schema: { type: 'string' } }, { name: 'source', in: 'query', schema: { enum: ['preloaded', 'upload'] } }, { name: 'search', in: 'query', schema: { type: 'string' } }],
        responses: { 200: ok('Documents'), ...common401, 403: err('Forbidden') },
      },
    },
    '/documents/{id}': {
      get: { tags: ['Documents'], summary: 'Document metadata incl. detected sections', security: secured, parameters: [idParam], responses: { 200: ok('Document'), ...common401, 404: err('Not found') } },
      delete: { tags: ['Documents'], summary: 'Delete document, its vectors and (uploads) its file (admin)', description: 'Vectors are removed first; if ChromaDB is unreachable the delete is refused (503) so no orphaned citations remain.', security: secured, parameters: [idParam], responses: { 204: { description: 'Deleted' }, ...common401, 403: err('Forbidden'), 404: err('Not found'), 409: err('Currently processing'), 503: err('Vector database unreachable') } },
    },
    '/documents/{id}/status': {
      get: { tags: ['Documents'], summary: 'Ingestion status, error, page and chunk counts (admin)', security: secured, parameters: [idParam], responses: { 200: ok('Status'), ...common401, 404: err('Not found') } },
    },
    '/documents/{id}/reprocess': {
      post: { tags: ['Documents'], summary: 'Re-run ingestion (replaces vectors) (admin)', security: secured, parameters: [idParam], responses: { 202: ok('Document (pending)'), ...common401, 403: err('Forbidden'), 404: err('Not found'), 409: err('Already queued') } },
    },
    '/documents/{id}/file': {
      get: { tags: ['Documents'], summary: 'Protected PDF download (admin, engineer)', security: secured, parameters: [idParam], responses: { 200: { description: 'PDF', content: { 'application/pdf': { schema: { type: 'string', format: 'binary' } } } }, ...common401, 403: err('Forbidden'), 404: err('Not found') } },
    },
    '/knowledge/search': {
      post: {
        tags: ['Knowledge'],
        summary: 'Semantic search over approved documents (engineer, admin)',
        description: 'Multilingual query → citations (documentName, pageNumber, section, excerpt, score). Results below the relevance threshold are dropped; when none remain `noResults: true` with an explicit message. Only documents with status "ready" are cited.',
        security: secured,
        requestBody: { required: true, content: json({ type: 'object', required: ['query'], properties: { query: { type: 'string' }, filters: { type: 'object', properties: { equipmentCode: { type: 'string' }, equipmentType: { type: 'string' }, documentType: { enum: ['manual', 'safety', 'troubleshooting', 'inspection', 'other'] }, documentId: { type: 'string' }, source: { enum: ['preloaded', 'upload'] } } }, topK: { type: 'integer', maximum: 20 } } }) },
        responses: { 200: ok('Search result'), 400: err('Validation error'), ...common401, 403: err('Forbidden'), 503: err('Vector database or embedding model unavailable') },
      },
    },
    '/knowledge/ask': {
      post: {
        tags: ['Knowledge'],
        summary: 'Grounded answer — extractive (best passages + citations)',
        description: 'No generated text: Gnani Evon has no documented API, so the answer is the retrieved passages verbatim with citations.',
        security: secured,
        requestBody: { required: true, content: json({ type: 'object', required: ['query'], properties: { query: { type: 'string' }, filters: { type: 'object', properties: { equipmentCode: { type: 'string' }, equipmentType: { type: 'string' }, documentType: { enum: ['manual', 'safety', 'troubleshooting', 'inspection', 'other'] }, documentId: { type: 'string' }, source: { enum: ['preloaded', 'upload'] } } }, topK: { type: 'integer' } } }) },
        responses: { 200: ok('mode=extractive, answer, citations, noResults'), ...common401, 403: err('Forbidden') },
      },
    },
    '/tickets/{id}/references': {
      get: {
        tags: ['Knowledge', 'Tickets'],
        summary: 'Manual references for a ticket (on demand; engineer, admin)',
        description: 'Query built from the ticket complaint. Scope widens: this equipment → its equipment type → all approved documents; `scope` reports which matched.',
        security: secured,
        parameters: [idParam],
        responses: { 200: ok('Citations with scope'), ...common401, 403: err('Forbidden'), 404: err('Not found') },
      },
    },
    // ---------------------------------------------------------------- Analytics, dashboards, audit
    '/analytics/overview': {
      get: { tags: ['Analytics'], summary: 'Live system summary (admin)', description: 'Ticket counts by status/severity (current), created/resolved in range, average resolution time, users by role, equipment, documents, open drafts.', security: secured, parameters: [{ name: 'from', in: 'query', schema: { type: 'string', format: 'date' }, description: 'Local day in ANALYTICS_TIMEZONE; default: start of the month 11 months ago' }, { name: 'to', in: 'query', schema: { type: 'string', format: 'date' } }], responses: { 200: ok('Overview'), 400: err('Invalid range'), ...common401, 403: err('Not an administrator') } },
    },
    '/analytics/tickets': {
      get: { tags: ['Analytics'], summary: 'Monthly created/resolved trend (zero-filled), breakdowns and resolution time (admin)', description: 'Months are bucketed in ANALYTICS_TIMEZONE. averageHours is null (not 0) when nothing was resolved.', security: secured, parameters: [{ name: 'from', in: 'query', schema: { type: 'string', format: 'date' }, description: 'Local day in ANALYTICS_TIMEZONE; default: start of the month 11 months ago' }, { name: 'to', in: 'query', schema: { type: 'string', format: 'date' } }], responses: { 200: ok('Ticket analytics'), 400: err('Invalid range (from > to, > 5 years, bad date)'), ...common401, 403: err('Not an administrator') } },
    },
    '/analytics/equipment': {
      get: { tags: ['Analytics'], summary: 'Complaints per equipment, recurring issues (2+ in range) with top symptoms, by type (admin)', security: secured, parameters: [{ name: 'from', in: 'query', schema: { type: 'string', format: 'date' }, description: 'Local day in ANALYTICS_TIMEZONE; default: start of the month 11 months ago' }, { name: 'to', in: 'query', schema: { type: 'string', format: 'date' } }, { name: 'limit', in: 'query', schema: { type: 'integer', maximum: 50, default: 10 } }], responses: { 200: ok('Equipment analytics'), ...common401, 403: err('Not an administrator') } },
    },
    '/dashboard': {
      get: { tags: ['Analytics'], summary: 'Role-specific dashboard for the signed-in user', description: 'Operator: own tickets, open drafts, notifications. Engineer: assigned counts, unassigned queue, severity-ordered work list, recent activity. Admin: overview, recent activity, latest audit entries.', security: secured, responses: { 200: ok('Dashboard (shape depends on role)'), ...common401 } },
    },
    '/audit-logs': {
      get: {
        tags: ['Audit'], summary: 'Audit log (admin), newest first', security: secured,
        parameters: [...pageParams, { name: 'action', in: 'query', schema: { type: 'string' }, description: 'Exact action, or a prefix ending with "." (e.g. "ticket.")' }, { name: 'entityType', in: 'query', schema: { type: 'string' } }, { name: 'entityId', in: 'query', schema: { type: 'string' } }, { name: 'actorId', in: 'query', schema: { type: 'string' } }, { name: 'from', in: 'query', schema: { type: 'string' }, description: 'Date (local day) or ISO datetime' }, { name: 'to', in: 'query', schema: { type: 'string' } }],
        responses: { 200: ok('Entries with populated actor'), 400: err('Validation error'), ...common401, 403: err('Not an administrator') },
      },
    },
    '/audit-logs/facets': {
      get: { tags: ['Audit'], summary: 'Distinct actions and entity types (admin)', security: secured, responses: { 200: ok('{ actions, entityTypes }'), ...common401, 403: err('Not an administrator') } },
    },
  },
} as const;
