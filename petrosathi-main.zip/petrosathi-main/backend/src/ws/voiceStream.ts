import type http from 'node:http';
import type { Duplex } from 'node:stream';
import { randomUUID } from 'node:crypto';
import { WebSocketServer, WebSocket, type RawData } from 'ws';
import { z } from 'zod';
import { env } from '../config/env.js';
import { needsEmailVerification, resolveUserFromToken } from '../middleware/auth.js';
import { ApiError } from '../utils/ApiError.js';
import { logger } from '../utils/logger.js';
import { resolveSttLanguage, AUTO_LANGUAGE } from '../config/languages.js';
import { getPrismaProvider } from '../providers/gnani/index.js';
import { PCM_BYTES_PER_SAMPLE, PCM_SAMPLE_RATE, type SttStream, type StreamSegment } from '../providers/gnani/prisma.types.js';
import { conversationResponse, saveConversation, toApiError } from '../modules/voice/voice.service.js';

/**
 * PetroSathi push-to-talk WebSocket — application contract (NOT the upstream Gnani protocol):
 *
 *   Handshake  Sec-WebSocket-Protocol: "petrosathi.voice.v1", "bearer.<JWT>"
 *   client →   {"type":"start","language":"hi-IN"|"auto"}
 *              binary: PCM signed 16-bit little-endian, mono, 16 kHz (any frame size ≤ 32 KB, even length)
 *              {"type":"stop"}
 *   server →   {"type":"session_ready", sessionId, provider, language, sampleRate, encoding, channels, maxSeconds}
 *              {"type":"transcript", text, segmentIndex, detectedLanguage, isFinal:true}
 *              {"type":"completed", conversationId|null, transcript, language, provider, ...}
 *              {"type":"error", code, message, recoverable}
 *
 * The provider adapter translates this to Gnani's documented upstream protocol. Audio is held
 * only in memory for the life of the session and is never written to disk or logged.
 */
export const VOICE_WS_PATH = '/api/v1/voice/stream';
export const APP_PROTOCOL = 'petrosathi.voice.v1';
const TOKEN_PROTOCOL_PREFIX = 'bearer.';

export const MAX_FRAME_BYTES = 32 * 1024;
const BYTES_PER_SECOND = PCM_SAMPLE_RATE * PCM_BYTES_PER_SAMPLE;
const START_TIMEOUT_MS = 10_000;
const IDLE_TIMEOUT_MS = 15_000;
const MAX_PREREADY_BUFFER = 2 * BYTES_PER_SECOND;
const MAX_SESSIONS_PER_USER = 1;

const clientMessageSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('start'), language: z.string().regex(/^(auto|[a-z]{2,3}-[A-Z]{2})$/) }).strict(),
  z.object({ type: z.literal('stop') }).strict(),
]);

const activeSessions = new Map<string, number>();

/** Upgrade attempts per client IP per minute (authenticated or not). */
export const UPGRADES_PER_MINUTE = 30;
const upgradeWindows = new Map<string, { start: number; count: number }>();

function allowUpgrade(ip: string, now = Date.now()): boolean {
  const w = upgradeWindows.get(ip);
  if (!w || now - w.start >= 60_000) {
    upgradeWindows.set(ip, { start: now, count: 1 });
    if (upgradeWindows.size > 10_000) {
      for (const [k, v] of upgradeWindows) if (now - v.start >= 60_000) upgradeWindows.delete(k);
    }
    return true;
  }
  w.count += 1;
  return w.count <= UPGRADES_PER_MINUTE;
}

/** Test helper. */
export function resetUpgradeLimiter() {
  upgradeWindows.clear();
}

/**
 * Client IP honouring TRUST_PROXY hops (same rule as Express "trust proxy" with a number):
 * X-Forwarded-For is only believed for the configured number of proxies.
 */
export function clientIp(req: http.IncomingMessage, trustHops: number): string {
  const socketIp = req.socket.remoteAddress ?? 'unknown';
  if (trustHops <= 0) return socketIp;
  const header = req.headers['x-forwarded-for'];
  const chain = (Array.isArray(header) ? header.join(',') : header ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  const addrs = [...chain, socketIp];
  return addrs[Math.max(0, addrs.length - 1 - trustHops)] ?? socketIp;
}

function rejectUpgrade(socket: Duplex, status: number, reason: string) {
  socket.write(`HTTP/1.1 ${status} ${reason}\r\nConnection: close\r\nContent-Type: text/plain\r\nContent-Length: ${Buffer.byteLength(reason)}\r\n\r\n${reason}`);
  socket.destroy();
}

function parseProtocols(header: string | undefined): string[] {
  return (header ?? '').split(',').map((p) => p.trim()).filter(Boolean);
}

type State = 'awaiting_start' | 'connecting' | 'streaming' | 'finishing' | 'closed';

class VoiceStreamSession {
  private state: State = 'awaiting_start';
  private readonly sessionId = randomUUID();
  private stream: SttStream | null = null;
  private requestedLanguage = '';
  private bytes = 0;
  private preReady: Buffer[] = [];
  private preReadyBytes = 0;
  private stopRequested = false;
  private readonly segments: StreamSegment[] = [];
  private startTimer: NodeJS.Timeout | null = null;
  private idleTimer: NodeJS.Timeout | null = null;
  private readonly maxBytes = env.VOICE_MAX_STREAM_SECONDS * BYTES_PER_SECOND;

  constructor(
    private readonly ws: WebSocket,
    private readonly user: Express.AuthenticatedUser,
  ) {
    this.startTimer = setTimeout(() => this.fail('START_TIMEOUT', 'No start message received', 1008), START_TIMEOUT_MS);
    ws.on('message', (data, isBinary) => this.onMessage(data, isBinary));
    ws.on('close', () => this.cleanup());
    ws.on('error', (err) => {
      logger.warn({ err: err.message, sessionId: this.sessionId }, 'Voice socket error');
      this.cleanup();
    });
  }

  private send(payload: Record<string, unknown>) {
    if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(payload));
  }

  private error(code: string, message: string, recoverable: boolean) {
    this.send({ type: 'error', code, message, recoverable });
  }

  private fail(code: string, message: string, closeCode = 1011) {
    this.error(code, message, false);
    this.close(closeCode, code);
  }

  private close(code: number, reason: string) {
    if (this.state === 'closed') return;
    this.cleanup();
    try {
      this.ws.close(code, reason.slice(0, 120));
    } catch {
      this.ws.terminate();
    }
  }

  private cleanup() {
    if (this.state === 'closed') return;
    this.state = 'closed';
    if (this.startTimer) clearTimeout(this.startTimer);
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.stream?.abort();
    this.stream = null;
    this.preReady = [];
    const n = (activeSessions.get(this.user.id) ?? 1) - 1;
    if (n <= 0) activeSessions.delete(this.user.id);
    else activeSessions.set(this.user.id, n);
  }

  private touch() {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => this.fail('IDLE_TIMEOUT', 'No audio received for 15 seconds', 1000), IDLE_TIMEOUT_MS);
  }

  private onMessage(data: RawData, isBinary: boolean) {
    if (this.state === 'closed') return;
    if (isBinary) return this.onAudio(data as Buffer);

    let parsed: z.infer<typeof clientMessageSchema>;
    try {
      const json: unknown = JSON.parse(data.toString());
      const r = clientMessageSchema.safeParse(json);
      if (!r.success) return this.error('INVALID_MESSAGE', 'Unrecognised control message', true);
      parsed = r.data;
    } catch {
      return this.error('INVALID_MESSAGE', 'Control messages must be JSON', true);
    }

    if (parsed.type === 'start') void this.onStart(parsed.language);
    else void this.onStop();
  }

  private async onStart(language: string) {
    if (this.state !== 'awaiting_start') return this.error('ALREADY_STARTED', 'Session already started', true);
    if (this.startTimer) clearTimeout(this.startTimer);

    const code = resolveSttLanguage(language, 'stream');
    if (!code) {
      return this.fail(
        'UNSUPPORTED_LANGUAGE',
        language === AUTO_LANGUAGE ? 'Automatic language detection is not available. Select a language.' : `Language ${language} is not supported for streaming`,
        1008,
      );
    }
    this.requestedLanguage = language;
    this.state = 'connecting';

    try {
      const provider = getPrismaProvider();
      const stream = await provider.openStream(code, {
        onSegment: (s) => {
          this.segments.push(s);
          this.send({ type: 'transcript', text: s.text, segmentIndex: s.segmentIndex, detectedLanguage: s.detectedLanguage, isFinal: true });
        },
        onWarning: (message) => this.error('PROVIDER_WARNING', message, true),
        onFatal: (err) => {
          const api = toApiError(err);
          this.fail(api.code, api.message);
        },
      });
      // The client may have disconnected while we were connecting upstream.
      if ((this.state as State) !== 'connecting') {
        stream.abort();
        return;
      }
      this.stream = stream;
      this.state = 'streaming';
      this.send({
        type: 'session_ready',
        sessionId: this.sessionId,
        provider: provider.id,
        language: this.requestedLanguage,
        sampleRate: PCM_SAMPLE_RATE,
        encoding: 'pcm_s16le',
        channels: 1,
        maxSeconds: env.VOICE_MAX_STREAM_SECONDS,
      });
      for (const chunk of this.preReady) stream.sendAudio(chunk);
      this.preReady = [];
      this.touch();
      if (this.stopRequested) await this.onStop();
    } catch (err) {
      if ((this.state as State) === 'closed') return;
      const api = toApiError(err);
      this.fail(api.code, api.message);
    }
  }

  private onAudio(chunk: Buffer) {
    if (this.state === 'awaiting_start') return this.fail('NOT_STARTED', 'Send a start message before audio', 1008);
    if (this.state === 'finishing') return; // trailing frames after stop are ignored
    if (chunk.length === 0) return;
    if (chunk.length % PCM_BYTES_PER_SAMPLE !== 0) {
      return this.fail('INVALID_AUDIO_FRAME', 'Audio frames must be 16-bit PCM (even byte length)', 1007);
    }

    this.bytes += chunk.length;
    if (this.bytes > this.maxBytes) {
      this.error('MAX_DURATION_REACHED', `Recording limit of ${env.VOICE_MAX_STREAM_SECONDS} seconds reached`, true);
      void this.onStop();
      return;
    }

    if (this.state === 'connecting') {
      this.preReadyBytes += chunk.length;
      if (this.preReadyBytes > MAX_PREREADY_BUFFER) return this.fail('NOT_READY', 'Wait for session_ready before streaming audio', 1008);
      this.preReady.push(chunk);
      return;
    }
    this.touch();
    this.stream?.sendAudio(chunk);
  }

  private async onStop() {
    if (this.state === 'connecting') {
      this.stopRequested = true;
      return;
    }
    if (this.state !== 'streaming') return;
    this.state = 'finishing';
    if (this.idleTimer) clearTimeout(this.idleTimer);

    try {
      await this.stream!.finish();
      if ((this.state as State) === 'closed') return;

      const transcript = this.segments.map((s) => s.text).join(' ').trim();
      const audioDurationMs = Math.round((this.bytes / BYTES_PER_SECOND) * 1000);
      if (!transcript) {
        this.send({ type: 'completed', conversationId: null, transcript: '', language: null, provider: getPrismaProvider().id, audioDurationMs, segmentCount: 0 });
        return this.close(1000, 'completed');
      }

      const detected = [...this.segments].reverse().find((s) => s.detectedLanguage)?.detectedLanguage ?? null;
      const conv = await saveConversation({
        userId: this.user.id,
        audioMode: 'stream',
        requestedLanguage: this.requestedLanguage,
        result: {
          provider: getPrismaProvider().id,
          transcript,
          detectedLanguage: detected,
          model: getPrismaProvider().id === 'mock' ? 'mock' : env.GNANI_PRISMA_MODEL ?? null,
          requestId: null,
          truncated: false,
        },
        segmentCount: this.segments.length,
        audioDurationMs,
      });
      this.send({ type: 'completed', ...conversationResponse(conv) });
      this.close(1000, 'completed');
    } catch (err) {
      if ((this.state as State) === 'closed') return;
      const api = err instanceof ApiError ? err : toApiError(err);
      this.fail(api.code, api.message);
    }
  }
}

export function attachVoiceSocket(server: http.Server): WebSocketServer {
  const wss = new WebSocketServer({
    noServer: true,
    maxPayload: MAX_FRAME_BYTES, // larger frames → close 1009
    handleProtocols: (protocols) => (protocols.has(APP_PROTOCOL) ? APP_PROTOCOL : false),
  });

  server.on('upgrade', (req, socket, head) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    if (url.pathname !== VOICE_WS_PATH) return rejectUpgrade(socket, 404, 'Not Found');

    // Each attempt costs a JWT check + DB lookup: cap attempts per client IP before doing any work.
    if (!allowUpgrade(clientIp(req, env.TRUST_PROXY))) return rejectUpgrade(socket, 429, 'Too Many Requests');

    const origin = req.headers.origin;
    if (origin && origin !== env.CLIENT_URL) return rejectUpgrade(socket, 403, 'Forbidden origin');

    const protocols = parseProtocols(req.headers['sec-websocket-protocol']);
    if (!protocols.includes(APP_PROTOCOL)) return rejectUpgrade(socket, 400, 'Missing subprotocol');
    const token = protocols.find((p) => p.startsWith(TOKEN_PROTOCOL_PREFIX))?.slice(TOKEN_PROTOCOL_PREFIX.length);
    if (!token) return rejectUpgrade(socket, 401, 'Unauthorized');

    resolveUserFromToken(token)
      .then((user) => {
        if (user.mustChangePassword) return rejectUpgrade(socket, 403, 'Password change required');
        if (needsEmailVerification(user)) return rejectUpgrade(socket, 403, 'Email verification required');
        const active = activeSessions.get(user.id) ?? 0;
        if (active >= MAX_SESSIONS_PER_USER) return rejectUpgrade(socket, 409, 'Another recording is already in progress');
        activeSessions.set(user.id, active + 1);
        wss.handleUpgrade(req, socket, head, (ws) => {
          new VoiceStreamSession(ws, user);
        });
      })
      .catch(() => rejectUpgrade(socket, 401, 'Unauthorized'));
  });

  return wss;
}

/** Test helper. */
export function activeVoiceSessionCount(): number {
  let n = 0;
  for (const v of activeSessions.values()) n += v;
  return n;
}
