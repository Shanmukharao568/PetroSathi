import http from 'node:http';
import { createApp } from './app.js';
import { env } from './config/env.js';
import { connectDatabase, disconnectDatabase } from './config/db.js';
import { logger } from './utils/logger.js';
import { attachVoiceSocket } from './ws/voiceStream.js';
import { ensureAudioDir, startAudioSweeper, stopAudioSweeper } from './jobs/audioCleanup.js';
import { startDraftExpiryJob, stopDraftExpiryJob } from './modules/complaints/complaint.service.js';
import { evonMode, getTtsProvider } from './providers/gnani/index.js';
import { resumeInterruptedIngestion } from './rag/ingestion.js';

async function main() {
  await connectDatabase();
  await ensureAudioDir();
  startAudioSweeper();
  startDraftExpiryJob();
  const resumed = await resumeInterruptedIngestion();
  if (resumed) logger.info({ resumed }, 'Re-queued interrupted document ingestion');

  const app = createApp();
  // Plain http.Server so the push-to-talk WebSocket shares the API port.
  const server = http.createServer(app);
  const wss = attachVoiceSocket(server);

  server.listen(env.PORT, () => {
    logger.info(
      { port: env.PORT, mode: env.NODE_ENV, aiProviderMode: env.AI_PROVIDER_MODE, prismaModel: env.GNANI_PRISMA_MODEL ?? '(provider default)', evonMode: evonMode(), tts: getTtsProvider() ? `${env.GNANI_TIMBRE_MODEL}/${env.GNANI_TIMBRE_VOICE}` : 'disabled' },
      `PetroSathi API listening — docs at http://localhost:${env.PORT}/api/docs`,
    );
  });

  const shutdown = (signal: string) => {
    logger.info({ signal }, 'Shutting down');
    stopAudioSweeper();
    stopDraftExpiryJob();
    for (const client of wss.clients) client.close(1001, 'server shutting down');
    server.close(() => {
      disconnectDatabase()
        .catch((err) => logger.error({ err }, 'Error during DB disconnect'))
        .finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((err) => {
  logger.fatal({ err: err instanceof Error ? err.message : err }, 'Failed to start PetroSathi API');
  process.exit(1);
});
