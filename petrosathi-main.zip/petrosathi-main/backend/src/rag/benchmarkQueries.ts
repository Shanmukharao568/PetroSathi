/**
 * Petroleum-maintenance retrieval benchmark. Each intent maps to ONE section of the demo corpus
 * (English documents), asked in English, Hindi, Telugu, Tamil and code-mixed Hinglish, so the
 * Indian-language queries measure cross-lingual retrieval. Translations were written for this
 * benchmark (not machine-generated at runtime); native-speaker review is recommended.
 */
export type BenchLang = 'en' | 'hi' | 'te' | 'ta' | 'hi-en';

export interface BenchIntent {
  /** Expected section key from demoContent.ts */
  expected: string;
  queries: Partial<Record<BenchLang, string>>;
}

export const BENCH_INTENTS: BenchIntent[] = [
  {
    expected: 'pump.vibration',
    queries: {
      en: 'What causes high vibration in a centrifugal pump?',
      hi: 'सेंट्रीफ्यूगल पंप में ज़्यादा कंपन क्यों होता है?',
      te: 'సెంట్రిఫ్యూగల్ పంపులో ఎక్కువ కంపనం ఎందుకు వస్తుంది?',
      ta: 'மையவிலக்கு பம்பில் அதிக அதிர்வு ஏன் ஏற்படுகிறது?',
      'hi-en': 'pump mein bahut vibration aa raha hai, reason kya hai?',
    },
  },
  {
    expected: 'pump.bearings',
    queries: {
      en: 'How often should pump bearings be lubricated and what are signs of bearing problems?',
      hi: 'पंप के बेयरिंग में कितनी बार ग्रीस डालना चाहिए और बेयरिंग खराब होने के क्या संकेत हैं?',
      te: 'పంప్ బేరింగ్‌లకు ఎంత తరచుగా గ్రీజ్ వేయాలి, బేరింగ్ సమస్యల సంకేతాలు ఏమిటి?',
      ta: 'பம்ப் பேரிங்குகளுக்கு எவ்வளவு அடிக்கடி கிரீஸ் போட வேண்டும், பேரிங் பிரச்சனையின் அறிகுறிகள் என்ன?',
      'hi-en': 'bearing ka greasing kitne din mein karna hai, oil ka colour change ho gaya hai',
    },
  },
  {
    expected: 'pump.seal',
    queries: {
      en: 'The mechanical seal is leaking, what should I report?',
      hi: 'मैकेनिकल सील से रिसाव हो रहा है, क्या रिपोर्ट करूं?',
      te: 'మెకానికల్ సీల్ నుండి లీక్ అవుతోంది, ఏమి రిపోర్ట్ చేయాలి?',
      ta: 'மெக்கானிக்கல் சீலில் கசிவு உள்ளது, என்ன புகாரளிக்க வேண்டும்?',
      'hi-en': 'pump ki seal se leakage ho raha hai, drops gir rahe hain',
    },
  },
  {
    expected: 'pump.cavitation',
    queries: {
      en: 'Pump makes a gravel-like noise and suction pressure is low',
      hi: 'पंप से कंकड़ जैसी आवाज़ आ रही है और सक्शन प्रेशर कम है',
      te: 'పంప్ నుండి కంకర లాంటి శబ్దం వస్తోంది, సక్షన్ ప్రెషర్ తక్కువగా ఉంది',
      ta: 'பம்பில் இருந்து கற்கள் போன்ற சத்தம் வருகிறது, சக்ஷன் அழுத்தம் குறைவாக உள்ளது',
      'hi-en': 'pump mein kankad jaisi awaaz, suction pressure low hai',
    },
  },
  {
    expected: 'pump.overheating',
    queries: {
      en: 'The pump casing and motor are getting very hot',
      hi: 'पंप का केसिंग और मोटर बहुत गर्म हो रहे हैं',
      te: 'పంప్ కేసింగ్ మరియు మోటార్ చాలా వేడెక్కుతున్నాయి',
      ta: 'பம்ப் கேசிங் மற்றும் மோட்டார் மிகவும் சூடாகின்றன',
      'hi-en': 'pump ka casing aur motor bahut garam ho raha hai',
    },
  },
  {
    expected: 'compressor.discharge_temp',
    queries: {
      en: 'Compressor discharge temperature is too high',
      hi: 'कंप्रेसर का डिस्चार्ज तापमान बहुत ज़्यादा है',
      te: 'కంప్రెసర్ డిశ్చార్జ్ ఉష్ణోగ్రత చాలా ఎక్కువగా ఉంది',
      ta: 'கம்ப்ரசர் டிஸ்சார்ஜ் வெப்பநிலை மிக அதிகமாக உள்ளது',
      'hi-en': 'compressor ka discharge temperature high ja raha hai',
    },
  },
  {
    expected: 'compressor.surge',
    queries: {
      en: 'Loud banging from the centrifugal compressor and pressure swinging, is it surge?',
      hi: 'सेंट्रीफ्यूगल कंप्रेसर से ज़ोर की धमाके जैसी आवाज़ और प्रेशर ऊपर-नीचे हो रहा है, क्या यह सर्ज है?',
      te: 'సెంట్రిఫ్యూగల్ కంప్రెసర్ నుండి పెద్ద చప్పుడు, ప్రెషర్ ఊగిసలాడుతోంది, ఇది సర్జ్ అవుతోందా?',
      ta: 'மையவிலக்கு கம்ப்ரசரில் இருந்து பலத்த சத்தம், அழுத்தம் ஏறி இறங்குகிறது, இது சர்ஜா?',
      'hi-en': 'compressor mein banging sound aur pressure fluctuate ho raha hai, surge hai kya?',
    },
  },
  {
    expected: 'compressor.lube_oil',
    queries: {
      en: 'Low lube oil pressure alarm on the compressor',
      hi: 'कंप्रेसर पर लुब ऑयल प्रेशर कम होने का अलार्म',
      te: 'కంప్రెసర్‌పై లూబ్ ఆయిల్ ప్రెషర్ తక్కువ అలారం',
      ta: 'கம்ப்ரசரில் லூப் ஆயில் அழுத்தம் குறைவு அலாரம்',
      'hi-en': 'compressor lube oil pressure low ka alarm aa raha hai',
    },
  },
  {
    expected: 'safety.report',
    queries: {
      en: 'I smell gas near the separator, how do I report it?',
      hi: 'सेपरेटर के पास गैस की गंध आ रही है, कैसे रिपोर्ट करूं?',
      te: 'సెపరేటర్ దగ్గర గ్యాస్ వాసన వస్తోంది, ఎలా రిపోర్ట్ చేయాలి?',
      ta: 'செப்பரேட்டர் அருகே வாயு வாசனை வருகிறது, எப்படி புகாரளிப்பது?',
      'hi-en': 'separator ke paas gas ki smell aa rahi hai, report kaise karein?',
    },
  },
  {
    expected: 'hx.fouling',
    queries: {
      en: 'Heat exchanger outlet temperature is drifting, possible fouling',
      hi: 'हीट एक्सचेंजर का आउटलेट तापमान बदल रहा है, फाउलिंग हो सकती है',
      te: 'హీట్ ఎక్స్ఛేంజర్ అవుట్‌లెట్ ఉష్ణోగ్రత మారుతోంది, ఫౌలింగ్ కావచ్చు',
      ta: 'வெப்பப் பரிமாற்றியின் வெளியேற்ற வெப்பநிலை மாறுகிறது, அழுக்கு படிதல் இருக்கலாம்',
      'hi-en': 'heat exchanger ka outlet temperature drift ho raha hai, fouling hai kya?',
    },
  },
  {
    expected: 'hx.tube_leak',
    queries: {
      en: 'Cooling water is contaminated, could the heat exchanger have a tube leak?',
      hi: 'कूलिंग वॉटर दूषित हो गया है, क्या हीट एक्सचेंजर में ट्यूब लीक है?',
      te: 'కూలింగ్ వాటర్ కలుషితమైంది, హీట్ ఎక్స్ఛేంజర్‌లో ట్యూబ్ లీక్ ఉందా?',
      ta: 'குளிரூட்டும் நீர் மாசடைந்துள்ளது, வெப்பப் பரிமாற்றியில் டியூப் கசிவு உள்ளதா?',
      'hi-en': 'cooling water contaminate ho gaya, heat exchanger tube leak hai kya?',
    },
  },
  {
    expected: 'pump.vibration',
    queries: { en: 'P-101 vibration troubleshooting' },
  },
];

/** Off-topic queries: used to pick a "no relevant documentation" threshold. */
export const BENCH_NEGATIVES: string[] = [
  'What is on the canteen menu today?',
  'आज कैंटीन में क्या खाना है?',
  'Who won the cricket match yesterday?',
  'నిన్న క్రికెట్ మ్యాచ్ ఎవరు గెలిచారు?',
  'இன்று வானிலை எப்படி இருக்கிறது?',
  'How do I apply for annual leave?',
  'mera salary slip kahan milega?',
  'Recommend a good movie for the weekend',
];
