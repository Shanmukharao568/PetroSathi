import { DocumentModel } from '../modules/documents/document.model.js';
import { EquipmentModel } from '../modules/equipment/equipment.model.js';
import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';
import { extractPdfPages, PdfValidationError } from './pdf.js';
import { chunkPages } from './chunker.js';
import { getEmbeddingProvider } from './embeddings/index.js';
import { getVectorStore, vectorStoreLabel, type ChunkRecord } from './vectorStore/index.js';
import { readStoredFile } from '../modules/documents/fileStore.js';

/**
 * One ingestion pipeline for BOTH preloaded and uploaded documents:
 *   validate → extract per page → chunk (page-aware, sections) → embed → replace vectors → status
 * Runs on a single in-process queue so CPU-heavy embedding never runs in parallel.
 */

const MIN_TEXT_CHARS = 50;

function safeMessage(err: unknown): string {
  if (err instanceof PdfValidationError) return err.message;
  const msg = err instanceof Error ? err.message : String(err);
  if (/ECONNREFUSED|fetch failed|Failed to connect|connect/i.test(msg)) return `Vector database (${vectorStoreLabel()}) is not reachable. Check it and reprocess the document.`;
  return `Ingestion failed: ${msg.slice(0, 300)}`;
}

export async function ingestDocument(documentId: string): Promise<void> {
  const doc = await DocumentModel.findById(documentId);
  if (!doc) return; // deleted while queued
  doc.ingestionStatus = 'processing';
  doc.ingestionError = null;
  doc.ingestionAttempts += 1;
  await doc.save();

  const started = Date.now();
  try {
    const buf = await readStoredFile(doc.storagePath);
    const { pageCount, pages } = await extractPdfPages(buf, env.MAX_PDF_PAGES);
    const totalText = pages.reduce((n, p) => n + p.lines.reduce((m, l) => m + l.text.length, 0), 0);
    if (totalText < MIN_TEXT_CHARS) {
      throw new PdfValidationError('No extractable text found. Scanned/image-only PDFs need OCR, which is not supported.');
    }

    const { chunks, sections } = chunkPages(pages, env.RAG_CHUNK_SIZE, env.RAG_CHUNK_OVERLAP);
    if (!chunks.length) throw new PdfValidationError('The document produced no text chunks.');

    const embedder = getEmbeddingProvider();
    const embeddings = await embedder.embedDocuments(chunks.map((c) => c.text));

    const equipment = doc.equipmentIds.length ? await EquipmentModel.find({ _id: { $in: doc.equipmentIds } }).select('equipmentCode') : [];
    const records: ChunkRecord[] = chunks.map((c, i) => ({
      id: `${documentId}:${c.chunkIndex}`,
      embedding: embeddings[i]!,
      text: c.text,
      metadata: {
        documentId,
        documentName: doc.title,
        documentType: doc.documentType,
        pageNumber: c.pageNumber,
        section: c.section,
        equipmentIds: doc.equipmentIds.map(String),
        equipmentCodes: equipment.map((e) => e.equipmentCode),
        equipmentTypes: [...doc.equipmentTypes],
        source: doc.source as 'preloaded' | 'upload',
        chunkIndex: c.chunkIndex,
        embeddingModel: embedder.model,
      },
    }));

    // Replace: never leave stale vectors from a previous ingestion.
    const store = getVectorStore();
    await store.deleteByDocument(documentId);
    await store.upsert(records);

    doc.ingestionStatus = 'ready';
    doc.pageCount = pageCount;
    doc.chunkCount = records.length;
    doc.sections = sections;
    doc.embeddingModel = embedder.model;
    doc.ingestedAt = new Date();
    await doc.save();
    logger.info({ documentId, pages: pageCount, chunks: records.length, ms: Date.now() - started }, 'Document ingested');
  } catch (err) {
    doc.ingestionStatus = 'failed';
    doc.ingestionError = safeMessage(err);
    await doc.save();
    logger.warn({ documentId, error: doc.ingestionError }, 'Document ingestion failed');
  }
}

let queue: Promise<void> = Promise.resolve();
let pending = 0;

export function enqueueIngestion(documentId: string): void {
  pending += 1;
  queue = queue
    .then(() => ingestDocument(documentId))
    .catch((err) => logger.error({ err, documentId }, 'Unexpected ingestion error'))
    .finally(() => {
      pending -= 1;
    });
}

/** Resolves when every queued ingestion has finished (tests, scripts). */
export async function waitForIngestionIdle(): Promise<void> {
  while (pending > 0) await queue;
}

/** After a restart, documents left mid-ingestion are queued again. */
export async function resumeInterruptedIngestion(): Promise<number> {
  const stuck = await DocumentModel.find({ ingestionStatus: { $in: ['pending', 'processing'] } }).select('_id');
  for (const d of stuck) enqueueIngestion(String(d._id));
  return stuck.length;
}
