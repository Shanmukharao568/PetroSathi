import { env } from '../../config/env.js';
import { getEmbeddingProvider } from '../embeddings/index.js';
import { collectionNameFor, createChromaStore } from './chromaStore.js';
import { createMongoVectorStore } from './mongoStore.js';
import type { VectorStore } from './types.js';

let cached: VectorStore | null = null;
let override: VectorStore | null = null;

/** Collection holding this embedding model's vectors (same name in Chroma and MongoDB). */
export function vectorCollectionName(): string {
  return collectionNameFor(env.CHROMA_COLLECTION_NAME, getEmbeddingProvider().model);
}

/** VECTOR_STORE=chroma (local ChromaDB server) or mongo (MongoDB Atlas Vector Search). */
export function getVectorStore(): VectorStore {
  if (override) return override;
  cached ??=
    env.VECTOR_STORE === 'mongo'
      ? createMongoVectorStore({ collection: vectorCollectionName(), index: env.MONGO_VECTOR_INDEX })
      : createChromaStore({ url: env.CHROMA_URL, collection: vectorCollectionName() });
  return cached;
}

/** Human-readable name for error messages. */
export function vectorStoreLabel(): string {
  return env.VECTOR_STORE === 'mongo' ? 'MongoDB Atlas Vector Search' : 'ChromaDB';
}

/** Test seam only. */
export function setVectorStoreForTests(s: VectorStore | null) {
  override = s;
}

export type { VectorStore, VectorFilter, VectorHit, ChunkRecord, ChunkMetadata } from './types.js';
