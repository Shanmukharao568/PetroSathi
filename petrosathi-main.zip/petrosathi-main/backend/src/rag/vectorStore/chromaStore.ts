import { ChromaClient, type Collection, type Metadata, type Where } from 'chromadb';
import type { ChunkMetadata, ChunkRecord, VectorFilter, VectorHit, VectorStore } from './types.js';

/**
 * ChromaDB vector store. One collection per embedding model (vectors of different models and
 * dimensions must never be mixed). Embeddings are computed by PetroSathi and passed explicitly,
 * so the collection has no embedding function. Distance space: cosine.
 */
export function collectionNameFor(base: string, model: string): string {
  const slug = model.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  return `${base}__${slug}`.slice(0, 63);
}

function toChromaMetadata(m: ChunkMetadata): Metadata {
  const out: Metadata = {
    documentId: m.documentId,
    documentName: m.documentName,
    documentType: m.documentType,
    pageNumber: m.pageNumber,
    section: m.section,
    source: m.source,
    chunkIndex: m.chunkIndex,
    embeddingModel: m.embeddingModel,
  };
  // Array metadata is filterable with $contains; empty arrays are omitted (untagged document).
  if (m.equipmentIds.length) out.equipmentIds = m.equipmentIds;
  if (m.equipmentCodes.length) out.equipmentCodes = m.equipmentCodes;
  if (m.equipmentTypes.length) out.equipmentTypes = m.equipmentTypes;
  return out;
}

function fromChromaMetadata(m: Metadata | null | undefined): ChunkMetadata {
  const arr = (v: unknown) => (Array.isArray(v) ? v.map(String) : []);
  return {
    documentId: String(m?.documentId ?? ''),
    documentName: String(m?.documentName ?? ''),
    documentType: String(m?.documentType ?? ''),
    pageNumber: Number(m?.pageNumber ?? 0),
    section: String(m?.section ?? ''),
    equipmentIds: arr(m?.equipmentIds),
    equipmentCodes: arr(m?.equipmentCodes),
    equipmentTypes: arr(m?.equipmentTypes),
    source: m?.source === 'upload' ? 'upload' : 'preloaded',
    chunkIndex: Number(m?.chunkIndex ?? 0),
    embeddingModel: String(m?.embeddingModel ?? ''),
  };
}

export function buildWhere(f: VectorFilter | undefined): Where | undefined {
  if (!f) return undefined;
  const clauses: Where[] = [];
  if (f.documentId) clauses.push({ documentId: f.documentId });
  if (f.documentType) clauses.push({ documentType: f.documentType });
  if (f.source) clauses.push({ source: f.source });
  if (f.equipmentCode) clauses.push({ equipmentCodes: { $contains: f.equipmentCode } });
  if (f.equipmentType) clauses.push({ equipmentTypes: { $contains: f.equipmentType } });
  if (!clauses.length) return undefined;
  return clauses.length === 1 ? clauses[0] : { $and: clauses };
}

export function createChromaStore(opts: { url: string; collection: string }): VectorStore {
  const u = new URL(opts.url);
  const client = new ChromaClient({ host: u.hostname, port: Number(u.port || (u.protocol === 'https:' ? 443 : 80)), ssl: u.protocol === 'https:' });
  let coll: Promise<Collection> | null = null;
  const collection = () =>
    (coll ??= client
      .getOrCreateCollection({ name: opts.collection, embeddingFunction: null, configuration: { hnsw: { space: 'cosine' } } })
      .catch((err: unknown) => {
        coll = null; // retry on next call (e.g. Chroma started later)
        throw err;
      }));

  return {
    id: `chroma:${opts.collection}`,

    async upsert(records: ChunkRecord[]) {
      if (!records.length) return;
      const c = await collection();
      for (let i = 0; i < records.length; i += 100) {
        const batch = records.slice(i, i + 100);
        await c.upsert({
          ids: batch.map((r) => r.id),
          embeddings: batch.map((r) => r.embedding),
          documents: batch.map((r) => r.text),
          metadatas: batch.map((r) => toChromaMetadata(r.metadata)),
        });
      }
    },

    async deleteByDocument(documentId: string) {
      const c = await collection();
      await c.delete({ where: { documentId } });
    },

    async query(embedding, topK, filter) {
      const c = await collection();
      const r = await c.query({
        queryEmbeddings: [embedding],
        nResults: topK,
        where: buildWhere(filter),
        include: ['documents', 'metadatas', 'distances'],
      });
      const ids = r.ids[0] ?? [];
      return ids.map(
        (id, i): VectorHit => ({
          id,
          text: r.documents[0]?.[i] ?? '',
          metadata: fromChromaMetadata(r.metadatas[0]?.[i]),
          // Cosine distance in [0, 2] → similarity, clamped to [0, 1].
          score: Math.max(0, Math.min(1, 1 - (r.distances[0]?.[i] ?? 1))),
        }),
      );
    },

    async countByDocument(documentId: string) {
      const c = await collection();
      const r = await c.get({ where: { documentId }, include: [] });
      return r.ids.length;
    },

    async health() {
      await client.heartbeat();
    },
  };
}
