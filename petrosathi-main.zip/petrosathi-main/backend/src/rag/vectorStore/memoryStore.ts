import type { ChunkRecord, VectorFilter, VectorHit, VectorStore } from './types.js';

/**
 * In-memory vector store with the same filter semantics as ChromaStore.
 * Used by automated tests and the embedding benchmark; not used by the running application.
 */
export function createMemoryStore(): VectorStore & { size(): number } {
  const rows = new Map<string, ChunkRecord>();

  const matches = (r: ChunkRecord, f?: VectorFilter) =>
    !f ||
    ((!f.documentId || r.metadata.documentId === f.documentId) &&
      (!f.documentType || r.metadata.documentType === f.documentType) &&
      (!f.source || r.metadata.source === f.source) &&
      (!f.equipmentCode || r.metadata.equipmentCodes.includes(f.equipmentCode)) &&
      (!f.equipmentType || r.metadata.equipmentTypes.includes(f.equipmentType)));

  return {
    id: 'memory',
    size: () => rows.size,
    async upsert(records) {
      for (const r of records) rows.set(r.id, r);
    },
    async deleteByDocument(documentId) {
      for (const [id, r] of rows) if (r.metadata.documentId === documentId) rows.delete(id);
    },
    async query(embedding, topK, filter) {
      const hits: VectorHit[] = [];
      for (const r of rows.values()) {
        if (!matches(r, filter)) continue;
        let dot = 0;
        for (let i = 0; i < embedding.length; i++) dot += embedding[i]! * (r.embedding[i] ?? 0);
        hits.push({ id: r.id, text: r.text, metadata: r.metadata, score: Math.max(0, Math.min(1, dot)) });
      }
      return hits.sort((a, b) => b.score - a.score).slice(0, topK);
    },
    async countByDocument(documentId) {
      let n = 0;
      for (const r of rows.values()) if (r.metadata.documentId === documentId) n++;
      return n;
    },
    async health() {},
  };
}
