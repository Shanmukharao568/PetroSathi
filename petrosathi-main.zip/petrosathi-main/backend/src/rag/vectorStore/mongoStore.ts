import mongoose from 'mongoose';
import type { ChunkMetadata, ChunkRecord, VectorFilter, VectorHit, VectorStore } from './types.js';

/**
 * MongoDB Atlas Vector Search store. One collection per embedding model (same naming as the
 * Chroma collections), each with an Atlas "vectorSearch" index on `embedding` plus filter
 * fields. Requires Atlas (the free M0 tier works); a plain local mongod has no $vectorSearch.
 * Create the index once with: npm run vector:index
 */

/** Metadata fields usable in $vectorSearch filters. */
export const FILTER_FIELDS = ['documentId', 'documentType', 'source', 'equipmentCodes', 'equipmentTypes'] as const;

export function vectorIndexDefinition(dimensions: number) {
  return {
    fields: [
      { type: 'vector', path: 'embedding', numDimensions: dimensions, similarity: 'cosine' },
      ...FILTER_FIELDS.map((path) => ({ type: 'filter', path })),
    ],
  };
}

type ChunkDoc = ChunkMetadata & { _id: string; embedding: number[]; text: string };

export function buildMongoFilter(f: VectorFilter | undefined): Record<string, unknown> | undefined {
  if (!f) return undefined;
  const clauses: Record<string, unknown>[] = [];
  if (f.documentId) clauses.push({ documentId: { $eq: f.documentId } });
  if (f.documentType) clauses.push({ documentType: { $eq: f.documentType } });
  if (f.source) clauses.push({ source: { $eq: f.source } });
  // $eq on an array field matches when any element equals the value.
  if (f.equipmentCode) clauses.push({ equipmentCodes: { $eq: f.equipmentCode } });
  if (f.equipmentType) clauses.push({ equipmentTypes: { $eq: f.equipmentType } });
  if (!clauses.length) return undefined;
  return clauses.length === 1 ? clauses[0] : { $and: clauses };
}

export function createMongoVectorStore(opts: { collection: string; index: string }): VectorStore {
  const coll = () => {
    const db = mongoose.connection.db;
    if (!db) throw new Error('MongoDB is not connected');
    return db.collection<ChunkDoc>(opts.collection);
  };

  return {
    id: `mongo:${opts.collection}`,

    async upsert(records: ChunkRecord[]) {
      for (let i = 0; i < records.length; i += 200) {
        const ops = records.slice(i, i + 200).map((r) => ({
          replaceOne: {
            filter: { _id: r.id },
            replacement: { ...r.metadata, embedding: r.embedding, text: r.text } as ChunkDoc,
            upsert: true,
          },
        }));
        if (ops.length) await coll().bulkWrite(ops, { ordered: false });
      }
    },

    async deleteByDocument(documentId: string) {
      await coll().deleteMany({ documentId });
    },

    async query(embedding, topK, filter) {
      const vectorSearch: Record<string, unknown> = {
        index: opts.index,
        path: 'embedding',
        queryVector: embedding,
        numCandidates: Math.min(10000, Math.max(100, topK * 20)),
        limit: topK,
      };
      const f = buildMongoFilter(filter);
      if (f) vectorSearch.filter = f;
      const rows = await coll()
        .aggregate<ChunkDoc & { score: number }>([{ $vectorSearch: vectorSearch }, { $project: { embedding: 0 } }, { $addFields: { score: { $meta: 'vectorSearchScore' } } }])
        .toArray();
      return rows.map(
        (r): VectorHit => ({
          id: r._id,
          text: r.text,
          metadata: {
            documentId: r.documentId,
            documentName: r.documentName,
            documentType: r.documentType,
            pageNumber: r.pageNumber,
            section: r.section,
            equipmentIds: r.equipmentIds ?? [],
            equipmentCodes: r.equipmentCodes ?? [],
            equipmentTypes: r.equipmentTypes ?? [],
            source: r.source,
            chunkIndex: r.chunkIndex,
            embeddingModel: r.embeddingModel,
          },
          // Atlas cosine score is (1 + cos) / 2; convert back to cosine similarity so the
          // relevance threshold means the same as with ChromaDB. Clamped to [0, 1].
          score: Math.max(0, Math.min(1, 2 * r.score - 1)),
        }),
      );
    },

    async countByDocument(documentId: string) {
      return coll().countDocuments({ documentId });
    },

    async health() {
      const c = coll();
      const indexes = await c.listSearchIndexes(opts.index).toArray();
      if (!indexes.length) throw new Error(`Atlas vector index "${opts.index}" is missing on collection "${opts.collection}". Run: npm run vector:index`);
    },
  };
}
