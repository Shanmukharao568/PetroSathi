/** Metadata stored with every chunk (spec: documentId … chunkIndex, plus equipment codes). */
export interface ChunkMetadata {
  documentId: string;
  documentName: string;
  documentType: string;
  pageNumber: number;
  section: string;
  equipmentIds: string[];
  equipmentCodes: string[];
  equipmentTypes: string[];
  source: 'preloaded' | 'upload';
  chunkIndex: number;
  embeddingModel: string;
}

export interface ChunkRecord {
  id: string;
  embedding: number[];
  text: string;
  metadata: ChunkMetadata;
}

export interface VectorFilter {
  equipmentCode?: string;
  equipmentType?: string;
  documentType?: string;
  documentId?: string;
  source?: 'preloaded' | 'upload';
}

export interface VectorHit {
  id: string;
  text: string;
  metadata: ChunkMetadata;
  /** Cosine similarity in [0, 1] (1 = identical direction). */
  score: number;
}

export interface VectorStore {
  readonly id: string;
  upsert(records: ChunkRecord[]): Promise<void>;
  deleteByDocument(documentId: string): Promise<void>;
  query(embedding: number[], topK: number, filter?: VectorFilter): Promise<VectorHit[]>;
  countByDocument(documentId: string): Promise<number>;
  /** Throws if the store is unreachable. */
  health(): Promise<void>;
}
