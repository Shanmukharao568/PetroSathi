/** Provider-neutral embedding contract. All vectors are L2-normalised (cosine == dot product). */
export interface EmbeddingProvider {
  /** e.g. "local:Xenova/multilingual-e5-small" or "mock:hash-256" */
  readonly id: string;
  readonly model: string;
  readonly dimensions: number;
  embedDocuments(texts: string[]): Promise<number[][]>;
  embedQuery(text: string): Promise<number[]>;
}

/**
 * Candidate models benchmarked in Phase 6. `prefix` reflects each model card's documented usage
 * (E5 models are trained with "query: " / "passage: " prefixes; sentence-transformers models use none).
 */
export interface LocalModelSpec {
  model: string;
  dimensions: number;
  queryPrefix: string;
  passagePrefix: string;
  /** Approximate download size of the quantized ONNX weights. */
  approxSizeMb: number;
  /** Benchmarked "no relevant documentation" threshold (cosine), see docs/EMBEDDING_BENCHMARK.md. */
  defaultMinScore?: number;
}

export const LOCAL_MODELS: Record<string, LocalModelSpec> = {
  'Xenova/multilingual-e5-small': {
    model: 'Xenova/multilingual-e5-small',
    dimensions: 384,
    queryPrefix: 'query: ',
    passagePrefix: 'passage: ',
    approxSizeMb: 118,
    // Benchmarked; narrow separation on the demo corpus — recalibrate on real manuals.
    defaultMinScore: 0.787,
  },
  'Xenova/paraphrase-multilingual-MiniLM-L12-v2': {
    model: 'Xenova/paraphrase-multilingual-MiniLM-L12-v2',
    dimensions: 384,
    queryPrefix: '',
    passagePrefix: '',
    approxSizeMb: 118,
    defaultMinScore: 0.189,
  },
};
