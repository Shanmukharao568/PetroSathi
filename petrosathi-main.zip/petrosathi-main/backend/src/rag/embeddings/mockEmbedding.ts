import { createHash } from 'node:crypto';
import type { EmbeddingProvider } from './types.js';

/**
 * MOCK embedding for automated tests: hashed bag of lower-cased word tokens, L2-normalised.
 * It is NOT semantic and NOT multilingual — it only matches shared words. Never use it to judge
 * retrieval quality (see the benchmark for that).
 */
export function createMockEmbedding(dimensions = 256): EmbeddingProvider {
  const embed = (text: string): number[] => {
    const v = new Array<number>(dimensions).fill(0);
    for (const token of text.toLowerCase().match(/[\p{L}\p{N}-]+/gu) ?? []) {
      const h = createHash('sha1').update(token).digest();
      v[h.readUInt32BE(0) % dimensions]! += 1;
    }
    const norm = Math.hypot(...v) || 1;
    return v.map((x) => x / norm);
  };
  return {
    id: `mock:hash-${dimensions}`,
    model: `mock-hash-${dimensions}`,
    dimensions,
    embedDocuments: async (texts) => texts.map(embed),
    embedQuery: async (text) => embed(text),
  };
}
