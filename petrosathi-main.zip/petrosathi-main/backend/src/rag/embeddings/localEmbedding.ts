import path from 'node:path';
import type { FeatureExtractionPipeline } from '@huggingface/transformers';
import { LOCAL_MODELS, type EmbeddingProvider, type LocalModelSpec } from './types.js';

/**
 * Runs an open multilingual sentence-embedding model locally (ONNX via transformers.js).
 * Weights are downloaded once from Hugging Face into MODEL_CACHE_DIR; no API key, and no
 * document text leaves the machine.
 */
export function createLocalEmbedding(model: string, cacheDir: string): EmbeddingProvider {
  const spec: LocalModelSpec | undefined = LOCAL_MODELS[model];
  if (!spec) throw new Error(`Unsupported local embedding model "${model}". Supported: ${Object.keys(LOCAL_MODELS).join(', ')}`);

  let extractor: Promise<FeatureExtractionPipeline> | null = null;
  // Imported lazily: the ONNX runtime costs hundreds of MB and is only needed for this provider.
  const load = () =>
    (extractor ??= import('@huggingface/transformers').then(({ env: hfEnv, pipeline }) => {
      hfEnv.cacheDir = path.resolve(cacheDir);
      hfEnv.allowLocalModels = false;
      return pipeline('feature-extraction', spec.model, { dtype: 'q8' }) as Promise<FeatureExtractionPipeline>;
    }));

  async function embed(texts: string[]): Promise<number[][]> {
    if (!texts.length) return [];
    const fe = await load();
    const out: number[][] = [];
    // Small batches keep memory flat on CPU.
    for (let i = 0; i < texts.length; i += 16) {
      const tensor = await fe(texts.slice(i, i + 16), { pooling: 'mean', normalize: true });
      out.push(...(tensor.tolist() as number[][]));
    }
    return out;
  }

  return {
    id: `local:${spec.model}`,
    model: spec.model,
    dimensions: spec.dimensions,
    embedDocuments: (texts) => embed(texts.map((t) => spec.passagePrefix + t)),
    embedQuery: async (text) => (await embed([spec.queryPrefix + text]))[0]!,
  };
}
