import type { EmbeddingProvider } from './types.js';

/**
 * Google Gemini embeddings (REST, models/<model>:batchEmbedContents). Used on hosts with too
 * little RAM for the local model. Document and query texts are sent to Google; the API key is
 * sent only in the x-goog-api-key header and never logged.
 *
 * Vectors are truncated to `dimensions` (Matryoshka) and L2-normalised here, because the API
 * only normalises full-size (3072) vectors.
 */
export const GEMINI_DEFAULT_MODEL = 'gemini-embedding-001';
const DEFAULT_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta';
/** batchEmbedContents accepts up to 100 texts per call. */
const BATCH = 100;
const MAX_ATTEMPTS = 6;

type TaskType = 'RETRIEVAL_DOCUMENT' | 'RETRIEVAL_QUERY';

export class GeminiEmbeddingError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
  ) {
    super(message);
    this.name = 'GeminiEmbeddingError';
  }
}

export interface GeminiOptions {
  apiKey: string;
  model?: string;
  dimensions: number;
  baseUrl?: string;
  timeoutMs?: number;
  /** Test seam. */
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
}

function normalise(v: number[]): number[] {
  const n = Math.hypot(...v) || 1;
  return v.map((x) => x / n);
}

/** Wait time from Retry-After or google.rpc.RetryInfo ("12s"), else exponential backoff. */
function retryDelayMs(res: Response, body: string, attempt: number): number {
  const header = Number(res.headers.get('retry-after'));
  if (Number.isFinite(header) && header > 0) return header * 1000;
  const m = /"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/.exec(body);
  if (m) return Math.ceil(Number(m[1]) * 1000);
  return Math.min(60_000, 2000 * 2 ** attempt);
}

export function createGeminiEmbedding(opts: GeminiOptions): EmbeddingProvider {
  const model = opts.model ?? GEMINI_DEFAULT_MODEL;
  const baseUrl = (opts.baseUrl ?? DEFAULT_BASE_URL).replace(/\/$/, '');
  const doFetch = opts.fetchImpl ?? fetch;
  const sleep = opts.sleep ?? ((ms: number) => new Promise((r) => setTimeout(r, ms)));
  const url = `${baseUrl}/models/${encodeURIComponent(model)}:batchEmbedContents`;

  async function call(texts: string[], taskType: TaskType): Promise<number[][]> {
    const body = JSON.stringify({
      requests: texts.map((text) => ({
        model: `models/${model}`,
        content: { parts: [{ text }] },
        taskType,
        outputDimensionality: opts.dimensions,
      })),
    });
    for (let attempt = 0; ; attempt++) {
      let res: Response;
      try {
        res = await doFetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': opts.apiKey },
          body,
          signal: AbortSignal.timeout(opts.timeoutMs ?? 30_000),
        });
      } catch (err) {
        if (attempt + 1 >= MAX_ATTEMPTS) throw new GeminiEmbeddingError(`Gemini embeddings unreachable: ${(err as Error).message}`);
        await sleep(Math.min(30_000, 1000 * 2 ** attempt));
        continue;
      }
      const text = await res.text();
      if (res.ok) {
        const json = JSON.parse(text) as { embeddings?: { values?: number[] }[] };
        const out = (json.embeddings ?? []).map((e) => e.values ?? []);
        if (out.length !== texts.length || out.some((v) => v.length !== opts.dimensions)) {
          throw new GeminiEmbeddingError(`Gemini returned ${out.length} embeddings for ${texts.length} texts (expected ${opts.dimensions} dimensions each)`);
        }
        return out.map(normalise);
      }
      // 429 (free-tier rate limit) and 5xx are temporary; everything else is a configuration error.
      const retryable = res.status === 429 || res.status >= 500;
      if (!retryable || attempt + 1 >= MAX_ATTEMPTS) {
        const msg = /"message"\s*:\s*"([^"]{0,300})/.exec(text)?.[1] ?? text.slice(0, 300);
        throw new GeminiEmbeddingError(`Gemini embeddings failed (HTTP ${res.status}): ${msg}`, res.status);
      }
      await sleep(retryDelayMs(res, text, attempt));
    }
  }

  async function embed(texts: string[], taskType: TaskType): Promise<number[][]> {
    const out: number[][] = [];
    for (let i = 0; i < texts.length; i += BATCH) out.push(...(await call(texts.slice(i, i + BATCH), taskType)));
    return out;
  }

  // The size is part of the model name so each size gets its own vector collection.
  const modelId = `${model}-${opts.dimensions}`;
  return {
    id: `gemini:${modelId}`,
    model: modelId,
    dimensions: opts.dimensions,
    embedDocuments: (texts) => (texts.length ? embed(texts, 'RETRIEVAL_DOCUMENT') : Promise.resolve([])),
    embedQuery: async (text) => (await embed([text], 'RETRIEVAL_QUERY'))[0]!,
  };
}
