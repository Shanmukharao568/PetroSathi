import { env } from '../../config/env.js';
import { createGeminiEmbedding } from './geminiEmbedding.js';
import { createLocalEmbedding } from './localEmbedding.js';
import { createMockEmbedding } from './mockEmbedding.js';
import type { EmbeddingProvider } from './types.js';

let cached: EmbeddingProvider | null = null;
let override: EmbeddingProvider | null = null;

function create(): EmbeddingProvider {
  switch (env.EMBEDDING_PROVIDER) {
    case 'mock':
      return createMockEmbedding();
    case 'gemini':
      return createGeminiEmbedding({
        apiKey: env.EMBEDDING_API_KEY!,
        model: env.EMBEDDING_MODEL,
        dimensions: env.EMBEDDING_DIMENSIONS,
        baseUrl: env.EMBEDDING_BASE_URL,
        timeoutMs: env.GNANI_REQUEST_TIMEOUT_MS,
      });
    default:
      return createLocalEmbedding(env.EMBEDDING_MODEL ?? 'Xenova/multilingual-e5-small', env.MODEL_CACHE_DIR);
  }
}

export function getEmbeddingProvider(): EmbeddingProvider {
  if (override) return override;
  cached ??= create();
  return cached;
}

/** Test seam only. */
export function setEmbeddingProviderForTests(p: EmbeddingProvider | null) {
  override = p;
}

export type { EmbeddingProvider } from './types.js';
