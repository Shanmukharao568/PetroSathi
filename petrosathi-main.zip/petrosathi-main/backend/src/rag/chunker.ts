import type { PdfPage } from './pdf.js';

export interface TextChunk {
  text: string;
  pageNumber: number;
  section: string;
  chunkIndex: number;
}

const NUMBERED_HEADING = /^(\d+(\.\d+)*|[A-Z])[.)]?\s+\S.{0,90}$/;

/** Repeated page furniture (headers/footers) is dropped: lines appearing on most pages. */
function boilerplate(pages: PdfPage[]): Set<string> {
  if (pages.length < 3) return new Set();
  const counts = new Map<string, number>();
  for (const p of pages) for (const t of new Set(p.lines.map((l) => l.text))) counts.set(t, (counts.get(t) ?? 0) + 1);
  return new Set([...counts].filter(([t, n]) => n >= Math.ceil(pages.length * 0.6) && t.length < 200).map(([t]) => t));
}

function isHeading(text: string, height: number, bodyHeight: number): boolean {
  if (text.length > 100 || /[.:;,]$/.test(text)) return false;
  if (bodyHeight > 0 && height >= bodyHeight * 1.15) return true;
  return NUMBERED_HEADING.test(text) && text.split(' ').length <= 12 && !/^\d+(\.\d+)?\s*(mm|bar|°C|rpm|kW|%)/.test(text);
}

function median(nums: number[]): number {
  if (!nums.length) return 0;
  const s = [...nums].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)]!;
}

/** Splits text at whitespace into pieces ≤ size, carrying `overlap` characters forward. */
function splitWithOverlap(text: string, size: number, overlap: number): string[] {
  if (text.length <= size) return [text];
  const out: string[] = [];
  let start = 0;
  while (start < text.length) {
    let end = Math.min(text.length, start + size);
    if (end < text.length) {
      const ws = text.lastIndexOf(' ', end);
      if (ws > start + size * 0.5) end = ws;
    }
    out.push(text.slice(start, end).trim());
    if (end >= text.length) break;
    let next = end - overlap;
    const ws = text.indexOf(' ', next);
    if (ws !== -1 && ws < end) next = ws + 1;
    start = Math.max(next, start + 1);
  }
  return out.filter(Boolean);
}

/**
 * Page-aware chunking: chunks never cross a page boundary, so each carries an exact page number.
 * The section is the most recent heading seen (it carries over from earlier pages).
 */
export function chunkPages(pages: PdfPage[], size: number, overlap: number): { chunks: TextChunk[]; sections: string[] } {
  const skip = boilerplate(pages);
  const bodyHeight = median(pages.flatMap((p) => p.lines.map((l) => l.height)).filter((h) => h > 0));
  const chunks: TextChunk[] = [];
  const sections: string[] = [];
  let section = '';

  // Headings with no body text yet are never emitted on their own (a title-only chunk matches
  // almost any query); they are carried into the next chunk, even across a page break.
  let carried = '';

  for (const page of pages) {
    let buffer = carried;
    let bufferHasBody = false;
    let bufferSection = section;
    let lastHeadingHeight = 0; // >0 while the previous line was a heading
    carried = '';
    const emit = () => {
      for (const piece of splitWithOverlap(buffer.trim(), size, overlap)) {
        if (piece.length >= 20) chunks.push({ text: piece, pageNumber: page.pageNumber, section: bufferSection, chunkIndex: chunks.length });
      }
      buffer = '';
      bufferHasBody = false;
    };

    for (const line of page.lines) {
      if (skip.has(line.text)) continue;
      if (isHeading(line.text, line.height, bodyHeight)) {
        // A heading wrapped over several lines (same size, consecutive) is one heading.
        if (lastHeadingHeight && Math.abs(line.height - lastHeadingHeight) < 0.5) {
          sections.pop();
          section = `${section} ${line.text}`;
          sections.push(section);
          bufferSection = section;
          buffer = `${buffer.trimEnd()} ${line.text}
`;
          continue;
        }
        if (bufferHasBody) emit();
        section = line.text;
        if (!sections.includes(section)) sections.push(section);
        bufferSection = section;
        lastHeadingHeight = line.height;
        // Headings stay in the chunk text (useful retrieval signal); stacked headings accumulate.
        buffer += `${line.text}
`;
        continue;
      }
      lastHeadingHeight = 0;
      if (!buffer.trim()) bufferSection = section;
      buffer += `${line.text} `;
      bufferHasBody = true;
    }
    if (bufferHasBody) emit();
    else carried = buffer;
  }
  return { chunks, sections: sections.slice(0, 100) };
}
