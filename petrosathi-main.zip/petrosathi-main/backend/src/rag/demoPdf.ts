import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib';
import { DEMO_BANNER, type DemoDocument } from './demoContent.js';

const PAGE: [number, number] = [595.28, 841.89]; // A4
const MARGIN = 56;
const BODY = 10.5;
const HEADING = 14;
const TITLE = 18;

function wrap(text: string, font: PDFFont, size: number, width: number): string[] {
  const lines: string[] = [];
  let line = '';
  for (const word of text.split(/\s+/)) {
    const candidate = line ? `${line} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) > width && line) {
      lines.push(line);
      line = word;
    } else line = candidate;
  }
  if (line) lines.push(line);
  return lines;
}

/** Renders a demo document: title page + one page per section, banner on every page. */
export async function buildDemoPdf(doc: DemoDocument): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  pdf.setTitle(doc.title);
  pdf.setSubject(DEMO_BANNER);
  pdf.setProducer('PetroSathi demo generator');
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const width = PAGE[0] - 2 * MARGIN;

  const newPage = (): { page: PDFPage; y: number } => {
    const page = pdf.addPage(PAGE);
    page.drawText(DEMO_BANNER, { x: MARGIN, y: PAGE[1] - 32, size: 7, font: bold, color: rgb(0.75, 0.1, 0.1) });
    return { page, y: PAGE[1] - MARGIN - 20 };
  };

  for (const [i, section] of doc.sections.entries()) {
    let { page, y } = newPage();
    if (i === 0) {
      for (const l of wrap(doc.title, bold, TITLE, width)) {
        page.drawText(l, { x: MARGIN, y, size: TITLE, font: bold, color: rgb(0.04, 0.07, 0.14) });
        y -= TITLE * 1.4;
      }
      y -= 12;
    }
    page.drawText(section.heading, { x: MARGIN, y, size: HEADING, font: bold, color: rgb(0.06, 0.46, 0.43) });
    y -= HEADING * 1.8;
    for (const para of section.paragraphs) {
      for (const l of wrap(para, regular, BODY, width)) {
        if (y < MARGIN + 20) ({ page, y } = newPage());
        page.drawText(l, { x: MARGIN, y, size: BODY, font: regular, color: rgb(0.1, 0.1, 0.12) });
        y -= BODY * 1.45;
      }
      y -= BODY * 0.8;
    }
  }
  return pdf.save();
}
