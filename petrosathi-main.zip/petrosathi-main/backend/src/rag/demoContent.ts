/**
 * DEMONSTRATION knowledge-base content written for PetroSathi development and the embedding
 * benchmark. General engineering descriptions only — NOT manufacturer documentation, NOT
 * site procedures, and NOT for operational use. Every generated page carries that banner.
 * Content describes what to observe and report; it never instructs operators to shut down,
 * isolate, repair or restart equipment.
 */
export interface DemoSection {
  /** Benchmark key, e.g. "pump.vibration". */
  key: string;
  heading: string;
  paragraphs: string[];
}

export interface DemoDocument {
  key: string;
  fileName: string;
  folder: 'manuals' | 'safety' | 'troubleshooting' | 'inspection';
  title: string;
  documentType: 'manual' | 'safety' | 'troubleshooting' | 'inspection';
  equipmentTypes: string[];
  sections: DemoSection[];
}

export const DEMO_BANNER = 'DEMONSTRATION DOCUMENT - SAMPLE CONTENT - NOT MANUFACTURER DOCUMENTATION - NOT FOR OPERATIONAL USE';

const notice = (subject: string): DemoSection => ({
  key: 'notice',
  heading: '1 About this demonstration document',
  paragraphs: [
    `This is sample content about ${subject}, written to demonstrate document search in PetroSathi. It is not manufacturer documentation and must not be used to operate, maintain or repair equipment.`,
    'Always follow your site procedures, permit-to-work system and the instructions of authorised maintenance engineers. Field operators should report abnormal conditions; they should not attempt repairs.',
  ],
});

export const DEMO_DOCUMENTS: DemoDocument[] = [
  {
    key: 'pump',
    fileName: 'DEMO-centrifugal-pump-guide.pdf',
    folder: 'manuals',
    title: 'DEMO - Centrifugal Pump Operation and Troubleshooting Guide',
    documentType: 'manual',
    equipmentTypes: ['pump', 'motor'],
    sections: [
      notice('centrifugal pumps'),
      {
        key: 'pump.principles',
        heading: '2 Operating principles',
        paragraphs: [
          'A centrifugal pump adds energy to a liquid with a rotating impeller. Liquid enters the impeller eye from the suction line and leaves through the volute casing towards the discharge line. The driver is usually an electric motor connected through a flexible coupling.',
          'Normal operation depends on adequate suction pressure, correct alignment between pump and motor shafts, healthy bearings, and a sealing system that prevents the pumped liquid from escaping along the shaft.',
        ],
      },
      {
        key: 'pump.vibration',
        heading: '3 High vibration: common causes and checks',
        paragraphs: [
          'High vibration is one of the most common pump complaints. Typical causes are shaft misalignment between pump and motor, impeller imbalance from wear or deposits, worn or damaged rolling-element bearings, loose foundation bolts or a soft foot under the baseplate, and operation far away from the best efficiency point.',
          'When reporting vibration, describe where it is felt (pump bearing housing, motor, piping), whether it is constant or changes with flow, any new noise such as grinding or knocking, and when it started. Readings from portable vibration meters, if taken by trained staff, help engineers compare against previous values.',
          'Vibration accompanied by rising bearing temperature or a grinding sound usually indicates bearing distress and should be reported promptly so that an engineer can assess it.',
        ],
      },
      {
        key: 'pump.bearings',
        heading: '4 Bearing inspection and lubrication',
        paragraphs: [
          'Rolling-element bearings in pumps are lubricated by grease or oil. Over-greasing can cause overheating just as under-greasing causes wear. Lubrication intervals depend on speed, bearing size and operating temperature and are set by the maintenance plan for each machine.',
          'Signs of bearing problems include rising bearing housing temperature, discoloured or contaminated oil in the sight glass, low oil level, grinding or rumbling noise, and increasing vibration. Operators should note the oil level and colour during rounds and report any change.',
        ],
      },
      {
        key: 'pump.seal',
        heading: '5 Mechanical seal leakage',
        paragraphs: [
          'Mechanical seals stop the pumped liquid from leaking along the rotating shaft. A small amount of vapour can be normal for some designs, but visible dripping or a continuous stream indicates seal wear or damage.',
          'Common contributors to seal leakage are dry running, excessive vibration, shaft misalignment, abrasive solids in the liquid, and problems with the seal flush or cooling line. When reporting a seal leak, note the leak rate (drops per minute or a stream), the liquid involved, and whether there is any smell, vapour or pooling near the pump.',
          'Leaks of hydrocarbons or toxic liquids are safety matters and must be reported immediately according to the site emergency procedure.',
        ],
      },
      {
        key: 'pump.cavitation',
        heading: '6 Cavitation and low suction pressure',
        paragraphs: [
          'Cavitation happens when the pressure at the impeller eye falls below the vapour pressure of the liquid. Vapour bubbles form and then collapse violently, which sounds like gravel or marbles passing through the pump and can erode the impeller.',
          'Typical causes include low level in the suction vessel, a partly closed or blocked suction strainer, high liquid temperature, and running at flows well above design. Report gravel-like noise together with suction pressure readings, suction vessel level and any recent changes in operating conditions.',
        ],
      },
      {
        key: 'pump.overheating',
        heading: '7 Overheating of pump casing or motor',
        paragraphs: [
          'Abnormally hot pump casings can result from running against a closed or restricted discharge, very low flow recirculation, or rubbing between rotating and stationary parts. Motor overheating can come from overload, blocked cooling air, voltage problems or bearing failure.',
          'Do not touch hot surfaces. Report the location of the heat, any burning smell or discolouration, and the current flow and discharge pressure readings if available.',
        ],
      },
    ],
  },
  {
    key: 'compressor',
    fileName: 'DEMO-gas-compressor-troubleshooting.pdf',
    folder: 'troubleshooting',
    title: 'DEMO - Gas Compressor Troubleshooting Notes',
    documentType: 'troubleshooting',
    equipmentTypes: ['compressor'],
    sections: [
      notice('gas compressors'),
      {
        key: 'compressor.discharge_temp',
        heading: '2 High discharge temperature',
        paragraphs: [
          'Discharge temperature rises when the compression ratio increases, when suction gas is hotter than normal, or when intercoolers and aftercoolers are fouled. Valve problems in reciprocating compressors, such as a leaking discharge valve, also raise the discharge temperature of the affected stage.',
          'When reporting high discharge temperature, include the suction and discharge pressures and temperatures of each stage, cooler inlet and outlet temperatures, and whether any alarms are active on the control panel.',
        ],
      },
      {
        key: 'compressor.surge',
        heading: '3 Surge in centrifugal compressors',
        paragraphs: [
          'Surge is an unstable flow condition in centrifugal compressors that occurs when flow drops below the surge limit for the operating speed. Flow briefly reverses through the machine, causing loud banging or roaring noises, pressure swings and strong vibration.',
          'Anti-surge control systems are designed to prevent surge by recycling gas. Operators who hear repeated bangs or see oscillating suction and discharge pressures should report the event immediately with the time, alarms shown and the process conditions.',
        ],
      },
      {
        key: 'compressor.lube_oil',
        heading: '4 Low lube oil pressure',
        paragraphs: [
          'The lubrication system supplies oil to compressor and driver bearings. Low lube oil pressure alarms can be caused by a low oil level in the reservoir, a clogged oil filter with high differential pressure, a failing oil pump, or high oil temperature that lowers viscosity.',
          'Report the oil level, filter differential pressure, oil temperature and the alarm message. Low lube oil pressure can quickly damage bearings, so these alarms need prompt attention from engineers.',
        ],
      },
    ],
  },
  {
    key: 'safety',
    fileName: 'DEMO-hydrocarbon-leak-reporting.pdf',
    folder: 'safety',
    title: 'DEMO - Hydrocarbon Leak and Gas Smell Reporting Guide',
    documentType: 'safety',
    equipmentTypes: ['separator', 'pipeline', 'vessel', 'pump', 'compressor', 'valve'],
    sections: [
      notice('reporting hydrocarbon leaks'),
      {
        key: 'safety.recognise',
        heading: '2 Recognising a possible gas or hydrocarbon leak',
        paragraphs: [
          'Possible signs of a leak include a smell of gas or hydrocarbons, a hissing sound, visible vapour clouds, liquid pooling or staining, frost on a pipe or fitting, and alarms from fixed or portable gas detectors.',
          'Some gases such as hydrogen sulphide can deaden the sense of smell, so the absence of smell does not mean the area is safe. Always rely on gas detector readings and site rules.',
        ],
      },
      {
        key: 'safety.report',
        heading: '3 How to report a leak or gas smell',
        paragraphs: [
          'Move away from the suspected leak, upwind if possible, and raise the alarm according to the site emergency procedure. Report the location, the nearby equipment tag such as a separator or pump number, what you observed, gas detector readings if available, and whether anyone is injured.',
          'Do not attempt to stop the leak, operate valves or restart equipment unless you are authorised to do so under the site procedure. After the emergency response, a maintenance complaint can be recorded in PetroSathi for follow-up investigation.',
        ],
      },
    ],
  },
  {
    key: 'hx',
    fileName: 'DEMO-heat-exchanger-inspection.pdf',
    folder: 'inspection',
    title: 'DEMO - Shell and Tube Heat Exchanger Inspection Checklist',
    documentType: 'inspection',
    equipmentTypes: ['heat_exchanger'],
    sections: [
      notice('shell and tube heat exchangers'),
      {
        key: 'hx.fouling',
        heading: '2 Fouling and falling heat transfer',
        paragraphs: [
          'Fouling is the build-up of deposits such as scale, coke, corrosion products or biological growth on tube surfaces. It reduces heat transfer, so outlet temperatures drift away from design and the exchanger no longer reaches its target duty.',
          'Indicators of fouling are a gradual drop in hot-side cooling or cold-side heating, increasing pressure drop across the shell or tube side, and the need for more utility flow to achieve the same outlet temperature. Record inlet and outlet temperatures and pressures on both sides when reporting.',
        ],
      },
      {
        key: 'hx.tube_leak',
        heading: '3 Tube leaks',
        paragraphs: [
          'A tube leak lets one fluid pass into the other. Signs include contamination of the lower-pressure stream, unexpected changes in product quality or colour, pressure changes on the low-pressure side, and gas appearing in cooling water.',
          'Tube leaks are confirmed by engineers through tests such as hydrostatic or helium leak testing during planned outages. Operators should report any contamination or unusual sampling results along with the exchanger tag number.',
        ],
      },
      {
        key: 'hx.pressure_drop',
        heading: '4 High pressure drop',
        paragraphs: [
          'Pressure drop that is higher than normal suggests partial blockage of tubes, baffles or nozzles by deposits or debris, or a flow rate far above design. A sudden increase can mean debris has entered the exchanger; a slow increase usually means fouling.',
          'Report differential pressure readings, flow rates and the date the increase was first noticed.',
        ],
      },
    ],
  },
];
