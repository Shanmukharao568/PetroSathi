import { getDocumentProxy } from 'unpdf';

export interface PdfLine {
  text: string;
  /** Font height in PDF units (used to spot headings). */
  height: number;
}

export interface PdfPage {
  pageNumber: number;
  lines: PdfLine[];
}

export class PdfValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PdfValidationError';
  }
}

export function looksLikePdf(buf: Buffer): boolean {
  return buf.subarray(0, 5).toString('latin1') === '%PDF-';
}

interface TextItemLike {
  str?: string;
  hasEOL?: boolean;
  height?: number;
  transform?: number[];
}

/**
 * Extracts text page by page, preserving line breaks and per-line font height, so chunks keep
 * exact page numbers and headings can be detected. Text-only: scanned (image) PDFs yield no text.
 */
export async function extractPdfPages(buf: Buffer, maxPages = Infinity): Promise<{ pageCount: number; pages: PdfPage[] }> {
  if (!looksLikePdf(buf)) throw new PdfValidationError('File is not a PDF');
  let pdf;
  try {
    // Hardening for untrusted files. Bundled pdf.js 6.4 has no eval-based font path any more
    // (the CVE-2024-4367 vector), and we only extract text: no font loading, no XFA forms.
    pdf = await getDocumentProxy(new Uint8Array(buf), { useSystemFonts: false, disableFontFace: true, enableXfa: false });
  } catch (err) {
    const name = (err as { name?: string }).name;
    if (name === 'PasswordException') throw new PdfValidationError('Encrypted or password-protected PDFs are not supported');
    throw new PdfValidationError('The PDF could not be read (it may be corrupted)');
  }

  if (pdf.numPages > maxPages) {
    await (pdf as unknown as { destroy?: () => Promise<void> }).destroy?.();
    throw new PdfValidationError(`The PDF has ${pdf.numPages} pages; the limit is ${maxPages}. Split it into smaller documents.`);
  }
  const pages: PdfPage[] = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const lines: PdfLine[] = [];
    let text = '';
    let height = 0;
    const flush = () => {
      const t = text.replace(/\s+/g, ' ').trim();
      if (t) lines.push({ text: t, height });
      text = '';
      height = 0;
    };
    for (const raw of content.items as TextItemLike[]) {
      if (typeof raw.str !== 'string') continue;
      text += raw.str;
      height = Math.max(height, raw.height ?? Math.abs(raw.transform?.[3] ?? 0));
      if (raw.hasEOL) flush();
    }
    flush();
    pages.push({ pageNumber: p, lines });
  }
  await (pdf as unknown as { destroy?: () => Promise<void> }).destroy?.();
  return { pageCount: pages.length, pages };
}
