import { PCM_BYTES_PER_SAMPLE, PCM_SAMPLE_RATE, type PrismaProvider, type SttStream, type TranscriptionResult } from './prisma.types.js';

/**
 * MOCK speech-to-text. Performs NO speech recognition and calls no external service.
 * Every transcript is prefixed with MOCK_PREFIX and the provider id is "mock", so mock output
 * can never be mistaken for a Gnani result — including after it is stored on a ticket.
 */
export const MOCK_PREFIX = '[MOCK TRANSCRIPT]';

/** Fixed demonstration sentences (not derived from the audio). */
const FIXTURES: Record<string, string> = {
  'en-IN': 'Pump P-101 has high vibration and a grinding noise is coming from the bearing.',
  'hi-IN': 'पंप P-101 में बहुत ज़्यादा वाइब्रेशन है और बेयरिंग से आवाज़ आ रही है।',
  'te-IN': 'పంప్ P-101 లో ఎక్కువ వైబ్రేషన్ ఉంది, బేరింగ్ నుండి శబ్దం వస్తోంది.',
  'ta-IN': 'பம்ப் P-101 இல் அதிக அதிர்வு உள்ளது, பேரிங்கில் இருந்து சத்தம் வருகிறது.',
};

function fixtureFor(languageCode: string): { text: string; language: string } {
  if (languageCode === 'indic-auto') return { text: FIXTURES['en-IN']!, language: 'en-IN' };
  const text = FIXTURES[languageCode];
  return text ? { text, language: languageCode } : { text: FIXTURES['en-IN']!, language: languageCode };
}

const MIN_STREAM_BYTES = 0.25 * PCM_SAMPLE_RATE * PCM_BYTES_PER_SAMPLE; // 250 ms of audio
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function createMockPrismaService(): PrismaProvider {
  return {
    id: 'mock',

    async transcribeFile({ languageCode }): Promise<TranscriptionResult> {
      await delay(150);
      const f = fixtureFor(languageCode);
      return {
        provider: 'mock',
        transcript: `${MOCK_PREFIX} ${f.text}`,
        detectedLanguage: f.language,
        model: 'mock',
        requestId: null,
        truncated: false,
      };
    },

    async openStream(languageCode, cb): Promise<SttStream> {
      await delay(30);
      let bytes = 0;
      let done = false;
      return {
        sendAudio(chunk) {
          if (!done) bytes += chunk.length;
        },
        async finish() {
          if (done) return;
          done = true;
          await delay(120);
          if (bytes < MIN_STREAM_BYTES) return; // too little audio → no segment, like a real VAD
          const f = fixtureFor(languageCode);
          cb.onSegment({
            text: `${MOCK_PREFIX} ${f.text}`,
            segmentIndex: 1,
            detectedLanguage: f.language,
            audioDurationMs: Math.round((bytes / (PCM_SAMPLE_RATE * PCM_BYTES_PER_SAMPLE)) * 1000),
          });
        },
        abort() {
          done = true;
        },
      };
    },
  };
}
