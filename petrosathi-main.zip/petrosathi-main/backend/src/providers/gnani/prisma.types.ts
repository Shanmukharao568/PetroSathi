/**
 * Provider-neutral speech-to-text contract used by business logic.
 * Implementations: gnaniPrismaService.ts (real) and mockPrismaService.ts (clearly labelled mock).
 */

export type SttProviderId = 'gnani-prisma' | 'mock';

export interface TranscriptionResult {
  provider: SttProviderId;
  transcript: string;
  /** Language detected by the provider, when it reports one (Prisma v3.0). */
  detectedLanguage: string | null;
  model: string | null;
  requestId: string | null;
  /** Provider reported that the transcript was truncated. */
  truncated: boolean;
}

export interface TranscribeFileInput {
  filePath: string;
  /** Original file name — Prisma detects the format from the extension. */
  fileName: string;
  /** Provider language_code, e.g. "hi-IN" or "indic-auto". */
  languageCode: string;
}

export interface StreamSegment {
  text: string;
  segmentIndex: number;
  detectedLanguage: string | null;
  audioDurationMs: number | null;
}

export interface StreamCallbacks {
  onSegment: (s: StreamSegment) => void;
  /** Non-fatal provider notice (provider keeps the session open). */
  onWarning?: (message: string) => void;
  /** Fatal: the provider session is gone. */
  onFatal: (err: ProviderError) => void;
}

export interface SttStream {
  /** PCM16LE mono 16 kHz audio of any length; the adapter handles provider framing. */
  sendAudio(chunk: Buffer): void;
  /** Flush remaining audio, ask the provider to finalise, and resolve when no more segments are expected. */
  finish(): Promise<void>;
  /** Tear down immediately (client disconnected, error, …). Safe to call more than once. */
  abort(): void;
}

export interface PrismaProvider {
  readonly id: SttProviderId;
  transcribeFile(input: TranscribeFileInput): Promise<TranscriptionResult>;
  /** Resolves once the provider session is ready to receive audio. */
  openStream(languageCode: string, callbacks: StreamCallbacks): Promise<SttStream>;
}

export type ProviderErrorKind =
  | 'timeout'
  | 'rejected' // 4xx caused by the request/audio (bad language, empty audio, too long…)
  | 'auth' // credentials invalid / not permitted — operator cannot fix this
  | 'rate_limited'
  | 'unavailable' // 5xx / network
  | 'protocol'; // unexpected response shape

export class ProviderError extends Error {
  constructor(
    public readonly kind: ProviderErrorKind,
    message: string,
    /** Provider error code/type, e.g. "MAX_AUDIO_DURATION_EXCEEDED". Never contains secrets. */
    public readonly providerCode?: string,
  ) {
    super(message);
    this.name = 'ProviderError';
  }
}

/** Documented streaming audio format (docs.gnani.ai/api/STT/stt-websocket.md). */
export const PCM_SAMPLE_RATE = 16000;
export const PCM_BYTES_PER_SAMPLE = 2;
/** Each upstream binary frame must be exactly 1,024 bytes (512 samples, 32 ms at 16 kHz). */
export const PRISMA_FRAME_BYTES = 1024;
