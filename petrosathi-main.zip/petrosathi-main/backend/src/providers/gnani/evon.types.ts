import type { ComplaintExtraction } from '../../modules/complaints/extraction.schema.js';

export type EvonProviderId = 'gnani-evon' | 'mock';

export interface ExtractionInput {
  /** Operator transcript (or typed text). Treated as untrusted data. */
  transcript: string;
  /** Language of the transcript, e.g. "hi-IN". */
  language: string;
}

export interface EvonProvider {
  readonly id: EvonProviderId;
  /** Languages this provider can extract from. Only verified/implemented ones are listed. */
  readonly supportedLanguages: readonly string[];
  extractComplaint(input: ExtractionInput): Promise<ComplaintExtraction>;
}
