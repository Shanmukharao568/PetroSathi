import { env } from '../../config/env.js';
import { createGnaniPrismaService } from './gnaniPrismaService.js';
import { createMockPrismaService } from './mockPrismaService.js';
import { createGnaniEvonService } from './gnaniEvonService.js';
import { createMockEvonService } from './mockEvonService.js';
import { createGnaniTimbreService, type TtsProvider } from './gnaniTimbreService.js';
import type { PrismaProvider } from './prisma.types.js';
import type { EvonProvider } from './evon.types.js';

let prismaOverride: PrismaProvider | null = null;
let prismaCached: PrismaProvider | null = null;
let evonOverride: EvonProvider | null = null;
let evonCached: EvonProvider | null = null;
let ttsOverride: TtsProvider | null | undefined;
let ttsCached: TtsProvider | null | undefined;

/**
 * Providers are selected strictly by configuration. There is no fallback: in "real" mode env
 * validation has already guaranteed the credentials exist, and provider failures surface as errors.
 */
export function getPrismaProvider(): PrismaProvider {
  if (prismaOverride) return prismaOverride;
  prismaCached ??=
    env.AI_PROVIDER_MODE === 'real'
      ? createGnaniPrismaService({
          apiKeyId: env.GNANI_API_KEY_ID!,
          restUrl: env.GNANI_PRISMA_STT_URL!,
          wsUrl: env.GNANI_PRISMA_WS_URL!,
          model: env.GNANI_PRISMA_MODEL,
          timeoutMs: env.GNANI_REQUEST_TIMEOUT_MS,
          maxRetries: env.GNANI_MAX_RETRIES,
        })
      : createMockPrismaService();
  return prismaCached;
}

export function evonMode(): 'mock' | 'real' {
  return env.EVON_PROVIDER_MODE ?? env.AI_PROVIDER_MODE;
}

export function getEvonProvider(): EvonProvider {
  if (evonOverride) return evonOverride;
  evonCached ??=
    evonMode() === 'real'
      ? createGnaniEvonService({ apiUrl: env.GNANI_EVON_API_URL, model: env.GNANI_EVON_MODEL, apiKeyId: env.GNANI_API_KEY_ID, timeoutMs: env.GNANI_REQUEST_TIMEOUT_MS })
      : createMockEvonService();
  return evonCached;
}

/**
 * Timbre TTS is optional and real-only: there is no mock speech, so the UI never plays fake audio.
 * Returns null when TTS is not configured (mock mode, or no Timbre settings).
 */
export function getTtsProvider(): TtsProvider | null {
  if (ttsOverride !== undefined) return ttsOverride;
  if (ttsCached !== undefined) return ttsCached;
  ttsCached =
    env.AI_PROVIDER_MODE === 'real' && env.GNANI_TIMBRE_API_URL && env.GNANI_TIMBRE_MODEL && env.GNANI_TIMBRE_VOICE
      ? createGnaniTimbreService({
          apiKeyId: env.GNANI_API_KEY_ID!,
          url: env.GNANI_TIMBRE_API_URL,
          model: env.GNANI_TIMBRE_MODEL,
          voice: env.GNANI_TIMBRE_VOICE,
          timeoutMs: env.GNANI_REQUEST_TIMEOUT_MS,
        })
      : null;
  return ttsCached;
}

/** Test seams only. */
export function setPrismaProviderForTests(p: PrismaProvider | null) {
  prismaOverride = p;
}
export function setEvonProviderForTests(p: EvonProvider | null) {
  evonOverride = p;
}
export function setTtsProviderForTests(p: TtsProvider | null | undefined) {
  ttsOverride = p;
}
