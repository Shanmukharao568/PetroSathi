import { z } from 'zod';
import { timbreLanguagesFor } from '../../config/timbreVoices.js';
import { ProviderError } from './prisma.types.js';

/**
 * Gnani Timbre TTS adapter — docs.gnani.ai/api/TTS/tts-inference.md (read 2026-11-08):
 *   POST {url}  header X-API-Key-ID, JSON { text, model, voice, language, speed?, audio_config }
 *   200 → raw audio bytes in the requested container (no JSON wrapper)
 *   400/500 → { success:false, message, status_code }; 401/402/403/429 → { detail:{ error_code, message } }
 *   Concurrency: "Only 1 active request is allowed at a time" → requests are serialised here.
 */

export interface TtsResult {
  audio: Buffer;
  contentType: string;
}

export interface TtsProvider {
  readonly id: 'gnani-timbre';
  readonly model: string;
  readonly voice: string;
  /** Languages the configured voice is documented to speak. */
  readonly languages: string[];
  synthesize(text: string, language: string): Promise<TtsResult>;
}

export interface GnaniTimbreConfig {
  apiKeyId: string;
  url: string;
  model: string;
  voice: string;
  timeoutMs: number;
}

/** Documented speed range is 0.85–1.15; default 1.0. */
const AUDIO_CONFIG = { sample_rate: 24000, num_channels: 1, sample_width: 2, container: 'mp3', bitrate: '64k' } as const;
export const MAX_TTS_CHARS = 500;
const CACHE_SIZE = 100;

const flatError = z.object({ message: z.string() });
const detailError = z.object({ detail: z.object({ error_code: z.string().optional(), message: z.string().optional() }) });

export function createGnaniTimbreService(cfg: GnaniTimbreConfig): TtsProvider {
  const languages = timbreLanguagesFor(cfg.model, cfg.voice);
  const cache = new Map<string, TtsResult>();
  let queue: Promise<unknown> = Promise.resolve();

  async function callOnce(text: string, language: string): Promise<Response> {
    try {
      return await fetch(cfg.url, {
        method: 'POST',
        headers: { 'X-API-Key-ID': cfg.apiKeyId, 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, model: cfg.model, voice: cfg.voice, language, speed: 1.0, audio_config: AUDIO_CONFIG }),
        signal: AbortSignal.timeout(cfg.timeoutMs),
      });
    } catch (err) {
      const name = (err as { name?: string }).name;
      if (name === 'TimeoutError' || name === 'AbortError') throw new ProviderError('timeout', 'Text-to-speech timed out');
      throw new ProviderError('unavailable', 'Could not reach the text-to-speech service');
    }
  }

  async function synthesizeNow(text: string, language: string): Promise<TtsResult> {
    let res = await callOnce(text, language);
    if (res.status === 429) {
      await new Promise((r) => setTimeout(r, 500));
      res = await callOnce(text, language);
    }
    if (!res.ok) {
      const body: unknown = await res.json().catch(() => null);
      const code = detailError.safeParse(body).data?.detail.error_code;
      const message = flatError.safeParse(body).data?.message;
      if (res.status === 400) throw new ProviderError('rejected', message ?? 'Text-to-speech rejected the request');
      if (res.status === 401 || res.status === 402 || res.status === 403) throw new ProviderError('auth', 'Text-to-speech credentials were rejected', code);
      if (res.status === 429) throw new ProviderError('rate_limited', 'Text-to-speech is busy', code);
      throw new ProviderError('unavailable', `Text-to-speech error (HTTP ${res.status})`);
    }
    const contentType = res.headers.get('content-type') ?? '';
    const audio = Buffer.from(await res.arrayBuffer());
    // Never report success unless real audio came back.
    if (!contentType.startsWith('audio/') || audio.length === 0) {
      throw new ProviderError('protocol', 'Text-to-speech returned no audio');
    }
    return { audio, contentType: contentType.split(';')[0]! };
  }

  return {
    id: 'gnani-timbre',
    model: cfg.model,
    voice: cfg.voice,
    languages,
    async synthesize(text, language) {
      const clean = text.trim().slice(0, MAX_TTS_CHARS);
      if (!clean) throw new ProviderError('rejected', 'Nothing to speak');
      if (!languages.includes(language)) throw new ProviderError('rejected', `Voice ${cfg.voice} does not support ${language}`);

      const key = `${language}|${clean}`;
      const hit = cache.get(key);
      if (hit) return hit;

      // Serialise: the provider allows one active request per account.
      const run = queue.then(() => synthesizeNow(clean, language));
      queue = run.catch(() => undefined);
      const result = await run;

      cache.set(key, result);
      if (cache.size > CACHE_SIZE) cache.delete(cache.keys().next().value!);
      return result;
    },
  };
}
