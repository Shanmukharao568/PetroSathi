import type { ComplaintCategory, Severity } from '../../config/constants.js';
import type { ComplaintExtraction } from '../../modules/complaints/extraction.schema.js';
import type { EvonProvider } from './evon.types.js';
import { MOCK_PREFIX } from './mockPrismaService.js';
import { parseEquipmentCode } from '../../modules/equipment/equipmentCode.js';

/**
 * MOCK complaint extractor — deterministic keyword rules, NOT a language model and NOT Gnani Evon.
 * It only reports what the text literally contains: equipment tags, listed symptom words, and a
 * severity ONLY for explicit safety words. Everything else stays null/"unknown".
 */

interface Symptom {
  label: string;
  category: ComplaintCategory;
  /** Lower-case needles across English, Hindi, Telugu and Tamil. */
  words: string[];
  safety?: boolean;
}

const LEXICON: Symptom[] = [
  { label: 'fire', category: 'safety', safety: true, words: ['fire', 'flame', 'आग', 'మంటలు', 'మంట', 'தீப்பிடி', 'தீ '] },
  { label: 'smoke', category: 'safety', safety: true, words: ['smoke', 'धुआं', 'धुआँ', 'పొగ', 'புகை'] },
  { label: 'gas leak', category: 'safety', safety: true, words: ['gas leak', 'gas smell', 'गैस', 'గ్యాస్', 'வாயு கசிவு', 'எரிவாயு'] },
  { label: 'electrical trip', category: 'electrical', words: [' trip', 'tripped', 'tripping', 'breaker', 'ट्रिप', 'ట్రిప్', 'ட்ரிப்'] },
  { label: 'sparking', category: 'electrical', words: ['spark', 'स्पार्क', 'चिंगारी', 'స్పార్క్', 'தீப்பொறி'] },
  { label: 'faulty reading', category: 'instrumentation', words: ['reading', 'transmitter', 'gauge', 'indicator', 'रीडिंग', 'गेज', 'రీడింగ్', 'அளவீடு'] },
  { label: 'leak', category: 'process', words: ['leak', 'dripping', 'रिसाव', 'लीक', 'टपक', 'లీక్', 'కారుతో', 'கசிவு'] },
  { label: 'abnormal pressure', category: 'process', words: ['pressure', 'प्रेशर', 'दबाव', 'ప్రెషర్', 'ఒత్తిడి', 'அழுத்தம்'] },
  { label: 'vibration', category: 'mechanical', words: ['vibrat', 'shaking', 'वाइब्रेशन', 'कंपन', 'వైబ్రేషన్', 'కంపన', 'அதிர்வு'] },
  { label: 'abnormal noise', category: 'mechanical', words: ['noise', 'grinding', 'knocking', 'sound', 'आवाज़', 'आवाज', 'शोर', 'శబ్దం', 'சத்தம்'] },
  { label: 'overheating', category: 'mechanical', words: ['overheat', 'too hot', 'high temperature', 'गर्म', 'गरम', 'వేడి', 'சூடு', 'வெப்பம்'] },
];

const CATEGORY_PRIORITY: ComplaintCategory[] = ['safety', 'electrical', 'instrumentation', 'process', 'mechanical'];
const MINOR_WORDS = ['minor', 'slight', 'small', 'थोड़ा', 'हल्का', 'కొంచెం', 'சிறிய'];

export const MOCK_EVON_LANGUAGES = ['en-IN', 'hi-IN', 'te-IN', 'ta-IN'] as const;

export function mockExtract(transcript: string, language: string): ComplaintExtraction {
  const text = transcript.replace(MOCK_PREFIX, '').trim();
  const lower = ` ${text.toLowerCase()} `;

  // Only hyphenated tags: the complaint service confirms "FV 601"-style tags against the register.
  const equipmentCode = parseEquipmentCode(text);

  const found = LEXICON.filter((s) => s.words.some((w) => lower.includes(w.toLowerCase())));
  const symptoms = found.map((s) => s.label);
  const category = CATEGORY_PRIORITY.find((c) => found.some((s) => s.category === c)) ?? 'other';
  const safety = found.some((s) => s.safety);

  let severity: Severity = 'unknown';
  if (safety) severity = 'critical';
  else if (symptoms.length && MINOR_WORDS.some((w) => lower.includes(w))) severity = 'low';

  const missingInformation: string[] = [];
  if (!equipmentCode) missingInformation.push('equipmentCode');
  if (!symptoms.length) missingInformation.push('symptoms');
  if (text.length < 10) missingInformation.push('description');

  return {
    equipmentCode,
    equipmentId: null,
    symptoms,
    description: text,
    category,
    severity,
    inspectionRequired: safety || symptoms.length > 0,
    missingInformation,
    confidence: Math.min(0.9, 0.3 + (equipmentCode ? 0.3 : 0) + (symptoms.length ? 0.3 : 0)),
    language,
  };
}

export function createMockEvonService(): EvonProvider {
  return {
    id: 'mock',
    supportedLanguages: MOCK_EVON_LANGUAGES,
    async extractComplaint({ transcript, language }) {
      await new Promise((r) => setTimeout(r, 80));
      return mockExtract(transcript, language);
    },
  };
}
