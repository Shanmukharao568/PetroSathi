import { openAsBlob } from 'node:fs';
import WebSocket from 'ws';
import { z } from 'zod';
import { logger } from '../../utils/logger.js';
import {
  PCM_SAMPLE_RATE,
  PRISMA_FRAME_BYTES,
  ProviderError,
  type PrismaProvider,
  type StreamCallbacks,
  type SttStream,
  type TranscribeFileInput,
  type TranscriptionResult,
} from './prisma.types.js';

/**
 * Gnani Prisma STT adapter — implemented strictly from docs.gnani.ai (read 2026-11-08):
 *   REST:      POST {restUrl}  multipart: audio_file, language_code, [model]
 *              header X-API-Key-ID
 *              200 → { success, request_id, transcript, model, detected_language_code?, truncated? }
 *              400 → { success:false, error:{ type, message } }
 *              401/402/403/429 → { detail:{ error_code, message, status_code } }
 *   Streaming: wss {wsUrl}; ALL config as upgrade headers (x-api-key-id, language_code, model,
 *              x-sample-rate); binary frames of exactly 1,024 bytes PCM16LE mono;
 *              client {"type":"commit"} closes the open utterance;
 *              server JSON: connected | speech_start | processing | transcript | error | settings_updated
 */

export interface GnaniPrismaConfig {
  apiKeyId: string;
  restUrl: string;
  wsUrl: string;
  /** e.g. "prisma-v3.0". Undefined → field/header omitted → provider default (v2.5). */
  model?: string;
  timeoutMs: number;
  maxRetries: number;
  /** Streaming: how long to wait for trailing segments after commit. */
  finishQuietMs?: number;
  finishMaxMs?: number;
}

const restSuccessSchema = z.object({
  success: z.literal(true),
  transcript: z.string(),
  request_id: z.string().optional(),
  model: z.string().optional(),
  detected_language_code: z.string().optional(),
  truncated: z.boolean().optional(),
});

const restErrorSchema = z.object({
  error: z.object({ type: z.string(), message: z.string().optional() }),
});
const authErrorSchema = z.object({ detail: z.object({ error_code: z.string(), message: z.string().optional() }) });

const RETRYABLE = new Set([429, 500, 502, 503, 504]);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function readJson(res: Response): Promise<unknown> {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function classifyHttpError(status: number, body: unknown): ProviderError {
  const typed = restErrorSchema.safeParse(body);
  const auth = authErrorSchema.safeParse(body);
  const code = typed.success ? typed.data.error.type : auth.success ? auth.data.detail.error_code : undefined;

  if (status === 400 || status === 422) {
    return new ProviderError('rejected', typed.success ? typed.data.error.message ?? typed.data.error.type : 'Speech service rejected the request', code ?? 'INVALID_REQUEST');
  }
  if (status === 401 || status === 402 || status === 403) {
    return new ProviderError('auth', 'Speech service credentials were rejected', code);
  }
  if (status === 429) return new ProviderError('rate_limited', 'Speech service rate limit reached', code ?? 'RATE_LIMITED');
  if (status === 504) return new ProviderError('timeout', 'Speech service timed out', code ?? 'UPSTREAM_TIMEOUT');
  return new ProviderError('unavailable', `Speech service error (HTTP ${status})`, code);
}

export function createGnaniPrismaService(cfg: GnaniPrismaConfig): PrismaProvider {
  return {
    id: 'gnani-prisma',

    async transcribeFile({ filePath, fileName, languageCode }: TranscribeFileInput): Promise<TranscriptionResult> {
      const blob = await openAsBlob(filePath);
      let lastError: ProviderError | null = null;

      for (let attempt = 0; attempt <= cfg.maxRetries; attempt++) {
        if (attempt > 0) await sleep(500 * 2 ** (attempt - 1));

        const form = new FormData();
        form.append('audio_file', blob, fileName);
        form.append('language_code', languageCode);
        if (cfg.model) form.append('model', cfg.model);

        let res: Response;
        try {
          res = await fetch(cfg.restUrl, {
            method: 'POST',
            headers: { 'X-API-Key-ID': cfg.apiKeyId },
            body: form,
            signal: AbortSignal.timeout(cfg.timeoutMs),
          });
        } catch (err) {
          const name = (err as { name?: string }).name;
          if (name === 'TimeoutError' || name === 'AbortError') {
            // Do not retry our own timeout: total latency would multiply.
            throw new ProviderError('timeout', `Speech service did not respond within ${cfg.timeoutMs} ms`);
          }
          lastError = new ProviderError('unavailable', 'Could not reach the speech service');
          continue;
        }

        const body = await readJson(res);
        if (res.ok) {
          const parsed = restSuccessSchema.safeParse(body);
          if (!parsed.success) throw new ProviderError('protocol', 'Unexpected response from the speech service');
          return {
            provider: 'gnani-prisma',
            transcript: parsed.data.transcript.trim(),
            detectedLanguage: parsed.data.detected_language_code ?? null,
            model: parsed.data.model ?? null,
            requestId: parsed.data.request_id ?? null,
            truncated: parsed.data.truncated === true,
          };
        }

        lastError = classifyHttpError(res.status, body);
        if (!RETRYABLE.has(res.status)) throw lastError;
        logger.warn({ status: res.status, attempt }, 'Prisma REST retryable error');
      }
      throw lastError ?? new ProviderError('unavailable', 'Speech service unavailable');
    },

    openStream(languageCode: string, cb: StreamCallbacks): Promise<SttStream> {
      const quietMs = cfg.finishQuietMs ?? 1200;
      const maxFinishMs = cfg.finishMaxMs ?? 8000;

      const headers: Record<string, string> = {
        'x-api-key-id': cfg.apiKeyId,
        language_code: languageCode,
        'x-sample-rate': String(PCM_SAMPLE_RATE),
      };
      if (cfg.model) headers.model = cfg.model;

      const ws = new WebSocket(cfg.wsUrl, { headers, handshakeTimeout: cfg.timeoutMs });

      let ready = false;
      let finishing = false;
      let closed = false;
      let pending: Buffer = Buffer.alloc(0);
      let inFlight = 0; // "processing" seen without the matching "transcript"
      let lastActivity = Date.now();
      let settle: (() => void) | null = null;

      const sendFrames = () => {
        while (pending.length >= PRISMA_FRAME_BYTES && ws.readyState === WebSocket.OPEN) {
          ws.send(pending.subarray(0, PRISMA_FRAME_BYTES), { binary: true });
          pending = pending.subarray(PRISMA_FRAME_BYTES);
        }
      };

      const closeUpstream = () => {
        if (closed) return;
        closed = true;
        try {
          ws.close(1000);
        } catch {
          ws.terminate();
        }
      };

      const stream: SttStream = {
        sendAudio(chunk) {
          if (finishing || closed) return;
          pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
          sendFrames();
        },

        async finish() {
          if (finishing || closed) return;
          finishing = true;
          if (pending.length > 0 && ws.readyState === WebSocket.OPEN) {
            // Pad the final partial frame with silence: frames must be exactly 1,024 bytes.
            const last = Buffer.alloc(PRISMA_FRAME_BYTES);
            pending.copy(last);
            ws.send(last, { binary: true });
            pending = Buffer.alloc(0);
          }
          if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'commit' }));
          lastActivity = Date.now();

          await new Promise<void>((resolve) => {
            const started = Date.now();
            settle = resolve;
            const tick = setInterval(() => {
              const quiet = Date.now() - lastActivity >= quietMs;
              if (closed || (quiet && inFlight === 0) || Date.now() - started >= maxFinishMs) {
                clearInterval(tick);
                settle = null;
                resolve();
              }
            }, 100);
          });
          closeUpstream();
        },

        abort() {
          finishing = true;
          closeUpstream();
        },
      };

      return new Promise<SttStream>((resolve, reject) => {
        ws.on('unexpected-response', (_req, res) => {
          closed = true;
          const status = res.statusCode ?? 0;
          reject(
            status === 401 || status === 403
              ? new ProviderError('auth', 'Speech service credentials were rejected')
              : status === 429
                ? new ProviderError('rate_limited', 'Speech service rate limit reached')
                : new ProviderError('unavailable', `Speech service refused the connection (HTTP ${status})`),
          );
        });

        ws.on('error', (err) => {
          logger.warn({ err: err.message }, 'Prisma stream socket error');
          if (!ready) reject(new ProviderError('unavailable', 'Could not connect to the speech service'));
        });

        ws.on('message', (data, isBinary) => {
          if (isBinary) return;
          lastActivity = Date.now();
          let msg: Record<string, unknown>;
          try {
            msg = JSON.parse(data.toString()) as Record<string, unknown>;
          } catch {
            return;
          }
          switch (msg.type) {
            case 'connected':
              ready = true;
              resolve(stream);
              break;
            case 'processing':
              inFlight += 1;
              break;
            case 'transcript': {
              inFlight = Math.max(0, inFlight - 1);
              const text = typeof msg.text === 'string' ? msg.text.trim() : '';
              if (text) {
                cb.onSegment({
                  text,
                  segmentIndex: typeof msg.segment_index === 'number' ? msg.segment_index : 0,
                  detectedLanguage: typeof msg.detected_language_code === 'string' ? msg.detected_language_code : null,
                  audioDurationMs: typeof msg.audio_duration_ms === 'number' ? msg.audio_duration_ms : null,
                });
              }
              break;
            }
            case 'error': {
              const message = typeof msg.message === 'string' ? msg.message : 'Speech service error';
              if (!ready) reject(new ProviderError('rejected', message));
              else cb.onWarning?.(message);
              break;
            }
            default:
              // speech_start, settings_updated: activity only
              break;
          }
        });

        ws.on('close', (code) => {
          const wasClosed = closed;
          closed = true;
          if (!ready) {
            reject(new ProviderError(code === 1008 ? 'rejected' : 'unavailable', `Speech service closed the connection (code ${code})`));
            return;
          }
          if (settle) settle();
          if (!finishing && !wasClosed) {
            cb.onFatal(
              new ProviderError(
                code === 1001 ? 'timeout' : code === 1008 ? 'rejected' : 'unavailable',
                `Speech service ended the session (code ${code})`,
              ),
            );
          }
        });
      });
    },
  };
}
