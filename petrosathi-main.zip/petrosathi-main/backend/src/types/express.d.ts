import type { Role } from '../config/constants.js';

declare global {
  namespace Express {
    interface AuthenticatedUser {
      id: string;
      role: Role;
      email: string;
      name: string;
      mustChangePassword: boolean;
      emailVerified: boolean;
    }
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

export {};
