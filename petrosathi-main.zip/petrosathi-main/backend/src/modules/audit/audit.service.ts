import type { Types } from 'mongoose';
import { AuditLogModel } from './auditLog.model.js';
import { logger } from '../../utils/logger.js';

export const AuditActions = {
  AUTH_LOGIN_SUCCESS: 'auth.login.success',
  AUTH_LOGIN_FAILED: 'auth.login.failed',
  AUTH_LOGOUT: 'auth.logout',
  USER_CREATED: 'user.created',
  USER_REGISTERED: 'user.registered',
  USER_UPDATED: 'user.updated',
  USER_ACTIVATED: 'user.activated',
  USER_DEACTIVATED: 'user.deactivated',
  USER_ROLE_CHANGED: 'user.role_changed',
  USER_PASSWORD_CHANGED: 'user.password_changed',
  USER_PASSWORD_RESET: 'user.password_reset',
  USER_EMAIL_CODE_SENT: 'user.email_code_sent',
  USER_EMAIL_VERIFIED: 'user.email_verified',
  EQUIPMENT_CREATED: 'equipment.created',
  EQUIPMENT_UPDATED: 'equipment.updated',
  EQUIPMENT_DELETED: 'equipment.deleted',
  TICKET_CREATED: 'ticket.created',
  TICKET_ASSIGNED: 'ticket.assigned',
  TICKET_STATUS_CHANGED: 'ticket.status_changed',
  TICKET_COMMENTED: 'ticket.commented',
  COMPLAINT_DRAFT_CREATED: 'complaint.draft_created',
  COMPLAINT_DRAFT_UPDATED: 'complaint.draft_updated',
  COMPLAINT_DRAFT_DELETED: 'complaint.draft_deleted',
  COMPLAINT_CONFIRMED: 'complaint.confirmed',
  DOCUMENT_UPLOADED: 'document.uploaded',
  DOCUMENT_REPROCESSED: 'document.reprocessed',
  DOCUMENT_DELETED: 'document.deleted',
} as const;
export type AuditAction = (typeof AuditActions)[keyof typeof AuditActions];

interface AuditEntry {
  actorId: Types.ObjectId | string | null;
  action: AuditAction | string;
  entityType: string;
  entityId?: Types.ObjectId | string | null;
  metadata?: Record<string, unknown>;
  ip?: string | null;
}

/**
 * Writes an audit record. Audit failures are logged but never break the business operation
 * that triggered them.
 */
export async function recordAudit(entry: AuditEntry): Promise<void> {
  try {
    await AuditLogModel.create({
      actorId: entry.actorId ?? null,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId ?? null,
      metadata: entry.metadata ?? {},
      ip: entry.ip ?? null,
    });
  } catch (err) {
    logger.error({ err, action: entry.action }, 'Failed to write audit log');
  }
}
