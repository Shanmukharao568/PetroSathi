import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import type { QueryFilter } from 'mongoose';
import { authenticate, authorize } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { objectIdSchema, paginationQuerySchema, escapeRegex } from '../../utils/schemas.js';
import { paginationMeta, sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import { AuditLogModel, type AuditLog } from './auditLog.model.js';
import { zonedDayBounds } from '../analytics/analytics.service.js';

const listQuerySchema = paginationQuerySchema.extend({
  /** Exact action ("ticket.assigned") or a prefix ending with "." ("ticket."). */
  action: z.string().trim().max(60).regex(/^[a-z_.]+$/).optional(),
  entityType: z.string().trim().max(40).regex(/^[A-Za-z]+$/).optional(),
  actorId: objectIdSchema.optional(),
  entityId: objectIdSchema.optional(),
  from: z.iso.datetime({ offset: true }).or(z.iso.date()).optional(),
  to: z.iso.datetime({ offset: true }).or(z.iso.date()).optional(),
});
type ListQuery = z.infer<typeof listQuerySchema>;

export const auditRouter = Router();
auditRouter.use(authenticate(), authorize('admin'));

auditRouter.get(
  '/',
  validate({ query: listQuerySchema }),
  asyncHandler(async (_req: Request, res: Response) => {
    const q = res.locals.query as ListQuery;
    const filter: QueryFilter<AuditLog> = {};
    if (q.action) filter.action = q.action.endsWith('.') ? new RegExp(`^${escapeRegex(q.action)}`) : q.action;
    if (q.entityType) filter.entityType = q.entityType;
    if (q.actorId) filter.actorId = q.actorId as never;
    if (q.entityId) filter.entityId = q.entityId as never;
    if (q.from || q.to) {
      const range: Record<string, Date> = {};
      // Plain dates are local days in ANALYTICS_TIMEZONE (same as analytics); datetimes are exact.
      if (q.from) range.$gte = q.from.length === 10 ? zonedDayBounds(q.from).start : new Date(q.from);
      if (q.to) range.$lte = q.to.length === 10 ? zonedDayBounds(q.to).end : new Date(q.to);
      if (range.$gte && range.$lte && range.$gte > range.$lte) throw ApiError.badRequest('"from" must be before "to"');
      filter.createdAt = range;
    }
    const [items, total] = await Promise.all([
      AuditLogModel.find(filter)
        .sort({ createdAt: -1 })
        .skip((q.page - 1) * q.limit)
        .limit(q.limit)
        .populate({ path: 'actorId', select: 'name email role' }),
      AuditLogModel.countDocuments(filter),
    ]);
    sendSuccess(res, items.map((i) => i.toJSON()), 200, { pagination: paginationMeta(q.page, q.limit, total) });
  }),
);

/** Distinct actions and entity types, for filter dropdowns. */
auditRouter.get(
  '/facets',
  asyncHandler(async (_req: Request, res: Response) => {
    const [actions, entityTypes] = await Promise.all([AuditLogModel.distinct('action'), AuditLogModel.distinct('entityType')]);
    sendSuccess(res, { actions: actions.sort(), entityTypes: entityTypes.sort() });
  }),
);
