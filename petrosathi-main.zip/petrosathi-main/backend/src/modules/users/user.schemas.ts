import { z } from 'zod';
import { AVATAR_DATA_URL_REGEX, AVATAR_MAX_CHARS, LANGUAGE_TAG_REGEX, ROLES } from '../../config/constants.js';
import { booleanQuery, paginationQuerySchema } from '../../utils/schemas.js';
import { passwordSchema } from '../../utils/password.js';

const nameSchema = z.string().trim().min(2).max(100);
const languageSchema = z.string().regex(LANGUAGE_TAG_REGEX, 'Invalid language tag (e.g. en-IN)');

export const createUserBodySchema = z
  .object({
    name: nameSchema,
    email: z.string().trim().toLowerCase().pipe(z.email('Invalid email')),
    role: z.enum(ROLES),
    preferredLanguage: languageSchema.optional(),
  })
  .strict();
export type CreateUserBody = z.infer<typeof createUserBodySchema>;

/** Optional text: trimmed; an empty string clears the field (stored as null). */
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === '' ? null : v))
    .nullable();

export const PROFILE_FIELDS = ['phone', 'jobTitle', 'site', 'bio', 'avatar'] as const;

export const updateUserBodySchema = z
  .object({
    name: nameSchema.optional(),
    preferredLanguage: languageSchema.optional(),
    phone: optionalText(20)
      .refine((v) => v === null || /^\+?[0-9][0-9 ()-]{5,18}$/.test(v), 'Enter a valid phone number')
      .optional(),
    jobTitle: optionalText(80).optional(),
    site: optionalText(120).optional(),
    bio: optionalText(280).optional(),
    avatar: z
      .string()
      .max(AVATAR_MAX_CHARS, 'Photo is too large')
      .regex(AVATAR_DATA_URL_REGEX, 'Photo must be a PNG, JPEG or WebP image')
      .nullable()
      .optional(),
    // Admin-only fields; enforced in the service.
    role: z.enum(ROLES).optional(),
    isActive: z.boolean().optional(),
  })
  .strict()
  .refine((b) => Object.keys(b).length > 0, { message: 'At least one field is required' });
export type UpdateUserBody = z.infer<typeof updateUserBodySchema>;

/**
 * - Self change:  { currentPassword, newPassword }
 * - Admin reset of another user: {} → server generates a one-time temporary password
 */
export const passwordBodySchema = z
  .object({
    currentPassword: z.string().min(1).max(256).optional(),
    newPassword: passwordSchema.optional(),
  })
  .strict();
export type PasswordBody = z.infer<typeof passwordBodySchema>;

export const listUsersQuerySchema = paginationQuerySchema.extend({
  role: z.enum(ROLES).optional(),
  isActive: booleanQuery.optional(),
  search: z.string().trim().max(100).optional(),
});
export type ListUsersQuery = z.infer<typeof listUsersQuerySchema>;
