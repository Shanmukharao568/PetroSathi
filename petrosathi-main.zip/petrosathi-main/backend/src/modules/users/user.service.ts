import type { QueryFilter } from 'mongoose';
import { UserModel, type User } from './user.model.js';
import { ApiError } from '../../utils/ApiError.js';
import { escapeRegex } from '../../utils/schemas.js';
import { paginationMeta } from '../../utils/response.js';
import { generateTemporaryPassword, hashPassword, verifyPassword } from '../../utils/password.js';
import { signAccessToken } from '../auth/token.service.js';
import { sessionUser } from '../auth/auth.service.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import { env } from '../../config/env.js';
import { PROFILE_FIELDS, type CreateUserBody, type ListUsersQuery, type PasswordBody, type UpdateUserBody } from './user.schemas.js';

type Actor = Express.AuthenticatedUser;

/** Admin-only. Returns the one-time temporary password exactly once; it is never stored in plain text. */
export async function createUser(body: CreateUserBody, actor: Actor, ip: string | null) {
  const exists = await UserModel.exists({ email: body.email });
  if (exists) throw ApiError.conflict('A user with this email already exists');

  const temporaryPassword = generateTemporaryPassword();
  const user = await UserModel.create({
    name: body.name,
    email: body.email,
    role: body.role,
    preferredLanguage: body.preferredLanguage ?? env.DEFAULT_LANGUAGE,
    passwordHash: await hashPassword(temporaryPassword),
    mustChangePassword: true,
    createdBy: actor.id,
  });

  await recordAudit({
    actorId: actor.id,
    action: AuditActions.USER_CREATED,
    entityType: 'User',
    entityId: user._id,
    metadata: { role: user.role, email: user.email },
    ip,
  });

  return { user: user.toJSON(), temporaryPassword };
}

export async function listUsers(query: ListUsersQuery) {
  const filter: QueryFilter<User> = {};
  if (query.role) filter.role = query.role;
  if (query.isActive !== undefined) filter.isActive = query.isActive;
  if (query.search) {
    const rx = new RegExp(escapeRegex(query.search), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }

  const [items, total] = await Promise.all([
    UserModel.find(filter)
      .sort({ createdAt: -1 })
      .skip((query.page - 1) * query.limit)
      .limit(query.limit),
    UserModel.countDocuments(filter),
  ]);
  return { items: items.map((u) => u.toJSON()), meta: paginationMeta(query.page, query.limit, total) };
}

/** Admins may read anyone; other roles only themselves. */
export async function getUser(id: string, actor: Actor) {
  if (actor.role !== 'admin' && actor.id !== id) throw ApiError.forbidden();
  const user = await UserModel.findById(id);
  if (!user) throw ApiError.notFound('User');
  return user.toJSON();
}

async function assertNotLastActiveAdmin(targetId: string) {
  const others = await UserModel.countDocuments({ role: 'admin', isActive: true, _id: { $ne: targetId } });
  if (others === 0) throw ApiError.conflict('At least one active administrator must remain');
}

export async function updateUser(id: string, body: UpdateUserBody, actor: Actor, ip: string | null) {
  const isSelf = actor.id === id;
  const isAdmin = actor.role === 'admin';
  if (!isAdmin && !isSelf) throw ApiError.forbidden();
  if (!isAdmin && (body.role !== undefined || body.isActive !== undefined)) {
    throw ApiError.forbidden('Only administrators can change role or account status');
  }

  const user = await UserModel.findById(id).select('+tokenVersion');
  if (!user) throw ApiError.notFound('User');

  const changes: Record<string, { from: unknown; to: unknown }> = {};
  let revokeSessions = false;

  if (body.role !== undefined && body.role !== user.role) {
    if (isSelf) throw ApiError.conflict('You cannot change your own role');
    if (user.role === 'admin') await assertNotLastActiveAdmin(id);
    changes.role = { from: user.role, to: body.role };
    user.role = body.role;
    revokeSessions = true; // JWT carries the role; force re-login with the new one
  }
  if (body.isActive !== undefined && body.isActive !== user.isActive) {
    if (isSelf) throw ApiError.conflict('You cannot change your own account status');
    if (!body.isActive && user.role === 'admin') await assertNotLastActiveAdmin(id);
    changes.isActive = { from: user.isActive, to: body.isActive };
    user.isActive = body.isActive;
    if (!body.isActive) revokeSessions = true;
  }
  if (body.name !== undefined && body.name !== user.name) {
    changes.name = { from: user.name, to: body.name };
    user.name = body.name;
  }
  if (body.preferredLanguage !== undefined && body.preferredLanguage !== user.preferredLanguage) {
    changes.preferredLanguage = { from: user.preferredLanguage, to: body.preferredLanguage };
    user.preferredLanguage = body.preferredLanguage;
  }
  for (const field of PROFILE_FIELDS) {
    const next = body[field];
    if (next === undefined || next === (user[field] ?? null)) continue;
    // The audit log records that the photo changed, never the image itself.
    changes[field] =
      field === 'avatar' ? { from: user.avatar ? 'set' : null, to: next ? 'set' : null } : { from: user[field] ?? null, to: next };
    user[field] = next;
  }

  if (revokeSessions) user.tokenVersion += 1;
  await user.save();

  if (Object.keys(changes).length) {
    const action = changes.isActive
      ? changes.isActive.to
        ? AuditActions.USER_ACTIVATED
        : AuditActions.USER_DEACTIVATED
      : changes.role
        ? AuditActions.USER_ROLE_CHANGED
        : AuditActions.USER_UPDATED;
    await recordAudit({ actorId: actor.id, action, entityType: 'User', entityId: user._id, metadata: { changes }, ip });
  }
  return user.toJSON();
}

/**
 * Self change requires the current password and returns a fresh token (old sessions are revoked).
 * Admin reset of another user generates a new one-time temporary password.
 */
export async function changePassword(id: string, body: PasswordBody, actor: Actor, ip: string | null) {
  const isSelf = actor.id === id;

  if (isSelf) {
    if (!body.currentPassword || !body.newPassword) {
      throw ApiError.validation([{ location: 'body', path: 'currentPassword,newPassword', message: 'Both current and new password are required' }]);
    }
    const user = await UserModel.findById(id).select('+passwordHash +tokenVersion');
    if (!user) throw ApiError.notFound('User');
    if (!(await verifyPassword(body.currentPassword, user.passwordHash))) {
      throw ApiError.badRequest('Current password is incorrect');
    }
    if (await verifyPassword(body.newPassword, user.passwordHash)) {
      throw ApiError.badRequest('New password must be different from the current password');
    }
    user.passwordHash = await hashPassword(body.newPassword);
    user.mustChangePassword = false;
    user.passwordChangedAt = new Date();
    user.tokenVersion += 1;
    await user.save();
    await recordAudit({ actorId: actor.id, action: AuditActions.USER_PASSWORD_CHANGED, entityType: 'User', entityId: user._id, ip });

    const session = signAccessToken({ sub: String(user._id), role: user.role, tv: user.tokenVersion });
    return { user: sessionUser(user), ...session };
  }

  if (actor.role !== 'admin') throw ApiError.forbidden();
  if (actor.mustChangePassword) {
    throw ApiError.forbidden('You must change your temporary password first', 'PASSWORD_CHANGE_REQUIRED');
  }
  if (body.currentPassword || body.newPassword) {
    throw ApiError.badRequest('Administrators cannot set another user\'s password; send an empty body to issue a temporary password');
  }
  const user = await UserModel.findById(id).select('+tokenVersion');
  if (!user) throw ApiError.notFound('User');

  const temporaryPassword = generateTemporaryPassword();
  user.passwordHash = await hashPassword(temporaryPassword);
  user.mustChangePassword = true;
  user.passwordChangedAt = new Date();
  user.tokenVersion += 1;
  await user.save();
  await recordAudit({ actorId: actor.id, action: AuditActions.USER_PASSWORD_RESET, entityType: 'User', entityId: user._id, ip });

  return { user: user.toJSON(), temporaryPassword };
}
