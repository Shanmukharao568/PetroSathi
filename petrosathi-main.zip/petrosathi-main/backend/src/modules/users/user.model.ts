import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';
import { AVATAR_MAX_CHARS, LANGUAGE_TAG_REGEX, ROLES } from '../../config/constants.js';

const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254,
      unique: true,
    },
    // Never selected by default; must be requested explicitly with .select('+passwordHash').
    passwordHash: { type: String, required: true, select: false },
    role: { type: String, enum: ROLES, required: true, index: true },
    preferredLanguage: { type: String, default: 'en-IN', match: LANGUAGE_TAG_REGEX },
    // Self-editable profile details. All optional; null means "not set".
    phone: { type: String, default: null, trim: true, maxlength: 20 },
    jobTitle: { type: String, default: null, trim: true, maxlength: 80 },
    site: { type: String, default: null, trim: true, maxlength: 120 },
    bio: { type: String, default: null, trim: true, maxlength: 280 },
    /** Small profile photo as a data URL (the client resizes it to ~192px before upload). */
    avatar: { type: String, default: null, maxlength: AVATAR_MAX_CHARS },
    isActive: { type: Boolean, default: true, index: true },
    /** Set for admin-created / admin-reset accounts; user must choose their own password. */
    mustChangePassword: { type: Boolean, default: true },
    /** Set once the user has confirmed their email address with a one-time code. */
    emailVerified: { type: Boolean, default: false },
    emailVerifiedAt: { type: Date, default: null },
    /** Incremented on logout, password change, deactivation → invalidates all issued JWTs. */
    tokenVersion: { type: Number, default: 0, select: false },
    lastLoginAt: { type: Date, default: null },
    passwordChangedAt: { type: Date, default: null },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.passwordHash;
        delete ret.tokenVersion;
        return ret;
      },
    },
  },
);

userSchema.index({ name: 'text', email: 'text' });

export type User = InferSchemaType<typeof userSchema>;
export type UserDocument = HydratedDocument<User>;
export const UserModel = model('User', userSchema);
