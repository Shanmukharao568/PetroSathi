import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema } from '../../utils/schemas.js';
import {
  createUserBodySchema,
  listUsersQuerySchema,
  passwordBodySchema,
  updateUserBodySchema,
} from './user.schemas.js';
import * as controller from './user.controller.js';

export const userRouter = Router();

// Password change must be reachable by users who still hold a temporary password.
userRouter.patch(
  '/:id/password',
  authenticate({ allowPendingPasswordChange: true, allowUnverifiedEmail: true }),
  validate({ params: idParamsSchema, body: passwordBodySchema }),
  asyncHandler(controller.changePassword),
);

userRouter.use(authenticate());

userRouter.post('/', authorize('admin'), validate({ body: createUserBodySchema }), asyncHandler(controller.create));
userRouter.get('/', authorize('admin'), validate({ query: listUsersQuerySchema }), asyncHandler(controller.list));
// Self-or-admin checks happen in the service.
userRouter.get('/:id', validate({ params: idParamsSchema }), asyncHandler(controller.getById));
userRouter.patch('/:id', validate({ params: idParamsSchema, body: updateUserBodySchema }), asyncHandler(controller.update));
