import type { Request, Response } from 'express';
import { requireUser } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/response.js';
import * as userService from './user.service.js';
import type { CreateUserBody, ListUsersQuery, PasswordBody, UpdateUserBody } from './user.schemas.js';

type IdReq = Request<{ id: string }>;

export async function create(req: Request, res: Response) {
  const result = await userService.createUser(req.body as CreateUserBody, requireUser(req), req.ip ?? null);
  sendSuccess(res, result, 201);
}

export async function list(_req: Request, res: Response) {
  const { items, meta } = await userService.listUsers(res.locals.query as ListUsersQuery);
  sendSuccess(res, items, 200, { pagination: meta });
}

export async function getById(req: IdReq, res: Response) {
  sendSuccess(res, await userService.getUser(req.params.id, requireUser(req)));
}

export async function update(req: IdReq, res: Response) {
  const user = await userService.updateUser(req.params.id, req.body as UpdateUserBody, requireUser(req), req.ip ?? null);
  sendSuccess(res, user);
}

export async function changePassword(req: IdReq, res: Response) {
  const result = await userService.changePassword(req.params.id, req.body as PasswordBody, requireUser(req), req.ip ?? null);
  sendSuccess(res, result);
}
