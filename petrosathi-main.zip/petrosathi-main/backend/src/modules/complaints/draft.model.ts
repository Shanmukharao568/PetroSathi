import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';
import { COMPLAINT_CATEGORIES, SEVERITIES } from '../../config/constants.js';

export const DRAFT_STATES = ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION', 'CONFIRMED', 'EXPIRED'] as const;
export type DraftState = (typeof DRAFT_STATES)[number];

export const EXTRACTION_STATUSES = ['completed', 'unsupported_language', 'failed', 'not_run'] as const;
export const EQUIPMENT_CHECK = ['not_provided', 'found', 'not_found', 'decommissioned'] as const;

const answerSchema = new Schema(
  {
    field: { type: String, required: true },
    question: { type: String, required: true, maxlength: 500 },
    answer: { type: String, required: true, maxlength: 2000 },
    at: { type: Date, required: true, default: () => new Date() },
  },
  { _id: false },
);

const complaintDraftSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    conversationId: { type: Schema.Types.ObjectId, ref: 'Conversation', default: null },
    source: { type: String, enum: ['voice', 'text'], required: true },
    /** Original transcript (voice) or the operator's typed text. Never rewritten. */
    transcript: { type: String, default: '', maxlength: 10000 },
    language: { type: String, required: true },

    extraction: {
      status: { type: String, enum: EXTRACTION_STATUSES, required: true },
      provider: { type: String, enum: ['gnani-evon', 'mock', null], default: null },
      /** Validated ComplaintExtraction exactly as returned (for audit/debug). */
      result: { type: Schema.Types.Mixed, default: null },
      error: { type: String, default: null },
      at: { type: Date, default: null },
    },

    /** Current complaint as the operator will confirm it. */
    fields: {
      equipmentCode: { type: String, default: null },
      equipmentId: { type: Schema.Types.ObjectId, ref: 'Equipment', default: null },
      description: { type: String, default: '', maxlength: 4000 },
      symptoms: { type: [String], default: [] },
      category: { type: String, enum: COMPLAINT_CATEGORIES, default: 'other' },
      severity: { type: String, enum: SEVERITIES, default: 'unknown' },
      inspectionRequired: { type: Boolean, default: false },
    },
    equipmentCheck: { type: String, enum: EQUIPMENT_CHECK, default: 'not_provided' },

    missingInformation: { type: [String], default: [] },
    answers: { type: [answerSchema], default: [] },
    state: { type: String, enum: DRAFT_STATES, required: true, index: true },

    /** Server-generated; makes confirmation create exactly one ticket. Never exposed for reuse elsewhere. */
    idempotencyKey: { type: String, required: true, unique: true },
    expiresAt: { type: Date, required: true },
    /** TTL: unconfirmed drafts are purged a week after expiry; null (confirmed) is never purged. */
    purgeAt: { type: Date, default: null },
    ticketId: { type: Schema.Types.ObjectId, ref: 'MaintenanceTicket', default: null },
    confirmedAt: { type: Date, default: null },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.idempotencyKey;
        delete ret.purgeAt;
        return ret;
      },
    },
  },
);

complaintDraftSchema.index({ userId: 1, createdAt: -1 });
complaintDraftSchema.index({ purgeAt: 1 }, { expireAfterSeconds: 0 });
complaintDraftSchema.index({ state: 1, expiresAt: 1 });

export type ComplaintDraft = InferSchemaType<typeof complaintDraftSchema>;
export type ComplaintDraftDocument = HydratedDocument<ComplaintDraft>;
export const ComplaintDraftModel = model('ComplaintDraft', complaintDraftSchema, 'complaint_drafts');
