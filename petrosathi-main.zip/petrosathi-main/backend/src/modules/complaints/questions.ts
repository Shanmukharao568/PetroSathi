import type { RequiredField } from './extraction.schema.js';

/**
 * Follow-up questions and spoken confirmations. These are fixed application templates
 * (not generated at runtime), written for English, Hindi, Telugu and Tamil; other languages
 * fall back to English. Native-speaker review is recommended before production use.
 */
type Lang = 'en' | 'hi' | 'te' | 'ta';

const T: Record<string, Record<Lang, string>> = {
  equipmentCode: {
    en: 'Which equipment has the problem? Please give the tag number written on it, for example P-101.',
    hi: 'किस उपकरण में समस्या है? कृपया उस पर लिखा टैग नंबर बताएं, जैसे P-101।',
    te: 'ఏ పరికరంలో సమస్య ఉంది? దానిపై ఉన్న ట్యాగ్ నంబర్ చెప్పండి, ఉదాహరణకు P-101.',
    ta: 'எந்த உபகரணத்தில் பிரச்சனை உள்ளது? அதில் எழுதப்பட்ட டேக் எண்ணைச் சொல்லுங்கள், எ.கா. P-101.',
  },
  equipmentNotFound: {
    en: 'Equipment {code} is not in the register. Please check the tag number on the equipment.',
    hi: 'उपकरण {code} रजिस्टर में नहीं है। कृपया उपकरण पर लिखा टैग नंबर दोबारा जांचें।',
    te: 'పరికరం {code} రిజిస్టర్‌లో లేదు. దయచేసి పరికరంపై ఉన్న ట్యాగ్ నంబర్‌ను మళ్లీ తనిఖీ చేయండి.',
    ta: 'உபகரணம் {code} பதிவேட்டில் இல்லை. உபகரணத்தில் உள்ள டேக் எண்ணை மீண்டும் சரிபார்க்கவும்.',
  },
  equipmentDecommissioned: {
    en: 'Equipment {code} is marked as decommissioned. Please confirm the correct tag number.',
    hi: 'उपकरण {code} सेवा से हटाया गया है। कृपया सही टैग नंबर बताएं।',
    te: 'పరికరం {code} సేవ నుండి తొలగించబడింది. దయచేసి సరైన ట్యాగ్ నంబర్ చెప్పండి.',
    ta: 'உபகரணம் {code} பயன்பாட்டிலிருந்து நீக்கப்பட்டது. சரியான டேக் எண்ணைச் சொல்லுங்கள்.',
  },
  symptoms: {
    en: 'What exactly is wrong? For example: vibration, noise, leak, overheating.',
    hi: 'ठीक-ठीक क्या समस्या है? जैसे: वाइब्रेशन, आवाज़, रिसाव, ज़्यादा गर्म होना।',
    te: 'సమస్య ఏమిటి? ఉదాహరణకు: వైబ్రేషన్, శబ్దం, లీక్, ఎక్కువ వేడి.',
    ta: 'சரியாக என்ன பிரச்சனை? உதாரணம்: அதிர்வு, சத்தம், கசிவு, அதிக சூடு.',
  },
  description: {
    en: 'Please describe the problem in a sentence or two.',
    hi: 'कृपया समस्या को एक-दो वाक्यों में बताएं।',
    te: 'దయచేసి సమస్యను ఒకటి రెండు వాక్యాల్లో వివరించండి.',
    ta: 'பிரச்சனையை ஒன்று இரண்டு வாக்கியங்களில் விவரிக்கவும்.',
  },
  ready: {
    en: 'Your complaint about {code} is ready. Please review it and confirm to create the ticket.',
    hi: '{code} के बारे में आपकी शिकायत तैयार है। टिकट बनाने के लिए कृपया जांचें और पुष्टि करें।',
    te: '{code} గురించి మీ ఫిర్యాదు సిద్ధంగా ఉంది. టికెట్ సృష్టించడానికి దయచేసి సమీక్షించి నిర్ధారించండి.',
    ta: '{code} பற்றிய உங்கள் புகார் தயாராக உள்ளது. டிக்கெட் உருவாக்க சரிபார்த்து உறுதிப்படுத்தவும்.',
  },
  // Spoken confirmation: {equipment} is "tag, register name"; {symptoms} is the draft's symptom list.
  readySummary: {
    en: 'Your complaint about {equipment} is ready. Problem: {symptoms}. Please review it and confirm to create the ticket.',
    hi: '{equipment} के बारे में आपकी शिकायत तैयार है। समस्या: {symptoms}। टिकट बनाने के लिए कृपया जांचें और पुष्टि करें।',
    te: '{equipment} గురించి మీ ఫిర్యాదు సిద్ధంగా ఉంది. సమస్య: {symptoms}. టికెట్ సృష్టించడానికి దయచేసి సమీక్షించి నిర్ధారించండి.',
    ta: '{equipment} பற்றிய உங்கள் புகார் தயாராக உள்ளது. பிரச்சனை: {symptoms}. டிக்கெட் உருவாக்க சரிபார்த்து உறுதிப்படுத்தவும்.',
  },
};

function lang(code: string): Lang {
  const base = code.slice(0, 2) as Lang;
  return base in T.symptoms! ? base : 'en';
}

export function template(key: keyof typeof T, language: string, vars: Record<string, string> = {}): { text: string; language: string } {
  const l = lang(language);
  const text = T[key]![l].replace(/\{(\w+)\}/g, (_, k: string) => vars[k] ?? '');
  // Report the language the text is actually in, so TTS is asked for the right one.
  return { text, language: l === 'en' ? 'en-IN' : `${l}-IN` };
}

export interface FollowUpQuestion {
  field: RequiredField;
  prompt: string;
  promptLanguage: string;
  inputType: 'equipment' | 'symptoms' | 'text';
}

export function questionsFor(
  missing: readonly string[],
  language: string,
  equipmentCheck: string,
  equipmentCode: string | null,
): FollowUpQuestion[] {
  return missing.map((field): FollowUpQuestion => {
    if (field === 'equipmentCode') {
      const key = equipmentCheck === 'not_found' ? 'equipmentNotFound' : equipmentCheck === 'decommissioned' ? 'equipmentDecommissioned' : 'equipmentCode';
      const t = template(key, language, { code: equipmentCode ?? '' });
      return { field: 'equipmentCode', prompt: t.text, promptLanguage: t.language, inputType: 'equipment' };
    }
    const t = template(field === 'symptoms' ? 'symptoms' : 'description', language);
    return { field: field as RequiredField, prompt: t.text, promptLanguage: t.language, inputType: field === 'symptoms' ? 'symptoms' : 'text' };
  });
}
