import type { DraftState } from './draft.model.js';
import type { RequiredField } from './extraction.schema.js';

/**
 * Complaint draft state machine.
 *
 *   DRAFT ──────────────┐           (extraction unavailable; operator completes manually)
 *     ▼                 ▼
 *   NEEDS_INFORMATION ⇄ READY_FOR_CONFIRMATION ──confirm──▶ CONFIRMED (terminal)
 *     └────────── any non-terminal ──expiry──▶ EXPIRED (terminal)
 *
 * A ticket is created ONLY by an explicit confirm from READY_FOR_CONFIRMATION.
 */
export const TERMINAL: readonly DraftState[] = ['CONFIRMED', 'EXPIRED'];

export const DRAFT_TRANSITIONS: Record<DraftState, readonly DraftState[]> = {
  DRAFT: ['NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION', 'EXPIRED'],
  NEEDS_INFORMATION: ['READY_FOR_CONFIRMATION', 'EXPIRED'],
  READY_FOR_CONFIRMATION: ['NEEDS_INFORMATION', 'CONFIRMED', 'EXPIRED'],
  CONFIRMED: [],
  EXPIRED: [],
};

export function isTerminal(s: DraftState) {
  return TERMINAL.includes(s);
}

export interface DraftFieldsView {
  description: string;
  symptoms: string[];
}

/** Required facts still missing. Severity is deliberately NOT required: "unknown" is valid. */
export function computeMissing(fields: DraftFieldsView, equipmentCheck: string): RequiredField[] {
  const missing: RequiredField[] = [];
  if (equipmentCheck !== 'found') missing.push('equipmentCode');
  if (!fields.symptoms.length) missing.push('symptoms');
  if (fields.description.trim().length < 10) missing.push('description');
  return missing;
}

/** Next non-terminal state for the given missing list. */
export function stateFor(missing: readonly string[]): DraftState {
  return missing.length ? 'NEEDS_INFORMATION' : 'READY_FOR_CONFIRMATION';
}
