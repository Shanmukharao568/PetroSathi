import { z } from 'zod';
import { COMPLAINT_CATEGORIES, EQUIPMENT_CODE_REGEX, SEVERITIES } from '../../config/constants.js';

/** Fields a complaint needs before it can be confirmed. */
export const REQUIRED_FIELDS = ['equipmentCode', 'symptoms', 'description'] as const;
export type RequiredField = (typeof REQUIRED_FIELDS)[number];

/**
 * Structured complaint produced by Evon (or the mock). Mirrors the spec's ComplaintExtraction.
 * Model output is UNTRUSTED: everything is validated, bounded and normalised here.
 */
export const complaintExtractionSchema = z
  .object({
    equipmentCode: z
      .string()
      .trim()
      .toUpperCase()
      .transform((s) => s.replace(/\s+/g, ''))
      .pipe(z.string().regex(EQUIPMENT_CODE_REGEX))
      .nullable(),
    equipmentId: z.string().nullable(),
    symptoms: z.array(z.string().trim().min(1).max(200)).max(20),
    description: z.string().trim().max(4000),
    category: z.enum(COMPLAINT_CATEGORIES),
    severity: z.enum(SEVERITIES),
    inspectionRequired: z.boolean(),
    missingInformation: z.array(z.string().trim().min(1).max(100)).max(20),
    confidence: z.number().min(0).max(1),
    language: z.string().trim().min(2).max(20),
  })
  .strict();

export type ComplaintExtraction = z.infer<typeof complaintExtractionSchema>;

/** Validates untrusted model output. Returns a typed error list instead of throwing. */
export function parseExtraction(raw: unknown): { ok: true; value: ComplaintExtraction } | { ok: false; issues: string[] } {
  const r = complaintExtractionSchema.safeParse(raw);
  if (r.success) return { ok: true, value: r.data };
  return { ok: false, issues: r.error.issues.map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`) };
}
