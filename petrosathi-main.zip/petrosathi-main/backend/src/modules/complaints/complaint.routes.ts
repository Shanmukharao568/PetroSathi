import { Router, type Request, type Response } from 'express';
import { ipKeyGenerator, rateLimit } from 'express-rate-limit';
import { authenticate, authorize, requireUser } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema } from '../../utils/schemas.js';
import { sendSuccess } from '../../utils/response.js';
import { isTest } from '../../config/env.js';
import {
  answersBodySchema,
  createDraftBodySchema,
  extractBodySchema,
  listDraftsQuerySchema,
  speechBodySchema,
  type AnswersBody,
  type CreateDraftBody,
  type ExtractBody,
  type ListDraftsQuery,
  type UpdateDraftBody,
  updateDraftBodySchema,
} from './complaint.schemas.js';
import * as service from './complaint.service.js';

type IdReq = Request<{ id: string }>;
const ip = (req: Request) => req.ip ?? null;

/** Extraction calls the LLM provider: limit per user. */
const aiLimiter = rateLimit({
  windowMs: 60_000,
  limit: isTest ? 1000 : 30,
  keyGenerator: (req) => req.user?.id ?? ipKeyGenerator(req.ip ?? '0.0.0.0'),
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (_req, res) => res.status(429).json({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many requests. Wait a minute and try again.' } }),
});

export const complaintRouter = Router();
// Reporting complaints is an operator activity; admins may also use it (e.g. for testing).
complaintRouter.use(authenticate(), authorize('operator', 'admin'));

complaintRouter.post(
  '/extract',
  aiLimiter,
  validate({ body: extractBodySchema }),
  asyncHandler(async (req: Request, res: Response) => sendSuccess(res, await service.extractPreview(req.body as ExtractBody))),
);

complaintRouter.post(
  '/drafts',
  aiLimiter,
  validate({ body: createDraftBodySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const { draft, created } = await service.createDraft(req.body as CreateDraftBody, requireUser(req), ip(req));
    sendSuccess(res, draft, created ? 201 : 200);
  }),
);

complaintRouter.get(
  '/drafts',
  validate({ query: listDraftsQuerySchema }),
  asyncHandler(async (req: Request, res: Response) => sendSuccess(res, await service.listDrafts(requireUser(req), res.locals.query as ListDraftsQuery))),
);

complaintRouter.get(
  '/drafts/:id',
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.getDraft(req.params.id, requireUser(req)))),
);

complaintRouter.patch(
  '/drafts/:id',
  validate({ params: idParamsSchema, body: updateDraftBodySchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.updateDraft(req.params.id, req.body as UpdateDraftBody, requireUser(req), ip(req)))),
);

complaintRouter.post(
  '/drafts/:id/questions',
  aiLimiter,
  validate({ params: idParamsSchema, body: answersBodySchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.answerQuestions(req.params.id, req.body as AnswersBody, requireUser(req), ip(req)))),
);

complaintRouter.post(
  '/drafts/:id/confirm',
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => {
    const r = await service.confirmDraft(req.params.id, requireUser(req), ip(req));
    sendSuccess(res, r.ticket, r.created ? 201 : 200, { idempotentReplay: !r.created, draftId: r.draftId });
  }),
);

complaintRouter.delete(
  '/drafts/:id',
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => {
    await service.deleteDraft(req.params.id, requireUser(req), ip(req));
    res.status(204).end();
  }),
);

complaintRouter.post(
  '/drafts/:id/speech',
  aiLimiter,
  validate({ params: idParamsSchema, body: speechBodySchema }),
  asyncHandler(async (req: IdReq, res: Response) => {
    const audio = await service.draftSpeech(req.params.id, (req.body as { target: 'questions' | 'confirmation' }).target, requireUser(req));
    res.status(200).set({ 'Content-Type': audio.contentType, 'Cache-Control': 'no-store' }).send(audio.audio);
  }),
);
