import { z } from 'zod';
import { COMPLAINT_CATEGORIES, SEVERITIES } from '../../config/constants.js';
import { objectIdSchema } from '../../utils/schemas.js';
import { REQUIRED_FIELDS } from './extraction.schema.js';

const languageSchema = z.string().regex(/^[a-z]{2,3}-[A-Z]{2}$/, 'Use a language code like hi-IN');

export const extractBodySchema = z
  .object({
    transcript: z.string().trim().min(1).max(10000),
    language: languageSchema,
  })
  .strict();
export type ExtractBody = z.infer<typeof extractBodySchema>;

/** Voice draft: conversationId (transcript is taken from the server record). Text draft: transcript. */
export const createDraftBodySchema = z
  .object({
    conversationId: objectIdSchema.optional(),
    transcript: z.string().trim().min(10, 'Describe the problem in at least 10 characters').max(10000).optional(),
    language: languageSchema.optional(),
  })
  .strict()
  .refine((b) => !!b.conversationId !== !!b.transcript, { message: 'Provide exactly one of conversationId or transcript', path: ['conversationId'] });
export type CreateDraftBody = z.infer<typeof createDraftBodySchema>;

export const updateDraftBodySchema = z
  .object({
    equipmentCode: z.string().trim().max(20).nullable().optional(),
    description: z.string().trim().max(4000).optional(),
    symptoms: z.array(z.string().trim().min(1).max(200)).max(20).optional(),
    category: z.enum(COMPLAINT_CATEGORIES).optional(),
    severity: z.enum(SEVERITIES).optional(),
  })
  .strict()
  .refine((b) => Object.keys(b).length > 0, { message: 'At least one field is required' });
export type UpdateDraftBody = z.infer<typeof updateDraftBodySchema>;

export const answersBodySchema = z
  .object({
    answers: z
      .array(z.object({ field: z.enum(REQUIRED_FIELDS), answer: z.string().trim().min(1).max(2000) }).strict())
      .min(1)
      .max(REQUIRED_FIELDS.length),
  })
  .strict();
export type AnswersBody = z.infer<typeof answersBodySchema>;

export const listDraftsQuerySchema = z.object({
  includeClosed: z.enum(['true', 'false']).transform((v) => v === 'true').optional(),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});
export type ListDraftsQuery = z.infer<typeof listDraftsQuerySchema>;

export const speechBodySchema = z.object({ target: z.enum(['questions', 'confirmation']) }).strict();
