import { randomUUID } from 'node:crypto';
import { Types, type QueryFilter } from 'mongoose';
import { ComplaintDraftModel, type ComplaintDraft, type ComplaintDraftDocument, type DraftState } from './draft.model.js';
import { computeMissing, isTerminal, stateFor } from './draft.workflow.js';
import { questionsFor, template } from './questions.js';
import type { ComplaintExtraction } from './extraction.schema.js';
import type { AnswersBody, CreateDraftBody, ExtractBody, UpdateDraftBody } from './complaint.schemas.js';
import { EquipmentModel } from '../equipment/equipment.model.js';
import { ConversationModel } from '../conversations/conversation.model.js';
import { UserModel } from '../users/user.model.js';
import { createTicket } from '../tickets/ticket.service.js';
import { getEvonProvider, getTtsProvider } from '../../providers/gnani/index.js';
import { ProviderError } from '../../providers/gnani/prisma.types.js';
import { MOCK_PREFIX } from '../../providers/gnani/mockPrismaService.js';
import { toApiError } from '../voice/voice.service.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import { ApiError } from '../../utils/ApiError.js';
import { SEVERITIES, type Severity } from '../../config/constants.js';
import { parseEquipmentCode, unhyphenatedCodeCandidates } from '../equipment/equipmentCode.js';
import { spokenTagToLatin } from '../equipment/spokenTag.js';
import { env } from '../../config/env.js';
import { logger } from '../../utils/logger.js';

type Actor = Express.AuthenticatedUser;

const PURGE_AFTER_EXPIRY_MS = 7 * 24 * 3600_000;
const MAX_SPOKEN_SYMPTOMS = 5;
const MAX_SPOKEN_SYMPTOM_CHARS = 60;

// ------------------------------------------------------------------ helpers

export { parseEquipmentCode };

/**
 * Finds the equipment tag in free text. A hyphenated tag is used as written (even if it is not
 * in the register, so the operator is told so). Otherwise tags without a hyphen ("FV 601",
 * "FV601", or spelled out in Indic script like "పీ టూ జీరో వన్" — how speech-to-text writes
 * spoken tags) are accepted only when exactly one of them
 * exists in the register; ordinary speech such as "pump 30" never becomes a tag.
 */
export async function resolveEquipmentCode(text: string): Promise<string | null> {
  const hyphenated = parseEquipmentCode(text);
  if (hyphenated) return hyphenated;
  // Also look at the tag as spelled out in Indic script ("పీ టూ జీరో వన్" → "P 201").
  const candidates = [...new Set([...unhyphenatedCodeCandidates(text), ...unhyphenatedCodeCandidates(spokenTagToLatin(text))])];
  if (!candidates.length) return null;
  const registered = await EquipmentModel.distinct('equipmentCode', { equipmentCode: { $in: candidates } });
  return registered.length === 1 ? String(registered[0]) : null;
}

/** Tag for a new draft: the extractor's tag (normalised when possible), else one found in the operator's words. */
async function equipmentCodeFor(extracted: string | null | undefined, transcript: string): Promise<string | null> {
  if (extracted) return (await resolveEquipmentCode(extracted)) ?? extracted;
  return resolveEquipmentCode(transcript.replace(MOCK_PREFIX, ''));
}

/** Register name as it should be spoken: bracketed notes such as "(Demo)" are dropped. */
function spokenEquipmentName(name: string | null | undefined): string {
  return (name ?? '').replace(/\s*\([^)]*\)/g, '').replace(/\s+/g, ' ').trim();
}

async function checkEquipment(code: string | null) {
  if (!code) return { status: 'not_provided' as const, equipment: null };
  const eq = await EquipmentModel.findOne({ equipmentCode: code });
  if (!eq) return { status: 'not_found' as const, equipment: null };
  if (eq.status === 'decommissioned') return { status: 'decommissioned' as const, equipment: eq };
  return { status: 'found' as const, equipment: eq };
}

function extractionSupported(language: string) {
  return getEvonProvider().supportedLanguages.includes(language);
}

async function runExtraction(transcript: string, language: string) {
  const provider = getEvonProvider();
  if (!extractionSupported(language)) {
    return { status: 'unsupported_language' as const, provider: provider.id, result: null, error: null };
  }
  try {
    const result = await provider.extractComplaint({ transcript, language });
    return { status: 'completed' as const, provider: provider.id, result, error: null };
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : err }, 'Complaint extraction failed');
    return { status: 'failed' as const, provider: provider.id, result: null, error: err instanceof ProviderError ? err.message : 'Extraction failed' };
  }
}

/** Re-checks equipment and recomputes missing information + state. Terminal states are left alone. */
async function refresh(draft: ComplaintDraftDocument, opts: { keepDraftState?: boolean } = {}) {
  const check = await checkEquipment(draft.fields!.equipmentCode ?? null);
  draft.equipmentCheck = check.status;
  draft.fields!.equipmentId = check.status === 'found' ? check.equipment!._id : null;
  const missing = computeMissing({ description: draft.fields!.description ?? '', symptoms: draft.fields!.symptoms ?? [] }, check.status);
  draft.missingInformation = missing;
  if (!isTerminal(draft.state as DraftState) && !opts.keepDraftState) draft.state = stateFor(missing);
}

async function loadEquipmentSummary(id: Types.ObjectId | null | undefined) {
  if (!id) return null;
  const eq = await EquipmentModel.findById(id).select('equipmentCode name type plant location status criticality');
  return eq ? eq.toJSON() : null;
}

async function toView(draft: ComplaintDraftDocument) {
  const json = draft.toJSON() as Record<string, unknown>;
  const state = draft.state as DraftState;
  return {
    ...json,
    equipment: await loadEquipmentSummary(draft.fields!.equipmentId),
    questions: isTerminal(state) ? [] : questionsFor(draft.missingInformation, draft.language, draft.equipmentCheck, draft.fields!.equipmentCode ?? null),
    canConfirm: state === 'READY_FOR_CONFIRMATION',
  };
}

/** Lazily marks an overdue draft as EXPIRED (the periodic job does the same in bulk). */
async function expireIfDue(draft: ComplaintDraftDocument) {
  if (!isTerminal(draft.state as DraftState) && draft.expiresAt.getTime() <= Date.now()) {
    draft.state = 'EXPIRED';
    await draft.save();
  }
}

async function loadOwn(id: string, actor: Actor, allowAdminRead = false) {
  const draft = await ComplaintDraftModel.findById(id);
  const isOwner = draft && String(draft.userId) === actor.id;
  if (!draft || !(isOwner || (allowAdminRead && actor.role === 'admin'))) throw ApiError.notFound('Complaint draft');
  await expireIfDue(draft);
  return draft;
}

function assertEditable(draft: ComplaintDraftDocument) {
  if (draft.state === 'CONFIRMED') throw ApiError.conflict('This complaint has already been confirmed');
  if (draft.state === 'EXPIRED') throw ApiError.conflict('This draft has expired. Please start a new report.');
}

// ------------------------------------------------------------------ preview

/** Stateless extraction preview (POST /complaints/extract). */
export async function extractPreview(body: ExtractBody) {
  if (!extractionSupported(body.language)) {
    throw new ApiError(422, 'AUDIO_REJECTED', `Complaint extraction is not available for ${body.language}`, { reason: 'unsupported_language' });
  }
  const provider = getEvonProvider();
  let result: ComplaintExtraction;
  try {
    result = await provider.extractComplaint({ transcript: body.transcript, language: body.language });
  } catch (err) {
    throw toApiError(err);
  }
  const equipmentCode = await equipmentCodeFor(result.equipmentCode, body.transcript);
  const check = await checkEquipment(equipmentCode);
  return {
    provider: provider.id,
    extraction: { ...result, equipmentCode, equipmentId: check.status === 'found' ? String(check.equipment!._id) : null },
    equipmentCheck: check.status,
  };
}

// ------------------------------------------------------------------ drafts

export async function createDraft(body: CreateDraftBody, actor: Actor, ip: string | null) {
  let transcript: string;
  let language: string;
  let conversationId: Types.ObjectId | null = null;

  if (body.conversationId) {
    const conv = await ConversationModel.findOne({ _id: body.conversationId, userId: actor.id });
    if (!conv) throw ApiError.badRequest('Voice conversation not found');
    if (conv.ticketId) throw ApiError.conflict('This recording has already been used for a ticket');
    if (!conv.transcript.trim()) throw ApiError.badRequest('The recording has no transcript. Please record again.');
    // One active draft per recording: return it instead of creating a duplicate.
    if (conv.complaintDraftId) {
      const existing = await ComplaintDraftModel.findById(conv.complaintDraftId);
      if (existing && !isTerminal(existing.state as DraftState)) return { draft: await toView(existing), created: false };
    }
    transcript = conv.transcript;
    language = conv.language ?? body.language ?? (await UserModel.findById(actor.id).select('preferredLanguage'))?.preferredLanguage ?? env.DEFAULT_LANGUAGE;
    conversationId = conv._id;
  } else {
    transcript = body.transcript!;
    language = body.language ?? (await UserModel.findById(actor.id).select('preferredLanguage'))?.preferredLanguage ?? env.DEFAULT_LANGUAGE;
  }

  const extraction = await runExtraction(transcript, language);
  const r = extraction.result;
  const expiresAt = new Date(Date.now() + env.COMPLAINT_DRAFT_TTL_HOURS * 3600_000);

  const draft = new ComplaintDraftModel({
    userId: actor.id,
    conversationId,
    source: conversationId ? 'voice' : 'text',
    transcript,
    language,
    extraction: { ...extraction, at: new Date() },
    fields: {
      equipmentCode: await equipmentCodeFor(r?.equipmentCode, transcript),
      // Description: extractor's faithful summary, else the operator's own words.
      description: (r?.description || transcript.replace(MOCK_PREFIX, '')).trim().slice(0, 4000),
      symptoms: r?.symptoms ?? [],
      category: r?.category ?? 'other',
      // Never invent severity: only what the extractor reported from evidence.
      severity: r?.severity ?? 'unknown',
      inspectionRequired: r?.inspectionRequired ?? false,
    },
    state: 'DRAFT',
    idempotencyKey: randomUUID(),
    expiresAt,
    purgeAt: new Date(expiresAt.getTime() + PURGE_AFTER_EXPIRY_MS),
  });
  // Extraction unavailable → stay in DRAFT until the operator edits or answers.
  await refresh(draft, { keepDraftState: extraction.status !== 'completed' });
  await draft.save();

  if (conversationId) {
    await ConversationModel.updateOne({ _id: conversationId }, { $set: { complaintDraftId: draft._id } });
  }
  await recordAudit({
    actorId: actor.id,
    action: AuditActions.COMPLAINT_DRAFT_CREATED,
    entityType: 'ComplaintDraft',
    entityId: draft._id,
    metadata: { source: draft.source, language, extraction: extraction.status, provider: extraction.provider, state: draft.state },
    ip,
  });
  return { draft: await toView(draft), created: true };
}

export async function getDraft(id: string, actor: Actor) {
  return toView(await loadOwn(id, actor, true));
}

export async function listDrafts(actor: Actor, q: { includeClosed?: boolean; limit: number }) {
  // Bulk-expire this user's overdue drafts so the list is accurate.
  await ComplaintDraftModel.updateMany(
    { userId: actor.id, state: { $in: ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION'] }, expiresAt: { $lte: new Date() } },
    { $set: { state: 'EXPIRED' } },
  );
  const open: DraftState[] = ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION'];
  const filter: QueryFilter<ComplaintDraft> = { userId: new Types.ObjectId(actor.id) };
  if (!q.includeClosed) filter.state = { $in: open };
  const drafts = await ComplaintDraftModel.find(filter).sort({ updatedAt: -1 }).limit(q.limit);
  return drafts.map((d) => {
    const j = d.toJSON() as Record<string, unknown>;
    return { id: j.id, state: d.state, source: d.source, language: d.language, fields: d.fields!, missingInformation: d.missingInformation, expiresAt: d.expiresAt, updatedAt: (j as { updatedAt: Date }).updatedAt, ticketId: d.ticketId };
  });
}

export async function updateDraft(id: string, body: UpdateDraftBody, actor: Actor, ip: string | null) {
  const draft = await loadOwn(id, actor);
  assertEditable(draft);

  if (body.equipmentCode !== undefined) {
    draft.fields!.equipmentCode = body.equipmentCode ? (await resolveEquipmentCode(body.equipmentCode)) ?? body.equipmentCode.toUpperCase() : null;
  }
  if (body.description !== undefined) draft.fields!.description = body.description;
  if (body.symptoms !== undefined) draft.fields!.symptoms = [...new Set(body.symptoms)];
  if (body.category !== undefined) draft.fields!.category = body.category;
  if (body.severity !== undefined) draft.fields!.severity = body.severity;

  await refresh(draft);
  await draft.save();
  await recordAudit({ actorId: actor.id, action: AuditActions.COMPLAINT_DRAFT_UPDATED, entityType: 'ComplaintDraft', entityId: draft._id, metadata: { fields: Object.keys(body), state: draft.state }, ip });
  return toView(draft);
}

/** Applies follow-up answers. Answers are stored verbatim alongside the question asked. */
export async function answerQuestions(id: string, body: AnswersBody, actor: Actor, ip: string | null) {
  const draft = await loadOwn(id, actor);
  assertEditable(draft);
  const asked = questionsFor(draft.missingInformation, draft.language, draft.equipmentCheck, draft.fields!.equipmentCode ?? null);

  for (const { field, answer } of body.answers) {
    const question = asked.find((q) => q.field === field)?.prompt ?? template(field === 'equipmentCode' ? 'equipmentCode' : field, draft.language).text;
    draft.answers.push({ field, question, answer, at: new Date() });

    if (field === 'equipmentCode') {
      draft.fields!.equipmentCode = await resolveEquipmentCode(answer);
    } else if (field === 'symptoms') {
      let symptoms: string[] = [];
      if (extractionSupported(draft.language)) {
        const ex = await runExtraction(answer, draft.language);
        symptoms = ex.result?.symptoms ?? [];
      }
      // If the extractor recognises nothing, keep the operator's own words (comma-separated).
      if (!symptoms.length) symptoms = answer.split(/[,،;\n]/).map((s) => s.trim()).filter(Boolean).map((s) => s.slice(0, 200));
      draft.fields!.symptoms = [...new Set([...(draft.fields!.symptoms ?? []), ...symptoms])].slice(0, 20);
    } else if (field === 'description') {
      const current = (draft.fields!.description ?? '').trim();
      draft.fields!.description = (current ? `${current}\n${answer}` : answer).slice(0, 4000);
    }
  }

  await refresh(draft);
  await draft.save();
  await recordAudit({ actorId: actor.id, action: AuditActions.COMPLAINT_DRAFT_UPDATED, entityType: 'ComplaintDraft', entityId: draft._id, metadata: { answered: body.answers.map((a) => a.field), state: draft.state }, ip });
  return toView(draft);
}

/**
 * Explicit confirmation → exactly one maintenance ticket.
 * Uses the draft's server-side idempotency key, so retries and concurrent confirms return the
 * same ticket. A confirmed draft returns its ticket again (created=false).
 */
export async function confirmDraft(id: string, actor: Actor, ip: string | null) {
  const draft = await loadOwn(id, actor);
  if (draft.state === 'EXPIRED') throw ApiError.conflict('This draft has expired. Please start a new report.');

  if (draft.state !== 'CONFIRMED') {
    await refresh(draft); // equipment may have been decommissioned since the last edit
    if (draft.state !== 'READY_FOR_CONFIRMATION') {
      await draft.save();
      throw ApiError.conflict('The complaint is missing required information', { missingInformation: draft.missingInformation });
    }
  }

  const { ticket, created } = await createTicket(
    {
      equipmentId: String(draft.fields!.equipmentId),
      description: draft.fields!.description ?? '',
      symptoms: draft.fields!.symptoms ?? [],
      category: draft.fields!.category as never,
      severity: (SEVERITIES as readonly string[]).includes(draft.fields!.severity ?? '') ? (draft.fields!.severity as Severity) : 'unknown',
      source: draft.source === 'voice' ? 'voice' : 'manual',
      // Voice: the ORIGINAL transcript is copied from the conversation by createTicket.
      conversationId: draft.conversationId ? String(draft.conversationId) : null,
      complaintDraftId: String(draft._id),
      language: draft.language,
    },
    actor,
    draft.idempotencyKey,
    ip,
  );

  if (draft.state !== 'CONFIRMED') {
    await ComplaintDraftModel.updateOne(
      { _id: draft._id, state: { $ne: 'CONFIRMED' } },
      { $set: { state: 'CONFIRMED', ticketId: new Types.ObjectId(ticket.id as string), confirmedAt: new Date(), purgeAt: null } },
    );
    if (created) {
      await recordAudit({
        actorId: actor.id,
        action: AuditActions.COMPLAINT_CONFIRMED,
        entityType: 'ComplaintDraft',
        entityId: draft._id,
        metadata: { ticketNumber: ticket.ticketNumber, ticketId: ticket.id },
        ip,
      });
    }
  }
  return { ticket, created, draftId: String(draft._id) };
}

export async function deleteDraft(id: string, actor: Actor, ip: string | null) {
  const draft = await loadOwn(id, actor);
  if (draft.state === 'CONFIRMED') throw ApiError.conflict('Confirmed complaints cannot be deleted');
  await draft.deleteOne();
  if (draft.conversationId) {
    await ConversationModel.updateOne({ _id: draft.conversationId, complaintDraftId: draft._id }, { $set: { complaintDraftId: null } });
  }
  await recordAudit({ actorId: actor.id, action: AuditActions.COMPLAINT_DRAFT_DELETED, entityType: 'ComplaintDraft', entityId: draft._id, ip });
}

/**
 * Confirmation prompt naming the equipment (tag + register name) and the symptoms, so the operator
 * hears what the ticket will say before confirming. The name comes from the register, never from
 * the operator's words. Symptoms are capped so the prompt stays within the TTS length limit.
 */
export async function confirmationPrompt(draft: ComplaintDraftDocument): Promise<{ text: string; language: string }> {
  const code = draft.fields!.equipmentCode ?? '';
  const eq = draft.fields!.equipmentId ? await EquipmentModel.findById(draft.fields!.equipmentId).select('name') : null;
  const name = spokenEquipmentName(eq?.name);
  const equipment = name ? `${code}, ${name}` : code;
  const symptoms = (draft.fields!.symptoms ?? [])
    .slice(0, MAX_SPOKEN_SYMPTOMS)
    .map((s) => s.trim().slice(0, MAX_SPOKEN_SYMPTOM_CHARS))
    .filter(Boolean)
    .join(', ');
  return symptoms
    ? template('readySummary', draft.language, { equipment, symptoms })
    : template('ready', draft.language, { code: equipment });
}

/**
 * Spoken version of the follow-up questions or the confirmation prompt (Timbre).
 * Text is generated server-side from templates — this is never a general-purpose TTS proxy.
 */
export async function draftSpeech(id: string, target: 'questions' | 'confirmation', actor: Actor) {
  const draft = await loadOwn(id, actor);
  const tts = getTtsProvider();
  if (!tts) throw ApiError.unavailable('Spoken prompts are not configured. Please read the text on screen.');

  let text: string;
  let language: string;
  if (target === 'questions') {
    const qs = questionsFor(draft.missingInformation, draft.language, draft.equipmentCheck, draft.fields!.equipmentCode ?? null);
    if (!qs.length) throw ApiError.badRequest('There are no open questions');
    text = qs.map((q) => q.prompt).join(' ');
    language = qs[0]!.promptLanguage;
  } else {
    const t = await confirmationPrompt(draft);
    text = t.text;
    language = t.language;
  }
  if (!tts.languages.includes(language)) {
    throw ApiError.unavailable('Spoken prompts are not available in this language. Please read the text on screen.');
  }
  try {
    return await tts.synthesize(text, language);
  } catch (err) {
    throw toApiError(err);
  }
}

// ------------------------------------------------------------------ expiry job

export async function expireOverdueDrafts(now = new Date()): Promise<number> {
  const r = await ComplaintDraftModel.updateMany(
    { state: { $in: ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION'] }, expiresAt: { $lte: now } },
    { $set: { state: 'EXPIRED' } },
  );
  return r.modifiedCount;
}

let expiryTimer: NodeJS.Timeout | null = null;
export function startDraftExpiryJob(intervalMs = 10 * 60_000) {
  if (expiryTimer) return;
  expiryTimer = setInterval(() => void expireOverdueDrafts().catch((err) => logger.error({ err }, 'Draft expiry job failed')), intervalMs);
  expiryTimer.unref();
}
export function stopDraftExpiryJob() {
  if (expiryTimer) clearInterval(expiryTimer);
  expiryTimer = null;
}
