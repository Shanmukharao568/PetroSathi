import { EQUIPMENT_CODE_REGEX } from '../../config/constants.js';

/**
 * Equipment tag parsing shared by the extractor and the complaint service. Pure: no database.
 *
 * Hyphenated tags ("P-101", "HX - 401", "fv-601") are trusted as written. Tags without a hyphen
 * ("FV 601", "FV601"), which is how speech-to-text usually writes a spoken tag, are only
 * CANDIDATES: they also match ordinary speech ("pump 30"), so callers must confirm them against
 * the equipment register before using one.
 */

// The part after the hyphen must start with a digit, so words like "follow-up" never match.
const HYPHENATED = /\b([A-Za-z]{1,6})\s?-\s?(\d[A-Za-z0-9]{0,9})\b/;
const UNHYPHENATED = /\b([A-Za-z]{1,6})\s?(\d{2,6}[A-Za-z]?)\b/g;

function normalise(prefix: string, rest: string): string | null {
  const code = `${prefix.toUpperCase()}-${rest.toUpperCase()}`;
  return EQUIPMENT_CODE_REGEX.test(code) ? code : null;
}

/** First hyphenated tag in the text, normalised ("it is p-101" → "P-101"), else null. */
export function parseEquipmentCode(text: string): string | null {
  const m = text.match(HYPHENATED);
  return m ? normalise(m[1]!, m[2]!) : null;
}

/** Possible tags written without a hyphen, normalised and de-duplicated, in order of appearance. */
export function unhyphenatedCodeCandidates(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(UNHYPHENATED)) {
    const code = normalise(m[1]!, m[2]!);
    if (code) out.add(code);
  }
  return [...out];
}
