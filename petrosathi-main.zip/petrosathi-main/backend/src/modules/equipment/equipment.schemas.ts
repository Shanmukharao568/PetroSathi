import { z } from 'zod';
import {
  EQUIPMENT_CODE_REGEX,
  EQUIPMENT_CRITICALITY,
  EQUIPMENT_STATUS,
  EQUIPMENT_TYPES,
} from '../../config/constants.js';
import { paginationQuerySchema } from '../../utils/schemas.js';

export const equipmentCodeSchema = z
  .string()
  .trim()
  .toUpperCase()
  .regex(EQUIPMENT_CODE_REGEX, 'Equipment code must look like P-101 or HX-301A');

const text = (max: number) => z.string().trim().max(max);

export const createEquipmentBodySchema = z
  .object({
    equipmentCode: equipmentCodeSchema,
    name: text(150).min(2),
    type: z.enum(EQUIPMENT_TYPES),
    plant: text(100).min(1),
    location: text(200).optional(),
    manufacturer: text(100).optional(),
    model: text(100).optional(),
    criticality: z.enum(EQUIPMENT_CRITICALITY).optional(),
    status: z.enum(EQUIPMENT_STATUS).optional(),
  })
  .strict();
export type CreateEquipmentBody = z.infer<typeof createEquipmentBodySchema>;

export const updateEquipmentBodySchema = createEquipmentBodySchema
  .partial()
  .strict()
  .refine((b) => Object.keys(b).length > 0, { message: 'At least one field is required' });
export type UpdateEquipmentBody = z.infer<typeof updateEquipmentBodySchema>;

export const listEquipmentQuerySchema = paginationQuerySchema.extend({
  search: z.string().trim().max(100).optional(),
  code: equipmentCodeSchema.optional(),
  type: z.enum(EQUIPMENT_TYPES).optional(),
  plant: z.string().trim().max(100).optional(),
  status: z.enum(EQUIPMENT_STATUS).optional(),
  criticality: z.enum(EQUIPMENT_CRITICALITY).optional(),
});
export type ListEquipmentQuery = z.infer<typeof listEquipmentQuerySchema>;
