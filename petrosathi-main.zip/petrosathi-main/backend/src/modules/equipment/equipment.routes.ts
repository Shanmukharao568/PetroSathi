import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema } from '../../utils/schemas.js';
import { createEquipmentBodySchema, listEquipmentQuerySchema, updateEquipmentBodySchema } from './equipment.schemas.js';
import * as controller from './equipment.controller.js';

export const equipmentRouter = Router();

equipmentRouter.use(authenticate());

// Read access for every signed-in role (operators pick equipment when reporting).
equipmentRouter.get('/', validate({ query: listEquipmentQuerySchema }), asyncHandler(controller.list));
equipmentRouter.get('/:id', validate({ params: idParamsSchema }), asyncHandler(controller.getById));

equipmentRouter.post('/', authorize('admin'), validate({ body: createEquipmentBodySchema }), asyncHandler(controller.create));
equipmentRouter.patch(
  '/:id',
  authorize('admin'),
  validate({ params: idParamsSchema, body: updateEquipmentBodySchema }),
  asyncHandler(controller.update),
);
equipmentRouter.delete('/:id', authorize('admin'), validate({ params: idParamsSchema }), asyncHandler(controller.remove));
