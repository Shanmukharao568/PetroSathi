import type { Request, Response } from 'express';
import { requireUser } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/response.js';
import * as service from './equipment.service.js';
import type { CreateEquipmentBody, ListEquipmentQuery, UpdateEquipmentBody } from './equipment.schemas.js';

type IdReq = Request<{ id: string }>;

export async function list(_req: Request, res: Response) {
  const { items, meta } = await service.listEquipment(res.locals.query as ListEquipmentQuery);
  sendSuccess(res, items, 200, { pagination: meta });
}

export async function getById(req: IdReq, res: Response) {
  sendSuccess(res, await service.getEquipment(req.params.id));
}

export async function create(req: Request, res: Response) {
  sendSuccess(res, await service.createEquipment(req.body as CreateEquipmentBody, requireUser(req), req.ip ?? null), 201);
}

export async function update(req: IdReq, res: Response) {
  sendSuccess(res, await service.updateEquipment(req.params.id, req.body as UpdateEquipmentBody, requireUser(req), req.ip ?? null));
}

export async function remove(req: IdReq, res: Response) {
  await service.deleteEquipment(req.params.id, requireUser(req), req.ip ?? null);
  res.status(204).end();
}
