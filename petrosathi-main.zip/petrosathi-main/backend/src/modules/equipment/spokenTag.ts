/**
 * Rewrites an equipment tag that speech-to-text spelled out in Telugu, Hindi or Tamil script
 * ("పీ టూ జీరో వన్లో") into Latin form ("P 201") so the tag parser can see it. Pure: no database.
 *
 * The output is only ever used to find CANDIDATE tags without a hyphen; callers must still confirm
 * them against the equipment register, because letter names and number words also occur in
 * ordinary speech. Spoken hyphens ("dash") are dropped rather than written as "-" for the same
 * reason: a written hyphen would make the tag trusted without that check.
 */

type Kind = 'letter' | 'digit' | 'skip';

const LETTERS: Record<string, string[]> = {
  A: ['ఏ', 'ఎ', 'ए', 'ஏ'],
  B: ['బీ', 'బి', 'बी'], // Tamil பி is read as P below: P tags are far more common
  C: ['సీ', 'సి', 'सी', 'சி', 'சீ'],
  D: ['డీ', 'డి', 'डी', 'டி'],
  E: ['ఈ', 'ई', 'ஈ'],
  F: ['ఎఫ్', 'एफ', 'एफ़', 'எஃப்', 'எப்'],
  G: ['జీ', 'జి', 'जी', 'ஜி', 'ஜீ'],
  H: ['హెచ్', 'హెచ్చ్', 'ఎచ్', 'एच', 'ஹெச்', 'எச்'],
  I: ['ఐ', 'आई', 'ஐ'],
  J: ['జే', 'జె', 'जे', 'ஜே'],
  K: ['కే', 'కె', 'के', 'கே'],
  L: ['ఎల్', 'एल', 'எல்'],
  M: ['ఎం', 'ఎమ్', 'एम', 'எம்'],
  N: ['ఎన్', 'एन', 'என்'],
  O: ['ఓ', 'ओ', 'ஓ'],
  P: ['పీ', 'పి', 'पी', 'பி', 'பீ'],
  Q: ['క్యూ', 'क्यू', 'க்யூ'],
  R: ['ఆర్', 'आर', 'ஆர்'],
  S: ['ఎస్', 'एस', 'எஸ்'],
  T: ['టీ', 'టి', 'टी', 'டீ'],
  U: ['యూ', 'యు', 'यू', 'யூ'],
  V: ['వీ', 'వి', 'वी', 'வி', 'வீ'],
  W: ['డబ్ల్యూ', 'డబ్ల్యు', 'डब्ल्यू', 'டபிள்யூ'],
  X: ['ఎక్స్', 'एक्स', 'எக்ஸ்'],
  Y: ['వై', 'वाई', 'வை'],
  Z: ['జెడ్', 'జడ్', 'ज़ेड', 'जेड', 'இசட்', 'ஜெட்'],
};

const DIGITS: Record<string, string[]> = {
  '0': ['zero', 'జీరో', 'సున్నా', 'ज़ीरो', 'जीरो', 'शून्य', 'ஜீரோ', 'பூஜ்ஜியம்', 'பூஜ்யம்'],
  '1': ['one', 'వన్', 'ఒకటి', 'वन', 'एक', 'ஒன்', 'ஒன்று'],
  '2': ['two', 'టూ', 'రెండు', 'टू', 'दो', 'டூ', 'இரண்டு'],
  '3': ['three', 'త్రీ', 'మూడు', 'थ्री', 'तीन', 'த்ரீ', 'மூன்று'],
  '4': ['four', 'ఫోర్', 'నాలుగు', 'फोर', 'फ़ोर', 'चार', 'ஃபோர்', 'போர்', 'நான்கு'],
  '5': ['five', 'ఫైవ్', 'ఐదు', 'फाइव', 'फ़ाइव', 'पांच', 'पाँच', 'ஃபைவ்', 'பைவ்', 'ஐந்து'],
  '6': ['six', 'సిక్స్', 'ఆరు', 'सिक्स', 'छह', 'छः', 'छे', 'சிக்ஸ்', 'ஆறு'],
  '7': ['seven', 'సెవెన్', 'ఏడు', 'सेवन', 'सात', 'செவன்', 'ஏழு'],
  '8': ['eight', 'ఎయిట్', 'ఎనిమిది', 'एट', 'आठ', 'எய்ட்', 'எட்டு'],
  '9': ['nine', 'నైన్', 'తొమ్మిది', 'नाइन', 'नौ', 'நைன்', 'ஒன்பது'],
};

const HYPHEN_WORDS = ['dash', 'hyphen', 'డాష్', 'హైఫన్', 'डैश', 'हाइफन', 'हाइफ़न', 'டாஷ்', 'ஹைஃபன்'];

/** Case endings that attach to the last spoken digit ("వన్లో" = "in one", "ஒன்றில்"). */
const SUFFIXES = ['లోని', 'లో', 'కి', 'కు', 'ని', 'ను', 'తో', 'పై', 'ది', 'యొక్క', 'का', 'की', 'के', 'में', 'இல்', 'க்கு'];

const NATIVE_DIGITS = /[౦-౯०-९௦-௯]/g;

const letterOf = new Map<string, string>();
for (const [l, words] of Object.entries(LETTERS)) for (const w of words) letterOf.set(w.normalize('NFC'), l);
const digitOf = new Map<string, string>();
for (const [d, words] of Object.entries(DIGITS)) for (const w of words) digitOf.set(w.normalize('NFC').toLowerCase(), d);
const hyphens = new Set(HYPHEN_WORDS.map((w) => w.normalize('NFC')));

function nativeToAscii(s: string): string {
  return s.replace(NATIVE_DIGITS, (c) => {
    const cp = c.codePointAt(0)!;
    const zero = cp >= 0x0c66 && cp <= 0x0c6f ? 0x0c66 : cp >= 0x0966 && cp <= 0x096f ? 0x0966 : 0x0be6;
    return String(cp - zero);
  });
}

function classify(raw: string): { kind: Kind; value: string } | null {
  const token = raw.replace(/^[\p{P}]+|[\p{P}]+$/gu, '');
  if (!token) return null;
  if (hyphens.has(token)) return { kind: 'skip', value: '' };
  const letter = letterOf.get(token);
  if (letter) return { kind: 'letter', value: letter };
  const lower = token.toLowerCase();
  const digit = digitOf.get(lower);
  if (digit) return { kind: 'digit', value: digit };
  for (const sfx of SUFFIXES) {
    if (lower.length > sfx.length && lower.endsWith(sfx)) {
      const d = digitOf.get(lower.slice(0, -sfx.length));
      if (d) return { kind: 'digit', value: d };
    }
  }
  // A lone Latin letter ("P టూ జీరో వన్") joins the spelled-out tag.
  if (/^[A-Za-z]$/.test(token)) return { kind: 'letter', value: token.toUpperCase() };
  return null;
}

/**
 * Text with spelled-out letters and digits rewritten: consecutive letters are joined ("H X" → "HX"),
 * consecutive digits are joined ("2 0 1" → "201"), and a letter run is followed by one space before
 * its digits, which is the shape `unhyphenatedCodeCandidates` accepts. Other words are kept.
 */
export function spokenTagToLatin(text: string): string {
  const tokens = nativeToAscii(text.normalize('NFC').replace(/[​-‍﻿]/g, '')).split(/\s+/).filter(Boolean);
  const out: string[] = [];
  let prev: Kind | null = null;
  for (const raw of tokens) {
    const t = classify(raw);
    if (t?.kind === 'skip') continue; // keep `prev` so "P dash 201" still reads as "P 201"
    if (t && prev === t.kind) out[out.length - 1] += t.value;
    else out.push(t ? t.value : raw);
    prev = t ? t.kind : null;
  }
  return out.join(' ');
}
