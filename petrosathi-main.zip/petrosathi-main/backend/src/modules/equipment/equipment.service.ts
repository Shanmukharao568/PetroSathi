import type { QueryFilter } from 'mongoose';
import { EquipmentModel, type Equipment } from './equipment.model.js';
import { TicketModel } from '../tickets/ticket.model.js';
import { ApiError } from '../../utils/ApiError.js';
import { escapeRegex } from '../../utils/schemas.js';
import { paginationMeta } from '../../utils/response.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import type { CreateEquipmentBody, ListEquipmentQuery, UpdateEquipmentBody } from './equipment.schemas.js';

type Actor = Express.AuthenticatedUser;

export async function listEquipment(q: ListEquipmentQuery) {
  const filter: QueryFilter<Equipment> = {};
  if (q.code) filter.equipmentCode = q.code;
  if (q.type) filter.type = q.type;
  if (q.status) filter.status = q.status;
  if (q.criticality) filter.criticality = q.criticality;
  if (q.plant) filter.plant = new RegExp(`^${escapeRegex(q.plant)}$`, 'i');
  if (q.search) {
    const rx = new RegExp(escapeRegex(q.search), 'i');
    filter.$or = [{ equipmentCode: rx }, { name: rx }, { location: rx }, { manufacturer: rx }];
  }
  const [items, total] = await Promise.all([
    EquipmentModel.find(filter)
      .sort({ equipmentCode: 1 })
      .skip((q.page - 1) * q.limit)
      .limit(q.limit),
    EquipmentModel.countDocuments(filter),
  ]);
  return { items: items.map((e) => e.toJSON()), meta: paginationMeta(q.page, q.limit, total) };
}

export async function getEquipment(id: string) {
  const eq = await EquipmentModel.findById(id);
  if (!eq) throw ApiError.notFound('Equipment');
  const [openTickets, totalTickets] = await Promise.all([
    TicketModel.countDocuments({ equipmentId: eq._id, status: { $nin: ['RESOLVED', 'CLOSED'] } }),
    TicketModel.countDocuments({ equipmentId: eq._id }),
  ]);
  return { ...eq.toJSON(), ticketCounts: { open: openTickets, total: totalTickets } };
}

export async function findByCode(code: string) {
  return EquipmentModel.findOne({ equipmentCode: code.trim().toUpperCase() });
}

export async function createEquipment(body: CreateEquipmentBody, actor: Actor, ip: string | null) {
  if (await EquipmentModel.exists({ equipmentCode: body.equipmentCode })) {
    throw ApiError.conflict(`Equipment ${body.equipmentCode} already exists`);
  }
  const eq = await EquipmentModel.create(body);
  await recordAudit({
    actorId: actor.id,
    action: AuditActions.EQUIPMENT_CREATED,
    entityType: 'Equipment',
    entityId: eq._id,
    metadata: { equipmentCode: eq.equipmentCode },
    ip,
  });
  return eq.toJSON();
}

export async function updateEquipment(id: string, body: UpdateEquipmentBody, actor: Actor, ip: string | null) {
  const eq = await EquipmentModel.findById(id);
  if (!eq) throw ApiError.notFound('Equipment');

  if (body.equipmentCode && body.equipmentCode !== eq.equipmentCode) {
    if (await EquipmentModel.exists({ equipmentCode: body.equipmentCode, _id: { $ne: eq._id } })) {
      throw ApiError.conflict(`Equipment ${body.equipmentCode} already exists`);
    }
  }
  const changes: Record<string, { from: unknown; to: unknown }> = {};
  for (const [key, value] of Object.entries(body) as [keyof UpdateEquipmentBody, unknown][]) {
    if (value !== undefined && eq.get(key) !== value) {
      changes[key] = { from: eq.get(key), to: value };
      eq.set(key, value);
    }
  }
  await eq.save();
  if (Object.keys(changes).length) {
    await recordAudit({
      actorId: actor.id,
      action: AuditActions.EQUIPMENT_UPDATED,
      entityType: 'Equipment',
      entityId: eq._id,
      metadata: { changes },
      ip,
    });
  }
  return eq.toJSON();
}

/**
 * Hard delete is only allowed for equipment never referenced by a ticket, so ticket history
 * is never orphaned. Referenced equipment should be set to status "decommissioned" instead.
 */
export async function deleteEquipment(id: string, actor: Actor, ip: string | null) {
  const eq = await EquipmentModel.findById(id);
  if (!eq) throw ApiError.notFound('Equipment');
  const refs = await TicketModel.countDocuments({ equipmentId: eq._id });
  if (refs > 0) {
    throw ApiError.conflict(
      `Equipment ${eq.equipmentCode} is referenced by ${refs} ticket(s). Set its status to "decommissioned" instead.`,
    );
  }
  await eq.deleteOne();
  await recordAudit({
    actorId: actor.id,
    action: AuditActions.EQUIPMENT_DELETED,
    entityType: 'Equipment',
    entityId: eq._id,
    metadata: { equipmentCode: eq.equipmentCode },
    ip,
  });
}
