import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';
import {
  EQUIPMENT_CODE_REGEX,
  EQUIPMENT_CRITICALITY,
  EQUIPMENT_STATUS,
  EQUIPMENT_TYPES,
} from '../../config/constants.js';

const equipmentSchema = new Schema(
  {
    equipmentCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      match: EQUIPMENT_CODE_REGEX,
      unique: true,
    },
    name: { type: String, required: true, trim: true, maxlength: 150 },
    type: { type: String, enum: EQUIPMENT_TYPES, required: true, index: true },
    plant: { type: String, required: true, trim: true, maxlength: 100, index: true },
    location: { type: String, trim: true, maxlength: 200, default: '' },
    manufacturer: { type: String, trim: true, maxlength: 100, default: '' },
    model: { type: String, trim: true, maxlength: 100, default: '' },
    criticality: { type: String, enum: EQUIPMENT_CRITICALITY, default: 'medium', index: true },
    status: { type: String, enum: EQUIPMENT_STATUS, default: 'operational', index: true },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        return ret;
      },
    },
  },
);

export type Equipment = InferSchemaType<typeof equipmentSchema>;
export type EquipmentDocument = HydratedDocument<Equipment>;
export const EquipmentModel = model('Equipment', equipmentSchema, 'equipment');
