import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';

/**
 * One voice interaction. Stores text only — audio is never persisted in MongoDB.
 * `transcript` is the provider's original output and is never edited; operator edits
 * live on the complaint/ticket description instead.
 */
const messageSchema = new Schema(
  {
    role: { type: String, enum: ['operator', 'assistant', 'system'], required: true },
    text: { type: String, required: true, maxlength: 10000 },
    at: { type: Date, required: true, default: () => new Date() },
  },
  { _id: false },
);

const conversationSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    audioMode: { type: String, enum: ['upload', 'stream'], required: true },
    /** What the operator asked for: a language code or "auto". */
    requestedLanguage: { type: String, required: true },
    /** Detected by the provider when reported, otherwise the requested code; null for unknown auto. */
    language: { type: String, default: null },
    provider: { type: String, enum: ['gnani-prisma', 'mock'], required: true },
    model: { type: String, default: null },
    providerRequestId: { type: String, default: null },
    transcript: { type: String, default: '', maxlength: 10000 },
    truncated: { type: Boolean, default: false },
    segmentCount: { type: Number, default: 0 },
    audioDurationMs: { type: Number, default: null },
    messages: { type: [messageSchema], default: [] },
    complaintDraftId: { type: Schema.Types.ObjectId, ref: 'ComplaintDraft', default: null },
    ticketId: { type: Schema.Types.ObjectId, ref: 'MaintenanceTicket', default: null },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        return ret;
      },
    },
  },
);

conversationSchema.index({ userId: 1, createdAt: -1 });

export type Conversation = InferSchemaType<typeof conversationSchema>;
export type ConversationDocument = HydratedDocument<Conversation>;
export const ConversationModel = model('Conversation', conversationSchema);
