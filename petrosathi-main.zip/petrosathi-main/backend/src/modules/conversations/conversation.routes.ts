import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { authenticate, requireUser } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema, objectIdSchema, paginationQuerySchema } from '../../utils/schemas.js';
import { paginationMeta, sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import { ConversationModel } from './conversation.model.js';

const listQuerySchema = paginationQuerySchema.extend({ userId: objectIdSchema.optional() });

export const conversationRouter = Router();
conversationRouter.use(authenticate());

/** Own conversations; administrators may list another user's with ?userId=. */
conversationRouter.get(
  '/',
  validate({ query: listQuerySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const actor = requireUser(req);
    const q = res.locals.query as z.infer<typeof listQuerySchema>;
    if (q.userId && q.userId !== actor.id && actor.role !== 'admin') throw ApiError.forbidden();
    const filter = { userId: q.userId ?? actor.id };
    const [items, total] = await Promise.all([
      ConversationModel.find(filter).sort({ createdAt: -1 }).skip((q.page - 1) * q.limit).limit(q.limit),
      ConversationModel.countDocuments(filter),
    ]);
    sendSuccess(res, items.map((c) => c.toJSON()), 200, { pagination: paginationMeta(q.page, q.limit, total) });
  }),
);

conversationRouter.get(
  '/:id',
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: Request<{ id: string }>, res: Response) => {
    const actor = requireUser(req);
    const c = await ConversationModel.findById(req.params.id);
    if (!c || (String(c.userId) !== actor.id && actor.role !== 'admin')) throw ApiError.notFound('Conversation');
    sendSuccess(res, c.toJSON());
  }),
);
