import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import { isTest } from '../../config/env.js';
import { authenticate } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { loginBodySchema, registerBodySchema, verifyEmailBodySchema } from './auth.schemas.js';
import * as controller from './auth.controller.js';

export const authRouter = Router();

/** Brute-force protection on credential checks. */
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: isTest ? 1000 : 20,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  handler: (_req, res) =>
    res.status(429).json({
      success: false,
      error: { code: 'RATE_LIMITED', message: 'Too many sign-in attempts. Try again in 15 minutes.' },
    }),
});

authRouter.post('/login', loginLimiter, validate({ body: loginBodySchema }), asyncHandler(controller.login));

/** Sign-up abuse protection (per IP). */
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: isTest ? 1000 : 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (_req, res) =>
    res.status(429).json({
      success: false,
      error: { code: 'RATE_LIMITED', message: 'Too many sign-ups from this network. Try again later.' },
    }),
});
// Public sign-up: always creates a Field Operator whose email must be verified (see auth.service.register).
authRouter.post('/register', registerLimiter, validate({ body: registerBodySchema }), asyncHandler(controller.register));
authRouter.get('/me', authenticate({ allowPendingPasswordChange: true, allowUnverifiedEmail: true }), asyncHandler(controller.me));
authRouter.post('/logout', authenticate({ allowPendingPasswordChange: true, allowUnverifiedEmail: true }), asyncHandler(controller.logout));

/** Guessing protection for one-time codes (on top of the per-code attempt limit). */
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: isTest ? 1000 : 30,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (_req, res) =>
    res.status(429).json({
      success: false,
      error: { code: 'RATE_LIMITED', message: 'Too many verification attempts. Try again in 15 minutes.' },
    }),
});

// Email verification (after any temporary password has been changed).
authRouter.post('/email/send-code', otpLimiter, authenticate({ allowUnverifiedEmail: true }), asyncHandler(controller.sendEmailCode));
authRouter.post(
  '/email/verify',
  otpLimiter,
  authenticate({ allowUnverifiedEmail: true }),
  validate({ body: verifyEmailBodySchema }),
  asyncHandler(controller.verifyEmail),
);
