import jwt, { type SignOptions } from 'jsonwebtoken';
import { env } from '../../config/env.js';
import type { Role } from '../../config/constants.js';
import { ApiError } from '../../utils/ApiError.js';

export interface AccessTokenPayload {
  sub: string;
  role: Role;
  /** Must match the user's current tokenVersion, otherwise the token is revoked. */
  tv: number;
}

const ISSUER = 'petrosathi-api';
const AUDIENCE = 'petrosathi-client';

export function signAccessToken(payload: AccessTokenPayload): { token: string; expiresAt: string } {
  const token = jwt.sign(payload, env.JWT_SECRET, {
    algorithm: 'HS256',
    expiresIn: env.JWT_EXPIRES_IN as SignOptions['expiresIn'],
    issuer: ISSUER,
    audience: AUDIENCE,
  });
  const decoded = jwt.decode(token) as { exp: number };
  return { token, expiresAt: new Date(decoded.exp * 1000).toISOString() };
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  try {
    const decoded = jwt.verify(token, env.JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: ISSUER,
      audience: AUDIENCE,
    });
    if (
      typeof decoded !== 'object' ||
      typeof decoded.sub !== 'string' ||
      typeof decoded.tv !== 'number' ||
      typeof decoded.role !== 'string'
    ) {
      throw ApiError.unauthorized('Invalid token');
    }
    return { sub: decoded.sub, role: decoded.role as Role, tv: decoded.tv };
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err instanceof jwt.TokenExpiredError) {
      throw ApiError.unauthorized('Session expired, please sign in again', 'TOKEN_EXPIRED');
    }
    throw ApiError.unauthorized('Invalid token');
  }
}
