import { Schema, model } from 'mongoose';

/**
 * One pending email-verification code per user. Only an HMAC of the code is stored; the
 * document expires on its own (TTL index) shortly after the code does.
 */
const emailOtpSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    codeHash: { type: String, required: true },
    expiresAt: { type: Date, required: true },
    /** When the latest code was sent — drives the resend cooldown. */
    sentAt: { type: Date, required: true },
    attempts: { type: Number, default: 0 },
    /** Removed by MongoDB an hour after the code expired (keeps the cooldown meaningful). */
    purgeAt: { type: Date, required: true, expires: 0 },
  },
  { timestamps: true },
);

export const EmailOtpModel = model('EmailOtp', emailOtpSchema);
