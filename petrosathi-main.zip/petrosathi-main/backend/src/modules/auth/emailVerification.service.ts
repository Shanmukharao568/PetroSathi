import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import { env } from '../../config/env.js';
import { ApiError } from '../../utils/ApiError.js';
import { mailMode, sendMail } from '../../utils/mailer.js';
import { logger } from '../../utils/logger.js';
import { UserModel } from '../users/user.model.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import { EmailOtpModel } from './emailOtp.model.js';
import { sessionUser } from './auth.service.js';

const CODE_LENGTH = 6;

/** Codes are bound to the user, so a code for one account is useless for another. */
function hashCode(userId: string, code: string) {
  return createHmac('sha256', env.JWT_SECRET).update(`email-otp:${userId}:${code}`).digest('hex');
}

function sameHash(a: string, b: string) {
  const ab = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

/** "ravi.kumar@example.com" → "ra••••••@example.com" (shown in the UI, never the full address in logs). */
export function maskEmail(email: string) {
  const [local = '', domain = ''] = email.split('@');
  const keep = local.length <= 2 ? 1 : 2;
  return `${local.slice(0, keep)}${'•'.repeat(Math.max(3, local.length - keep))}@${domain}`;
}

export function emailVerificationRequired() {
  return env.EMAIL_VERIFICATION_REQUIRED;
}

function emailBody(name: string, code: string, minutes: number) {
  const text =
    `Hello ${name},\n\n` +
    `Your PetroSathi verification code is: ${code}\n\n` +
    `It expires in ${minutes} minutes. If you did not try to sign in to PetroSathi, ignore this email and tell your administrator.\n`;
  const html = `<!doctype html><html><body style="margin:0;background:#f4f7f8;font-family:Arial,Helvetica,sans-serif;color:#151c21">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 12px"><tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:460px;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #dbe2e6">
      <tr><td style="background:#0c1a1d;padding:20px 28px;color:#ffffff;font-size:18px;font-weight:bold">Petro<span style="color:#f4b740">Sathi</span></td></tr>
      <tr><td style="padding:28px">
        <p style="margin:0 0 12px;font-size:15px">Hello ${escapeHtml(name)},</p>
        <p style="margin:0 0 20px;font-size:15px;line-height:1.5">Use this code to verify your email address:</p>
        <p style="margin:0 0 20px;font-size:34px;letter-spacing:10px;font-weight:bold;font-family:'Courier New',monospace;color:#10584a;text-align:center;background:#eef6f3;border-radius:10px;padding:14px 0">${code}</p>
        <p style="margin:0;font-size:13px;line-height:1.5;color:#62717b">It expires in ${minutes} minutes. If you did not try to sign in to PetroSathi, ignore this email and tell your administrator.</p>
      </td></tr>
    </table>
  </td></tr></table></body></html>`;
  return { text, html };
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

export interface CodeStatus {
  sentTo: string;
  expiresAt: Date;
  resendAvailableAt: Date;
  /** Where the code went: "email", or "server-log" in development without SMTP. */
  delivery: 'email' | 'server-log';
}

/**
 * Sends (or re-sends) a 6-digit code. Re-sending within the cooldown is refused with
 * RATE_LIMITED and the time when a new code may be requested.
 */
export async function sendVerificationCode(userId: string, ip: string | null): Promise<CodeStatus> {
  const user = await UserModel.findById(userId);
  if (!user) throw ApiError.notFound('User');
  if (user.emailVerified) throw ApiError.conflict('Your email address is already verified');

  const now = Date.now();
  const existing = await EmailOtpModel.findOne({ userId: user._id });
  if (existing) {
    const resendAt = existing.sentAt.getTime() + env.EMAIL_OTP_RESEND_SECONDS * 1000;
    if (now < resendAt) {
      throw new ApiError(429, 'RATE_LIMITED', 'A code was sent recently. Please wait before asking for another.', {
        retryAfterSeconds: Math.ceil((resendAt - now) / 1000),
        sentTo: maskEmail(user.email),
        expiresAt: existing.expiresAt,
        resendAvailableAt: new Date(resendAt),
      });
    }
  }

  const code = String(randomInt(0, 10 ** CODE_LENGTH)).padStart(CODE_LENGTH, '0');
  const expiresAt = new Date(now + env.EMAIL_OTP_TTL_MINUTES * 60_000);
  await EmailOtpModel.findOneAndUpdate(
    { userId: user._id },
    {
      codeHash: hashCode(String(user._id), code),
      expiresAt,
      sentAt: new Date(now),
      attempts: 0,
      purgeAt: new Date(expiresAt.getTime() + 3600_000),
    },
    { upsert: true },
  );

  try {
    await sendMail({ to: user.email, subject: `${code} is your PetroSathi verification code`, ...emailBody(user.name, code, env.EMAIL_OTP_TTL_MINUTES) });
  } catch (err) {
    // Remove the unusable code so the user can retry immediately.
    await EmailOtpModel.deleteOne({ userId: user._id });
    logger.error({ err: err instanceof Error ? err.message : err }, 'Verification email could not be sent');
    throw new ApiError(503, 'SERVICE_UNAVAILABLE', 'We could not send the email right now. Please try again in a minute.');
  }

  await recordAudit({ actorId: user._id, action: AuditActions.USER_EMAIL_CODE_SENT, entityType: 'User', entityId: user._id, ip });
  return {
    sentTo: maskEmail(user.email),
    expiresAt,
    resendAvailableAt: new Date(now + env.EMAIL_OTP_RESEND_SECONDS * 1000),
    delivery: mailMode() === 'smtp' ? 'email' : 'server-log',
  };
}

/** Checks a code. Wrong codes count towards a limit, after which a new code is needed. */
export async function verifyEmailCode(userId: string, code: string, ip: string | null) {
  const user = await UserModel.findById(userId);
  if (!user) throw ApiError.notFound('User');
  if (user.emailVerified) return sessionUser(user);

  const otp = await EmailOtpModel.findOne({ userId: user._id });
  if (!otp) throw new ApiError(400, 'OTP_EXPIRED', 'No active code. Request a new code.');
  if (otp.expiresAt.getTime() <= Date.now()) {
    await otp.deleteOne();
    throw new ApiError(400, 'OTP_EXPIRED', 'This code has expired. Request a new code.');
  }

  if (!sameHash(otp.codeHash, hashCode(String(user._id), code))) {
    otp.attempts += 1;
    const left = env.EMAIL_OTP_MAX_ATTEMPTS - otp.attempts;
    if (left <= 0) {
      await otp.deleteOne();
      throw new ApiError(400, 'OTP_EXPIRED', 'Too many wrong codes. Request a new code.');
    }
    await otp.save();
    throw new ApiError(400, 'OTP_INVALID', `That code is not correct. ${left} ${left === 1 ? 'try' : 'tries'} left.`, { attemptsLeft: left });
  }

  await otp.deleteOne();
  user.emailVerified = true;
  user.emailVerifiedAt = new Date();
  await user.save();
  await recordAudit({ actorId: user._id, action: AuditActions.USER_EMAIL_VERIFIED, entityType: 'User', entityId: user._id, ip });
  return sessionUser(user);
}
