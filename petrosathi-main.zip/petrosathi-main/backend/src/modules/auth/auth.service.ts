import { UserModel } from '../users/user.model.js';
import { ApiError } from '../../utils/ApiError.js';
import { getDummyHash, hashPassword, verifyPassword } from '../../utils/password.js';
import { signAccessToken } from './token.service.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import type { LoginBody, RegisterBody } from './auth.schemas.js';
import { env } from '../../config/env.js';
import type { UserDocument } from '../users/user.model.js';

/** The signed-in user as the client sees it, plus whether the email still needs confirming. */
export function sessionUser(user: UserDocument) {
  return { ...user.toJSON(), emailVerificationRequired: env.EMAIL_VERIFICATION_REQUIRED && !user.emailVerified };
}

const INVALID = () => ApiError.unauthorized('Invalid email or password', 'INVALID_CREDENTIALS');

export async function login({ email, password }: LoginBody, ip: string | null) {
  const user = await UserModel.findOne({ email }).select('+passwordHash +tokenVersion');

  if (!user) {
    // Equalise timing so attackers cannot enumerate valid emails.
    await verifyPassword(password, await getDummyHash());
    await recordAudit({ actorId: null, action: AuditActions.AUTH_LOGIN_FAILED, entityType: 'User', metadata: { reason: 'unknown_email' }, ip });
    throw INVALID();
  }

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    await recordAudit({ actorId: null, action: AuditActions.AUTH_LOGIN_FAILED, entityType: 'User', entityId: user._id, metadata: { reason: 'bad_password' }, ip });
    throw INVALID();
  }

  // Only reveal deactivation after a correct password, so it cannot be probed.
  if (!user.isActive) {
    await recordAudit({ actorId: user._id, action: AuditActions.AUTH_LOGIN_FAILED, entityType: 'User', entityId: user._id, metadata: { reason: 'inactive' }, ip });
    throw ApiError.forbidden('This account has been deactivated. Contact your administrator.', 'ACCOUNT_DISABLED');
  }

  user.lastLoginAt = new Date();
  await user.save();

  const { token, expiresAt } = signAccessToken({ sub: String(user._id), role: user.role, tv: user.tokenVersion });
  await recordAudit({ actorId: user._id, action: AuditActions.AUTH_LOGIN_SUCCESS, entityType: 'User', entityId: user._id, ip });

  return { token, expiresAt, user: sessionUser(user) };
}

/** Revokes every token issued to this user (all devices). */
export async function logout(userId: string, ip: string | null) {
  await UserModel.updateOne({ _id: userId }, { $inc: { tokenVersion: 1 } });
  await recordAudit({ actorId: userId, action: AuditActions.AUTH_LOGOUT, entityType: 'User', entityId: userId, ip });
}

export async function getCurrentUser(userId: string) {
  const user = await UserModel.findById(userId);
  if (!user) throw ApiError.notFound('User');
  return sessionUser(user);
}

/**
 * Self sign-up: always a Field Operator, own password (no forced change), email unverified —
 * the one-time email code is required before anything else works. Signs the new user in.
 */
export async function register(body: RegisterBody, ip: string | null) {
  if (!env.SELF_REGISTRATION_ENABLED) {
    throw ApiError.forbidden('Sign-up is turned off. Ask your site administrator for an account.', 'FORBIDDEN');
  }
  if (await UserModel.exists({ email: body.email })) {
    throw ApiError.conflict('An account with this email already exists. Sign in instead.');
  }

  let user;
  try {
    user = await UserModel.create({
      name: body.name,
      email: body.email,
      role: 'operator',
      preferredLanguage: body.preferredLanguage ?? env.DEFAULT_LANGUAGE,
      passwordHash: await hashPassword(body.password),
      mustChangePassword: false,
      emailVerified: false,
      lastLoginAt: new Date(),
    });
  } catch (err) {
    // Two sign-ups racing for the same address: the unique index decides.
    if ((err as { code?: number }).code === 11000) throw ApiError.conflict('An account with this email already exists. Sign in instead.');
    throw err;
  }
  const fresh = await UserModel.findById(user._id).select('+tokenVersion');
  const { token, expiresAt } = signAccessToken({ sub: String(user._id), role: user.role, tv: fresh!.tokenVersion });
  await recordAudit({ actorId: user._id, action: AuditActions.USER_REGISTERED, entityType: 'User', entityId: user._id, metadata: { role: user.role }, ip });
  return { token, expiresAt, user: sessionUser(fresh!) };
}
