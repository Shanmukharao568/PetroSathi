import { z } from 'zod';
import { LANGUAGE_TAG_REGEX } from '../../config/constants.js';
import { passwordSchema } from '../../utils/password.js';

export const loginBodySchema = z.object({
  email: z.string().trim().toLowerCase().pipe(z.email('Invalid email')),
  // Do not apply the password policy here: login must not reveal policy details.
  password: z.string().min(1, 'Password is required').max(256),
});
export type LoginBody = z.infer<typeof loginBodySchema>;

export const verifyEmailBodySchema = z
  .object({
    // Tolerate spaces/dashes people type between digit groups ("123 456").
    code: z
      .string()
      .transform((v) => v.replace(/[\s-]/g, ''))
      .pipe(z.string().regex(/^\d{6}$/, 'Enter the 6-digit code from the email')),
  })
  .strict();
export type VerifyEmailBody = z.infer<typeof verifyEmailBodySchema>;

/**
 * Public sign-up. Deliberately has no `role` (or any other privileged field): `.strict()` rejects
 * them, and the service always creates a Field Operator.
 */
export const registerBodySchema = z
  .object({
    name: z.string().trim().min(2, 'At least 2 characters').max(100),
    email: z.string().trim().toLowerCase().pipe(z.email('Enter a valid email address')),
    password: passwordSchema,
    preferredLanguage: z.string().regex(LANGUAGE_TAG_REGEX, 'Invalid language tag (e.g. en-IN)').optional(),
  })
  .strict();
export type RegisterBody = z.infer<typeof registerBodySchema>;
