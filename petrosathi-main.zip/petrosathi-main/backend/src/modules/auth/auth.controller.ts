import type { Request, Response } from 'express';
import { requireUser } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/response.js';
import * as authService from './auth.service.js';
import type { LoginBody, RegisterBody, VerifyEmailBody } from './auth.schemas.js';
import * as emailVerification from './emailVerification.service.js';

export async function login(req: Request, res: Response) {
  const result = await authService.login(req.body as LoginBody, req.ip ?? null);
  sendSuccess(res, result);
}

export async function me(req: Request, res: Response) {
  sendSuccess(res, await authService.getCurrentUser(requireUser(req).id));
}

export async function logout(req: Request, res: Response) {
  await authService.logout(requireUser(req).id, req.ip ?? null);
  res.status(204).end();
}

export async function sendEmailCode(req: Request, res: Response) {
  sendSuccess(res, await emailVerification.sendVerificationCode(requireUser(req).id, req.ip ?? null));
}

export async function verifyEmail(req: Request, res: Response) {
  const { code } = req.body as VerifyEmailBody;
  sendSuccess(res, await emailVerification.verifyEmailCode(requireUser(req).id, code, req.ip ?? null));
}

export async function register(req: Request, res: Response) {
  const result = await authService.register(req.body as RegisterBody, req.ip ?? null);
  sendSuccess(res, result, 201);
}
