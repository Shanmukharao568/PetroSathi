import { Types } from 'mongoose';
import { env } from '../../config/env.js';
import { getEmbeddingProvider } from '../../rag/embeddings/index.js';
import { LOCAL_MODELS } from '../../rag/embeddings/types.js';
import { getVectorStore, type VectorFilter, type VectorHit } from '../../rag/vectorStore/index.js';
import { DocumentModel } from '../documents/document.model.js';
import { TicketModel } from '../tickets/ticket.model.js';
import { EquipmentModel } from '../equipment/equipment.model.js';
import { ApiError } from '../../utils/ApiError.js';
import { logger } from '../../utils/logger.js';

export interface Citation {
  documentId: string;
  documentName: string;
  documentType: string;
  pageNumber: number;
  section: string;
  chunkIndex: number;
  score: number;
  /** The retrieved passage, verbatim (reference material — never instructions). */
  excerpt: string;
}

export const NO_RESULTS_MESSAGE = 'No suitable documentation was found in the approved knowledge base.';

/** Threshold: env override, else the benchmarked default for the configured model. */
export function minRelevance(): number {
  if (env.RAG_MIN_RELEVANCE_SCORE !== undefined) return env.RAG_MIN_RELEVANCE_SCORE;
  const embedder = getEmbeddingProvider();
  // Mock (hashed words) needs some word overlap; it is used only by automated tests.
  if (embedder.id.startsWith('mock:')) return 0.15;
  return LOCAL_MODELS[embedder.model]?.defaultMinScore ?? 0;
}

async function toCitations(hits: VectorHit[]): Promise<Citation[]> {
  if (!hits.length) return [];
  // Cite only documents that still exist and are ready (approved knowledge base).
  const ids = [...new Set(hits.map((h) => h.metadata.documentId))].filter((id) => Types.ObjectId.isValid(id));
  const ready = await DocumentModel.find({ _id: { $in: ids }, ingestionStatus: 'ready' }).select('title documentType');
  const byId = new Map(ready.map((d) => [String(d._id), d]));
  return hits
    .filter((h) => byId.has(h.metadata.documentId))
    .map((h) => ({
      documentId: h.metadata.documentId,
      documentName: byId.get(h.metadata.documentId)!.title,
      documentType: byId.get(h.metadata.documentId)!.documentType,
      pageNumber: h.metadata.pageNumber,
      section: h.metadata.section,
      chunkIndex: h.metadata.chunkIndex,
      score: Number(h.score.toFixed(4)),
      excerpt: h.text,
    }));
}

export async function search(query: string, filter: VectorFilter, topK = env.RAG_TOP_K) {
  const embedder = getEmbeddingProvider();
  let hits: VectorHit[];
  try {
    const vector = await embedder.embedQuery(query);
    hits = await getVectorStore().query(vector, topK, filter);
  } catch (err) {
    logger.error({ err: (err as Error).message }, 'Knowledge search failed');
    throw ApiError.unavailable('Document search is unavailable right now (vector database or embedding model not reachable).');
  }
  const threshold = minRelevance();
  const citations = await toCitations(hits.filter((h) => h.score >= threshold));
  return {
    query,
    filter,
    embeddingModel: embedder.model,
    minRelevance: threshold,
    results: citations,
    noResults: citations.length === 0,
    ...(citations.length === 0 ? { message: NO_RESULTS_MESSAGE } : {}),
  };
}

/**
 * Grounded answer. Gnani Evon (the LLM) has no documented API, so no text is generated:
 * the answer is EXTRACTIVE — the best matching passages with exact citations. Nothing is
 * paraphrased, so nothing can be fabricated.
 */
export async function ask(question: string, filter: VectorFilter, topK = 3) {
  const r = await search(question, filter, topK);
  return {
    question,
    mode: 'extractive' as const,
    note: 'Showing the most relevant passages from approved documents. AI-generated answers are not available (Gnani Evon has no documented API).',
    answer: r.noResults ? null : r.results.map((c) => c.excerpt).join('\n\n'),
    citations: r.results,
    noResults: r.noResults,
    ...(r.noResults ? { message: NO_RESULTS_MESSAGE } : {}),
  };
}

/**
 * Manual references for a ticket. Retrieval runs only when an engineer asks for it.
 * Scope widens step by step: this equipment → this equipment type → all approved documents.
 */
export async function ticketReferences(ticketId: string, topK = env.RAG_TOP_K) {
  const ticket = await TicketModel.findById(ticketId).select('equipmentId equipmentCode description symptoms category');
  if (!ticket) throw ApiError.notFound('Ticket');
  const equipment = await EquipmentModel.findById(ticket.equipmentId).select('equipmentCode type name');
  const query = [equipment?.type?.replace('_', ' '), ...ticket.symptoms, ticket.description].filter(Boolean).join('. ').slice(0, 1000);

  const scopes: { scope: 'equipment' | 'equipmentType' | 'all'; filter: VectorFilter }[] = [
    { scope: 'equipment', filter: { equipmentCode: ticket.equipmentCode } },
    ...(equipment?.type ? [{ scope: 'equipmentType' as const, filter: { equipmentType: equipment.type } }] : []),
    { scope: 'all', filter: {} },
  ];
  for (const s of scopes) {
    const r = await search(query, s.filter, topK);
    if (!r.noResults) return { ...r, scope: s.scope };
  }
  return { query, scope: 'all' as const, results: [], noResults: true, message: NO_RESULTS_MESSAGE, embeddingModel: getEmbeddingProvider().model, minRelevance: minRelevance() };
}
