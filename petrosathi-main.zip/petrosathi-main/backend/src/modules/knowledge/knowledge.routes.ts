import { Router, type Request, type Response } from 'express';
import { ipKeyGenerator, rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { authenticate, authorize } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { sendSuccess } from '../../utils/response.js';
import { isTest } from '../../config/env.js';
import { EQUIPMENT_TYPES } from '../../config/constants.js';
import { objectIdSchema } from '../../utils/schemas.js';
import { equipmentCodeSchema } from '../equipment/equipment.schemas.js';
import { DOCUMENT_TYPES } from '../documents/document.model.js';
import * as service from './knowledge.service.js';

const filtersSchema = z
  .object({
    equipmentCode: equipmentCodeSchema.optional(),
    equipmentType: z.enum(EQUIPMENT_TYPES).optional(),
    documentType: z.enum(DOCUMENT_TYPES).optional(),
    documentId: objectIdSchema.optional(),
    source: z.enum(['preloaded', 'upload']).optional(),
  })
  .strict()
  .default({});

const searchBodySchema = z
  .object({
    query: z.string().trim().min(2).max(1000),
    filters: filtersSchema,
    topK: z.number().int().min(1).max(20).optional(),
  })
  .strict();

const limiter = rateLimit({
  windowMs: 60_000,
  limit: isTest ? 1000 : 60,
  keyGenerator: (req) => req.user?.id ?? ipKeyGenerator(req.ip ?? '0.0.0.0'),
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (_req, res) => res.status(429).json({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many searches. Wait a minute and try again.' } }),
});

export const knowledgeRouter = Router();
knowledgeRouter.use(authenticate(), authorize('engineer', 'admin'), limiter);

knowledgeRouter.post(
  '/search',
  validate({ body: searchBodySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const b = req.body as z.infer<typeof searchBodySchema>;
    sendSuccess(res, await service.search(b.query, b.filters, b.topK));
  }),
);

knowledgeRouter.post(
  '/ask',
  validate({ body: searchBodySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const b = req.body as z.infer<typeof searchBodySchema>;
    sendSuccess(res, await service.ask(b.query, b.filters, b.topK ?? 3));
  }),
);
