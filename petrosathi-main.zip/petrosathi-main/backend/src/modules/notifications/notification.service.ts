import type { Types } from 'mongoose';
import { NotificationModel, type NotificationType } from './notification.model.js';
import { ApiError } from '../../utils/ApiError.js';
import { paginationMeta } from '../../utils/response.js';
import { logger } from '../../utils/logger.js';

type Id = Types.ObjectId | string;

/**
 * Creates one notification per recipient. The actor is never notified about their own action.
 * Failures are logged and swallowed so a notification problem cannot roll back a ticket change.
 */
export async function notify(
  recipients: (Id | null | undefined)[],
  payload: { actorId: Id; ticketId: Id; type: NotificationType; message: string },
): Promise<void> {
  const actor = String(payload.actorId);
  const unique = [...new Set(recipients.filter((r): r is Id => !!r).map(String))].filter((r) => r !== actor);
  if (!unique.length) return;
  try {
    await NotificationModel.insertMany(
      unique.map((userId) => ({ userId, ticketId: payload.ticketId, type: payload.type, message: payload.message })),
    );
  } catch (err) {
    logger.error({ err, type: payload.type }, 'Failed to create notifications');
  }
}

export async function listNotifications(userId: string, q: { page: number; limit: number; unreadOnly?: boolean }) {
  const filter = { userId, ...(q.unreadOnly ? { isRead: false } : {}) };
  const [items, total, unread] = await Promise.all([
    NotificationModel.find(filter)
      .sort({ createdAt: -1 })
      .skip((q.page - 1) * q.limit)
      .limit(q.limit),
    NotificationModel.countDocuments(filter),
    NotificationModel.countDocuments({ userId, isRead: false }),
  ]);
  return { items: items.map((n) => n.toJSON()), meta: { ...paginationMeta(q.page, q.limit, total), unread } };
}

/** Scoped by userId so nobody can read or mark another user's notification (returns 404). */
export async function markRead(userId: string, id: string) {
  const n = await NotificationModel.findOneAndUpdate({ _id: id, userId }, { $set: { isRead: true } }, { returnDocument: 'after' });
  if (!n) throw ApiError.notFound('Notification');
  return n.toJSON();
}

export async function markAllRead(userId: string) {
  const r = await NotificationModel.updateMany({ userId, isRead: false }, { $set: { isRead: true } });
  return { updated: r.modifiedCount };
}
