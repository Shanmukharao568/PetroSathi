import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { authenticate, requireUser } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { booleanQuery, idParamsSchema, paginationQuerySchema } from '../../utils/schemas.js';
import { sendSuccess } from '../../utils/response.js';
import * as service from './notification.service.js';

const listQuerySchema = paginationQuerySchema.extend({ unreadOnly: booleanQuery.optional() });

export const notificationRouter = Router();
notificationRouter.use(authenticate());

notificationRouter.get(
  '/',
  validate({ query: listQuerySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const { items, meta } = await service.listNotifications(requireUser(req).id, res.locals.query as z.infer<typeof listQuerySchema>);
    sendSuccess(res, items, 200, { pagination: meta, unread: meta.unread });
  }),
);

// Registered before '/:id/read' so "read-all" is not parsed as an id.
notificationRouter.patch(
  '/read-all',
  asyncHandler(async (req: Request, res: Response) => {
    sendSuccess(res, await service.markAllRead(requireUser(req).id));
  }),
);

notificationRouter.patch(
  '/:id/read',
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: Request<{ id: string }>, res: Response) => {
    sendSuccess(res, await service.markRead(requireUser(req).id, req.params.id));
  }),
);
