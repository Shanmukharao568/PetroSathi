import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { Router, type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import { ipKeyGenerator, rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { authenticate, requireUser } from '../../middleware/auth.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import { env, isTest } from '../../config/env.js';
import { AUDIO_EXTENSIONS } from '../../utils/audioFormat.js';
import { audioDir, deleteAudio } from '../../jobs/audioCleanup.js';
import { mkdirSync } from 'node:fs';
import { languageCatalog, transcribeUpload } from './voice.service.js';

const languageFieldSchema = z
  .string()
  .trim()
  .regex(/^(auto|[a-z]{2,3}-[A-Z]{2})$/, 'language must be "auto" or a code like hi-IN')
  .optional();

/** Random server-side file names: the client name is never used on disk. */
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => {
      const dir = audioDir();
      mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${randomUUID()}${AUDIO_EXTENSIONS[ext] ? ext : '.bin'}`);
    },
  }),
  limits: { fileSize: env.MAX_AUDIO_SIZE_MB * 1024 * 1024, files: 1, fields: 5, fieldSize: 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!AUDIO_EXTENSIONS[ext]) {
      cb(ApiError.unsupportedMedia('Unsupported file type. Upload an MP3 (or WAV, OGG, FLAC, M4A, AAC) file.'));
      return;
    }
    cb(null, true);
  },
});

/** Runs multer and converts its errors into ApiErrors (multer removes partial files itself). */
function receiveAudio(req: Request, res: Response, next: NextFunction) {
  upload.single('audio')(req, res, (err: unknown) => {
    if (!err) return next();
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') return next(ApiError.payloadTooLarge(`Audio files must be ${env.MAX_AUDIO_SIZE_MB} MB or smaller`));
      return next(ApiError.badRequest(`Upload error: ${err.message}`));
    }
    next(err);
  });
}

const voiceLimiter = rateLimit({
  windowMs: 60_000,
  limit: isTest ? 1000 : 20,
  // Per authenticated user; IP fallback normalised to the /56 subnet for IPv6 (library helper).
  keyGenerator: (req) => req.user?.id ?? ipKeyGenerator(req.ip ?? '0.0.0.0'),
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (_req, res) =>
    res.status(429).json({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many transcription requests. Wait a minute and try again.' } }),
});

export const voiceRouter = Router();
voiceRouter.use(authenticate());

voiceRouter.get('/languages', (_req, res) => {
  sendSuccess(res, languageCatalog());
});

voiceRouter.post(
  '/transcribe',
  voiceLimiter,
  receiveAudio,
  asyncHandler(async (req: Request, res: Response) => {
    const file = req.file;
    const lang = languageFieldSchema.safeParse(req.body?.language);
    if (!lang.success) {
      // Validation failed after upload: the service is skipped, so delete the file here.
      await deleteAudio(file?.path);
      throw ApiError.validation(lang.error.issues.map((i) => ({ location: 'body', path: 'language', message: i.message })));
    }
    const result = await transcribeUpload(file, lang.data ?? env.DEFAULT_LANGUAGE, requireUser(req).id);
    sendSuccess(res, result, 201);
  }),
);
