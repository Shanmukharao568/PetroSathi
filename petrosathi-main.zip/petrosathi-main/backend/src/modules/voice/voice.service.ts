import { ConversationModel } from '../conversations/conversation.model.js';
import { evonMode, getPrismaProvider, getTtsProvider } from '../../providers/gnani/index.js';
import { ProviderError, type TranscriptionResult } from '../../providers/gnani/prisma.types.js';
import { AUTO_LANGUAGE, autoDetectionAvailable, languageRegistry, resolveSttLanguage, supportLevel } from '../../config/languages.js';
import { ApiError } from '../../utils/ApiError.js';
import { deleteAudio } from '../../jobs/audioCleanup.js';
import { detectAudioFormatOfFile } from '../../utils/audioFormat.js';
import { env } from '../../config/env.js';
import { logger } from '../../utils/logger.js';

/** Documented Prisma REST limit (docs.gnani.ai/api/STT/limits.md). */
export const MAX_UPLOAD_AUDIO_SECONDS = 30;

export function languageCatalog() {
  const tts = getTtsProvider();
  return {
    providerMode: env.AI_PROVIDER_MODE,
    extractionMode: evonMode(),
    tts: tts ? { available: true, provider: tts.id, model: tts.model, voice: tts.voice } : { available: false },
    autoDetection: autoDetectionAvailable(),
    defaultLanguage: env.DEFAULT_LANGUAGE,
    maxUploadSeconds: MAX_UPLOAD_AUDIO_SECONDS,
    maxUploadMb: env.MAX_AUDIO_SIZE_MB,
    maxStreamSeconds: env.VOICE_MAX_STREAM_SECONDS,
    languages: languageRegistry().map((l) => ({ ...l, supportLevel: supportLevel(l) })),
  };
}

/** Maps provider failures to API errors without leaking provider internals or credentials. */
export function toApiError(err: unknown): ApiError {
  if (err instanceof ApiError) return err;
  if (err instanceof ProviderError) {
    switch (err.kind) {
      case 'timeout':
        return ApiError.providerTimeout('The speech service took too long to respond. Please try again.');
      case 'rejected':
        return new ApiError(422, 'AUDIO_REJECTED', speechRejectionMessage(err.providerCode, err.message), { providerCode: err.providerCode });
      case 'auth':
        logger.error({ providerCode: err.providerCode }, 'Gnani rejected the configured credentials');
        return ApiError.provider('The speech service is not configured correctly. Contact your administrator.');
      case 'rate_limited':
        return ApiError.unavailable('The speech service is busy. Please try again in a moment.');
      default:
        return ApiError.provider('The speech service is unavailable right now. Please try again or type your report.');
    }
  }
  logger.error({ err }, 'Unexpected transcription error');
  return new ApiError(500, 'INTERNAL_ERROR', 'Transcription failed unexpectedly');
}

function speechRejectionMessage(code: string | undefined, fallback: string): string {
  switch (code) {
    case 'MAX_AUDIO_DURATION_EXCEEDED':
      return `The recording is longer than ${MAX_UPLOAD_AUDIO_SECONDS} seconds. Upload a shorter clip or use push-to-talk.`;
    case 'EMPTY_AUDIO':
      return 'The audio file contains no sound.';
    case 'UNSUPPORTED_AUDIO_FORMAT':
    case 'AUDIO_CONVERSION_ERROR':
      return 'The audio file could not be decoded. Upload a valid MP3 file.';
    case 'INVALID_LANGUAGE_CODE':
    case 'MODEL_UNSUPPORTED_LANGUAGE':
      return 'The selected language is not supported by the speech service.';
    default:
      return fallback;
  }
}

export interface SaveConversationInput {
  userId: string;
  audioMode: 'upload' | 'stream';
  requestedLanguage: string;
  result: TranscriptionResult;
  segmentCount?: number;
  audioDurationMs?: number | null;
}

export async function saveConversation(input: SaveConversationInput) {
  const { result } = input;
  const language = result.detectedLanguage ?? (input.requestedLanguage === AUTO_LANGUAGE ? null : input.requestedLanguage);
  const conv = await ConversationModel.create({
    userId: input.userId,
    audioMode: input.audioMode,
    requestedLanguage: input.requestedLanguage,
    language,
    provider: result.provider,
    model: result.model,
    providerRequestId: result.requestId,
    transcript: result.transcript,
    truncated: result.truncated,
    segmentCount: input.segmentCount ?? (result.transcript ? 1 : 0),
    audioDurationMs: input.audioDurationMs ?? null,
    messages: result.transcript ? [{ role: 'operator', text: result.transcript }] : [],
  });
  return conv;
}

export function conversationResponse(conv: Awaited<ReturnType<typeof saveConversation>>) {
  return {
    conversationId: String(conv._id),
    transcript: conv.transcript,
    language: conv.language,
    requestedLanguage: conv.requestedLanguage,
    provider: conv.provider,
    model: conv.model,
    truncated: conv.truncated,
    audioMode: conv.audioMode,
    audioDurationMs: conv.audioDurationMs,
    segmentCount: conv.segmentCount,
  };
}

/**
 * MP3 (or other documented format) → transcript. The temporary file is ALWAYS deleted,
 * whether transcription succeeds, fails, or times out.
 */
export async function transcribeUpload(file: { path: string } | undefined, requestedLanguage: string, userId: string) {
  try {
    if (!file) throw ApiError.badRequest('Attach an audio file in the "audio" field');

    const format = await detectAudioFormatOfFile(file.path);
    if (!format) throw ApiError.unsupportedMedia('The file is not a recognised audio file. Upload an MP3 recording.');

    const languageCode = resolveSttLanguage(requestedLanguage, 'rest');
    if (!languageCode) {
      throw ApiError.badRequest(
        requestedLanguage === AUTO_LANGUAGE
          ? 'Automatic language detection is not available with the current speech configuration. Select a language.'
          : `Language ${requestedLanguage} is not supported for speech recognition`,
      );
    }

    let result: TranscriptionResult;
    try {
      // Canonical extension: Prisma detects the format from the file name.
      result = await getPrismaProvider().transcribeFile({ filePath: file.path, fileName: `audio.${format}`, languageCode });
    } catch (err) {
      throw toApiError(err);
    }

    const conv = await saveConversation({ userId, audioMode: 'upload', requestedLanguage, result });
    return conversationResponse(conv);
  } finally {
    await deleteAudio(file?.path);
  }
}
