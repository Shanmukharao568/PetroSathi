import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';
import { EQUIPMENT_TYPES } from '../../config/constants.js';

export const DOCUMENT_TYPES = ['manual', 'safety', 'troubleshooting', 'inspection', 'other'] as const;
export type DocumentType = (typeof DOCUMENT_TYPES)[number];
export const INGESTION_STATUSES = ['pending', 'processing', 'ready', 'failed'] as const;
export type IngestionStatus = (typeof INGESTION_STATUSES)[number];

const documentSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 200 },
    /** Original file name, sanitised; display only. */
    fileName: { type: String, required: true, maxlength: 255 },
    documentType: { type: String, enum: DOCUMENT_TYPES, required: true, index: true },
    equipmentIds: { type: [{ type: Schema.Types.ObjectId, ref: 'Equipment' }], default: [] },
    equipmentTypes: { type: [{ type: String, enum: EQUIPMENT_TYPES }], default: [] },
    /** null for preloaded knowledge-base documents. */
    uploadedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    source: { type: String, enum: ['preloaded', 'upload'], required: true, index: true },
    /** File reference: "gridfs:<id>" (MongoDB GridFS) or a legacy filesystem path. Never sent to clients. */
    storagePath: { type: String, required: true },
    /** Preloaded documents only: path inside knowledge-base/ (e.g. "manuals/pump.pdf"). */
    kbPath: { type: String, default: null, index: true },
    sizeBytes: { type: Number, required: true },
    checksum: { type: String, required: true, unique: true },

    ingestionStatus: { type: String, enum: INGESTION_STATUSES, default: 'pending', index: true },
    ingestionError: { type: String, default: null, maxlength: 1000 },
    ingestionAttempts: { type: Number, default: 0 },
    pageCount: { type: Number, default: null },
    chunkCount: { type: Number, default: null },
    /** Section headings detected during extraction (for display). */
    sections: { type: [String], default: [] },
    embeddingModel: { type: String, default: null },
    ingestedAt: { type: Date, default: null },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.storagePath;
        delete ret.kbPath;
        return ret;
      },
    },
  },
);

documentSchema.index({ createdAt: -1 });

export type KnowledgeDocument = InferSchemaType<typeof documentSchema>;
export type KnowledgeDocumentDoc = HydratedDocument<KnowledgeDocument>;
export const DocumentModel = model('Document', documentSchema, 'documents');
