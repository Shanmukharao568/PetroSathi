import { createReadStream } from 'node:fs';
import { readFile } from 'node:fs/promises';
import type { Readable } from 'node:stream';
import mongoose from 'mongoose';

/**
 * PDF storage in MongoDB GridFS (bucket "documentFiles"), so files survive hosts whose disk is
 * wiped on restart. A document's `storagePath` is a reference: "gridfs:<ObjectId>" for files
 * stored here, or a plain filesystem path for documents created before GridFS (still readable).
 */
const PREFIX = 'gridfs:';
const BUCKET = 'documentFiles';

function bucket() {
  const db = mongoose.connection.db;
  if (!db) throw new Error('MongoDB is not connected');
  return new mongoose.mongo.GridFSBucket(db, { bucketName: BUCKET });
}

function gridId(ref: string) {
  return ref.startsWith(PREFIX) ? new mongoose.Types.ObjectId(ref.slice(PREFIX.length)) : null;
}

/** Stores the bytes and returns the reference to keep in `storagePath`. */
export async function saveFile(buf: Buffer, fileName: string): Promise<string> {
  const upload = bucket().openUploadStream(fileName, { metadata: { contentType: 'application/pdf' } });
  await new Promise<void>((resolve, reject) => {
    upload.once('finish', () => resolve());
    upload.once('error', reject);
    upload.end(buf);
  });
  return `${PREFIX}${String(upload.id)}`;
}

export async function readStoredFile(ref: string): Promise<Buffer> {
  const id = gridId(ref);
  if (!id) return readFile(ref);
  const parts: Buffer[] = [];
  for await (const part of bucket().openDownloadStream(id)) parts.push(part as Buffer);
  return Buffer.concat(parts);
}

export function openStoredFile(ref: string): Readable {
  const id = gridId(ref);
  return id ? bucket().openDownloadStream(id) : createReadStream(ref);
}

/** Removes a GridFS file. Filesystem paths are left alone (they belong to the operator). */
export async function deleteStoredFile(ref: string): Promise<void> {
  const id = gridId(ref);
  if (!id) return;
  try {
    await bucket().delete(id);
  } catch (err) {
    if (!/File not found/i.test((err as Error).message)) throw err;
  }
}

export function isGridFsRef(ref: string): boolean {
  return ref.startsWith(PREFIX);
}

/** Number of stored files (tests). */
export async function countStoredFiles(): Promise<number> {
  const db = mongoose.connection.db;
  if (!db) return 0;
  return db.collection(`${BUCKET}.files`).countDocuments();
}
