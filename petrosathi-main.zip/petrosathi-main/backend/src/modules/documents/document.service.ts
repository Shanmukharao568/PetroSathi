import { createHash } from 'node:crypto';
import path from 'node:path';
import type { QueryFilter } from 'mongoose';
import { DocumentModel, type DocumentType, type KnowledgeDocument } from './document.model.js';
import { EquipmentModel } from '../equipment/equipment.model.js';
import type { EquipmentType } from '../../config/constants.js';
import { ApiError } from '../../utils/ApiError.js';
import { escapeRegex } from '../../utils/schemas.js';
import { paginationMeta } from '../../utils/response.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import { enqueueIngestion } from '../../rag/ingestion.js';
import { getVectorStore, vectorStoreLabel } from '../../rag/vectorStore/index.js';
import { deleteStoredFile, isGridFsRef, saveFile } from './fileStore.js';
import { logger } from '../../utils/logger.js';

type Actor = Express.AuthenticatedUser;

export function sha256(buf: Buffer): string {
  return createHash('sha256').update(buf).digest('hex');
}

/** Equipment tags → ids; unknown tags are a client error (never silently dropped). */
export async function resolveEquipmentCodes(codes: string[]) {
  if (!codes.length) return [];
  const found = await EquipmentModel.find({ equipmentCode: { $in: codes } }).select('_id equipmentCode');
  const missing = codes.filter((c) => !found.some((f) => f.equipmentCode === c));
  if (missing.length) throw ApiError.badRequest(`Unknown equipment: ${missing.join(', ')}`);
  return found.map((f) => f._id);
}

export interface UploadInput {
  title: string;
  documentType: DocumentType;
  equipmentCodes: string[];
  equipmentTypes: EquipmentType[];
}

export async function createUploadedDocument(file: { buffer: Buffer; originalname: string; size: number }, input: UploadInput, actor: Actor, ip: string | null) {
  const buf = file.buffer;
  if (buf.subarray(0, 5).toString('latin1') !== '%PDF-') throw ApiError.unsupportedMedia('The file is not a PDF');
  const checksum = sha256(buf);
  const existing = await DocumentModel.findOne({ checksum }).select('_id title');
  if (existing) throw ApiError.conflict(`This file has already been uploaded as "${existing.title}"`, { documentId: String(existing._id) });
  const equipmentIds = await resolveEquipmentCodes(input.equipmentCodes);

  const fileName = path.basename(file.originalname).replace(/[^\w.\- ()]/g, '_').slice(0, 255);
  // Stored in MongoDB GridFS so the file survives hosts with an ephemeral disk.
  const storagePath = await saveFile(buf, fileName);
  let doc;
  try {
    doc = await DocumentModel.create({
      title: input.title,
      fileName,
      documentType: input.documentType,
      equipmentIds,
      equipmentTypes: input.equipmentTypes,
      uploadedBy: actor.id,
      source: 'upload',
      storagePath,
      sizeBytes: file.size,
      checksum,
      ingestionStatus: 'pending',
    });
  } catch (err) {
    await deleteStoredFile(storagePath);
    throw err;
  }
  await recordAudit({ actorId: actor.id, action: AuditActions.DOCUMENT_UPLOADED, entityType: 'Document', entityId: doc._id, metadata: { title: doc.title, documentType: doc.documentType, sizeBytes: doc.sizeBytes }, ip });
  enqueueIngestion(String(doc._id));
  return doc.toJSON();
}

export async function listDocuments(q: { page: number; limit: number; status?: string; documentType?: string; source?: string; search?: string }, actor: Actor) {
  const filter: QueryFilter<KnowledgeDocument> = {};
  // Engineers only see documents that are ready for search; admins see everything.
  if (actor.role !== 'admin') filter.ingestionStatus = 'ready';
  else if (q.status) filter.ingestionStatus = q.status as never;
  if (q.documentType) filter.documentType = q.documentType as never;
  if (q.source) filter.source = q.source as never;
  if (q.search) filter.title = new RegExp(escapeRegex(q.search), 'i');
  const [items, total] = await Promise.all([
    DocumentModel.find(filter).sort({ createdAt: -1 }).skip((q.page - 1) * q.limit).limit(q.limit).populate({ path: 'equipmentIds', select: 'equipmentCode name' }).populate({ path: 'uploadedBy', select: 'name' }),
    DocumentModel.countDocuments(filter),
  ]);
  return { items: items.map((d) => d.toJSON()), meta: paginationMeta(q.page, q.limit, total) };
}

async function loadVisible(id: string, actor: Actor) {
  const doc = await DocumentModel.findById(id);
  if (!doc || (actor.role !== 'admin' && doc.ingestionStatus !== 'ready')) throw ApiError.notFound('Document');
  return doc;
}

export async function getDocument(id: string, actor: Actor) {
  const doc = await loadVisible(id, actor);
  await doc.populate([{ path: 'equipmentIds', select: 'equipmentCode name' }, { path: 'uploadedBy', select: 'name' }]);
  return doc.toJSON();
}

export async function getStatus(id: string) {
  const doc = await DocumentModel.findById(id).select('ingestionStatus ingestionError pageCount chunkCount ingestionAttempts ingestedAt embeddingModel');
  if (!doc) throw ApiError.notFound('Document');
  const j = doc.toJSON() as Record<string, unknown>;
  return { id: j.id, ingestionStatus: j.ingestionStatus, ingestionError: j.ingestionError, pageCount: j.pageCount, chunkCount: j.chunkCount, ingestionAttempts: j.ingestionAttempts, ingestedAt: j.ingestedAt, embeddingModel: j.embeddingModel };
}

export async function reprocessDocument(id: string, actor: Actor, ip: string | null) {
  const doc = await DocumentModel.findById(id);
  if (!doc) throw ApiError.notFound('Document');
  if (doc.ingestionStatus === 'processing' || doc.ingestionStatus === 'pending') throw ApiError.conflict('The document is already queued for processing');
  doc.ingestionStatus = 'pending';
  doc.ingestionError = null;
  await doc.save();
  await recordAudit({ actorId: actor.id, action: AuditActions.DOCUMENT_REPROCESSED, entityType: 'Document', entityId: doc._id, ip });
  enqueueIngestion(String(doc._id));
  return doc.toJSON();
}

/**
 * Removes vectors FIRST: if the vector database is unreachable the delete is refused, so no orphaned
 * vectors can keep being cited after the document is gone.
 */
export async function deleteDocument(id: string, actor: Actor, ip: string | null) {
  const doc = await DocumentModel.findById(id);
  if (!doc) throw ApiError.notFound('Document');
  if (doc.ingestionStatus === 'processing') throw ApiError.conflict('The document is being processed. Try again in a moment.');
  try {
    await getVectorStore().deleteByDocument(String(doc._id));
  } catch (err) {
    logger.error({ err: (err as Error).message }, 'Vector cleanup failed');
    throw ApiError.unavailable(`The vector database (${vectorStoreLabel()}) is unreachable, so the document was not deleted. Try again later.`);
  }
  // GridFS copies are removed; legacy files on disk (e.g. knowledge-base/) stay under your control.
  if (isGridFsRef(doc.storagePath)) await deleteStoredFile(doc.storagePath);
  await doc.deleteOne();
  await recordAudit({ actorId: actor.id, action: AuditActions.DOCUMENT_DELETED, entityType: 'Document', entityId: doc._id, metadata: { title: doc.title, source: doc.source }, ip });
}

export async function getDocumentFile(id: string, actor: Actor) {
  const doc = await loadVisible(id, actor);
  return { ref: doc.storagePath, fileName: doc.fileName };
}
