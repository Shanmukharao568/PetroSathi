import path from 'node:path';
import { Router, type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { authenticate, authorize, requireUser } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema, paginationQuerySchema } from '../../utils/schemas.js';
import { sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import { env } from '../../config/env.js';
import { EQUIPMENT_TYPES } from '../../config/constants.js';
import { equipmentCodeSchema } from '../equipment/equipment.schemas.js';
import { DOCUMENT_TYPES, INGESTION_STATUSES } from './document.model.js';
import * as service from './document.service.js';
import { openStoredFile } from './fileStore.js';

// Held in memory (bounded by MAX_PDF_SIZE_MB) and then stored in MongoDB GridFS.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.MAX_PDF_SIZE_MB * 1024 * 1024, files: 1, fields: 10, fieldSize: 4096 },
  fileFilter: (_req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== '.pdf') return cb(ApiError.unsupportedMedia('Only PDF files can be uploaded'));
    cb(null, true);
  },
});

function receivePdf(req: Request, res: Response, next: NextFunction) {
  upload.single('file')(req, res, (err: unknown) => {
    if (!err) return next();
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') return next(ApiError.payloadTooLarge(`PDF files must be ${env.MAX_PDF_SIZE_MB} MB or smaller`));
      return next(ApiError.badRequest(`Upload error: ${err.message}`));
    }
    next(err);
  });
}

/** Multipart fields arrive as strings; lists are comma-separated. */
const csv = z
  .string()
  .optional()
  .transform((s) => (s ?? '').split(',').map((x) => x.trim()).filter(Boolean));

const uploadFieldsSchema = z.object({
  title: z.string().trim().min(3).max(200),
  documentType: z.enum(DOCUMENT_TYPES),
  equipmentCodes: csv.pipe(z.array(equipmentCodeSchema).max(50)),
  equipmentTypes: csv.pipe(z.array(z.enum(EQUIPMENT_TYPES)).max(13)),
});

const listQuerySchema = paginationQuerySchema.extend({
  status: z.enum(INGESTION_STATUSES).optional(),
  documentType: z.enum(DOCUMENT_TYPES).optional(),
  source: z.enum(['preloaded', 'upload']).optional(),
  search: z.string().trim().max(100).optional(),
});

type IdReq = Request<{ id: string }>;
const ip = (req: Request) => req.ip ?? null;

export const documentRouter = Router();
documentRouter.use(authenticate());

documentRouter.post(
  '/',
  authorize('admin'),
  receivePdf,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.file) throw ApiError.badRequest('Attach a PDF in the "file" field');
    const fields = uploadFieldsSchema.safeParse(req.body);
    if (!fields.success) {
      throw ApiError.validation(fields.error.issues.map((i) => ({ location: 'body', path: i.path.join('.'), message: i.message })));
    }
    // 202: ingestion continues in the background; poll GET /documents/:id/status.
    sendSuccess(res, await service.createUploadedDocument(req.file, fields.data, requireUser(req), ip(req)), 202);
  }),
);

documentRouter.get(
  '/',
  authorize('admin', 'engineer'),
  validate({ query: listQuerySchema }),
  asyncHandler(async (req: Request, res: Response) => {
    const { items, meta } = await service.listDocuments(res.locals.query as z.infer<typeof listQuerySchema>, requireUser(req));
    sendSuccess(res, items, 200, { pagination: meta });
  }),
);

documentRouter.get(
  '/:id',
  authorize('admin', 'engineer'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.getDocument(req.params.id, requireUser(req)))),
);

documentRouter.get(
  '/:id/status',
  authorize('admin'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.getStatus(req.params.id))),
);

/** Protected file access (no public static route): admins and engineers only. */
documentRouter.get(
  '/:id/file',
  authorize('admin', 'engineer'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => {
    const f = await service.getDocumentFile(req.params.id, requireUser(req));
    const stream = openStoredFile(f.ref);
    stream.once('error', () => {
      if (!res.headersSent) res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'File is missing on the server' } });
      else res.destroy();
    });
    // Headers go out only once the first bytes arrive, so a missing file can still return 404.
    stream.once('data', () => {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${f.fileName.replace(/"/g, '')}"`);
      res.setHeader('Cache-Control', 'private, no-store');
    });
    stream.pipe(res);
  }),
);

documentRouter.post(
  '/:id/reprocess',
  authorize('admin'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => sendSuccess(res, await service.reprocessDocument(req.params.id, requireUser(req), ip(req)), 202)),
);

documentRouter.delete(
  '/:id',
  authorize('admin'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req: IdReq, res: Response) => {
    await service.deleteDocument(req.params.id, requireUser(req), ip(req));
    res.status(204).end();
  }),
);
