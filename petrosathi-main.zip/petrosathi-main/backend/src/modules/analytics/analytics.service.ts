import { Types, type PipelineStage } from 'mongoose';
import { TicketModel } from '../tickets/ticket.model.js';
import { EquipmentModel } from '../equipment/equipment.model.js';
import { UserModel } from '../users/user.model.js';
import { DocumentModel } from '../documents/document.model.js';
import { ComplaintDraftModel } from '../complaints/draft.model.js';
import { SEVERITIES, TICKET_STATUSES, COMPLAINT_CATEGORIES, ROLES, type TicketStatus } from '../../config/constants.js';
import { env } from '../../config/env.js';

/**
 * Every figure here is computed from MongoDB at request time — no cached or demo values.
 * Time buckets use ANALYTICS_TIMEZONE.
 */

export interface Range {
  from: Date;
  to: Date;
}

const ACTIVE: TicketStatus[] = ['OPEN', 'UNDER_INSPECTION', 'IN_PROGRESS'];
const HOUR = 3600_000;

/** Offset (ms) of `tz` from UTC at the given instant, e.g. +19_800_000 for Asia/Kolkata. */
function tzOffsetMs(at: Date, tz: string): number {
  const name = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'longOffset' }).formatToParts(at).find((p) => p.type === 'timeZoneName')?.value ?? 'GMT';
  const m = name.match(/GMT([+-])(\d{2}):?(\d{2})?/);
  if (!m) return 0;
  return (m[1] === '-' ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3] ?? 0)) * 60_000;
}

/**
 * A calendar day "YYYY-MM-DD" interpreted in ANALYTICS_TIMEZONE (the same zone used for
 * monthly buckets), so a range never spills into a neighbouring month.
 */
export function zonedDayBounds(day: string, tz = env.ANALYTICS_TIMEZONE): { start: Date; end: Date } {
  const [y, m, d] = day.split('-').map(Number) as [number, number, number];
  const utcMidnight = Date.UTC(y, m - 1, d);
  const start = new Date(utcMidnight - tzOffsetMs(new Date(utcMidnight), tz));
  const nextUtc = Date.UTC(y, m - 1, d + 1);
  const end = new Date(nextUtc - tzOffsetMs(new Date(nextUtc), tz) - 1);
  return { start, end };
}

/** Default range: the last 12 calendar months up to now. */
export function defaultRange(now = new Date()): Range {
  const from = new Date(now);
  from.setMonth(from.getMonth() - 11, 1);
  from.setHours(0, 0, 0, 0);
  return { from, to: now };
}

const toCounts = <K extends string>(keys: readonly K[], rows: { _id: string; n: number }[]) =>
  Object.fromEntries(keys.map((k) => [k, rows.find((r) => r._id === k)?.n ?? 0])) as Record<K, number>;

/** "YYYY-MM" keys from `from` to `to` inclusive (in ANALYTICS_TIMEZONE). */
export function monthKeys(r: Range): string[] {
  const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: env.ANALYTICS_TIMEZONE, year: 'numeric', month: '2-digit' });
  const key = (d: Date) => fmt.format(d).slice(0, 7);
  const keys: string[] = [];
  const cursor = new Date(r.from);
  cursor.setDate(15); // mid-month avoids timezone edge cases when stepping
  while (key(cursor) <= key(r.to)) {
    keys.push(key(cursor));
    cursor.setMonth(cursor.getMonth() + 1);
  }
  return keys;
}

async function resolutionStats(match: Record<string, unknown>) {
  const rows = await TicketModel.aggregate<{ _id: string | null; avgMs: number; n: number }>([
    // $and, not a spread: spreading would let `resolvedAt: {$ne: null}` overwrite a resolvedAt range.
    { $match: { $and: [match, { resolvedAt: { $ne: null } }] } },
    { $project: { severity: 1, ms: { $subtract: ['$resolvedAt', '$createdAt'] } } },
    {
      $facet: {
        overall: [{ $group: { _id: null, avgMs: { $avg: '$ms' }, n: { $sum: 1 } } }],
        bySeverity: [{ $group: { _id: '$severity', avgMs: { $avg: '$ms' }, n: { $sum: 1 } } }],
      },
    },
    { $project: { all: { $concatArrays: ['$overall', '$bySeverity'] } } },
    { $unwind: '$all' },
    { $replaceRoot: { newRoot: '$all' } },
  ]);
  const overall = rows.find((r) => r._id === null);
  return {
    averageHours: overall ? Number((overall.avgMs / HOUR).toFixed(1)) : null,
    resolvedCount: overall?.n ?? 0,
    bySeverity: SEVERITIES.map((s) => {
      const r = rows.find((x) => x._id === s);
      return { severity: s, averageHours: r ? Number((r.avgMs / HOUR).toFixed(1)) : null, resolvedCount: r?.n ?? 0 };
    }),
  };
}

// ------------------------------------------------------------------ overview (admin)

export async function overview(r: Range) {
  const inRange = { createdAt: { $gte: r.from, $lte: r.to } };
  const [byStatus, bySeverityActive, unassigned, createdInRange, resolvedInRange, bySource, users, equipment, documents, chunks, openDrafts, resolution] = await Promise.all([
    TicketModel.aggregate<{ _id: string; n: number }>([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    TicketModel.aggregate<{ _id: string; n: number }>([{ $match: { status: { $in: ACTIVE } } }, { $group: { _id: '$severity', n: { $sum: 1 } } }]),
    TicketModel.countDocuments({ status: { $in: ACTIVE }, assignedTo: null }),
    TicketModel.countDocuments(inRange),
    TicketModel.countDocuments({ resolvedAt: { $gte: r.from, $lte: r.to } }),
    TicketModel.aggregate<{ _id: string; n: number }>([{ $match: inRange }, { $group: { _id: '$source', n: { $sum: 1 } } }]),
    UserModel.aggregate<{ _id: { role: string; active: boolean }; n: number }>([{ $group: { _id: { role: '$role', active: '$isActive' }, n: { $sum: 1 } } }]),
    EquipmentModel.aggregate<{ _id: string; n: number }>([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    DocumentModel.aggregate<{ _id: string; n: number }>([{ $group: { _id: '$ingestionStatus', n: { $sum: 1 } } }]),
    DocumentModel.aggregate<{ n: number }>([{ $match: { ingestionStatus: 'ready' } }, { $group: { _id: null, n: { $sum: '$chunkCount' } } }]),
    ComplaintDraftModel.countDocuments({ state: { $in: ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION'] } }),
    resolutionStats({ resolvedAt: { $gte: r.from, $lte: r.to } }),
  ]);
  const status = toCounts(TICKET_STATUSES, byStatus);
  return {
    range: r,
    tickets: {
      total: Object.values(status).reduce((a, b) => a + b, 0),
      active: ACTIVE.reduce((n, s) => n + (status[s as keyof typeof status] ?? 0), 0),
      byStatus: status,
      activeBySeverity: toCounts(SEVERITIES, bySeverityActive),
      unassignedActive: unassigned,
      createdInRange,
      resolvedInRange,
      bySource: toCounts(['voice', 'manual'] as const, bySource),
    },
    resolution,
    users: Object.fromEntries(
      ROLES.map((role) => [
        role,
        {
          active: users.find((u) => u._id.role === role && u._id.active)?.n ?? 0,
          inactive: users.find((u) => u._id.role === role && !u._id.active)?.n ?? 0,
        },
      ]),
    ),
    equipment: { total: equipment.reduce((a, b) => a + b.n, 0), byStatus: Object.fromEntries(equipment.map((e) => [e._id, e.n])) },
    documents: { byStatus: toCounts(['pending', 'processing', 'ready', 'failed'] as const, documents), indexedPassages: chunks[0]?.n ?? 0 },
    openComplaintDrafts: openDrafts,
  };
}

// ------------------------------------------------------------------ tickets (admin)

export async function ticketAnalytics(r: Range) {
  const tz = env.ANALYTICS_TIMEZONE;
  const inRange = { createdAt: { $gte: r.from, $lte: r.to } };
  const [created, resolved, byStatus, bySeverity, byCategory, resolution] = await Promise.all([
    TicketModel.aggregate<{ _id: string; n: number }>([
      { $match: inRange },
      { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$createdAt', timezone: tz } }, n: { $sum: 1 } } },
    ]),
    TicketModel.aggregate<{ _id: string; n: number }>([
      { $match: { resolvedAt: { $gte: r.from, $lte: r.to } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$resolvedAt', timezone: tz } }, n: { $sum: 1 } } },
    ]),
    TicketModel.aggregate<{ _id: string; n: number }>([{ $match: inRange }, { $group: { _id: '$status', n: { $sum: 1 } } }]),
    TicketModel.aggregate<{ _id: string; n: number }>([{ $match: inRange }, { $group: { _id: '$severity', n: { $sum: 1 } } }]),
    TicketModel.aggregate<{ _id: string; n: number }>([{ $match: inRange }, { $group: { _id: '$category', n: { $sum: 1 } } }]),
    resolutionStats({ resolvedAt: { $gte: r.from, $lte: r.to } }),
  ]);
  return {
    range: r,
    timezone: tz,
    monthly: monthKeys(r).map((month) => ({
      month,
      created: created.find((c) => c._id === month)?.n ?? 0,
      resolved: resolved.find((c) => c._id === month)?.n ?? 0,
    })),
    byStatus: toCounts(TICKET_STATUSES, byStatus),
    bySeverity: toCounts(SEVERITIES, bySeverity),
    byCategory: toCounts(COMPLAINT_CATEGORIES, byCategory),
    resolution,
  };
}

// ------------------------------------------------------------------ equipment (admin)

export async function equipmentAnalytics(r: Range, limit = 10) {
  const inRange = { createdAt: { $gte: r.from, $lte: r.to } };
  const lookup: PipelineStage[] = [
    { $lookup: { from: 'equipment', localField: '_id', foreignField: '_id', as: 'eq' } },
    { $unwind: { path: '$eq', preserveNullAndEmptyArrays: true } },
  ];
  const [top, recurring, byType] = await Promise.all([
    TicketModel.aggregate([
      { $match: inRange },
      {
        $group: {
          _id: '$equipmentId',
          code: { $first: '$equipmentCode' },
          total: { $sum: 1 },
          active: { $sum: { $cond: [{ $in: ['$status', ACTIVE] }, 1, 0] } },
          critical: { $sum: { $cond: [{ $eq: ['$severity', 'critical'] }, 1, 0] } },
        },
      },
      { $sort: { total: -1, code: 1 } },
      { $limit: limit },
      ...lookup,
      { $project: { _id: 0, equipmentId: '$_id', equipmentCode: { $ifNull: ['$eq.equipmentCode', '$code'] }, name: '$eq.name', type: '$eq.type', total: 1, active: 1, critical: 1 } },
    ]),
    // Recurring issues: the same equipment reported 2+ times in the range.
    TicketModel.aggregate([
      { $match: inRange },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: '$equipmentId',
          code: { $first: '$equipmentCode' },
          count: { $sum: 1 },
          lastReportedAt: { $first: '$createdAt' },
          categories: { $addToSet: '$category' },
          symptoms: { $push: '$symptoms' },
        },
      },
      { $match: { count: { $gte: 2 } } },
      { $sort: { count: -1, lastReportedAt: -1 } },
      { $limit: limit },
      ...lookup,
      {
        $project: {
          _id: 0,
          equipmentId: '$_id',
          equipmentCode: { $ifNull: ['$eq.equipmentCode', '$code'] },
          name: '$eq.name',
          type: '$eq.type',
          count: 1,
          lastReportedAt: 1,
          categories: 1,
          symptoms: { $reduce: { input: '$symptoms', initialValue: [], in: { $concatArrays: ['$$value', '$$this'] } } },
        },
      },
    ]),
    TicketModel.aggregate<{ _id: string | null; n: number }>([
      { $match: inRange },
      { $lookup: { from: 'equipment', localField: 'equipmentId', foreignField: '_id', as: 'eq' } },
      { $unwind: { path: '$eq', preserveNullAndEmptyArrays: true } },
      { $group: { _id: '$eq.type', n: { $sum: 1 } } },
      { $sort: { n: -1 } },
    ]),
  ]);

  // Most frequent symptoms per recurring equipment (computed here to keep the pipeline readable).
  const recurringIssues = (recurring as { symptoms: string[] }[]).map((row) => {
    const freq = new Map<string, number>();
    for (const s of row.symptoms) freq.set(s, (freq.get(s) ?? 0) + 1);
    return {
      ...row,
      symptoms: undefined,
      topSymptoms: [...freq].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([symptom, count]) => ({ symptom, count })),
    };
  });

  return {
    range: r,
    topEquipment: top,
    recurringIssues,
    byEquipmentType: byType.map((t) => ({ type: t._id ?? 'unknown', count: t.n })),
  };
}

// ------------------------------------------------------------------ helpers shared with dashboards

export function activeStatuses() {
  return ACTIVE;
}

export function oid(id: string) {
  return new Types.ObjectId(id);
}
