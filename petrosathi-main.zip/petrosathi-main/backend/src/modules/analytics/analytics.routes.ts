import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { authenticate, authorize, requireUser } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import { defaultRange, equipmentAnalytics, overview, ticketAnalytics, zonedDayBounds, type Range } from './analytics.service.js';
import { dashboardFor } from './dashboard.service.js';

const rangeQuerySchema = z.object({
  from: z.iso.date().optional(),
  to: z.iso.date().optional(),
  limit: z.coerce.number().int().min(1).max(50).optional(),
});

function rangeFrom(q: z.infer<typeof rangeQuerySchema>): Range {
  const def = defaultRange();
  // Days are interpreted in ANALYTICS_TIMEZONE, matching the monthly buckets.
  const from = q.from ? zonedDayBounds(q.from).start : def.from;
  const to = q.to ? zonedDayBounds(q.to).end : def.to;
  if (from > to) throw ApiError.badRequest('"from" must be before "to"');
  if (to.getTime() - from.getTime() > 5 * 366 * 24 * 3600_000) throw ApiError.badRequest('Range cannot exceed 5 years');
  return { from, to };
}

export const analyticsRouter = Router();
analyticsRouter.use(authenticate(), authorize('admin'));

analyticsRouter.get(
  '/overview',
  validate({ query: rangeQuerySchema }),
  asyncHandler(async (_req: Request, res: Response) => sendSuccess(res, await overview(rangeFrom(res.locals.query)))),
);
analyticsRouter.get(
  '/tickets',
  validate({ query: rangeQuerySchema }),
  asyncHandler(async (_req: Request, res: Response) => sendSuccess(res, await ticketAnalytics(rangeFrom(res.locals.query)))),
);
analyticsRouter.get(
  '/equipment',
  validate({ query: rangeQuerySchema }),
  asyncHandler(async (_req: Request, res: Response) => {
    const q = res.locals.query as z.infer<typeof rangeQuerySchema>;
    sendSuccess(res, await equipmentAnalytics(rangeFrom(q), q.limit ?? 10));
  }),
);

/** Role-specific dashboard (any signed-in role). */
export const dashboardRouter = Router();
dashboardRouter.get(
  '/',
  authenticate(),
  asyncHandler(async (req: Request, res: Response) => sendSuccess(res, await dashboardFor(requireUser(req)))),
);
