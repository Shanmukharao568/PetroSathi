import { TicketModel } from '../tickets/ticket.model.js';
import { ComplaintDraftModel } from '../complaints/draft.model.js';
import { NotificationModel } from '../notifications/notification.model.js';
import { AuditLogModel } from '../audit/auditLog.model.js';
import { UserModel } from '../users/user.model.js';
import { activeStatuses, defaultRange, oid, overview } from './analytics.service.js';
import { TICKET_STATUSES } from '../../config/constants.js';

type Actor = Express.AuthenticatedUser;

const TICKET_SUMMARY = 'ticketNumber equipmentCode description severity status category assignedTo createdAt updatedAt';

async function statusCounts(match: Record<string, unknown>) {
  const rows = await TicketModel.aggregate<{ _id: string; n: number }>([{ $match: match }, { $group: { _id: '$status', n: { $sum: 1 } } }]);
  return Object.fromEntries(TICKET_STATUSES.map((s) => [s, rows.find((r) => r._id === s)?.n ?? 0])) as Record<(typeof TICKET_STATUSES)[number], number>;
}

/** Latest history events (status/assignment) for the given tickets, newest first. */
async function recentActivity(match: Record<string, unknown>, limit = 10) {
  const rows = await TicketModel.aggregate<{
    ticketId: string;
    ticketNumber: string;
    equipmentCode: string;
    event: { type: string; at: Date; fromStatus: string | null; toStatus: string | null; actor: string; comment: string | null };
  }>([
    { $match: match },
    { $project: { ticketNumber: 1, equipmentCode: 1, history: { $slice: ['$history', -10] } } },
    { $unwind: '$history' },
    { $sort: { 'history.at': -1 } },
    { $limit: limit },
    { $project: { _id: 0, ticketId: '$_id', ticketNumber: 1, equipmentCode: 1, event: '$history' } },
  ]);
  const actors = await UserModel.find({ _id: { $in: [...new Set(rows.map((r) => String(r.event.actor)))] } }).select('name');
  const names = new Map(actors.map((a) => [String(a._id), a.name]));
  return rows.map((r) => ({
    ticketId: String(r.ticketId),
    ticketNumber: r.ticketNumber,
    equipmentCode: r.equipmentCode,
    type: r.event.type,
    at: r.event.at,
    fromStatus: r.event.fromStatus,
    toStatus: r.event.toStatus,
    actorName: names.get(String(r.event.actor)) ?? 'Unknown',
    comment: r.event.comment,
  }));
}

async function recentNotifications(userId: string, limit = 5) {
  const items = await NotificationModel.find({ userId }).sort({ createdAt: -1 }).limit(limit);
  return items.map((n) => n.toJSON());
}

async function operatorDashboard(actor: Actor) {
  const mine = { reportedBy: oid(actor.id) };
  const [counts, recentTickets, drafts, notifications] = await Promise.all([
    statusCounts(mine),
    TicketModel.find(mine).sort({ updatedAt: -1 }).limit(5).select(TICKET_SUMMARY).populate({ path: 'assignedTo', select: 'name' }),
    ComplaintDraftModel.find({ userId: actor.id, state: { $in: ['DRAFT', 'NEEDS_INFORMATION', 'READY_FOR_CONFIRMATION'] }, expiresAt: { $gt: new Date() } })
      .sort({ updatedAt: -1 })
      .limit(3)
      .select('state fields.equipmentCode fields.description updatedAt expiresAt'),
    recentNotifications(actor.id),
  ]);
  const active = activeStatuses().reduce((n, s) => n + counts[s as keyof typeof counts], 0);
  return {
    role: 'operator' as const,
    counts: { total: Object.values(counts).reduce((a, b) => a + b, 0), active, resolved: counts.RESOLVED + counts.CLOSED, byStatus: counts },
    recentTickets: recentTickets.map((t) => t.toJSON()),
    openDrafts: drafts.map((d) => {
      const j = d.toJSON() as Record<string, unknown>;
      return { id: j.id, state: d.state, equipmentCode: d.fields?.equipmentCode ?? null, description: d.fields?.description ?? '', updatedAt: (j as { updatedAt: Date }).updatedAt, expiresAt: d.expiresAt };
    }),
    notifications,
  };
}

async function engineerDashboard(actor: Actor) {
  const me = oid(actor.id);
  const active = { $in: activeStatuses() };
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 3600_000);
  const [assigned, criticalAssigned, unassigned, unassignedCritical, resolvedByMe, queue, activity, notifications] = await Promise.all([
    statusCounts({ assignedTo: me }),
    TicketModel.countDocuments({ assignedTo: me, status: active, severity: 'critical' }),
    TicketModel.countDocuments({ assignedTo: null, status: active }),
    TicketModel.countDocuments({ assignedTo: null, status: active, severity: 'critical' }),
    TicketModel.countDocuments({ 'resolution.resolvedBy': me, resolvedAt: { $gte: thirtyDaysAgo } }),
    // Work queue: my active tickets plus unassigned ones, most severe first.
    TicketModel.aggregate([
      { $match: { status: active, $or: [{ assignedTo: me }, { assignedTo: null }] } },
      { $addFields: { _rank: { $indexOfArray: [['critical', 'high', 'medium', 'low', 'unknown'], '$severity'] } } },
      { $sort: { _rank: 1, createdAt: 1 } },
      { $limit: 8 },
      { $project: { _id: 0, id: { $toString: '$_id' }, ticketNumber: 1, equipmentCode: 1, description: 1, severity: 1, status: 1, assignedToMe: { $eq: ['$assignedTo', me] }, createdAt: 1 } },
    ]),
    recentActivity({ $or: [{ assignedTo: me }, { assignedTo: null, status: active }] }),
    recentNotifications(actor.id),
  ]);
  return {
    role: 'engineer' as const,
    counts: {
      assignedTotal: Object.values(assigned).reduce((a, b) => a + b, 0),
      open: assigned.OPEN,
      underInspection: assigned.UNDER_INSPECTION,
      inProgress: assigned.IN_PROGRESS,
      resolved: assigned.RESOLVED,
      closed: assigned.CLOSED,
      criticalAssigned,
      unassigned,
      unassignedCritical,
      resolvedByMeLast30Days: resolvedByMe,
    },
    queue,
    recentActivity: activity,
    notifications,
  };
}

async function adminDashboard() {
  const [summary, audit, activity] = await Promise.all([
    overview(defaultRange()),
    AuditLogModel.find({}).sort({ createdAt: -1 }).limit(8).populate({ path: 'actorId', select: 'name role' }),
    recentActivity({}, 8),
  ]);
  return { role: 'admin' as const, summary, recentAudit: audit.map((a) => a.toJSON()), recentActivity: activity };
}

/** One endpoint, role-specific content. Operators only ever see their own data. */
export async function dashboardFor(actor: Actor) {
  if (actor.role === 'operator') return operatorDashboard(actor);
  if (actor.role === 'engineer') return engineerDashboard(actor);
  return adminDashboard();
}
