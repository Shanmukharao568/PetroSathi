import { Schema, model, type HydratedDocument, type InferSchemaType } from 'mongoose';
import { COMPLAINT_CATEGORIES, SEVERITIES, TICKET_STATUSES } from '../../config/constants.js';

export const HISTORY_EVENT_TYPES = ['created', 'status_changed', 'assigned', 'unassigned', 'resolution_updated'] as const;

/** Append-only record of significant transitions. */
const historySchema = new Schema(
  {
    type: { type: String, enum: HISTORY_EVENT_TYPES, required: true },
    actor: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    at: { type: Date, required: true, default: () => new Date() },
    fromStatus: { type: String, enum: [...TICKET_STATUSES, null], default: null },
    toStatus: { type: String, enum: [...TICKET_STATUSES, null], default: null },
    fromAssignee: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    toAssignee: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    comment: { type: String, maxlength: 2000, default: null },
  },
  { _id: true },
);

const commentSchema = new Schema(
  {
    author: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    body: { type: String, required: true, trim: true, maxlength: 4000 },
    createdAt: { type: Date, required: true, default: () => new Date() },
  },
  { _id: true },
);

const resolutionSchema = new Schema(
  {
    summary: { type: String, trim: true, maxlength: 4000, required: true },
    rootCause: { type: String, trim: true, maxlength: 2000, default: '' },
    actionsTaken: { type: String, trim: true, maxlength: 4000, default: '' },
    resolvedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    resolvedAt: { type: Date, required: true },
  },
  { _id: false },
);

const ticketSchema = new Schema(
  {
    ticketNumber: { type: String, required: true, unique: true },
    equipmentId: { type: Schema.Types.ObjectId, ref: 'Equipment', required: true, index: true },
    /** Snapshot so the ticket remains readable even if the equipment record is renamed. */
    equipmentCode: { type: String, required: true },
    reportedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    assignedTo: { type: Schema.Types.ObjectId, ref: 'User', default: null, index: true },

    description: { type: String, required: true, trim: true, maxlength: 4000 },
    symptoms: { type: [{ type: String, trim: true, maxlength: 200 }], default: [] },
    category: { type: String, enum: COMPLAINT_CATEGORIES, required: true, index: true },
    severity: { type: String, enum: SEVERITIES, required: true, index: true },
    status: { type: String, enum: TICKET_STATUSES, default: 'OPEN', index: true },

    /** Original operator transcript (voice tickets) — never machine-rewritten. */
    transcript: { type: String, maxlength: 10000, default: null },
    language: { type: String, default: null },
    source: { type: String, enum: ['manual', 'voice'], required: true, default: 'manual' },
    complaintDraftId: { type: Schema.Types.ObjectId, ref: 'ComplaintDraft', default: null },
    conversationId: { type: Schema.Types.ObjectId, ref: 'Conversation', default: null },
    /** Client-supplied key; with reportedBy it makes ticket creation idempotent. */
    idempotencyKey: { type: String, default: null },

    resolution: { type: resolutionSchema, default: null },
    history: { type: [historySchema], default: [] },
    comments: { type: [commentSchema], default: [] },
    resolvedAt: { type: Date, default: null },
    closedAt: { type: Date, default: null },
  },
  {
    timestamps: true,
    toJSON: {
      versionKey: false,
      transform: (_doc, ret: Record<string, unknown>) => {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.idempotencyKey;
        return ret;
      },
    },
  },
);

ticketSchema.index({ createdAt: -1 });
ticketSchema.index({ status: 1, severity: 1, createdAt: -1 });
ticketSchema.index(
  { reportedBy: 1, idempotencyKey: 1 },
  { unique: true, partialFilterExpression: { idempotencyKey: { $type: 'string' } } },
);

export type Ticket = InferSchemaType<typeof ticketSchema>;
export type TicketDocument = HydratedDocument<Ticket>;
export const TicketModel = model('MaintenanceTicket', ticketSchema, 'maintenance_tickets');
