import type { Request, Response } from 'express';
import { requireUser } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/response.js';
import { ApiError } from '../../utils/ApiError.js';
import * as service from './ticket.service.js';
import {
  idempotencyKeySchema,
  type AssignBody,
  type CommentBody,
  type CreateTicketBody,
  type ListTicketsQuery,
  type StatusBody,
} from './ticket.schemas.js';

type IdReq = Request<{ id: string }>;

export async function create(req: Request, res: Response) {
  const header = req.header('Idempotency-Key');
  if (!header) throw ApiError.badRequest('Idempotency-Key header is required to create a ticket');
  const key = idempotencyKeySchema.safeParse(header);
  if (!key.success) throw ApiError.badRequest(key.error.issues[0]!.message);

  const body = req.body as CreateTicketBody;
  const { ticket, created } = await service.createTicket(
    { ...body, source: 'manual' },
    requireUser(req),
    key.data,
    req.ip ?? null,
  );
  // 201 on first creation, 200 when the same key is replayed (no duplicate ticket).
  sendSuccess(res, ticket, created ? 201 : 200, { idempotentReplay: !created });
}

export async function list(req: Request, res: Response) {
  const { items, meta } = await service.listTickets(res.locals.query as ListTicketsQuery, requireUser(req));
  sendSuccess(res, items, 200, { pagination: meta });
}

export async function getById(req: IdReq, res: Response) {
  sendSuccess(res, await service.getTicket(req.params.id, requireUser(req)));
}

export async function history(req: IdReq, res: Response) {
  sendSuccess(res, await service.getHistory(req.params.id, requireUser(req)));
}

export async function assign(req: IdReq, res: Response) {
  sendSuccess(res, await service.assignTicket(req.params.id, req.body as AssignBody, requireUser(req), req.ip ?? null));
}

export async function status(req: IdReq, res: Response) {
  sendSuccess(res, await service.changeStatus(req.params.id, req.body as StatusBody, requireUser(req), req.ip ?? null));
}

export async function comment(req: IdReq, res: Response) {
  sendSuccess(res, await service.addComment(req.params.id, req.body as CommentBody, requireUser(req), req.ip ?? null), 201);
}
