import { z } from 'zod';
import { COMPLAINT_CATEGORIES, SEVERITIES, TICKET_STATUSES } from '../../config/constants.js';
import { objectIdSchema, paginationQuerySchema } from '../../utils/schemas.js';
import { equipmentCodeSchema } from '../equipment/equipment.schemas.js';

/** Comma-separated multi-value query param, e.g. status=OPEN,IN_PROGRESS */
const csvEnum = <T extends readonly [string, ...string[]]>(values: T) =>
  z
    .string()
    .transform((s) => s.split(',').map((v) => v.trim()).filter(Boolean))
    .pipe(z.array(z.enum(values)).min(1));

export const idempotencyKeySchema = z
  .string()
  .trim()
  .min(8, 'Idempotency-Key must be 8–128 characters')
  .max(128, 'Idempotency-Key must be 8–128 characters')
  .regex(/^[A-Za-z0-9_-]+$/, 'Idempotency-Key may contain letters, digits, "-" and "_" only');

/**
 * Manual complaint → ticket. Either equipmentId or equipmentCode identifies the equipment.
 * Severity "unknown" is valid: the reporter must not be forced to guess.
 */
export const createTicketBodySchema = z
  .object({
    equipmentId: objectIdSchema.optional(),
    equipmentCode: equipmentCodeSchema.optional(),
    description: z.string().trim().min(10, 'Describe the problem in at least 10 characters').max(4000),
    symptoms: z.array(z.string().trim().min(1).max(200)).max(20).default([]),
    category: z.enum(COMPLAINT_CATEGORIES).default('other'),
    severity: z.enum(SEVERITIES).default('unknown'),
    /** Voice report: the server copies the ORIGINAL transcript from this conversation. */
    conversationId: objectIdSchema.optional(),
  })
  .strict()
  .refine((b) => !!b.equipmentId !== !!b.equipmentCode, {
    message: 'Provide exactly one of equipmentId or equipmentCode',
    path: ['equipmentId'],
  });
export type CreateTicketBody = z.infer<typeof createTicketBodySchema>;

export const listTicketsQuerySchema = paginationQuerySchema.extend({
  scope: z.enum(['all', 'assigned', 'unassigned', 'reported']).default('all'),
  status: csvEnum(TICKET_STATUSES).optional(),
  severity: csvEnum(SEVERITIES).optional(),
  category: z.enum(COMPLAINT_CATEGORIES).optional(),
  equipmentId: objectIdSchema.optional(),
  assignedTo: objectIdSchema.optional(),
  search: z.string().trim().max(100).optional(),
  sort: z.enum(['newest', 'oldest', 'severity']).default('newest'),
});
export type ListTicketsQuery = z.infer<typeof listTicketsQuerySchema>;

export const assignBodySchema = z
  .object({ assigneeId: objectIdSchema.nullable(), comment: z.string().trim().max(2000).optional() })
  .strict();
export type AssignBody = z.infer<typeof assignBodySchema>;

export const statusBodySchema = z
  .object({
    status: z.enum(TICKET_STATUSES),
    comment: z.string().trim().max(2000).optional(),
    resolution: z
      .object({
        summary: z.string().trim().min(5).max(4000),
        rootCause: z.string().trim().max(2000).optional(),
        actionsTaken: z.string().trim().max(4000).optional(),
      })
      .strict()
      .optional(),
  })
  .strict();
export type StatusBody = z.infer<typeof statusBodySchema>;

export const commentBodySchema = z.object({ body: z.string().trim().min(1).max(4000) }).strict();
export type CommentBody = z.infer<typeof commentBodySchema>;
