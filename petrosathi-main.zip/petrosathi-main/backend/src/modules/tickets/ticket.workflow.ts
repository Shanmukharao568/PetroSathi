import type { Role, TicketStatus } from '../../config/constants.js';

/**
 * Ticket lifecycle. Anything not listed here is an invalid transition.
 *
 *   OPEN ─▶ UNDER_INSPECTION ─▶ IN_PROGRESS ─▶ RESOLVED ─▶ CLOSED
 *     └──────────────────────────▲   ▲   │           │
 *                                └───┘   │ (back to   │ (reopen)
 *                    UNDER_INSPECTION ◀──┘ inspection)│
 *                                IN_PROGRESS ◀────────┘
 *
 * UNDER_INSPECTION → RESOLVED is allowed for "inspected, no fault / no work required".
 * CLOSED is terminal.
 */
export const TRANSITIONS: Record<TicketStatus, readonly TicketStatus[]> = {
  OPEN: ['UNDER_INSPECTION', 'IN_PROGRESS'],
  UNDER_INSPECTION: ['IN_PROGRESS', 'RESOLVED'],
  IN_PROGRESS: ['UNDER_INSPECTION', 'RESOLVED'],
  RESOLVED: ['CLOSED', 'IN_PROGRESS'],
  CLOSED: [],
};

export function canTransition(from: TicketStatus, to: TicketStatus): boolean {
  return TRANSITIONS[from].includes(to);
}

export interface TicketPermissionContext {
  actorId: string;
  actorRole: Role;
  reportedBy: string;
  assignedTo: string | null;
  status: TicketStatus;
}

export interface TicketPermissions {
  view: boolean;
  comment: boolean;
  /** Engineer may take an unassigned ticket. */
  accept: boolean;
  /** Admin may assign/reassign to any engineer. */
  assign: boolean;
  /** Assigned engineer may hand the ticket back to the queue. */
  release: boolean;
  changeStatus: boolean;
  allowedTransitions: TicketStatus[];
}

/** Single source of truth for who can do what — used by the service AND sent to the UI. */
export function ticketPermissions(c: TicketPermissionContext): TicketPermissions {
  const isAdmin = c.actorRole === 'admin';
  const isEngineer = c.actorRole === 'engineer';
  const isReporter = c.reportedBy === c.actorId;
  const isAssignee = c.assignedTo === c.actorId;
  const closed = c.status === 'CLOSED';

  const view = isAdmin || isEngineer || isReporter;
  const changeStatus = !closed && c.assignedTo !== null && (isAdmin || (isEngineer && isAssignee));

  return {
    view,
    comment: view && !closed,
    accept: isEngineer && c.assignedTo === null && !closed,
    assign: isAdmin && !closed,
    release: isEngineer && isAssignee && c.status === 'OPEN',
    changeStatus,
    allowedTransitions: changeStatus ? [...TRANSITIONS[c.status]] : [],
  };
}
