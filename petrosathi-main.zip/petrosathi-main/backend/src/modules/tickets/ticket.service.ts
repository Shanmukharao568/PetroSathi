import { Types, type QueryFilter } from 'mongoose';
import { TicketModel, type Ticket } from './ticket.model.js';
import { nextSequence } from './counter.model.js';
import { canTransition, ticketPermissions, type TicketPermissions } from './ticket.workflow.js';
import { EquipmentModel } from '../equipment/equipment.model.js';
import { UserModel } from '../users/user.model.js';
import { ConversationModel } from '../conversations/conversation.model.js';
import { notify } from '../notifications/notification.service.js';
import { AuditActions, recordAudit } from '../audit/audit.service.js';
import { ApiError } from '../../utils/ApiError.js';
import { escapeRegex } from '../../utils/schemas.js';
import { paginationMeta } from '../../utils/response.js';
import type { ComplaintCategory, Severity, TicketStatus } from '../../config/constants.js';
import type { AssignBody, CommentBody, ListTicketsQuery, StatusBody } from './ticket.schemas.js';

type Actor = Express.AuthenticatedUser;

const USER_FIELDS = 'name email role';
const EQUIPMENT_FIELDS = 'equipmentCode name type plant location criticality status';

const POPULATE = [
  { path: 'equipmentId', select: EQUIPMENT_FIELDS },
  { path: 'reportedBy', select: USER_FIELDS },
  { path: 'assignedTo', select: USER_FIELDS },
  { path: 'history.actor', select: USER_FIELDS },
  { path: 'history.fromAssignee', select: USER_FIELDS },
  { path: 'history.toAssignee', select: USER_FIELDS },
  { path: 'comments.author', select: USER_FIELDS },
  { path: 'resolution.resolvedBy', select: USER_FIELDS },
];

const SEVERITY_RANK: Record<Severity, number> = { critical: 0, high: 1, medium: 2, low: 3, unknown: 4 };

/** Extracts an id string whether or not the path has been populated. */
function refId(v: unknown): string | null {
  if (!v) return null;
  if (v instanceof Types.ObjectId) return String(v);
  if (typeof v === 'object' && '_id' in v) return String((v as { _id: unknown })._id);
  return String(v);
}

function permissionsFor(t: { reportedBy: unknown; assignedTo?: unknown; status: string }, actor: Actor): TicketPermissions {
  return ticketPermissions({
    actorId: actor.id,
    actorRole: actor.role,
    reportedBy: refId(t.reportedBy)!,
    assignedTo: refId(t.assignedTo),
    status: t.status as TicketStatus,
  });
}

/** Rename populated refs to friendly keys while keeping the raw id fields. */
function toView(doc: InstanceType<typeof TicketModel>, actor: Actor) {
  const json = doc.toJSON() as unknown as Record<string, unknown> & { id: string; ticketNumber: string; equipmentId: unknown; reportedBy: unknown; assignedTo: unknown };
  const { equipmentId, reportedBy, assignedTo, ...rest } = json;
  return {
    ...rest,
    equipmentId: refId(equipmentId),
    equipment: typeof equipmentId === 'object' ? equipmentId : null,
    reportedBy: typeof reportedBy === 'object' ? reportedBy : { id: refId(reportedBy) },
    assignedTo: assignedTo && typeof assignedTo === 'object' ? assignedTo : null,
    permissions: permissionsFor(doc, actor),
  };
}

async function loadVisible(id: string, actor: Actor) {
  const ticket = await TicketModel.findById(id);
  // 404 (not 403) for tickets the actor cannot see, so ticket ids cannot be probed.
  if (!ticket || !permissionsFor(ticket, actor).view) throw ApiError.notFound('Ticket');
  return ticket;
}

async function populated(id: Types.ObjectId | string) {
  const t = await TicketModel.findById(id).populate(POPULATE);
  if (!t) throw ApiError.notFound('Ticket');
  return t;
}

async function activeEngineerIds(): Promise<Types.ObjectId[]> {
  const engineers = await UserModel.find({ role: 'engineer', isActive: true }).select('_id').lean();
  return engineers.map((e) => e._id);
}

// ------------------------------------------------------------------ create

export interface CreateTicketInput {
  equipmentId?: string;
  equipmentCode?: string;
  description: string;
  symptoms: string[];
  category: ComplaintCategory;
  severity: Severity;
  source: 'manual' | 'voice';
  transcript?: string | null;
  language?: string | null;
  complaintDraftId?: string | null;
  conversationId?: string | null;
}

/**
 * Creates a ticket exactly once per (reporter, idempotencyKey).
 * Used directly by POST /tickets and, from Phase 5, by draft confirmation.
 */
export async function createTicket(input: CreateTicketInput, actor: Actor, idempotencyKey: string | null, ip: string | null) {
  if (idempotencyKey) {
    const existing = await TicketModel.findOne({ reportedBy: actor.id, idempotencyKey });
    if (existing) return { ticket: toView(await populated(existing._id), actor), created: false };
  }

  // Voice report: the transcript comes from the stored conversation, never from the client.
  let conversation: Awaited<ReturnType<typeof ConversationModel.findOne>> = null;
  if (input.conversationId) {
    conversation = await ConversationModel.findOne({ _id: input.conversationId, userId: actor.id });
    if (!conversation) throw ApiError.badRequest('Voice conversation not found');
    if (conversation.ticketId) throw ApiError.conflict('This voice recording has already been used for a ticket');
    input = {
      ...input,
      source: 'voice',
      transcript: conversation.transcript,
      language: conversation.language ?? null,
    };
  }

  const equipment = input.equipmentId
    ? await EquipmentModel.findById(input.equipmentId)
    : await EquipmentModel.findOne({ equipmentCode: input.equipmentCode });
  if (!equipment) {
    throw ApiError.badRequest(
      input.equipmentCode ? `Equipment ${input.equipmentCode} is not registered` : 'Equipment not found',
    );
  }
  if (equipment.status === 'decommissioned') {
    throw ApiError.badRequest(`Equipment ${equipment.equipmentCode} is decommissioned`);
  }

  const year = new Date().getUTCFullYear();
  const seq = await nextSequence(`ticket-${year}`);
  const ticketNumber = `TKT-${year}-${String(seq).padStart(5, '0')}`;

  let ticket;
  try {
    ticket = await TicketModel.create({
      ticketNumber,
      equipmentId: equipment._id,
      equipmentCode: equipment.equipmentCode,
      reportedBy: actor.id,
      description: input.description,
      symptoms: input.symptoms,
      category: input.category,
      severity: input.severity,
      status: 'OPEN',
      transcript: input.transcript ?? null,
      language: input.language ?? null,
      source: input.source,
      complaintDraftId: input.complaintDraftId ?? null,
      conversationId: input.conversationId ?? null,
      idempotencyKey,
      history: [{ type: 'created', actor: actor.id, toStatus: 'OPEN' }],
    });
  } catch (err) {
    // Concurrent duplicate with the same idempotency key: return the winner.
    if (idempotencyKey && (err as { code?: number }).code === 11000) {
      const existing = await TicketModel.findOne({ reportedBy: actor.id, idempotencyKey });
      if (existing) return { ticket: toView(await populated(existing._id), actor), created: false };
    }
    throw err;
  }

  if (conversation) {
    await ConversationModel.updateOne({ _id: conversation._id }, { $set: { ticketId: ticket._id } });
  }

  await recordAudit({
    actorId: actor.id,
    action: AuditActions.TICKET_CREATED,
    entityType: 'MaintenanceTicket',
    entityId: ticket._id,
    metadata: { ticketNumber, equipmentCode: equipment.equipmentCode, severity: input.severity, source: input.source },
    ip,
  });
  await notify(await activeEngineerIds(), {
    actorId: actor.id,
    ticketId: ticket._id,
    type: 'ticket_created',
    message: `New ${input.severity === 'unknown' ? '' : `${input.severity} `}ticket ${ticketNumber} on ${equipment.equipmentCode}`,
  });

  return { ticket: toView(await populated(ticket._id), actor), created: true };
}

// ------------------------------------------------------------------ read

export async function listTickets(q: ListTicketsQuery, actor: Actor) {
  const filter: QueryFilter<Ticket> = {};

  if (actor.role === 'operator') {
    // Operators only ever see what they reported, regardless of requested scope.
    filter.reportedBy = new Types.ObjectId(actor.id);
  } else {
    if (q.scope === 'assigned') filter.assignedTo = new Types.ObjectId(actor.id);
    if (q.scope === 'unassigned') filter.assignedTo = null;
    if (q.scope === 'reported') filter.reportedBy = new Types.ObjectId(actor.id);
    if (q.assignedTo && q.scope === 'all') filter.assignedTo = new Types.ObjectId(q.assignedTo);
  }
  if (q.status) filter.status = { $in: q.status };
  if (q.severity) filter.severity = { $in: q.severity };
  if (q.category) filter.category = q.category;
  if (q.equipmentId) filter.equipmentId = new Types.ObjectId(q.equipmentId);
  if (q.search) {
    const rx = new RegExp(escapeRegex(q.search), 'i');
    filter.$or = [{ ticketNumber: rx }, { equipmentCode: rx }, { description: rx }];
  }

  const total = await TicketModel.countDocuments(filter);
  const skip = (q.page - 1) * q.limit;

  let docs;
  if (q.sort === 'severity') {
    // Severity is an enum, not orderable lexically: rank it in an aggregation, then hydrate.
    const ids = await TicketModel.aggregate<{ _id: Types.ObjectId }>([
      { $match: filter },
      {
        $addFields: {
          _rank: {
            $switch: {
              branches: Object.entries(SEVERITY_RANK).map(([k, v]) => ({ case: { $eq: ['$severity', k] }, then: v })),
              default: 9,
            },
          },
        },
      },
      { $sort: { _rank: 1, createdAt: -1 } },
      { $skip: skip },
      { $limit: q.limit },
      { $project: { _id: 1 } },
    ]);
    const byId = new Map(
      (await TicketModel.find({ _id: { $in: ids.map((i) => i._id) } })
        .select('-history -comments -transcript')
        .populate(POPULATE.slice(0, 3))).map((d) => [String(d._id), d]),
    );
    docs = ids.map((i) => byId.get(String(i._id))!).filter(Boolean);
  } else {
    docs = await TicketModel.find(filter)
      .select('-history -comments -transcript')
      .sort({ createdAt: q.sort === 'oldest' ? 1 : -1 })
      .skip(skip)
      .limit(q.limit)
      .populate(POPULATE.slice(0, 3));
  }

  return { items: docs.map((d) => toView(d, actor)), meta: paginationMeta(q.page, q.limit, total) };
}

export async function getTicket(id: string, actor: Actor) {
  await loadVisible(id, actor);
  return toView(await populated(id), actor);
}

export async function getHistory(id: string, actor: Actor) {
  await loadVisible(id, actor);
  const t = await TicketModel.findById(id).select('history ticketNumber').populate(POPULATE.slice(3, 6));
  return t!.toJSON().history;
}

// ------------------------------------------------------------------ assign

export async function assignTicket(id: string, body: AssignBody, actor: Actor, ip: string | null) {
  const ticket = await loadVisible(id, actor);
  const perms = permissionsFor(ticket, actor);
  const current = refId(ticket.assignedTo);
  const target = body.assigneeId;

  if (target === current) throw ApiError.conflict(target ? 'Ticket is already assigned to this engineer' : 'Ticket is already unassigned');

  if (actor.role === 'engineer') {
    const accepting = target === actor.id && perms.accept;
    const releasing = target === null && perms.release;
    if (!accepting && !releasing) {
      throw ApiError.forbidden(
        target === null
          ? 'Only the assigned engineer can release an OPEN ticket'
          : 'Engineers can only accept unassigned tickets for themselves',
      );
    }
  } else if (actor.role === 'admin') {
    if (!perms.assign) throw ApiError.conflict('Closed tickets cannot be reassigned');
    if (target === null && ticket.status !== 'OPEN') {
      throw ApiError.conflict('Only OPEN tickets can be unassigned; reassign it to another engineer instead');
    }
  } else {
    throw ApiError.forbidden();
  }

  if (target) {
    const engineer = await UserModel.findOne({ _id: target, role: 'engineer', isActive: true }).select('_id');
    if (!engineer) throw ApiError.badRequest('Assignee must be an active maintenance engineer');
  }

  // Optimistic concurrency: only apply if nobody changed the assignee in the meantime.
  const updated = await TicketModel.findOneAndUpdate(
    { _id: ticket._id, assignedTo: current ? new Types.ObjectId(current) : null, status: { $ne: 'CLOSED' } },
    {
      $set: { assignedTo: target ? new Types.ObjectId(target) : null },
      $push: {
        history: {
          type: target ? 'assigned' : 'unassigned',
          actor: actor.id,
          at: new Date(),
          fromAssignee: current,
          toAssignee: target,
          comment: body.comment ?? null,
        },
      },
    },
    { returnDocument: 'after' },
  );
  if (!updated) throw ApiError.conflict('The ticket was changed by someone else. Reload and try again.');

  await recordAudit({
    actorId: actor.id,
    action: AuditActions.TICKET_ASSIGNED,
    entityType: 'MaintenanceTicket',
    entityId: ticket._id,
    metadata: { ticketNumber: ticket.ticketNumber, from: current, to: target },
    ip,
  });
  if (target) {
    await notify([target], { actorId: actor.id, ticketId: ticket._id, type: 'ticket_assigned', message: `Ticket ${ticket.ticketNumber} has been assigned to you` });
  }
  if (current && current !== target) {
    await notify([current], { actorId: actor.id, ticketId: ticket._id, type: 'ticket_unassigned', message: `You are no longer assigned to ticket ${ticket.ticketNumber}` });
  }
  await notify([ticket.reportedBy], {
    actorId: actor.id,
    ticketId: ticket._id,
    type: target ? 'ticket_assigned' : 'ticket_unassigned',
    message: target ? `An engineer has been assigned to your ticket ${ticket.ticketNumber}` : `Your ticket ${ticket.ticketNumber} is back in the queue`,
  });

  return toView(await populated(ticket._id), actor);
}

// ------------------------------------------------------------------ status

export async function changeStatus(id: string, body: StatusBody, actor: Actor, ip: string | null) {
  const ticket = await loadVisible(id, actor);
  const perms = permissionsFor(ticket, actor);
  const from = ticket.status as TicketStatus;
  const to = body.status;

  if (!perms.changeStatus) {
    if (!ticket.assignedTo && from !== 'CLOSED') throw ApiError.conflict('Assign the ticket to an engineer before changing its status');
    throw ApiError.forbidden('Only the assigned engineer or an administrator can change this ticket\'s status');
  }
  if (!canTransition(from, to)) {
    throw new ApiError(409, 'INVALID_STATUS_TRANSITION', `Cannot move a ticket from ${from} to ${to}`, {
      from,
      to,
      allowed: perms.allowedTransitions,
    });
  }

  const now = new Date();
  const set: Record<string, unknown> = { status: to };
  if (to === 'RESOLVED') {
    if (!body.resolution) {
      throw ApiError.validation([{ location: 'body', path: 'resolution.summary', message: 'Resolution details are required to resolve a ticket' }]);
    }
    set.resolution = {
      summary: body.resolution.summary,
      rootCause: body.resolution.rootCause ?? '',
      actionsTaken: body.resolution.actionsTaken ?? '',
      resolvedBy: new Types.ObjectId(actor.id),
      resolvedAt: now,
    };
    set.resolvedAt = now;
  }
  if (from === 'RESOLVED' && to === 'IN_PROGRESS') {
    if (!body.comment) {
      throw ApiError.validation([{ location: 'body', path: 'comment', message: 'Give a reason when reopening a resolved ticket' }]);
    }
    set.resolution = null;
    set.resolvedAt = null;
  }
  if (to === 'CLOSED') set.closedAt = now;

  const updated = await TicketModel.findOneAndUpdate(
    { _id: ticket._id, status: from },
    {
      $set: set,
      $push: { history: { type: 'status_changed', actor: actor.id, at: now, fromStatus: from, toStatus: to, comment: body.comment ?? null } },
    },
    { returnDocument: 'after', runValidators: true },
  );
  if (!updated) throw ApiError.conflict('The ticket status was changed by someone else. Reload and try again.');

  await recordAudit({
    actorId: actor.id,
    action: AuditActions.TICKET_STATUS_CHANGED,
    entityType: 'MaintenanceTicket',
    entityId: ticket._id,
    metadata: { ticketNumber: ticket.ticketNumber, from, to },
    ip,
  });
  await notify([ticket.reportedBy, ticket.assignedTo], {
    actorId: actor.id,
    ticketId: ticket._id,
    type: 'ticket_status_changed',
    message: `Ticket ${ticket.ticketNumber} moved from ${from.replace('_', ' ')} to ${to.replace('_', ' ')}`,
  });

  return toView(await populated(ticket._id), actor);
}

// ------------------------------------------------------------------ comments

export async function addComment(id: string, body: CommentBody, actor: Actor, ip: string | null) {
  const ticket = await loadVisible(id, actor);
  if (!permissionsFor(ticket, actor).comment) throw ApiError.conflict('Closed tickets cannot receive new comments');

  const updated = await TicketModel.findByIdAndUpdate(
    ticket._id,
    { $push: { comments: { author: actor.id, body: body.body, createdAt: new Date() } } },
    { returnDocument: 'after' },
  ).populate({ path: 'comments.author', select: USER_FIELDS });
  const comment = updated!.toJSON().comments.at(-1);

  await recordAudit({
    actorId: actor.id,
    action: AuditActions.TICKET_COMMENTED,
    entityType: 'MaintenanceTicket',
    entityId: ticket._id,
    metadata: { ticketNumber: ticket.ticketNumber },
    ip,
  });
  await notify([ticket.reportedBy, ticket.assignedTo], {
    actorId: actor.id,
    ticketId: ticket._id,
    type: 'ticket_commented',
    message: `${actor.name} commented on ticket ${ticket.ticketNumber}`,
  });
  return comment;
}
