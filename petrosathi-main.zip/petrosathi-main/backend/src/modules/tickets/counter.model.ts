import { Schema, model } from 'mongoose';

/** Atomic sequence generator (one document per sequence key, e.g. "ticket-2026"). */
const counterSchema = new Schema({
  _id: { type: String, required: true },
  seq: { type: Number, required: true, default: 0 },
});

export const CounterModel = model('Counter', counterSchema);

export async function nextSequence(key: string): Promise<number> {
  const doc = await CounterModel.findOneAndUpdate(
    { _id: key },
    { $inc: { seq: 1 } },
    { upsert: true, returnDocument: 'after' },
  ).lean();
  return doc!.seq;
}
