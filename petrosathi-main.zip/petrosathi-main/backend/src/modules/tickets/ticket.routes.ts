import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth.js';
import { validate } from '../../middleware/validate.js';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { idParamsSchema } from '../../utils/schemas.js';
import {
  assignBodySchema,
  commentBodySchema,
  createTicketBodySchema,
  listTicketsQuerySchema,
  statusBodySchema,
} from './ticket.schemas.js';
import * as controller from './ticket.controller.js';
import { requireUser } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/response.js';
import { getTicket } from './ticket.service.js';
import { ticketReferences } from '../knowledge/knowledge.service.js';

export const ticketRouter = Router();
ticketRouter.use(authenticate());

// Fine-grained per-ticket rules (reporter / assignee / admin) live in ticket.workflow.ts.
ticketRouter.post('/', validate({ body: createTicketBodySchema }), asyncHandler(controller.create));
ticketRouter.get('/', validate({ query: listTicketsQuerySchema }), asyncHandler(controller.list));
ticketRouter.get('/:id', validate({ params: idParamsSchema }), asyncHandler(controller.getById));
ticketRouter.get('/:id/history', validate({ params: idParamsSchema }), asyncHandler(controller.history));
ticketRouter.post('/:id/comments', validate({ params: idParamsSchema, body: commentBodySchema }), asyncHandler(controller.comment));

/** Manual references (RAG) — fetched on demand by engineers/admins only. */
ticketRouter.get(
  '/:id/references',
  authorize('engineer', 'admin'),
  validate({ params: idParamsSchema }),
  asyncHandler(async (req, res) => {
    await getTicket(req.params.id as string, requireUser(req)); // visibility check
    sendSuccess(res, await ticketReferences(req.params.id as string));
  }),
);

ticketRouter.patch(
  '/:id/assign',
  authorize('engineer', 'admin'),
  validate({ params: idParamsSchema, body: assignBodySchema }),
  asyncHandler(controller.assign),
);
ticketRouter.patch(
  '/:id/status',
  authorize('engineer', 'admin'),
  validate({ params: idParamsSchema, body: statusBodySchema }),
  asyncHandler(controller.status),
);
