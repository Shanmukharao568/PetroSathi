/**
 * Gnani Timbre voice catalog — docs.gnani.ai/api/TTS/available-voices.md (read 2026-11-08).
 * Voices are model-specific: a voice from one model is rejected (400) by the other.
 */
export const TIMBRE_MODELS = ['timbre-v3.0', 'timbre-v2.5'] as const;
export type TimbreModel = (typeof TIMBRE_MODELS)[number];

/** The ten Indian language codes Timbre documents (same codes as Prisma). */
export const TIMBRE_LANGUAGES = ['hi-IN', 'en-IN', 'ta-IN', 'te-IN', 'kn-IN', 'ml-IN', 'mr-IN', 'pa-IN', 'bn-IN', 'gu-IN'] as const;

/** timbre-v3.0: every voice speaks all ten languages. */
export const TIMBRE_V3_VOICES = [
  'Shivani', 'Lakshmi', 'Kalpana', 'Chetana', 'Vasudha', 'Riyaa', 'Tarika',
  'Avinash', 'Shubham', 'Prakash', 'Devansh', 'Yashraj', 'Harshad',
] as const;

/** timbre-v2.5: one preferred language per voice ("hi-en" = Hinglish). Mismatches "may reduce quality". */
export const TIMBRE_V25_VOICES: Record<string, string> = {
  Ambuja: 'hi-IN', Asmita: 'ta-IN', Bhavna: 'hi-IN', Brinda: 'ta-IN', Chitra: 'hi-IN', Deepak: 'hi-IN',
  Devika: 'en-IN', Dhruva: 'bn-IN', Falak: 'gu-IN', Girish: 'en-IN', Hemraj: 'hi-IN', Ishaan: 'mr-IN',
  Jalaj: 'hi-IN', Jwala: 'hi-IN', Kaveri: 'en-IN', Kavin: 'kn-IN', Kirra: 'bn-IN', Lavanya: 'te-IN',
  Lehara: 'te-IN', Mehuli: 'pa-IN', Nalini: 'hi-IN', Noopur: 'ta-IN', Omkar: 'hi-IN', Poorvi: 'hi-en',
  Pranav: 'en-IN', Reshma: 'ml-IN', Riyaan: 'ml-IN', Roopesh: 'hi-IN', Saanvi: 'kn-IN', Shlok: 'en-IN',
  Suhana: 'te-IN', Trisha: 'ta-IN', Trupti: 'en-IN', Urmila: 'hi-IN', Varuni: 'te-IN', Vedika: 'ta-IN',
  Veera: 'gu-IN', Vikrant: 'hi-IN', Yashvi: 'hi-IN', Yukti: 'te-IN', Zahira: 'mr-IN', Zayan: 'pa-IN',
};

export function isValidTimbreVoice(model: string, voice: string): boolean {
  if (model === 'timbre-v3.0') return (TIMBRE_V3_VOICES as readonly string[]).includes(voice);
  if (model === 'timbre-v2.5') return voice in TIMBRE_V25_VOICES;
  return false;
}

/**
 * Languages the configured voice can speak at documented quality.
 * v3.0 → all ten; v2.5 → only the voice's preferred language.
 */
export function timbreLanguagesFor(model: string, voice: string): string[] {
  if (model === 'timbre-v3.0' && isValidTimbreVoice(model, voice)) return [...TIMBRE_LANGUAGES];
  if (model === 'timbre-v2.5' && voice in TIMBRE_V25_VOICES) return [TIMBRE_V25_VOICES[voice]!];
  return [];
}
