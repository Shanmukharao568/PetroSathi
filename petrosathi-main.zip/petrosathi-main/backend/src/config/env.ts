import { config as loadDotenv } from 'dotenv';
import { z } from 'zod';
import { isValidTimbreVoice, TIMBRE_MODELS } from './timbreVoices.js';

loadDotenv({ quiet: true });

/** Treat empty strings from .env as "not set". */
const optionalString = z
  .string()
  .optional()
  .transform((v) => (v === undefined || v.trim() === '' ? undefined : v.trim()));

const optionalUrl = optionalString.pipe(z.url().optional());

const boolString = z
  .enum(['true', 'false'])
  .default('false')
  .transform((v) => v === 'true');

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(5000),
  /** Number of reverse proxies in front of the API (0 = none; X-Forwarded-For ignored). */
  TRUST_PROXY: z.coerce.number().int().min(0).max(10).default(0),
  /** Swagger UI at /api/docs. Default: on outside production, off in production. */
  ENABLE_API_DOCS: optionalString.pipe(z.enum(['true', 'false']).optional()).transform((v) => (v === undefined ? undefined : v === 'true')),
  CLIENT_URL: z.url().default('http://localhost:5173'),
  API_BASE_URL: z.url().default('http://localhost:5000/api/v1'),

  MONGODB_URI: z.string().min(1).default('mongodb://localhost:27017/petrosathi'),

  JWT_SECRET: z.string().min(32, 'JWT_SECRET must be at least 32 characters'),
  JWT_EXPIRES_IN: z.string().default('1d'),
  BCRYPT_SALT_ROUNDS: z.coerce.number().int().min(10).max(15).default(12),

  SEED_ADMIN_EMAIL: optionalString,
  SEED_ADMIN_PASSWORD: optionalString,
  SEED_DEMO_USER_PASSWORD: optionalString,

  GNANI_API_KEY_ID: optionalString,
  GNANI_API_KEY_SECRET: optionalString,
  GNANI_PRISMA_STT_URL: optionalUrl,
  GNANI_PRISMA_WS_URL: optionalUrl,
  GNANI_PRISMA_MODEL: optionalString,
  GNANI_EVON_API_URL: optionalUrl,
  GNANI_EVON_MODEL: optionalString,
  GNANI_TIMBRE_API_URL: optionalUrl,
  GNANI_TIMBRE_MODEL: optionalString,
  GNANI_TIMBRE_VOICE: optionalString,

  AI_PROVIDER_MODE: z.enum(['mock', 'real']).default('mock'),
  /**
   * Evon mode, defaults to AI_PROVIDER_MODE. "real" is currently rejected at startup because
   * Gnani publishes no Evon API contract; set "mock" explicitly to run Prisma for real with a
   * clearly-labelled mock extractor.
   */
  EVON_PROVIDER_MODE: optionalString.pipe(z.enum(['mock', 'real']).optional()),
  COMPLAINT_DRAFT_TTL_HOURS: z.coerce.number().int().min(1).max(168).default(24),
  GNANI_REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().default(30000),
  GNANI_MAX_RETRIES: z.coerce.number().int().min(0).max(5).default(2),

  /** Where vectors live: "chroma" (local ChromaDB server) or "mongo" (MongoDB Atlas Vector Search). */
  VECTOR_STORE: z.enum(['chroma', 'mongo']).default('chroma'),
  /** Name of the Atlas vectorSearch index (VECTOR_STORE=mongo); created by `npm run vector:index`. */
  MONGO_VECTOR_INDEX: z.string().min(1).default('vector_index'),
  CHROMA_URL: z.url().default('http://localhost:8000'),
  CHROMA_COLLECTION_NAME: z.string().default('petrosathi_knowledge'),
  /**
   * "local": open multilingual model run in-process with transformers.js (no API key).
   * "gemini": Google Gemini embeddings API (EMBEDDING_API_KEY); for hosts with little RAM.
   * "mock": deterministic hashed bag-of-words for automated tests only — not semantic.
   */
  EMBEDDING_PROVIDER: optionalString.pipe(z.enum(['local', 'gemini', 'mock']).optional()).transform((v) => v ?? 'local'),
  /**
   * local: Hugging Face model id (ONNX), default chosen by the Phase 6 benchmark (docs/EMBEDDING_BENCHMARK.md).
   * gemini: Gemini embedding model, default gemini-embedding-001.
   */
  EMBEDDING_MODEL: optionalString,
  /** gemini only: output vector size (Matryoshka truncation). 768 keeps quality with small storage. */
  EMBEDDING_DIMENSIONS: z.coerce.number().int().min(128).max(3072).default(768),
  MODEL_CACHE_DIR: z.string().default('./.models'),
  /** gemini: API key from Google AI Studio (sent as the x-goog-api-key header). */
  EMBEDDING_API_KEY: optionalString,
  /** gemini: API base URL; empty = https://generativelanguage.googleapis.com/v1beta */
  EMBEDDING_BASE_URL: optionalUrl,
  RAG_TOP_K: z.coerce.number().int().min(1).max(50).default(5),
  RAG_MIN_RELEVANCE_SCORE: optionalString.transform((v, ctx) => {
    if (v === undefined) return undefined;
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0 || n > 1) {
      ctx.addIssue({ code: 'custom', message: 'must be a number between 0 and 1' });
      return z.NEVER;
    }
    return n;
  }),
  RAG_CHUNK_SIZE: z.coerce.number().int().min(100).default(1000),
  RAG_CHUNK_OVERLAP: z.coerce.number().int().min(0).default(200),

  UPLOAD_DIR: z.string().default('./uploads'),
  DOCUMENT_UPLOAD_DIR: z.string().default('./uploads/documents'),
  AUDIO_UPLOAD_DIR: z.string().default('./uploads/audio'),
  MAX_AUDIO_SIZE_MB: z.coerce.number().positive().default(20),
  MAX_PDF_SIZE_MB: z.coerce.number().positive().default(25),
  /** Ingestion refuses PDFs with more pages (protects the single ingestion worker). */
  MAX_PDF_PAGES: z.coerce.number().int().min(1).max(20000).default(2000),
  AUDIO_RETENTION_MINUTES: z.coerce.number().int().positive().default(30),
  /** App-level cap for one push-to-talk recording (provider session limit is 15 min). */
  VOICE_MAX_STREAM_SECONDS: z.coerce.number().int().min(5).max(900).default(120),

  /** IANA timezone used to bucket analytics by day/month. */
  ANALYTICS_TIMEZONE: z.string().default('Asia/Kolkata'),
  DEFAULT_LANGUAGE: z.string().default('en-IN'),
  ENABLE_LANGUAGE_AUTO_DETECTION: boolString,

  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),

  /**
   * Users must confirm their email with a one-time code once, on first sign-in.
   * Set "false" to switch the requirement off (e.g. an offline demo).
   */
  EMAIL_VERIFICATION_REQUIRED: z
    .enum(['true', 'false'])
    .default('true')
    .transform((v) => v === 'true'),
  /** Public sign-up page. New accounts are always Field Operators and must verify their email. */
  SELF_REGISTRATION_ENABLED: z
    .enum(['true', 'false'])
    .default('true')
    .transform((v) => v === 'true'),
  EMAIL_OTP_TTL_MINUTES: z.coerce.number().int().min(2).max(60).default(10),
  EMAIL_OTP_MAX_ATTEMPTS: z.coerce.number().int().min(3).max(10).default(5),
  EMAIL_OTP_RESEND_SECONDS: z.coerce.number().int().min(15).max(600).default(60),
  /**
   * Outgoing mail (SMTP). When SMTP_HOST is not set, codes are written to the server log in
   * development; production refuses to start without SMTP while verification is required.
   */
  SMTP_HOST: optionalString,
  SMTP_PORT: z.coerce.number().int().positive().default(587),
  /** "true" = TLS from the first byte (usually port 465); "false" = STARTTLS upgrade (587). */
  SMTP_SECURE: boolString,
  SMTP_USER: optionalString,
  SMTP_PASS: optionalString,
  MAIL_FROM: optionalString,
});

export type Env = z.infer<typeof envSchema>;

/**
 * Real-provider requirements. In `real` mode these MUST be present — we never silently
 * downgrade to mock. Evon/Timbre requirements are enforced when those adapters land
 * (Phase 5) so that Phase 4 can be exercised with Prisma alone.
 *
 * Per docs.gnani.ai (checked 2026-11-08) the STT APIs authenticate with the single header
 * `X-API-Key-ID`; no secret header is documented, so GNANI_API_KEY_SECRET is not required.
 */
const REAL_MODE_REQUIRED: (keyof Env)[] = ['GNANI_API_KEY_ID', 'GNANI_PRISMA_STT_URL', 'GNANI_PRISMA_WS_URL'];

export class EnvValidationError extends Error {
  constructor(public readonly problems: string[]) {
    super(`Invalid environment configuration:\n  - ${problems.join('\n  - ')}`);
    this.name = 'EnvValidationError';
  }
}

export function parseEnv(source: NodeJS.ProcessEnv): Env {
  const result = envSchema.safeParse(source);
  if (!result.success) {
    // Report variable names and messages only — never echo values (may be secrets).
    throw new EnvValidationError(
      result.error.issues.map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`),
    );
  }
  const env = result.data;
  const problems: string[] = [];

  if (env.AI_PROVIDER_MODE === 'real') {
    for (const key of REAL_MODE_REQUIRED) {
      if (env[key] === undefined) problems.push(`${key}: required when AI_PROVIDER_MODE=real`);
    }
  }
  // Evon: no silent fallback. Real mode needs a documented contract, which does not exist yet.
  if ((env.EVON_PROVIDER_MODE ?? env.AI_PROVIDER_MODE) === 'real') {
    problems.push(
      'EVON_PROVIDER_MODE: real Evon integration is unavailable (Gnani publishes no Evon API documentation). ' +
        'Set EVON_PROVIDER_MODE=mock explicitly to use the labelled mock extractor.',
    );
  }

  // Email codes must really be delivered in production; the log fallback is for development only.
  if (env.NODE_ENV === 'production' && env.EMAIL_VERIFICATION_REQUIRED && !env.SMTP_HOST) {
    problems.push('SMTP_HOST: required in production while EMAIL_VERIFICATION_REQUIRED=true (codes must be emailed)');
  }
  if (env.SMTP_HOST && !env.MAIL_FROM && !env.SMTP_USER) {
    problems.push('MAIL_FROM: required when SMTP_HOST is set without SMTP_USER (sender address)');
  }
  if ((env.SMTP_USER === undefined) !== (env.SMTP_PASS === undefined)) {
    problems.push('SMTP_USER / SMTP_PASS: set both or neither');
  }

  // Timbre TTS is optional. If any Timbre setting is given in real mode, all must be valid.
  const timbre = [env.GNANI_TIMBRE_API_URL, env.GNANI_TIMBRE_MODEL, env.GNANI_TIMBRE_VOICE];
  if (env.AI_PROVIDER_MODE === 'real' && timbre.some((v) => v !== undefined)) {
    if (!env.GNANI_TIMBRE_API_URL) problems.push('GNANI_TIMBRE_API_URL: required when Timbre TTS is configured');
    if (!env.GNANI_TIMBRE_MODEL || !(TIMBRE_MODELS as readonly string[]).includes(env.GNANI_TIMBRE_MODEL)) {
      problems.push(`GNANI_TIMBRE_MODEL: must be one of ${TIMBRE_MODELS.join(', ')}`);
    } else if (!env.GNANI_TIMBRE_VOICE || !isValidTimbreVoice(env.GNANI_TIMBRE_MODEL, env.GNANI_TIMBRE_VOICE)) {
      problems.push(`GNANI_TIMBRE_VOICE: not a documented voice for ${env.GNANI_TIMBRE_MODEL}`);
    }
  }

  if (env.EMBEDDING_PROVIDER === 'gemini' && !env.EMBEDDING_API_KEY) {
    problems.push('EMBEDDING_API_KEY: required when EMBEDDING_PROVIDER=gemini');
  }
  // Without a calibrated threshold every question would be answered from the closest manual.
  if (env.NODE_ENV === 'production' && env.EMBEDDING_PROVIDER === 'gemini' && env.RAG_MIN_RELEVANCE_SCORE === undefined) {
    problems.push('RAG_MIN_RELEVANCE_SCORE: required in production with EMBEDDING_PROVIDER=gemini (get it from npm run rag:calibrate)');
  }
  if (env.RAG_CHUNK_OVERLAP >= env.RAG_CHUNK_SIZE) {
    problems.push('RAG_CHUNK_OVERLAP: must be smaller than RAG_CHUNK_SIZE');
  }
  if (env.NODE_ENV === 'production' && env.JWT_SECRET.startsWith('replace_with')) {
    problems.push('JWT_SECRET: placeholder value is not allowed in production');
  }
  if (problems.length) throw new EnvValidationError(problems);
  return env;
}

export const env: Env = parseEnv(process.env);
export const isTest = env.NODE_ENV === 'test';
export const isProd = env.NODE_ENV === 'production';
