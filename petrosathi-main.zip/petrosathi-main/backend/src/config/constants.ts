export const ROLES = ['operator', 'engineer', 'admin'] as const;
export type Role = (typeof ROLES)[number];

/** Password policy shared by user creation, change and reset. */
export const PASSWORD_MIN_LENGTH = 10;
export const PASSWORD_MAX_LENGTH = 128;

/** BCP-47-ish language tag, e.g. "en-IN", "hi-IN". Validated against the registry in Phase 4. */
export const LANGUAGE_TAG_REGEX = /^[a-z]{2,3}(-[A-Z]{2})?$/;

/** Profile photo: a base64 data URL of a small raster image (~90 KB of image data at most). */
export const AVATAR_MAX_CHARS = 120_000;
export const AVATAR_DATA_URL_REGEX = /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/;

// ---------- Equipment ----------
export const EQUIPMENT_TYPES = [
  'pump',
  'compressor',
  'heat_exchanger',
  'valve',
  'motor',
  'turbine',
  'separator',
  'tank',
  'vessel',
  'pipeline',
  'instrument',
  'generator',
  'other',
] as const;
export type EquipmentType = (typeof EQUIPMENT_TYPES)[number];

export const EQUIPMENT_CRITICALITY = ['low', 'medium', 'high', 'critical'] as const;
export const EQUIPMENT_STATUS = ['operational', 'degraded', 'down', 'under_maintenance', 'decommissioned'] as const;

/** Codes like P-101, HX-301A, FV-2201. Stored upper-case. */
export const EQUIPMENT_CODE_REGEX = /^[A-Z0-9]{1,6}-[A-Z0-9]{1,10}$/;

// ---------- Complaints / tickets ----------
export const COMPLAINT_CATEGORIES = ['mechanical', 'electrical', 'instrumentation', 'process', 'safety', 'other'] as const;
export type ComplaintCategory = (typeof COMPLAINT_CATEGORIES)[number];

export const SEVERITIES = ['low', 'medium', 'high', 'critical', 'unknown'] as const;
export type Severity = (typeof SEVERITIES)[number];

export const TICKET_STATUSES = ['OPEN', 'UNDER_INSPECTION', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'] as const;
export type TicketStatus = (typeof TICKET_STATUSES)[number];
