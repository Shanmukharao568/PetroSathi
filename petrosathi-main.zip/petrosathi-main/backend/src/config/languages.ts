import { env } from './env.js';
import { getEvonProvider, getTtsProvider } from '../providers/gnani/index.js';

/**
 * Language capability registry.
 *
 * - prismaSTT / prismaStreaming: docs.gnani.ai/api/STT/languages.md (read 2026-11-08).
 * - evonInput / evonOutput: languages the CONFIGURED extractor implements. Gnani Evon has no
 *   public documentation, so in practice this is the labelled mock's keyword lexicon
 *   (en/hi/te/ta); the catalog reports which provider that is.
 * - timbreTTS: languages the configured Timbre voice is documented to speak; false whenever
 *   TTS is not configured (always false in mock mode — there is no mock speech).
 */
export interface LanguageCapability {
  code: string;
  displayName: string;
  nativeName: string;
  prismaSTT: boolean;
  prismaStreaming: boolean;
  evonInput: boolean;
  evonOutput: boolean;
  timbreTTS: boolean;
  /** Can be recognised by "indic-auto" detection. */
  autoDetection: boolean;
}

export type SupportLevel = 'full_voice' | 'speech_recognition_only' | 'text_response' | 'tts' | 'unsupported';

/** Prisma STT languages — same list for REST and streaming, Prisma v2.5 and v3.0. */
const PRISMA_LANGUAGES: [code: string, displayName: string, nativeName: string][] = [
  ['bn-IN', 'Bengali', 'বাংলা'],
  ['en-IN', 'English (India)', 'English'],
  ['gu-IN', 'Gujarati', 'ગુજરાતી'],
  ['hi-IN', 'Hindi', 'हिन्दी'],
  ['kn-IN', 'Kannada', 'ಕನ್ನಡ'],
  ['ml-IN', 'Malayalam', 'മലയാളം'],
  ['mr-IN', 'Marathi', 'मराठी'],
  ['pa-IN', 'Punjabi', 'ਪੰਜਾਬੀ'],
  ['ta-IN', 'Tamil', 'தமிழ்'],
  ['te-IN', 'Telugu', 'తెలుగు'],
];

/** Provider value meaning "detect among supported Indic languages". Prisma v3.0 only. */
export const AUTO_DETECT_CODE = 'indic-auto';
/** Application-level token the UI sends for auto-detection. */
export const AUTO_LANGUAGE = 'auto';

/** Auto-detection and code-mix output are documented for Prisma v3.0 only. */
export function prismaV3Configured(): boolean {
  return env.GNANI_PRISMA_MODEL === 'prisma-v3.0';
}

export function autoDetectionAvailable(): boolean {
  // Mock mode simulates v3 behaviour so the UI flow can be exercised; it is labelled as mock.
  const providerSupports = env.AI_PROVIDER_MODE === 'mock' || prismaV3Configured();
  return env.ENABLE_LANGUAGE_AUTO_DETECTION && providerSupports;
}

export function languageRegistry(): LanguageCapability[] {
  const auto = autoDetectionAvailable();
  const evon = new Set(getEvonProvider().supportedLanguages);
  const tts = new Set(getTtsProvider()?.languages ?? []);
  return PRISMA_LANGUAGES.map(([code, displayName, nativeName]) => ({
    code,
    displayName,
    nativeName,
    prismaSTT: true,
    prismaStreaming: true,
    evonInput: evon.has(code),
    evonOutput: evon.has(code),
    timbreTTS: tts.has(code),
    autoDetection: auto,
  }));
}

export function supportLevel(c: LanguageCapability): SupportLevel {
  const stt = c.prismaSTT || c.prismaStreaming;
  if (stt && c.evonInput && c.evonOutput && c.timbreTTS) return 'full_voice';
  if (stt && c.evonInput && c.evonOutput) return 'text_response'; // speak in, text back
  if (stt) return 'speech_recognition_only';
  if (c.evonOutput) return 'text_response';
  if (c.timbreTTS) return 'tts';
  return 'unsupported';
}

export function findLanguage(code: string): LanguageCapability | undefined {
  return languageRegistry().find((l) => l.code === code);
}

/**
 * Validates a requested language and maps it to the provider's language_code value.
 * Returns null when the request cannot be served (unsupported code, or auto unavailable).
 */
export function resolveSttLanguage(requested: string, mode: 'rest' | 'stream'): string | null {
  if (requested === AUTO_LANGUAGE) return autoDetectionAvailable() ? AUTO_DETECT_CODE : null;
  const lang = findLanguage(requested);
  if (!lang) return null;
  return (mode === 'rest' ? lang.prismaSTT : lang.prismaStreaming) ? lang.code : null;
}
