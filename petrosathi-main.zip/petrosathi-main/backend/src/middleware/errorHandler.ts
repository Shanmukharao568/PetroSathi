import type { ErrorRequestHandler, RequestHandler } from 'express';
import mongoose from 'mongoose';
import { ApiError } from '../utils/ApiError.js';
import { logger } from '../utils/logger.js';
import { isProd } from '../config/env.js';

export const notFoundHandler: RequestHandler = (req, _res, next) => {
  next(new ApiError(404, 'NOT_FOUND', `Route ${req.method} ${req.path} not found`));
};

function normalize(err: unknown): ApiError {
  if (err instanceof ApiError) return err;

  if (err instanceof mongoose.Error.ValidationError) {
    return ApiError.validation(
      Object.values(err.errors).map((e) => ({ location: 'body', path: e.path, message: e.message })),
    );
  }
  if (err instanceof mongoose.Error.CastError) {
    return ApiError.badRequest(`Invalid value for ${err.path}`);
  }
  // Duplicate key
  if (typeof err === 'object' && err !== null && (err as { code?: unknown }).code === 11000) {
    const keys = Object.keys((err as { keyValue?: Record<string, unknown> }).keyValue ?? {});
    return ApiError.conflict(`Duplicate value for ${keys.join(', ') || 'unique field'}`);
  }
  // body-parser errors
  if (typeof err === 'object' && err !== null && 'type' in err) {
    const type = (err as { type?: string }).type;
    if (type === 'entity.parse.failed') return ApiError.badRequest('Malformed JSON body');
    if (type === 'entity.too.large') return ApiError.payloadTooLarge('Request body too large');
  }
  return new ApiError(500, 'INTERNAL_ERROR', 'An unexpected error occurred');
}

export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  const apiError = normalize(err);

  if (apiError.statusCode >= 500) {
    // Log the original error server-side; never leak internals to the client in production.
    logger.error({ err, path: req.path, method: req.method }, 'Unhandled error');
  }

  res.status(apiError.statusCode).json({
    success: false,
    error: {
      code: apiError.code,
      message: apiError.message,
      ...(apiError.details !== undefined ? { details: apiError.details } : {}),
      ...(!isProd && apiError.statusCode >= 500 && err instanceof Error ? { debug: err.message } : {}),
    },
  });
};
