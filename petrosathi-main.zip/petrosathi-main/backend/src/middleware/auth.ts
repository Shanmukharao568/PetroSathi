import type { Request, RequestHandler } from 'express';
import type { Role } from '../config/constants.js';
import { ApiError } from '../utils/ApiError.js';
import { verifyAccessToken } from '../modules/auth/token.service.js';
import { UserModel } from '../modules/users/user.model.js';
import { env } from '../config/env.js';

export function extractBearerToken(header: string | undefined): string | null {
  if (!header) return null;
  const [scheme, token] = header.split(' ');
  if (scheme?.toLowerCase() !== 'bearer' || !token) return null;
  return token;
}

/**
 * Resolves a JWT into the current user. Re-reads the user on every request so that
 * deactivation, role changes and token revocation take effect immediately.
 */
export async function resolveUserFromToken(token: string): Promise<Express.AuthenticatedUser> {
  const payload = verifyAccessToken(token);
  const user = await UserModel.findById(payload.sub).select('+tokenVersion').lean();
  if (!user) throw ApiError.unauthorized('Invalid token');
  if (!user.isActive) throw ApiError.unauthorized('Account is deactivated', 'ACCOUNT_DISABLED');
  if (user.tokenVersion !== payload.tv) throw ApiError.unauthorized('Session has been revoked, please sign in again');
  return {
    id: String(user._id),
    role: user.role,
    email: user.email,
    name: user.name,
    mustChangePassword: user.mustChangePassword,
    emailVerified: user.emailVerified === true,
  };
}

interface AuthenticateOptions {
  /**
   * Allow users who still have a temporary password. Only /auth/me, /auth/logout and
   * the self password-change endpoint should set this.
   */
  allowPendingPasswordChange?: boolean;
  /**
   * Allow users whose email is not verified yet. Only /auth/me, /auth/logout, the self
   * password-change endpoint and the email-verification endpoints should set this.
   */
  allowUnverifiedEmail?: boolean;
}

/** True when this user still has to confirm their email before using the app. */
export function needsEmailVerification(user: Pick<Express.AuthenticatedUser, 'emailVerified'>) {
  return env.EMAIL_VERIFICATION_REQUIRED && !user.emailVerified;
}

export function authenticate(options: AuthenticateOptions = {}): RequestHandler {
  return (req, _res, next) => {
    const token = extractBearerToken(req.headers.authorization);
    if (!token) return next(ApiError.unauthorized());
    resolveUserFromToken(token)
      .then((user) => {
        if (user.mustChangePassword && !options.allowPendingPasswordChange) {
          throw ApiError.forbidden('You must change your temporary password first', 'PASSWORD_CHANGE_REQUIRED');
        }
        if (needsEmailVerification(user) && !options.allowUnverifiedEmail) {
          throw ApiError.forbidden('Verify your email address to continue', 'EMAIL_VERIFICATION_REQUIRED');
        }
        req.user = user;
        next();
      })
      .catch(next);
  };
}

/** Server-side role gate. Must be used after authenticate(). */
export function authorize(...roles: Role[]): RequestHandler {
  return (req, _res, next) => {
    if (!req.user) return next(ApiError.unauthorized());
    if (!roles.includes(req.user.role)) return next(ApiError.forbidden());
    next();
  };
}

/** Narrowing helper for controllers that run behind authenticate(). */
export function requireUser(req: Request): Express.AuthenticatedUser {
  if (!req.user) throw ApiError.unauthorized();
  return req.user;
}
