import type { RequestHandler } from 'express';
import type { z } from 'zod';
import { ApiError } from '../utils/ApiError.js';

interface Schemas {
  body?: z.ZodType;
  query?: z.ZodType;
  params?: z.ZodType;
}

/**
 * Validates and replaces req.body / req.params with parsed values.
 * Parsed query is stored on res.locals.query (Express query object is getter-backed).
 */
export function validate(schemas: Schemas): RequestHandler {
  return (req, res, next) => {
    const issues: { location: string; path: string; message: string }[] = [];

    for (const location of ['params', 'query', 'body'] as const) {
      const schema = schemas[location];
      if (!schema) continue;
      const result = schema.safeParse(req[location] ?? {});
      if (!result.success) {
        for (const issue of result.error.issues) {
          issues.push({ location, path: issue.path.join('.'), message: issue.message });
        }
        continue;
      }
      if (location === 'query') res.locals.query = result.data;
      else req[location] = result.data;
    }

    if (issues.length) return next(ApiError.validation(issues));
    next();
  };
}
