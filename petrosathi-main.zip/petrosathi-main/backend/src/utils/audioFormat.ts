import { open } from 'node:fs/promises';

/** Formats Prisma REST accepts (docs.gnani.ai/api/STT/speech-to-text.md). */
export const SUPPORTED_AUDIO_FORMATS = ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'] as const;
export type AudioFormat = (typeof SUPPORTED_AUDIO_FORMATS)[number];

export const AUDIO_EXTENSIONS: Record<string, AudioFormat> = {
  '.mp3': 'mp3',
  '.wav': 'wav',
  '.ogg': 'ogg',
  '.oga': 'ogg',
  '.flac': 'flac',
  '.m4a': 'm4a',
  '.aac': 'aac',
};

/**
 * Identifies an audio container from its leading bytes. The client-declared MIME type and
 * file name are not trusted.
 */
export function detectAudioFormat(head: Buffer): AudioFormat | null {
  if (head.length < 12) return null;
  const ascii = (start: number, end: number) => head.toString('latin1', start, end);

  if (ascii(0, 3) === 'ID3') return 'mp3';
  if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WAVE') return 'wav';
  if (ascii(0, 4) === 'OggS') return 'ogg';
  if (ascii(0, 4) === 'fLaC') return 'flac';
  if (ascii(4, 8) === 'ftyp') return 'm4a';
  // MPEG frame sync: 11 set bits. Layer bits 00 → AAC ADTS; otherwise MPEG audio (MP3).
  if (head[0] === 0xff && (head[1]! & 0xe0) === 0xe0) {
    return (head[1]! & 0x06) === 0 ? 'aac' : 'mp3';
  }
  return null;
}

export async function detectAudioFormatOfFile(path: string): Promise<AudioFormat | null> {
  const fh = await open(path, 'r');
  try {
    const buf = Buffer.alloc(16);
    const { bytesRead } = await fh.read(buf, 0, 16, 0);
    return detectAudioFormat(buf.subarray(0, bytesRead));
  } finally {
    await fh.close();
  }
}
