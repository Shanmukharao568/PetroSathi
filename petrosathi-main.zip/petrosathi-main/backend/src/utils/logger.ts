import { pino } from 'pino';
import { env, isProd, isTest } from '../config/env.js';

/**
 * Paths that must never reach logs: credentials, tokens, passwords, raw audio.
 * Keep this list in sync with any new sensitive fields.
 */
export const REDACT_PATHS = [
  'req.headers.authorization',
  'req.headers.cookie',
  'req.headers["x-api-key-id"]',
  'req.headers["x-api-key-secret"]',
  '*.password',
  '*.newPassword',
  '*.currentPassword',
  '*.passwordHash',
  '*.token',
  '*.apiKey',
  '*.secret',
  '*.audio',
  '*.buffer',
];

export const logger = pino({
  level: isTest ? 'silent' : env.LOG_LEVEL,
  redact: { paths: REDACT_PATHS, censor: '[REDACTED]' },
  ...(isProd || isTest
    ? {}
    : { transport: { target: 'pino-pretty', options: { colorize: true, translateTime: 'SYS:HH:MM:ss' } } }),
});
