export type ErrorCode =
  | 'BAD_REQUEST'
  | 'VALIDATION_ERROR'
  | 'UNAUTHORIZED'
  | 'TOKEN_EXPIRED'
  | 'INVALID_CREDENTIALS'
  | 'ACCOUNT_DISABLED'
  | 'PASSWORD_CHANGE_REQUIRED'
  | 'EMAIL_VERIFICATION_REQUIRED'
  | 'OTP_INVALID'
  | 'OTP_EXPIRED'
  | 'FORBIDDEN'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'INVALID_STATUS_TRANSITION'
  | 'PAYLOAD_TOO_LARGE'
  | 'UNSUPPORTED_MEDIA_TYPE'
  | 'AUDIO_REJECTED'
  | 'RATE_LIMITED'
  | 'PROVIDER_ERROR'
  | 'PROVIDER_TIMEOUT'
  | 'SERVICE_UNAVAILABLE'
  | 'INTERNAL_ERROR';

/** Operational error with an HTTP status and a stable machine-readable code. */
export class ApiError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: ErrorCode,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }

  static badRequest(message: string, details?: unknown) {
    return new ApiError(400, 'BAD_REQUEST', message, details);
  }
  static validation(details: unknown) {
    return new ApiError(400, 'VALIDATION_ERROR', 'Request validation failed', details);
  }
  static unauthorized(message = 'Authentication required', code: ErrorCode = 'UNAUTHORIZED') {
    return new ApiError(401, code, message);
  }
  static forbidden(message = 'You do not have permission to perform this action', code: ErrorCode = 'FORBIDDEN') {
    return new ApiError(403, code, message);
  }
  static notFound(entity = 'Resource') {
    return new ApiError(404, 'NOT_FOUND', `${entity} not found`);
  }
  static conflict(message: string, details?: unknown) {
    return new ApiError(409, 'CONFLICT', message, details);
  }
  static payloadTooLarge(message: string) {
    return new ApiError(413, 'PAYLOAD_TOO_LARGE', message);
  }
  static unsupportedMedia(message: string) {
    return new ApiError(415, 'UNSUPPORTED_MEDIA_TYPE', message);
  }
  static provider(message: string, details?: unknown) {
    return new ApiError(502, 'PROVIDER_ERROR', message, details);
  }
  static providerTimeout(message = 'Upstream provider timed out') {
    return new ApiError(504, 'PROVIDER_TIMEOUT', message);
  }
  static unavailable(message: string) {
    return new ApiError(503, 'SERVICE_UNAVAILABLE', message);
  }
}
