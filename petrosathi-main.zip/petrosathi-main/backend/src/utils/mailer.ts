import nodemailer, { type Transporter } from 'nodemailer';
import { env, isTest } from '../config/env.js';
import { logger } from './logger.js';

export interface OutgoingMail {
  to: string;
  subject: string;
  text: string;
  html: string;
}

/**
 * Delivery modes:
 *   - "smtp":    SMTP_HOST is set → real email.
 *   - "log":     development without SMTP → the message (including any code) is written to the
 *                server log so the flow can be tested locally. Never used in production (env.ts
 *                refuses to start).
 *   - "memory":  automated tests → kept in `testOutbox` for assertions.
 */
export type MailMode = 'smtp' | 'log' | 'memory';

export function mailMode(): MailMode {
  if (isTest) return 'memory';
  return env.SMTP_HOST ? 'smtp' : 'log';
}

/** Test-only outbox (cleared by tests as needed). */
export const testOutbox: OutgoingMail[] = [];

let transporter: Transporter | null = null;
function smtp(): Transporter {
  transporter ??= nodemailer.createTransport({
    host: env.SMTP_HOST,
    port: env.SMTP_PORT,
    secure: env.SMTP_SECURE,
    auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
    // Never follow file paths or URLs inside message content.
    disableFileAccess: true,
    disableUrlAccess: true,
  });
  return transporter;
}

export async function sendMail(mail: OutgoingMail): Promise<void> {
  const mode = mailMode();
  if (mode === 'memory') {
    testOutbox.push(mail);
    return;
  }
  if (mode === 'log') {
    logger.warn(
      { to: mail.to, subject: mail.subject },
      `SMTP is not configured — email NOT sent. Development copy:\n${mail.text}`,
    );
    return;
  }
  await smtp().sendMail({ from: env.MAIL_FROM ?? env.SMTP_USER, ...mail });
}
