import bcrypt from 'bcrypt';
import { randomInt } from 'node:crypto';
import { z } from 'zod';
import { env } from '../config/env.js';
import { PASSWORD_MAX_LENGTH, PASSWORD_MIN_LENGTH } from '../config/constants.js';

export const passwordSchema = z
  .string()
  .min(PASSWORD_MIN_LENGTH, `Password must be at least ${PASSWORD_MIN_LENGTH} characters`)
  .max(PASSWORD_MAX_LENGTH, `Password must be at most ${PASSWORD_MAX_LENGTH} characters`)
  .refine((p) => /[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p), {
    message: 'Password must contain upper-case, lower-case letters and a digit',
  });

export function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, env.BCRYPT_SALT_ROUNDS);
}

export function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/** A fixed hash used to equalise timing when the email does not exist. */
let dummyHash: string | null = null;
export async function getDummyHash(): Promise<string> {
  dummyHash ??= await bcrypt.hash('timing-equaliser-not-a-real-password', env.BCRYPT_SALT_ROUNDS);
  return dummyHash;
}

/**
 * Cryptographically random one-time password satisfying passwordSchema.
 * Excludes visually ambiguous characters so it can be read out to a field operator.
 */
export function generateTemporaryPassword(length = 14): string {
  const lower = 'abcdefghjkmnpqrstuvwxyz';
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const digits = '23456789';
  const symbols = '!@#$%*?';
  const all = lower + upper + digits + symbols;
  const pick = (set: string) => set[randomInt(set.length)]!;

  const chars = [pick(lower), pick(upper), pick(digits), pick(symbols)];
  while (chars.length < length) chars.push(pick(all));
  // Fisher–Yates shuffle with CSPRNG
  for (let i = chars.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [chars[i], chars[j]] = [chars[j]!, chars[i]!];
  }
  return chars.join('');
}
