import { z } from 'zod';
import { Types } from 'mongoose';

export const objectIdSchema = z
  .string()
  .refine((v) => Types.ObjectId.isValid(v) && String(new Types.ObjectId(v)) === v, { message: 'Invalid id' });

export const idParamsSchema = z.object({ id: objectIdSchema });

export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

/** Query strings arrive as "true"/"false". */
export const booleanQuery = z.enum(['true', 'false']).transform((v) => v === 'true');

/** Escape user input before using it inside a RegExp. */
export function escapeRegex(input: string): string {
  return input.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
