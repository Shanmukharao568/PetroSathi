// Starts the local ChromaDB server from the project venv (backend/tools/chroma-venv).
// Usage: npm run chroma            (data in backend/chroma-data, port from CHROMA_URL or 8000)
// Setup (once): python -m venv tools/chroma-venv && tools/chroma-venv/<Scripts|bin>/python -m pip install chromadb==1.5.9
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const venv = path.join(root, 'tools', 'chroma-venv');
const bin = process.platform === 'win32' ? path.join(venv, 'Scripts', 'chroma.exe') : path.join(venv, 'bin', 'chroma');
if (!existsSync(bin)) {
  console.error(`ChromaDB not found at ${bin}.\nCreate it with:\n  python -m venv tools/chroma-venv\n  ${process.platform === 'win32' ? 'tools\\chroma-venv\\Scripts' : 'tools/chroma-venv/bin'}/python -m pip install chromadb==1.5.9`);
  process.exit(1);
}
const port = (() => {
  try {
    return new URL(process.env.CHROMA_URL ?? 'http://localhost:8000').port || '8000';
  } catch {
    return '8000';
  }
})();
const dataDir = process.env.CHROMA_DATA_DIR ?? path.join(root, 'chroma-data');
const child = spawn(bin, ['run', '--path', dataDir, '--host', '127.0.0.1', '--port', port], { stdio: 'inherit' });
child.on('exit', (code) => process.exit(code ?? 0));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => child.kill(sig));
