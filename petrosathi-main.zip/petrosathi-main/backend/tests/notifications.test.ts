import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';

const app = createApp();
useTestDatabase();

const notes = (auth: string, q = '') => request(app).get(`/api/v1/notifications${q}`).set('Authorization', auth);

describe('notifications', () => {
  it('notifies engineers on creation, reporter + assignee on assignment, status and comments — never the actor', async () => {
    const op = await userWithToken(app, 'operator');
    const eng = await userWithToken(app, 'engineer');
    const eng2 = await userWithToken(app, 'engineer');
    const { id: equipmentId } = await createEquipment();

    const created = await request(app)
      .post('/api/v1/tickets')
      .set('Authorization', op.auth)
      .set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId, description: 'Pump discharge pressure dropping', severity: 'high' });
    const ticketId = created.body.data.id;

    // Both engineers are told about the new ticket; the reporter is not notified of their own action.
    expect((await notes(eng.auth)).body.data[0]).toMatchObject({ type: 'ticket_created', ticketId, isRead: false });
    expect((await notes(eng2.auth)).body.data).toHaveLength(1);
    expect((await notes(op.auth)).body.data).toHaveLength(0);

    await request(app).patch(`/api/v1/tickets/${ticketId}/assign`).set('Authorization', eng.auth).send({ assigneeId: eng.id }).expect(200);
    expect((await notes(op.auth)).body.data[0].type).toBe('ticket_assigned');
    expect((await notes(eng.auth)).body.data).toHaveLength(1); // self-accept: no self-notification

    await request(app).patch(`/api/v1/tickets/${ticketId}/status`).set('Authorization', eng.auth).send({ status: 'IN_PROGRESS' }).expect(200);
    expect((await notes(op.auth)).body.data[0]).toMatchObject({ type: 'ticket_status_changed' });

    await request(app).post(`/api/v1/tickets/${ticketId}/comments`).set('Authorization', op.auth).send({ body: 'Thanks' }).expect(201);
    expect((await notes(eng.auth)).body.data[0].type).toBe('ticket_commented');
  });

  it('marks one or all as read; unread count and filter work', async () => {
    const op = await userWithToken(app, 'operator');
    await userWithToken(app, 'engineer');
    const eng = await userWithToken(app, 'engineer');
    const { id: equipmentId } = await createEquipment();
    for (let i = 0; i < 3; i++) {
      await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey())
        .send({ equipmentId, description: `Complaint number ${i} for testing` }).expect(201);
    }
    const list = await notes(eng.auth);
    expect(list.body.meta.unread).toBe(3);

    const one = await request(app).patch(`/api/v1/notifications/${list.body.data[0].id}/read`).set('Authorization', eng.auth);
    expect(one.body.data.isRead).toBe(true);
    expect((await notes(eng.auth, '?unreadOnly=true')).body.data).toHaveLength(2);

    const all = await request(app).patch('/api/v1/notifications/read-all').set('Authorization', eng.auth);
    expect(all.body.data.updated).toBe(2);
    expect((await notes(eng.auth)).body.meta.unread).toBe(0);
  });

  it("cannot read or mark another user's notification", async () => {
    const op = await userWithToken(app, 'operator');
    const eng = await userWithToken(app, 'engineer');
    const other = await userWithToken(app, 'engineer');
    const { id: equipmentId } = await createEquipment();
    await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId, description: 'Complaint for isolation test' }).expect(201);

    const engNote = (await notes(eng.auth)).body.data[0];
    const res = await request(app).patch(`/api/v1/notifications/${engNote.id}/read`).set('Authorization', other.auth);
    expect(res.status).toBe(404);
  });
});
