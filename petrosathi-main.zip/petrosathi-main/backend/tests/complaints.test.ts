import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, userWithToken } from './helpers/factories.js';
import { fakeMp3 } from './helpers/audio.js';
import { TicketModel } from '../src/modules/tickets/ticket.model.js';
import { ComplaintDraftModel } from '../src/modules/complaints/draft.model.js';
import { ConversationModel } from '../src/modules/conversations/conversation.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';
import { expireOverdueDrafts } from '../src/modules/complaints/complaint.service.js';
import { setEvonProviderForTests, setTtsProviderForTests } from '../src/providers/gnani/index.js';
import { ProviderError } from '../src/providers/gnani/prisma.types.js';
import type { TtsProvider } from '../src/providers/gnani/gnaniTimbreService.js';

const app = createApp();
useTestDatabase();

type U = Awaited<ReturnType<typeof userWithToken>>;
let op: U;

beforeEach(async () => {
  op = await userWithToken(app, 'operator');
  await createEquipment({ equipmentCode: 'P-101', name: 'Crude Transfer Pump A' });
});
afterEach(() => {
  setEvonProviderForTests(null);
  setTtsProviderForTests(undefined);
});

const textDraft = (auth: string, transcript: string, language = 'en-IN') =>
  request(app).post('/api/v1/complaints/drafts').set('Authorization', auth).send({ transcript, language });
const answer = (auth: string, id: string, answers: { field: string; answer: string }[]) =>
  request(app).post(`/api/v1/complaints/drafts/${id}/questions`).set('Authorization', auth).send({ answers });
const confirm = (auth: string, id: string) => request(app).post(`/api/v1/complaints/drafts/${id}/confirm`).set('Authorization', auth);

async function voiceConversation(auth: string, language = 'en-IN') {
  const r = await request(app).post('/api/v1/voice/transcribe').set('Authorization', auth).attach('audio', fakeMp3(), 'a.mp3').field('language', language);
  expect(r.status).toBe(201);
  return r.body.data as { conversationId: string; transcript: string };
}

describe('POST /complaints/extract', () => {
  it('returns a validated extraction and equipment check, labelled as mock', async () => {
    const res = await request(app).post('/api/v1/complaints/extract').set('Authorization', op.auth)
      .send({ transcript: 'P-101 is leaking oil and vibrating', language: 'en-IN' });
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ provider: 'mock', equipmentCheck: 'found', extraction: { equipmentCode: 'P-101', symptoms: ['leak', 'vibration'] } });
    expect(res.body.data.extraction.equipmentId).toEqual(expect.any(String));
  });

  it('rejects languages the extractor does not support', async () => {
    const res = await request(app).post('/api/v1/complaints/extract').set('Authorization', op.auth).send({ transcript: 'પંપ P-101 માં કંપન', language: 'gu-IN' });
    expect(res.status).toBe(422);
  });

  it('engineers cannot use the complaint endpoints', async () => {
    const eng = await userWithToken(app, 'engineer');
    expect((await request(app).post('/api/v1/complaints/extract').set('Authorization', eng.auth).send({ transcript: 'x', language: 'en-IN' })).status).toBe(403);
  });
});

describe('voice draft → confirmation → exactly one ticket', () => {
  it('creates a READY draft from a voice conversation and confirms it into a voice ticket', async () => {
    const conv = await voiceConversation(op.auth, 'hi-IN'); // mock Hindi transcript mentions P-101
    const d = await request(app).post('/api/v1/complaints/drafts').set('Authorization', op.auth).send({ conversationId: conv.conversationId });
    expect(d.status).toBe(201);
    expect(d.body.data).toMatchObject({
      state: 'READY_FOR_CONFIRMATION',
      source: 'voice',
      language: 'hi-IN',
      equipmentCheck: 'found',
      canConfirm: true,
      questions: [],
      extraction: { status: 'completed', provider: 'mock' },
      fields: { equipmentCode: 'P-101', severity: 'unknown' },
      equipment: { equipmentCode: 'P-101' },
    });
    expect(d.body.data).not.toHaveProperty('idempotencyKey');

    // No ticket exists until the operator explicitly confirms.
    expect(await TicketModel.countDocuments()).toBe(0);

    const c = await confirm(op.auth, d.body.data.id);
    expect(c.status).toBe(201);
    expect(c.body.data).toMatchObject({ source: 'voice', language: 'hi-IN', equipmentCode: 'P-101', transcript: conv.transcript });
    expect(c.body.data.complaintDraftId).toBe(d.body.data.id);

    const again = await confirm(op.auth, d.body.data.id);
    expect(again.status).toBe(200);
    expect(again.body.meta.idempotentReplay).toBe(true);
    expect(again.body.data.id).toBe(c.body.data.id);
    expect(await TicketModel.countDocuments()).toBe(1);

    const stored = await ComplaintDraftModel.findById(d.body.data.id);
    expect(stored).toMatchObject({ state: 'CONFIRMED' });
    expect(String(stored!.ticketId)).toBe(c.body.data.id);
    expect(String((await ConversationModel.findById(conv.conversationId))!.ticketId)).toBe(c.body.data.id);
    expect(await AuditLogModel.countDocuments({ action: 'complaint.confirmed' })).toBe(1);
  });

  it('concurrent confirmations still create exactly one ticket', async () => {
    const d = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    const results = await Promise.all(Array.from({ length: 5 }, () => confirm(op.auth, d.body.data.id)));
    expect(results.every((r) => [200, 201].includes(r.status))).toBe(true);
    expect(new Set(results.map((r) => r.body.data.id)).size).toBe(1);
    expect(await TicketModel.countDocuments()).toBe(1);
  });

  it('re-using a recording returns its open draft instead of creating another', async () => {
    const conv = await voiceConversation(op.auth);
    const a = await request(app).post('/api/v1/complaints/drafts').set('Authorization', op.auth).send({ conversationId: conv.conversationId });
    const b = await request(app).post('/api/v1/complaints/drafts').set('Authorization', op.auth).send({ conversationId: conv.conversationId });
    expect(b.status).toBe(200);
    expect(b.body.data.id).toBe(a.body.data.id);
    expect(await ComplaintDraftModel.countDocuments()).toBe(1);
  });
});

describe('follow-up questions', () => {
  it('missing equipment code → question → spoken answer resolves it', async () => {
    const d = await textDraft(op.auth, 'There is a loud grinding noise coming from the pump');
    expect(d.body.data).toMatchObject({ state: 'NEEDS_INFORMATION', missingInformation: ['equipmentCode'], canConfirm: false });
    expect(d.body.data.questions[0]).toMatchObject({ field: 'equipmentCode', inputType: 'equipment' });
    expect(d.body.data.questions[0].prompt).toMatch(/tag number/);

    expect((await confirm(op.auth, d.body.data.id)).status).toBe(409);
    expect(await TicketModel.countDocuments()).toBe(0);

    const a = await answer(op.auth, d.body.data.id, [{ field: 'equipmentCode', answer: 'It is p-101' }]);
    expect(a.body.data).toMatchObject({ state: 'READY_FOR_CONFIRMATION', fields: { equipmentCode: 'P-101' }, equipmentCheck: 'found' });
    expect(a.body.data.answers[0]).toMatchObject({ field: 'equipmentCode', answer: 'It is p-101' });
  });

  it('an unregistered equipment code is flagged, never invented', async () => {
    const d = await textDraft(op.auth, 'P-999 is leaking oil at the flange');
    expect(d.body.data).toMatchObject({ equipmentCheck: 'not_found', fields: { equipmentCode: 'P-999', equipmentId: null }, state: 'NEEDS_INFORMATION' });
    expect(d.body.data.questions[0].prompt).toMatch(/P-999 is not in the register/);
  });

  it('missing symptoms → answered in Hindi → extracted symptoms', async () => {
    const d = await textDraft(op.auth, 'P-101 में सुबह से कुछ दिक्कत है, कृपया देखें', 'hi-IN');
    expect(d.body.data.missingInformation).toEqual(['symptoms']);
    expect(d.body.data.questions[0].prompt).toMatch(/समस्या/);
    const a = await answer(op.auth, d.body.data.id, [{ field: 'symptoms', answer: 'बहुत वाइब्रेशन है' }]);
    expect(a.body.data).toMatchObject({ state: 'READY_FOR_CONFIRMATION', fields: { symptoms: ['vibration'] } });
  });

  it('an ambiguous complaint asks for both equipment and symptoms', async () => {
    const d = await textDraft(op.auth, 'Something is wrong here, please come and check it');
    expect(d.body.data.questions.map((q: { field: string }) => q.field)).toEqual(['equipmentCode', 'symptoms']);
  });

  it('keeps the operator’s own words as symptoms when nothing is recognised', async () => {
    const d = await textDraft(op.auth, 'Please check P-101 urgently today');
    const a = await answer(op.auth, d.body.data.id, [{ field: 'symptoms', answer: 'strange smell, discoloured oil' }]);
    expect(a.body.data.fields.symptoms).toEqual(['strange smell', 'discoloured oil']);
  });
});

describe('unsupported language and extraction failure', () => {
  it('unsupported language → DRAFT with the operator text; manual edit makes it ready', async () => {
    const d = await textDraft(op.auth, 'પંપ P-101 માં ઘણું કંપન છે', 'gu-IN');
    expect(d.body.data).toMatchObject({ state: 'DRAFT', extraction: { status: 'unsupported_language' }, fields: { description: 'પંપ P-101 માં ઘણું કંપન છે', symptoms: [] } });
    const p = await request(app).patch(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth).send({ equipmentCode: 'P-101', symptoms: ['vibration'] });
    expect(p.body.data.state).toBe('READY_FOR_CONFIRMATION');
  });

  it('provider failure still creates an editable draft (no silent mock substitution)', async () => {
    setEvonProviderForTests({ id: 'gnani-evon', supportedLanguages: ['en-IN'], extractComplaint: async () => { throw new ProviderError('unavailable', 'down'); } });
    const d = await textDraft(op.auth, 'P-101 vibrating strongly since morning');
    expect(d.status).toBe(201);
    expect(d.body.data).toMatchObject({ state: 'DRAFT', extraction: { status: 'failed', provider: 'gnani-evon' } });
  });
});

describe('editing, deletion, expiry and access', () => {
  it('edits fields; rejects invalid severity', async () => {
    const d = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    const p = await request(app).patch(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth).send({ severity: 'high', category: 'mechanical' });
    expect(p.body.data.fields).toMatchObject({ severity: 'high', category: 'mechanical' });
    const bad = await request(app).patch(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth).send({ severity: 'apocalyptic' });
    expect(bad.status).toBe(400);
  });

  it('confirmed drafts can no longer be edited or deleted', async () => {
    const d = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    await confirm(op.auth, d.body.data.id).expect(201);
    expect((await request(app).patch(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth).send({ severity: 'low' })).status).toBe(409);
    expect((await request(app).delete(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth)).status).toBe(409);
  });

  it('deletes an open draft and frees its recording', async () => {
    const conv = await voiceConversation(op.auth);
    const d = await request(app).post('/api/v1/complaints/drafts').set('Authorization', op.auth).send({ conversationId: conv.conversationId });
    expect((await request(app).delete(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth)).status).toBe(204);
    expect((await ConversationModel.findById(conv.conversationId))!.complaintDraftId).toBeNull();
  });

  it('expired drafts cannot be confirmed (lazy and job-based expiry)', async () => {
    const d = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    await ComplaintDraftModel.updateOne({ _id: d.body.data.id }, { $set: { expiresAt: new Date(Date.now() - 1000) } });
    expect((await request(app).get(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', op.auth)).body.data.state).toBe('EXPIRED');
    expect((await confirm(op.auth, d.body.data.id)).status).toBe(409);

    const d2 = await textDraft(op.auth, 'P-101 has a small leak at the seal area');
    await ComplaintDraftModel.updateOne({ _id: d2.body.data.id }, { $set: { expiresAt: new Date(Date.now() - 1000) } });
    expect(await expireOverdueDrafts()).toBe(1);
    expect(await TicketModel.countDocuments()).toBe(0);
  });

  it("other operators cannot see or confirm someone else's draft", async () => {
    const other = await userWithToken(app, 'operator');
    const d = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    expect((await request(app).get(`/api/v1/complaints/drafts/${d.body.data.id}`).set('Authorization', other.auth)).status).toBe(404);
    expect((await confirm(other.auth, d.body.data.id)).status).toBe(404);
    expect((await request(app).get('/api/v1/complaints/drafts').set('Authorization', other.auth)).body.data).toHaveLength(0);
  });

  it("cannot draft from another user's recording", async () => {
    const other = await userWithToken(app, 'operator');
    const conv = await voiceConversation(other.auth);
    const res = await request(app).post('/api/v1/complaints/drafts').set('Authorization', op.auth).send({ conversationId: conv.conversationId });
    expect(res.status).toBe(400);
  });

  it('accepts a spoken tag without a hyphen only when it is in the register', async () => {
    await createEquipment({ equipmentCode: 'FV-601', name: 'Flow Control Valve (Demo)', type: 'valve' });

    const spaced = await textDraft(op.auth, 'FV 601 వాల్వ్ లీక్ అవుతోంది', 'te-IN');
    expect(spaced.body.data).toMatchObject({ equipmentCheck: 'found', fields: { equipmentCode: 'FV-601' } });
    expect(spaced.body.data.missingInformation).not.toContain('equipmentCode');

    const joined = await textDraft(op.auth, 'FV601 has a leak at the flange');
    expect(joined.body.data.fields.equipmentCode).toBe('FV-601');

    // Ordinary speech never becomes a tag.
    const plain = await textDraft(op.auth, 'pump 30 is leaking near the tank farm');
    expect(plain.body.data).toMatchObject({ equipmentCheck: 'not_provided', fields: { equipmentCode: null } });
    expect(plain.body.data.questions[0]).toMatchObject({ field: 'equipmentCode' });

    // A hyphenated tag is still used as written, so the operator hears it is not registered.
    const unknown = await textDraft(op.auth, 'P-999 has a leak at the flange');
    expect(unknown.body.data).toMatchObject({ equipmentCheck: 'not_found', fields: { equipmentCode: 'P-999' } });

    // The follow-up answer accepts the spoken form too.
    const a = await answer(op.auth, plain.body.data.id, [{ field: 'equipmentCode', answer: 'FV 601' }]);
    expect(a.body.data).toMatchObject({ equipmentCheck: 'found', fields: { equipmentCode: 'FV-601' } });
  });

  it('finds a tag spelled out in Telugu script when it is in the register', async () => {
    await createEquipment({ equipmentCode: 'P-201', name: 'Cooling Water Pump (Demo)', type: 'pump' });

    const d = await textDraft(op.auth, 'పీ టూ జీరో వన్లో చెక్ వాల్వ్ పనిచేయడం లేదు, దానివల్ల ప్రెషర్ చాలా ఎక్కువగా ఉంది.', 'te-IN');
    expect(d.body.data).toMatchObject({ equipmentCheck: 'found', fields: { equipmentCode: 'P-201' } });
    expect(d.body.data.missingInformation).not.toContain('equipmentCode');

    // Spelled out but not registered: never invented.
    const none = await textDraft(op.auth, 'పీ నైన్ నైన్ నైన్ లో ప్రెషర్ ఎక్కువగా ఉంది', 'te-IN');
    expect(none.body.data).toMatchObject({ equipmentCheck: 'not_provided', fields: { equipmentCode: null } });
  });

  it('lists open drafts only by default', async () => {
    const a = await textDraft(op.auth, 'P-101 has strong vibration near the bearing housing');
    await textDraft(op.auth, 'Something is wrong here, please come and check it');
    await confirm(op.auth, a.body.data.id).expect(201);
    expect((await request(app).get('/api/v1/complaints/drafts').set('Authorization', op.auth)).body.data).toHaveLength(1);
    expect((await request(app).get('/api/v1/complaints/drafts?includeClosed=true').set('Authorization', op.auth)).body.data).toHaveLength(2);
  });
});

describe('spoken prompts (Timbre)', () => {
  it('returns 503 when TTS is not configured (no fake audio)', async () => {
    const d = await textDraft(op.auth, 'There is a loud grinding noise coming from the pump');
    const res = await request(app).post(`/api/v1/complaints/drafts/${d.body.data.id}/speech`).set('Authorization', op.auth).send({ target: 'questions' });
    expect(res.status).toBe(503);
  });

  it('speaks the server-generated question text in the draft language', async () => {
    const calls: { text: string; language: string }[] = [];
    const fake: TtsProvider = {
      id: 'gnani-timbre', model: 'timbre-v3.0', voice: 'Shivani', languages: ['en-IN', 'hi-IN'],
      synthesize: async (text, language) => {
        calls.push({ text, language });
        return { audio: Buffer.from('ID3fakeaudio'), contentType: 'audio/mpeg' };
      },
    };
    setTtsProviderForTests(fake);
    const d = await textDraft(op.auth, 'P-101 में सुबह से कुछ दिक्कत है, कृपया देखें', 'hi-IN');
    const res = await request(app).post(`/api/v1/complaints/drafts/${d.body.data.id}/speech`).set('Authorization', op.auth).send({ target: 'questions' });
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/audio\/mpeg/);
    expect(calls[0]).toMatchObject({ language: 'hi-IN' });
    expect(calls[0]!.text).toBe(d.body.data.questions[0].prompt);
  });

  it('the confirmation prompt names the equipment and the symptoms', async () => {
    const calls: { text: string; language: string }[] = [];
    setTtsProviderForTests({
      id: 'gnani-timbre', model: 'timbre-v3.0', voice: 'Shivani', languages: ['en-IN', 'hi-IN'],
      synthesize: async (text, language) => {
        calls.push({ text, language });
        return { audio: Buffer.from('ID3fakeaudio'), contentType: 'audio/mpeg' };
      },
    });
    await createEquipment({ equipmentCode: 'M-701', name: 'Pump Drive Motor (Demo)', type: 'motor' });
    const d = await textDraft(op.auth, 'M-701 का electricity problem है, overheating हो रहा है।', 'hi-IN');
    expect(d.body.data.canConfirm).toBe(true);
    const res = await request(app).post(`/api/v1/complaints/drafts/${d.body.data.id}/speech`).set('Authorization', op.auth).send({ target: 'confirmation' });
    expect(res.status).toBe(200);
    expect(calls[0]).toEqual({
      language: 'hi-IN',
      text: 'M-701, Pump Drive Motor के बारे में आपकी शिकायत तैयार है। समस्या: overheating। टिकट बनाने के लिए कृपया जांचें और पुष्टि करें।',
    });
  });

  it('the confirmation prompt caps a long symptom list', async () => {
    const calls: string[] = [];
    setTtsProviderForTests({
      id: 'gnani-timbre', model: 'timbre-v3.0', voice: 'Shivani', languages: ['en-IN'],
      synthesize: async (text) => {
        calls.push(text);
        return { audio: Buffer.from('ID3fakeaudio'), contentType: 'audio/mpeg' };
      },
    });
    const d = await textDraft(op.auth, 'P-101 has smoke, a leak, high pressure, vibration, grinding noise and is overheating');
    expect(d.body.data.fields.symptoms.length).toBeGreaterThan(5);
    await request(app).post(`/api/v1/complaints/drafts/${d.body.data.id}/speech`).set('Authorization', op.auth).send({ target: 'confirmation' }).expect(200);
    const spoken = calls[0]!.match(/Problem: (.*?)\. Please/)![1]!.split(', ');
    expect(spoken).toEqual(d.body.data.fields.symptoms.slice(0, 5));
    expect(calls[0]).toMatch(/^Your complaint about P-101, Crude Transfer Pump A is ready\./);
  });

  it('503 when the configured voice does not speak the draft language', async () => {
    setTtsProviderForTests({ id: 'gnani-timbre', model: 'timbre-v2.5', voice: 'Nalini', languages: ['hi-IN'], synthesize: async () => ({ audio: Buffer.from('x'), contentType: 'audio/mpeg' }) });
    const d = await textDraft(op.auth, 'There is a loud grinding noise coming from the pump');
    expect((await request(app).post(`/api/v1/complaints/drafts/${d.body.data.id}/speech`).set('Authorization', op.auth).send({ target: 'questions' })).status).toBe(503);
  });
});
