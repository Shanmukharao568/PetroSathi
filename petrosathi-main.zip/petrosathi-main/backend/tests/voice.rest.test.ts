import { afterEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { rmSync, utimesSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';
import { audioDirEntries, fakeMp3 } from './helpers/audio.js';
import { setPrismaProviderForTests } from '../src/providers/gnani/index.js';
import { ProviderError, type PrismaProvider } from '../src/providers/gnani/prisma.types.js';
import { ConversationModel } from '../src/modules/conversations/conversation.model.js';
import { sweepAudioDir } from '../src/jobs/audioCleanup.js';
import { MOCK_PREFIX } from '../src/providers/gnani/mockPrismaService.js';

const app = createApp();
useTestDatabase();

afterEach(() => {
  setPrismaProviderForTests(null);
  // Every request must leave the temporary audio directory empty.
  expect(audioDirEntries()).toEqual([]);
});

const upload = (auth: string, file: Buffer, name: string, language?: string) => {
  const r = request(app).post('/api/v1/voice/transcribe').set('Authorization', auth).attach('audio', file, name);
  return language ? r.field('language', language) : r;
};

function failingProvider(err: Error): PrismaProvider {
  return {
    id: 'gnani-prisma',
    transcribeFile: async () => {
      throw err;
    },
    openStream: async () => {
      throw err;
    },
  };
}

describe('GET /voice/languages', () => {
  it('lists only documented Prisma languages with honest capability flags', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await request(app).get('/api/v1/voice/languages').set('Authorization', op.auth);
    expect(res.status).toBe(200);
    const codes = res.body.data.languages.map((l: { code: string }) => l.code).sort();
    expect(codes).toEqual(['bn-IN', 'en-IN', 'gu-IN', 'hi-IN', 'kn-IN', 'ml-IN', 'mr-IN', 'pa-IN', 'ta-IN', 'te-IN']);
    // Extraction support = what the configured (mock) extractor implements; no TTS in mock mode.
    const withExtraction = ['en-IN', 'hi-IN', 'ta-IN', 'te-IN'];
    for (const l of res.body.data.languages) {
      const ex = withExtraction.includes(l.code);
      expect(l).toMatchObject({
        prismaSTT: true,
        prismaStreaming: true,
        evonInput: ex,
        evonOutput: ex,
        timbreTTS: false,
        supportLevel: ex ? 'text_response' : 'speech_recognition_only',
      });
    }
    expect(res.body.data).toMatchObject({ providerMode: 'mock', extractionMode: 'mock', tts: { available: false }, maxUploadSeconds: 30 });
  });
});

describe('POST /voice/transcribe (mock provider)', () => {
  it('transcribes a valid MP3, labels the mock, stores a conversation and deletes the audio', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, fakeMp3(), 'report.mp3', 'en-IN');
    expect(res.status).toBe(201);
    expect(res.body.data).toMatchObject({ provider: 'mock', model: 'mock', language: 'en-IN', audioMode: 'upload' });
    expect(res.body.data.transcript.startsWith(MOCK_PREFIX)).toBe(true);

    const conv = await ConversationModel.findById(res.body.data.conversationId);
    expect(conv).toMatchObject({ provider: 'mock', requestedLanguage: 'en-IN' });
    expect(String(conv!.userId)).toBe(op.id);
  });

  it('supports Indian-language and auto-detect requests', async () => {
    const op = await userWithToken(app, 'operator');
    const hi = await upload(op.auth, fakeMp3(), 'a.mp3', 'hi-IN');
    expect(hi.body.data.language).toBe('hi-IN');
    expect(hi.body.data.transcript).toMatch(/पंप/);
    const auto = await upload(op.auth, fakeMp3(), 'a.mp3', 'auto');
    expect(auto.status).toBe(201);
    expect(auto.body.data.requestedLanguage).toBe('auto');
  });

  it('rejects a non-audio extension with 415', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, Buffer.from('hello'), 'notes.txt');
    expect(res.status).toBe(415);
  });

  it('rejects a file whose content is not audio, even with an .mp3 name', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, Buffer.from('<html>definitely not audio</html>'), 'fake.mp3');
    expect(res.status).toBe(415);
  });

  it('rejects files over MAX_AUDIO_SIZE_MB with 413', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, fakeMp3(21 * 1024 * 1024), 'big.mp3');
    expect(res.status).toBe(413);
  });

  it('requires a file', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await request(app).post('/api/v1/voice/transcribe').set('Authorization', op.auth).field('language', 'en-IN');
    expect(res.status).toBe(400);
  });

  it('rejects unsupported and malformed languages, still deleting the audio', async () => {
    const op = await userWithToken(app, 'operator');
    expect((await upload(op.auth, fakeMp3(), 'a.mp3', 'fr-FR')).status).toBe(400);
    expect((await upload(op.auth, fakeMp3(), 'a.mp3', 'hindi')).status).toBe(400);
  });

  it('maps a provider timeout to 504 and deletes the audio', async () => {
    setPrismaProviderForTests(failingProvider(new ProviderError('timeout', 'slow')));
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, fakeMp3(), 'a.mp3', 'en-IN');
    expect(res.status).toBe(504);
    expect(res.body.error.code).toBe('PROVIDER_TIMEOUT');
    expect(await ConversationModel.countDocuments()).toBe(0);
  });

  it('maps rejected audio to 422 with a helpful message', async () => {
    setPrismaProviderForTests(failingProvider(new ProviderError('rejected', 'too long', 'MAX_AUDIO_DURATION_EXCEEDED')));
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, fakeMp3(), 'a.mp3', 'en-IN');
    expect(res.status).toBe(422);
    expect(res.body.error.message).toMatch(/30 seconds/);
  });

  it('does not leak provider credential problems to the operator', async () => {
    setPrismaProviderForTests(failingProvider(new ProviderError('auth', 'INVALID_API_KEY details', 'INVALID_API_KEY')));
    const op = await userWithToken(app, 'operator');
    const res = await upload(op.auth, fakeMp3(), 'a.mp3', 'en-IN');
    expect(res.status).toBe(502);
    expect(JSON.stringify(res.body)).not.toMatch(/INVALID_API_KEY/);
  });

  it('requires authentication', async () => {
    const res = await request(app).post('/api/v1/voice/transcribe').attach('audio', fakeMp3(), 'a.mp3');
    expect(res.status).toBe(401);
  });
});

describe('voice → ticket', () => {
  it('copies the ORIGINAL transcript from the conversation; the description may be edited', async () => {
    const op = await userWithToken(app, 'operator');
    const { id: equipmentId } = await createEquipment();
    const t = await upload(op.auth, fakeMp3(), 'a.mp3', 'hi-IN');
    const conversationId = t.body.data.conversationId;

    const res = await request(app)
      .post('/api/v1/tickets')
      .set('Authorization', op.auth)
      .set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId, conversationId, description: 'Operator-edited description of pump vibration' });
    expect(res.status).toBe(201);
    expect(res.body.data).toMatchObject({ source: 'voice', language: 'hi-IN', description: 'Operator-edited description of pump vibration' });
    expect(res.body.data.transcript).toBe(t.body.data.transcript);

    const conv = await ConversationModel.findById(conversationId);
    expect(String(conv!.ticketId)).toBe(res.body.data.id);

    // A recording can only back one ticket.
    const again = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId, conversationId, description: 'Second attempt with same recording' });
    expect(again.status).toBe(409);
  });

  it("cannot attach another user's conversation", async () => {
    const op = await userWithToken(app, 'operator');
    const other = await userWithToken(app, 'operator');
    const { id: equipmentId } = await createEquipment();
    const t = await upload(other.auth, fakeMp3(), 'a.mp3', 'en-IN');
    const res = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId, conversationId: t.body.data.conversationId, description: 'Trying to steal a transcript' });
    expect(res.status).toBe(400);
  });
});

describe('conversations', () => {
  it('users see their own conversations; others get 404', async () => {
    const op = await userWithToken(app, 'operator');
    const other = await userWithToken(app, 'operator');
    const admin = await userWithToken(app, 'admin');
    const t = await upload(op.auth, fakeMp3(), 'a.mp3', 'en-IN');
    const id = t.body.data.conversationId;

    expect((await request(app).get('/api/v1/conversations').set('Authorization', op.auth)).body.data).toHaveLength(1);
    expect((await request(app).get(`/api/v1/conversations/${id}`).set('Authorization', op.auth)).status).toBe(200);
    expect((await request(app).get(`/api/v1/conversations/${id}`).set('Authorization', other.auth)).status).toBe(404);
    expect((await request(app).get(`/api/v1/conversations?userId=${op.id}`).set('Authorization', other.auth)).status).toBe(403);
    expect((await request(app).get(`/api/v1/conversations/${id}`).set('Authorization', admin.auth)).status).toBe(200);
  });
});

describe('abandoned audio sweeper', () => {
  it('removes files older than the retention window and keeps recent ones', async () => {
    const dir = process.env.AUDIO_UPLOAD_DIR!;
    const old = path.join(dir, 'old.mp3');
    const fresh = path.join(dir, 'fresh.mp3');
    writeFileSync(old, 'x');
    writeFileSync(fresh, 'x');
    const hourAgo = new Date(Date.now() - 60 * 60_000);
    utimesSync(old, hourAgo, hourAgo);

    expect(await sweepAudioDir(dir, 30 * 60_000)).toBe(1);
    expect(audioDirEntries()).toEqual(['fresh.mp3']);
    rmSync(fresh);
  });
});
