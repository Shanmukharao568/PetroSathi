import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createUser, userWithToken } from './helpers/factories.js';
import { UserModel } from '../src/modules/users/user.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';

const app = createApp();
useTestDatabase();

describe('admin user management', () => {
  it('admin creates a user with a one-time temporary password', async () => {
    const admin = await userWithToken(app, 'admin');
    const res = await request(app)
      .post('/api/v1/users')
      .set('Authorization', admin.auth)
      .send({ name: 'New Operator', email: 'New.Op@Example.test', role: 'operator', preferredLanguage: 'hi-IN' });

    expect(res.status).toBe(201);
    expect(res.body.data.user).toMatchObject({ email: 'new.op@example.test', role: 'operator', mustChangePassword: true });
    expect(res.body.data.temporaryPassword).toMatch(/^.{14}$/);
    expect(JSON.stringify(res.body)).not.toMatch(/passwordHash/);

    // The temporary password works, and the stored hash is not the plaintext.
    const stored = await UserModel.findOne({ email: 'new.op@example.test' }).select('+passwordHash');
    expect(stored!.passwordHash).not.toBe(res.body.data.temporaryPassword);
    const login = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: 'new.op@example.test', password: res.body.data.temporaryPassword });
    expect(login.status).toBe(200);
    expect(login.body.data.user.mustChangePassword).toBe(true);

    expect(await AuditLogModel.countDocuments({ action: 'user.created' })).toBe(1);
  });

  it('rejects duplicate emails with 409', async () => {
    const admin = await userWithToken(app, 'admin');
    const { email } = await createUser();
    const res = await request(app)
      .post('/api/v1/users')
      .set('Authorization', admin.auth)
      .send({ name: 'Dup', email, role: 'operator' });
    expect(res.status).toBe(409);
  });

  it('rejects unknown fields (e.g. trying to set passwordHash or isActive on create)', async () => {
    const admin = await userWithToken(app, 'admin');
    const res = await request(app)
      .post('/api/v1/users')
      .set('Authorization', admin.auth)
      .send({ name: 'X Y', email: 'x@example.test', role: 'operator', passwordHash: 'abc' });
    expect(res.status).toBe(400);
  });

  it('lists users with pagination and filters', async () => {
    const admin = await userWithToken(app, 'admin');
    await createUser({ role: 'engineer', name: 'Findable Engineer' });
    await createUser({ role: 'operator' });

    const res = await request(app).get('/api/v1/users?role=engineer&search=findable').set('Authorization', admin.auth);
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(1);
    expect(res.body.meta.pagination).toMatchObject({ page: 1, total: 1 });
  });

  it('admin can change role and deactivate; changes are audited', async () => {
    const admin = await userWithToken(app, 'admin');
    const { id } = await createUser({ role: 'operator' });

    const role = await request(app).patch(`/api/v1/users/${id}`).set('Authorization', admin.auth).send({ role: 'engineer' });
    expect(role.status).toBe(200);
    expect(role.body.data.role).toBe('engineer');

    const off = await request(app).patch(`/api/v1/users/${id}`).set('Authorization', admin.auth).send({ isActive: false });
    expect(off.body.data.isActive).toBe(false);

    expect(await AuditLogModel.countDocuments({ action: 'user.role_changed' })).toBe(1);
    expect(await AuditLogModel.countDocuments({ action: 'user.deactivated' })).toBe(1);
  });

  it('admin cannot deactivate or demote themselves', async () => {
    const admin = await userWithToken(app, 'admin');
    const a = await request(app).patch(`/api/v1/users/${admin.id}`).set('Authorization', admin.auth).send({ isActive: false });
    const b = await request(app).patch(`/api/v1/users/${admin.id}`).set('Authorization', admin.auth).send({ role: 'operator' });
    expect(a.status).toBe(409);
    expect(b.status).toBe(409);
  });

  it('an admin can deactivate another admin while an active admin remains', async () => {
    const admin = await userWithToken(app, 'admin');
    const other = await createUser({ role: 'admin' });
    await request(app).patch(`/api/v1/users/${other.id}`).set('Authorization', admin.auth).send({ isActive: false }).expect(200);
  });

  it('admin password reset issues a new temporary password and revokes sessions', async () => {
    const admin = await userWithToken(app, 'admin');
    const op = await userWithToken(app, 'operator');

    const res = await request(app).patch(`/api/v1/users/${op.id}/password`).set('Authorization', admin.auth).send({});
    expect(res.status).toBe(200);
    expect(res.body.data.temporaryPassword).toEqual(expect.any(String));
    expect(res.body.data.user.mustChangePassword).toBe(true);

    expect((await request(app).get('/api/v1/auth/me').set('Authorization', op.auth)).status).toBe(401);
  });

  it('admin cannot set another user\'s password directly', async () => {
    const admin = await userWithToken(app, 'admin');
    const { id } = await createUser();
    const res = await request(app)
      .patch(`/api/v1/users/${id}/password`)
      .set('Authorization', admin.auth)
      .send({ newPassword: 'Chosen-By-Admin-1' });
    expect(res.status).toBe(400);
  });

  it('returns 400 for malformed ids and 404 for missing users', async () => {
    const admin = await userWithToken(app, 'admin');
    expect((await request(app).get('/api/v1/users/not-an-id').set('Authorization', admin.auth)).status).toBe(400);
    expect((await request(app).get('/api/v1/users/64b7f0c2a1b2c3d4e5f60718').set('Authorization', admin.auth)).status).toBe(404);
  });
});

describe('role-based access control', () => {
  for (const role of ['operator', 'engineer'] as const) {
    it(`${role} cannot create or list users`, async () => {
      const u = await userWithToken(app, role);
      const create = await request(app)
        .post('/api/v1/users')
        .set('Authorization', u.auth)
        .send({ name: 'Sneaky', email: 'sneaky@example.test', role: 'admin' });
      expect(create.status).toBe(403);
      expect((await request(app).get('/api/v1/users').set('Authorization', u.auth)).status).toBe(403);
      expect(await UserModel.exists({ email: 'sneaky@example.test' })).toBeNull();
    });

    it(`${role} cannot escalate their own role or reactivate themselves`, async () => {
      const u = await userWithToken(app, role);
      const res = await request(app).patch(`/api/v1/users/${u.id}`).set('Authorization', u.auth).send({ role: 'admin' });
      expect(res.status).toBe(403);
      expect((await UserModel.findById(u.id))!.role).toBe(role);
    });
  }

  it('a user can read and update their own profile (name, language)', async () => {
    const op = await userWithToken(app, 'operator');
    expect((await request(app).get(`/api/v1/users/${op.id}`).set('Authorization', op.auth)).status).toBe(200);
    const res = await request(app)
      .patch(`/api/v1/users/${op.id}`)
      .set('Authorization', op.auth)
      .send({ name: 'Renamed Op', preferredLanguage: 'ta-IN' });
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ name: 'Renamed Op', preferredLanguage: 'ta-IN' });
  });

  it('a user can fill in, change and clear their profile details and photo', async () => {
    const eng = await userWithToken(app, 'engineer');
    const photo = `data:image/png;base64,${Buffer.from('fake-png-bytes').toString('base64')}`;
    const set = await request(app)
      .patch(`/api/v1/users/${eng.id}`)
      .set('Authorization', eng.auth)
      .send({ phone: '+91 98765 43210', jobTitle: '  Rotating Equipment Engineer ', site: 'Demo Refinery Unit 1', bio: 'Pumps and compressors.', avatar: photo });
    expect(set.status).toBe(200);
    expect(set.body.data).toMatchObject({
      phone: '+91 98765 43210',
      jobTitle: 'Rotating Equipment Engineer',
      site: 'Demo Refinery Unit 1',
      bio: 'Pumps and compressors.',
      avatar: photo,
    });

    // The session's own user record carries the profile too.
    const me = await request(app).get('/api/v1/auth/me').set('Authorization', eng.auth);
    expect(me.body.data.user ?? me.body.data).toMatchObject({ jobTitle: 'Rotating Equipment Engineer', avatar: photo });

    // Empty string or null clears a field.
    const cleared = await request(app).patch(`/api/v1/users/${eng.id}`).set('Authorization', eng.auth).send({ phone: '', avatar: null });
    expect(cleared.body.data).toMatchObject({ phone: null, avatar: null, site: 'Demo Refinery Unit 1' });

    // The audit trail records that the photo changed, never the image data.
    const audits = await AuditLogModel.find({ action: 'user.updated', entityId: eng.id });
    expect(JSON.stringify(audits)).not.toContain('base64');
    expect(audits.some((a) => (a.metadata as { changes?: Record<string, unknown> })?.changes?.avatar)).toBe(true);
  });

  it('rejects invalid profile values', async () => {
    const op = await userWithToken(app, 'operator');
    const patch = (body: object) => request(app).patch(`/api/v1/users/${op.id}`).set('Authorization', op.auth).send(body);
    expect((await patch({ phone: 'call me' })).status).toBe(400);
    expect((await patch({ bio: 'x'.repeat(281) })).status).toBe(400);
    expect((await patch({ avatar: 'https://example.test/me.png' })).status).toBe(400);
    expect((await patch({ avatar: 'data:image/svg+xml;base64,PHN2Zz4=' })).status).toBe(400);
    expect((await patch({ avatar: `data:image/png;base64,${'A'.repeat(130_000)}` })).status).toBe(400);
  });

  it('cross-user access is forbidden for non-admins', async () => {
    const op1 = await userWithToken(app, 'operator');
    const op2 = await createUser({ role: 'operator' });
    const eng = await userWithToken(app, 'engineer');

    expect((await request(app).get(`/api/v1/users/${op2.id}`).set('Authorization', op1.auth)).status).toBe(403);
    expect((await request(app).patch(`/api/v1/users/${op2.id}`).set('Authorization', op1.auth).send({ name: 'Hacked' })).status).toBe(403);
    expect((await request(app).patch(`/api/v1/users/${op2.id}/password`).set('Authorization', eng.auth).send({})).status).toBe(403);
  });

  it('admin can read any user', async () => {
    const admin = await userWithToken(app, 'admin');
    const op = await createUser();
    expect((await request(app).get(`/api/v1/users/${op.id}`).set('Authorization', admin.auth)).status).toBe(200);
  });
});
