import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';
import { demoPdf, simplePdf, textlessPdf } from './helpers/rag.js';
import { extractPdfPages, PdfValidationError } from '../src/rag/pdf.js';
import { chunkPages } from '../src/rag/chunker.js';
import { waitForIngestionIdle } from '../src/rag/ingestion.js';
import { createMemoryStore } from '../src/rag/vectorStore/memoryStore.js';
import { setVectorStoreForTests } from '../src/rag/vectorStore/index.js';
import { getEmbeddingProvider } from '../src/rag/embeddings/index.js';
import type { VectorStore } from '../src/rag/vectorStore/types.js';
import { DocumentModel } from '../src/modules/documents/document.model.js';
import { countStoredFiles } from '../src/modules/documents/fileStore.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';

const app = createApp();
useTestDatabase();

let store: ReturnType<typeof createMemoryStore>;
type U = Awaited<ReturnType<typeof userWithToken>>;
let admin: U, eng: U, op: U;

beforeEach(async () => {
  store = createMemoryStore();
  setVectorStoreForTests(store);
  [admin, eng, op] = await Promise.all([userWithToken(app, 'admin'), userWithToken(app, 'engineer'), userWithToken(app, 'operator')]);
});
afterEach(() => setVectorStoreForTests(null));


async function upload(file: Buffer, fields: Record<string, string> = {}, name = 'manual.pdf', auth = admin.auth) {
  let r = request(app).post('/api/v1/documents').set('Authorization', auth).attach('file', file, name);
  for (const [k, v] of Object.entries({ title: 'Pump guide', documentType: 'manual', ...fields })) r = r.field(k, v);
  return r;
}

async function uploadReady(file: Buffer, fields: Record<string, string> = {}) {
  const res = await upload(file, fields);
  expect(res.status).toBe(202);
  await waitForIngestionIdle();
  return (await DocumentModel.findById(res.body.data.id))!;
}

const search = (body: Record<string, unknown>, auth = eng.auth) => request(app).post('/api/v1/knowledge/search').set('Authorization', auth).send(body);

describe('PDF extraction and chunking', () => {
  it('extracts text per page and rejects non-PDF content', async () => {
    const { pageCount, pages } = await extractPdfPages(await demoPdf('pump'));
    expect(pageCount).toBe(7);
    expect(pages[4]!.lines.some((l) => l.text.startsWith('5 Mechanical seal leakage'))).toBe(true);
    await expect(extractPdfPages(Buffer.from('not a pdf at all'))).rejects.toBeInstanceOf(PdfValidationError);
  });

  it('keeps chunks on their page, assigns sections, merges wrapped titles and drops page banners', async () => {
    const { pages } = await extractPdfPages(await demoPdf('pump'));
    const { chunks, sections } = chunkPages(pages, 1000, 200);
    expect(sections[0]).toBe('DEMO - Centrifugal Pump Operation and Troubleshooting Guide');
    expect(sections).toContain('5 Mechanical seal leakage');
    const seal = chunks.filter((c) => c.section === '5 Mechanical seal leakage');
    expect(seal.length).toBeGreaterThan(0);
    expect(seal.every((c) => c.pageNumber === 5)).toBe(true);
    expect(chunks.some((c) => c.text.includes('DEMONSTRATION DOCUMENT'))).toBe(false);
    expect(chunks.map((c) => c.chunkIndex)).toEqual(chunks.map((_, i) => i));
  });

  it('splits long pages with overlap and never crosses a page boundary', async () => {
    const long = Array.from({ length: 40 }, (_, i) => `Sentence number ${i} about pump bearings and lubrication intervals.`);
    const { pages } = await extractPdfPages(await simplePdf([long, ['Second page text about seals and leakage checks.']]));
    const { chunks } = chunkPages(pages, 300, 80);
    const p1 = chunks.filter((c) => c.pageNumber === 1);
    expect(p1.length).toBeGreaterThan(3);
    expect(p1.every((c) => c.text.length <= 300)).toBe(true);
    // overlap: the start of chunk n+1 repeats the end of chunk n
    expect(p1[0]!.text.slice(-40)).toContain(p1[1]!.text.slice(0, 20).trim().split(' ')[0]!);
    expect(chunks.at(-1)).toMatchObject({ pageNumber: 2 });
  });
});

describe('document upload and ingestion', () => {
  it('uploads, ingests in the background and stores page-level vectors with metadata', async () => {
    await createEquipment({ equipmentCode: 'P-101', type: 'pump' });
    const res = await upload(await demoPdf('pump'), { equipmentCodes: 'p-101', equipmentTypes: 'pump,motor' }, 'pump-guide.pdf');
    expect(res.status).toBe(202);
    expect(res.body.data).toMatchObject({ ingestionStatus: 'pending', source: 'upload', fileName: 'pump-guide.pdf' });
    expect(res.body.data).not.toHaveProperty('storagePath');

    await waitForIngestionIdle();
    const status = await request(app).get(`/api/v1/documents/${res.body.data.id}/status`).set('Authorization', admin.auth);
    expect(status.body.data).toMatchObject({ ingestionStatus: 'ready', pageCount: 7, embeddingModel: 'mock-hash-256' });
    expect(status.body.data.chunkCount).toBe(store.size());

    const hit = (await store.query(await getEmbeddingProvider().embedQuery('mechanical seal leakage'), 1))[0]!;
    expect(hit.metadata).toMatchObject({
      documentId: res.body.data.id,
      documentName: 'Pump guide',
      documentType: 'manual',
      pageNumber: 5,
      section: '5 Mechanical seal leakage',
      equipmentCodes: ['P-101'],
      equipmentTypes: ['pump', 'motor'],
      source: 'upload',
    });
    expect(hit.metadata.equipmentIds).toHaveLength(1);
    expect(await AuditLogModel.countDocuments({ action: 'document.uploaded' })).toBe(1);
  });

  it('rejects duplicates (409), non-PDF content, wrong extensions and unknown equipment — leaving no stray files', async () => {
    await uploadReady(await demoPdf('compressor'));
    const before = await countStoredFiles();
    expect((await upload(await demoPdf('compressor'))).status).toBe(409);
    expect((await upload(Buffer.from('<html>fake</html>'), {}, 'fake.pdf')).status).toBe(415);
    expect((await upload(await demoPdf('hx'), {}, 'notes.txt')).status).toBe(415);
    expect((await upload(await demoPdf('hx'), { equipmentCodes: 'ZZ-999' })).status).toBe(400);
    expect((await upload(await demoPdf('hx'), { documentType: 'novel' })).status).toBe(400);
    expect(await countStoredFiles()).toBe(before);
  });

  it('rejects PDFs over MAX_PDF_SIZE_MB with 413', async () => {
    const big = Buffer.concat([Buffer.from('%PDF-1.7\n'), Buffer.alloc(26 * 1024 * 1024, 0x20)]);
    expect((await upload(big)).status).toBe(413);
  });

  it('marks text-less (scanned) PDFs as failed with a clear reason', async () => {
    const doc = await uploadReady(await textlessPdf());
    expect(doc.ingestionStatus).toBe('failed');
    expect(doc.ingestionError).toMatch(/OCR/);
  });

  it('marks ingestion failed when the vector database is unreachable, then reprocess succeeds', async () => {
    const down: VectorStore = { ...store, id: 'down', upsert: async () => { throw new Error('connect ECONNREFUSED 127.0.0.1:8000'); }, deleteByDocument: async () => { throw new Error('connect ECONNREFUSED'); } };
    setVectorStoreForTests(down);
    const doc = await uploadReady(await demoPdf('hx'));
    expect(doc.ingestionStatus).toBe('failed');
    expect(doc.ingestionError).toMatch(/ChromaDB/);

    setVectorStoreForTests(store);
    const r = await request(app).post(`/api/v1/documents/${doc.id}/reprocess`).set('Authorization', admin.auth);
    expect(r.status).toBe(202);
    await waitForIngestionIdle();
    expect((await DocumentModel.findById(doc.id))!.ingestionStatus).toBe('ready');
  });

  it('reprocessing replaces vectors instead of duplicating them', async () => {
    const doc = await uploadReady(await demoPdf('pump'));
    const n = store.size();
    await request(app).post(`/api/v1/documents/${doc.id}/reprocess`).set('Authorization', admin.auth).expect(202);
    await waitForIngestionIdle();
    expect(store.size()).toBe(n);
  });

  it('deletes the document, its file and its vectors', async () => {
    const doc = await uploadReady(await demoPdf('pump'));
    const filesBefore = await countStoredFiles();
    const res = await request(app).delete(`/api/v1/documents/${doc.id}`).set('Authorization', admin.auth);
    expect(res.status).toBe(204);
    expect(await store.countByDocument(doc.id)).toBe(0);
    expect(await countStoredFiles()).toBe(filesBefore - 1);
    expect(await DocumentModel.findById(doc.id)).toBeNull();
    expect((await search({ query: 'mechanical seal leakage' })).body.data.noResults).toBe(true);
  });

  it('refuses to delete when vectors cannot be removed (no orphaned citations)', async () => {
    const doc = await uploadReady(await demoPdf('pump'));
    setVectorStoreForTests({ ...store, deleteByDocument: async () => { throw new Error('ECONNREFUSED'); } });
    expect((await request(app).delete(`/api/v1/documents/${doc.id}`).set('Authorization', admin.auth)).status).toBe(503);
    expect(await DocumentModel.findById(doc.id)).not.toBeNull();
  });
});

describe('document access control', () => {
  it('only admins upload, reprocess or delete; engineers list ready documents; operators have no access', async () => {
    const ready = await uploadReady(await demoPdf('pump'));
    await DocumentModel.create({ title: 'Broken', fileName: 'b.pdf', documentType: 'manual', source: 'upload', storagePath: '/nope', sizeBytes: 1, checksum: 'x'.repeat(64), ingestionStatus: 'failed' });

    expect((await upload(await demoPdf('hx'), {}, 'a.pdf', eng.auth)).status).toBe(403);
    expect((await request(app).delete(`/api/v1/documents/${ready.id}`).set('Authorization', eng.auth)).status).toBe(403);
    expect((await request(app).post(`/api/v1/documents/${ready.id}/reprocess`).set('Authorization', eng.auth)).status).toBe(403);

    const engList = await request(app).get('/api/v1/documents').set('Authorization', eng.auth);
    expect(engList.body.data.map((d: { title: string }) => d.title)).toEqual(['Pump guide']);
    expect((await request(app).get('/api/v1/documents').set('Authorization', admin.auth)).body.data).toHaveLength(2);

    expect((await request(app).get('/api/v1/documents').set('Authorization', op.auth)).status).toBe(403);
    expect((await search({ query: 'seal' }, op.auth)).status).toBe(403);
  });

  it('serves the PDF only to authorised roles (no public file route)', async () => {
    const doc = await uploadReady(await demoPdf('pump'));
    const file = await request(app).get(`/api/v1/documents/${doc.id}/file`).set('Authorization', eng.auth);
    expect(file.status).toBe(200);
    expect(file.headers['content-type']).toMatch(/application\/pdf/);
    expect((await request(app).get(`/api/v1/documents/${doc.id}/file`).set('Authorization', op.auth)).status).toBe(403);
    expect((await request(app).get(`/api/v1/documents/${doc.id}/file`)).status).toBe(401);
  });
});

describe('knowledge search', () => {
  beforeEach(async () => {
    await createEquipment({ equipmentCode: 'P-101', type: 'pump' });
    await createEquipment({ equipmentCode: 'C-301', type: 'compressor' });
    await uploadReady(await demoPdf('pump'), { title: 'Pump guide', equipmentCodes: 'P-101', equipmentTypes: 'pump' });
    await uploadReady(await demoPdf('compressor'), { title: 'Compressor notes', documentType: 'troubleshooting', equipmentCodes: 'C-301', equipmentTypes: 'compressor' });
  });

  it('returns citations with document name, page and section', async () => {
    const res = await search({ query: 'mechanical seal leakage dripping' });
    expect(res.status).toBe(200);
    expect(res.body.data.noResults).toBe(false);
    expect(res.body.data.results[0]).toMatchObject({ documentName: 'Pump guide', documentType: 'manual', pageNumber: 5, section: '5 Mechanical seal leakage' });
    expect(res.body.data.results[0].excerpt).toMatch(/seal/i);
  });

  it('filters by equipment code, equipment type, document type, document id and source', async () => {
    const q = 'bearing oil temperature pressure';
    const byCode = await search({ query: q, filters: { equipmentCode: 'c-301' } });
    expect(new Set(byCode.body.data.results.map((r: { documentName: string }) => r.documentName))).toEqual(new Set(['Compressor notes']));
    const byType = await search({ query: q, filters: { equipmentType: 'pump' } });
    expect(new Set(byType.body.data.results.map((r: { documentName: string }) => r.documentName))).toEqual(new Set(['Pump guide']));
    expect(byType.body.data.noResults).toBe(false);
    const byDocType = await search({ query: q, filters: { documentType: 'troubleshooting' } });
    expect(byDocType.body.data.results.every((r: { documentType: string }) => r.documentType === 'troubleshooting')).toBe(true);
    const id = byCode.body.data.results[0].documentId;
    const byId = await search({ query: q, filters: { documentId: id } });
    expect(byId.body.data.results.every((r: { documentId: string }) => r.documentId === id)).toBe(true);
    expect((await search({ query: q, filters: { source: 'preloaded' } })).body.data.noResults).toBe(true);
  });

  it('says so explicitly when nothing relevant is found (no fabricated citations)', async () => {
    const res = await search({ query: 'cricket scores canteen menu' });
    expect(res.body.data).toMatchObject({ noResults: true, results: [], message: 'No suitable documentation was found in the approved knowledge base.' });
    const none = await search({ query: 'seal leakage', filters: { equipmentCode: 'HX-999' } });
    expect(none.body.data.noResults).toBe(true);
  });

  it('respects topK and validates filters', async () => {
    expect((await search({ query: 'pump bearing vibration temperature', topK: 2 })).body.data.results.length).toBeLessThanOrEqual(2);
    expect((await search({ query: 'x', filters: { documentType: 'novel' } })).status).toBe(400);
  });

  it('/knowledge/ask is extractive and cites its passages', async () => {
    const res = await request(app).post('/api/v1/knowledge/ask').set('Authorization', eng.auth).send({ query: 'lube oil pressure alarm' });
    expect(res.body.data).toMatchObject({ mode: 'extractive', noResults: false });
    expect(res.body.data.answer).toContain(res.body.data.citations[0].excerpt);
    expect(res.body.data.citations[0]).toMatchObject({ documentName: 'Compressor notes', section: '4 Low lube oil pressure' });
  });

  it('ticket references: on demand, engineers only, scoped to the ticket equipment first', async () => {
    const t = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentCode: 'P-101', description: 'Mechanical seal leaking, dripping liquid near the pump', symptoms: ['leak'] });
    const refs = await request(app).get(`/api/v1/tickets/${t.body.data.id}/references`).set('Authorization', eng.auth);
    expect(refs.status).toBe(200);
    expect(refs.body.data).toMatchObject({ scope: 'equipment', noResults: false });
    expect(refs.body.data.results[0]).toMatchObject({ documentName: 'Pump guide', section: '5 Mechanical seal leakage', pageNumber: 5 });
    expect((await request(app).get(`/api/v1/tickets/${t.body.data.id}/references`).set('Authorization', op.auth)).status).toBe(403);
  });
});
