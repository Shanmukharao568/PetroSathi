import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';

const app = createApp();
useTestDatabase();

const P101 = { equipmentCode: 'p-101', name: 'Crude Transfer Pump A', type: 'pump', plant: 'Unit 1', criticality: 'high' };

describe('equipment CRUD (admin)', () => {
  it('creates equipment, normalising the code to upper-case', async () => {
    const admin = await userWithToken(app, 'admin');
    const res = await request(app).post('/api/v1/equipment').set('Authorization', admin.auth).send(P101);
    expect(res.status).toBe(201);
    expect(res.body.data).toMatchObject({ equipmentCode: 'P-101', status: 'operational', criticality: 'high' });
    expect(await AuditLogModel.countDocuments({ action: 'equipment.created' })).toBe(1);
  });

  it('rejects duplicate codes and malformed codes', async () => {
    const admin = await userWithToken(app, 'admin');
    await request(app).post('/api/v1/equipment').set('Authorization', admin.auth).send(P101).expect(201);
    expect((await request(app).post('/api/v1/equipment').set('Authorization', admin.auth).send(P101)).status).toBe(409);
    const bad = await request(app).post('/api/v1/equipment').set('Authorization', admin.auth).send({ ...P101, equipmentCode: 'pump 101' });
    expect(bad.status).toBe(400);
  });

  it('updates and lists with filters', async () => {
    const admin = await userWithToken(app, 'admin');
    const { id } = await createEquipment();
    await createEquipment({ type: 'compressor', equipmentCode: 'C-301' });

    const upd = await request(app).patch(`/api/v1/equipment/${id}`).set('Authorization', admin.auth).send({ status: 'degraded' });
    expect(upd.body.data.status).toBe('degraded');

    const list = await request(app).get('/api/v1/equipment?type=compressor').set('Authorization', admin.auth);
    expect(list.body.data.map((e: { equipmentCode: string }) => e.equipmentCode)).toEqual(['C-301']);
    const byCode = await request(app).get('/api/v1/equipment?code=c-301').set('Authorization', admin.auth);
    expect(byCode.body.data).toHaveLength(1);
  });

  it('deletes unreferenced equipment but refuses when tickets reference it', async () => {
    const admin = await userWithToken(app, 'admin');
    const op = await userWithToken(app, 'operator');
    const free = await createEquipment();
    const used = await createEquipment();

    await request(app)
      .post('/api/v1/tickets')
      .set('Authorization', op.auth)
      .set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentId: used.id, description: 'Abnormal vibration at the pump bearing housing' })
      .expect(201);

    expect((await request(app).delete(`/api/v1/equipment/${free.id}`).set('Authorization', admin.auth)).status).toBe(204);
    const refused = await request(app).delete(`/api/v1/equipment/${used.id}`).set('Authorization', admin.auth);
    expect(refused.status).toBe(409);
    expect(refused.body.error.message).toMatch(/decommissioned/);
  });
});

describe('equipment RBAC', () => {
  it('operators and engineers can read but not write', async () => {
    const { id } = await createEquipment();
    for (const role of ['operator', 'engineer'] as const) {
      const u = await userWithToken(app, role);
      expect((await request(app).get('/api/v1/equipment').set('Authorization', u.auth)).status).toBe(200);
      expect((await request(app).get(`/api/v1/equipment/${id}`).set('Authorization', u.auth)).status).toBe(200);
      expect((await request(app).post('/api/v1/equipment').set('Authorization', u.auth).send({ ...P101, equipmentCode: `X-${role}` })).status).toBe(403);
      expect((await request(app).patch(`/api/v1/equipment/${id}`).set('Authorization', u.auth).send({ name: 'Hacked' })).status).toBe(403);
      expect((await request(app).delete(`/api/v1/equipment/${id}`).set('Authorization', u.auth)).status).toBe(403);
    }
  });

  it('requires authentication', async () => {
    expect((await request(app).get('/api/v1/equipment')).status).toBe(401);
  });
});
