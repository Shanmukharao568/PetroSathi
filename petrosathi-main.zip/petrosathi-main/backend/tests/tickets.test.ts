import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';
import { TicketModel } from '../src/modules/tickets/ticket.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';
import { canTransition, TRANSITIONS } from '../src/modules/tickets/ticket.workflow.js';
import { TICKET_STATUSES } from '../src/config/constants.js';

const app = createApp();
useTestDatabase();

type U = Awaited<ReturnType<typeof userWithToken>>;
let admin: U, op: U, op2: U, eng: U, eng2: U, equipmentId: string, equipmentCode: string;

beforeEach(async () => {
  [admin, op, op2, eng, eng2] = await Promise.all([
    userWithToken(app, 'admin'),
    userWithToken(app, 'operator'),
    userWithToken(app, 'operator'),
    userWithToken(app, 'engineer'),
    userWithToken(app, 'engineer'),
  ]);
  const eq = await createEquipment();
  equipmentId = eq.id;
  equipmentCode = eq.code;
});

async function newTicket(by: U = op, body: Record<string, unknown> = {}) {
  const res = await request(app)
    .post('/api/v1/tickets')
    .set('Authorization', by.auth)
    .set('Idempotency-Key', newIdempotencyKey())
    .send({ equipmentId, description: 'High vibration and noise from pump bearing', symptoms: ['vibration', 'noise'], category: 'mechanical', severity: 'high', ...body });
  expect(res.status).toBe(201);
  return res.body.data as { id: string; ticketNumber: string };
}

const assign = (as: U, id: string, assigneeId: string | null) =>
  request(app).patch(`/api/v1/tickets/${id}/assign`).set('Authorization', as.auth).send({ assigneeId });
const status = (as: U, id: string, body: Record<string, unknown>) =>
  request(app).patch(`/api/v1/tickets/${id}/status`).set('Authorization', as.auth).send(body);

describe('ticket creation', () => {
  it('creates an OPEN ticket with a sequential number and a "created" history entry', async () => {
    const t1 = await newTicket();
    const t2 = await newTicket();
    expect(t1.ticketNumber).toMatch(/^TKT-\d{4}-00001$/);
    expect(t2.ticketNumber).toMatch(/^TKT-\d{4}-00002$/);

    const res = await request(app).get(`/api/v1/tickets/${t1.id}`).set('Authorization', op.auth);
    expect(res.body.data).toMatchObject({
      status: 'OPEN',
      equipmentCode,
      severity: 'high',
      source: 'manual',
      assignedTo: null,
      equipment: { equipmentCode },
    });
    expect(res.body.data.history).toHaveLength(1);
    expect(res.body.data.history[0]).toMatchObject({ type: 'created', toStatus: 'OPEN' });
    expect(res.body.data).not.toHaveProperty('idempotencyKey');
    expect(await AuditLogModel.countDocuments({ action: 'ticket.created' })).toBe(2);
  });

  it('accepts equipmentCode instead of equipmentId', async () => {
    const res = await request(app)
      .post('/api/v1/tickets')
      .set('Authorization', op.auth)
      .set('Idempotency-Key', newIdempotencyKey())
      .send({ equipmentCode: equipmentCode.toLowerCase(), description: 'Seal leaking at the pump casing' });
    expect(res.status).toBe(201);
    expect(res.body.data.severity).toBe('unknown'); // never guessed
  });

  it('is idempotent: replaying the same key returns the same ticket without a duplicate', async () => {
    const key = newIdempotencyKey();
    const send = () =>
      request(app)
        .post('/api/v1/tickets')
        .set('Authorization', op.auth)
        .set('Idempotency-Key', key)
        .send({ equipmentId, description: 'Duplicate submission test complaint' });

    const first = await send();
    const second = await send();
    expect(first.status).toBe(201);
    expect(second.status).toBe(200);
    expect(second.body.meta.idempotentReplay).toBe(true);
    expect(second.body.data.id).toBe(first.body.data.id);
    expect(await TicketModel.countDocuments()).toBe(1);
  });

  it('concurrent submissions with one key still create exactly one ticket', async () => {
    const key = newIdempotencyKey();
    const results = await Promise.all(
      Array.from({ length: 5 }, () =>
        request(app)
          .post('/api/v1/tickets')
          .set('Authorization', op.auth)
          .set('Idempotency-Key', key)
          .send({ equipmentId, description: 'Concurrent duplicate submission' }),
      ),
    );
    expect(results.every((r) => [200, 201].includes(r.status))).toBe(true);
    expect(new Set(results.map((r) => r.body.data.id)).size).toBe(1);
    expect(await TicketModel.countDocuments()).toBe(1);
  });

  it('requires an Idempotency-Key header', async () => {
    const res = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).send({ equipmentId, description: 'No key supplied here' });
    expect(res.status).toBe(400);
  });

  it('rejects unknown and decommissioned equipment, and invalid severity', async () => {
    const key = () => newIdempotencyKey();
    const unknown = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', key())
      .send({ equipmentCode: 'ZZ-999', description: 'Unknown equipment complaint' });
    expect(unknown.status).toBe(400);
    expect(unknown.body.error.message).toMatch(/not registered/);

    const dead = await createEquipment({ status: 'decommissioned' });
    const decom = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', key())
      .send({ equipmentId: dead.id, description: 'Decommissioned equipment complaint' });
    expect(decom.status).toBe(400);

    const sev = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', key())
      .send({ equipmentId, description: 'Bad severity complaint text', severity: 'catastrophic' });
    expect(sev.status).toBe(400);
  });
});

describe('ticket visibility', () => {
  it('operators only see their own tickets; others get 404', async () => {
    const mine = await newTicket(op);
    const theirs = await newTicket(op2);

    const list = await request(app).get('/api/v1/tickets?scope=all').set('Authorization', op.auth);
    expect(list.body.data.map((t: { id: string }) => t.id)).toEqual([mine.id]);

    expect((await request(app).get(`/api/v1/tickets/${theirs.id}`).set('Authorization', op.auth)).status).toBe(404);
    expect((await request(app).get(`/api/v1/tickets/${theirs.id}/history`).set('Authorization', op.auth)).status).toBe(404);
    expect((await request(app).post(`/api/v1/tickets/${theirs.id}/comments`).set('Authorization', op.auth).send({ body: 'hi' })).status).toBe(404);
  });

  it('engineers see all tickets and can filter by scope, status and severity', async () => {
    const a = await newTicket(op, { severity: 'critical' });
    await newTicket(op2, { severity: 'low' });
    await assign(eng, a.id, eng.id).expect(200);

    const all = await request(app).get('/api/v1/tickets').set('Authorization', eng.auth);
    expect(all.body.meta.pagination.total).toBe(2);
    const mine = await request(app).get('/api/v1/tickets?scope=assigned').set('Authorization', eng.auth);
    expect(mine.body.data.map((t: { id: string }) => t.id)).toEqual([a.id]);
    const unassigned = await request(app).get('/api/v1/tickets?scope=unassigned').set('Authorization', eng.auth);
    expect(unassigned.body.data).toHaveLength(1);
    const crit = await request(app).get('/api/v1/tickets?severity=critical,high').set('Authorization', eng.auth);
    expect(crit.body.data).toHaveLength(1);
    const bySeverity = await request(app).get('/api/v1/tickets?sort=severity').set('Authorization', eng.auth);
    expect(bySeverity.body.data[0].severity).toBe('critical');
  });

  it('list responses omit heavy fields (history, comments, transcript)', async () => {
    await newTicket();
    const res = await request(app).get('/api/v1/tickets').set('Authorization', eng.auth);
    expect(res.body.data[0]).not.toHaveProperty('history');
    expect(res.body.data[0]).not.toHaveProperty('comments');
  });
});

describe('assignment', () => {
  it('an engineer can accept an unassigned ticket; others cannot steal it', async () => {
    const t = await newTicket();
    const res = await assign(eng, t.id, eng.id);
    expect(res.status).toBe(200);
    expect(res.body.data.assignedTo.id).toBe(eng.id);
    expect(res.body.data.history.at(-1)).toMatchObject({ type: 'assigned' });

    expect((await assign(eng2, t.id, eng2.id)).status).toBe(403);
  });

  it('an engineer cannot assign tickets to someone else', async () => {
    const t = await newTicket();
    expect((await assign(eng, t.id, eng2.id)).status).toBe(403);
  });

  it('the assigned engineer can release an OPEN ticket but not one in progress', async () => {
    const t = await newTicket();
    await assign(eng, t.id, eng.id).expect(200);
    expect((await assign(eng, t.id, null)).status).toBe(200);

    await assign(eng, t.id, eng.id).expect(200);
    await status(eng, t.id, { status: 'IN_PROGRESS' }).expect(200);
    expect((await assign(eng, t.id, null)).status).toBe(403);
  });

  it('admin can assign and reassign, but only to active engineers', async () => {
    const t = await newTicket();
    await assign(admin, t.id, eng.id).expect(200);
    const re = await assign(admin, t.id, eng2.id);
    expect(re.status).toBe(200);
    expect(re.body.data.assignedTo.id).toBe(eng2.id);

    expect((await assign(admin, t.id, op.id)).status).toBe(400);
  });

  it('operators cannot assign', async () => {
    const t = await newTicket();
    expect((await assign(op, t.id, eng.id)).status).toBe(403);
  });
});

describe('status lifecycle', () => {
  it('the transition table matches the documented lifecycle', () => {
    expect(canTransition('OPEN', 'UNDER_INSPECTION')).toBe(true);
    expect(canTransition('OPEN', 'RESOLVED')).toBe(false);
    expect(canTransition('OPEN', 'CLOSED')).toBe(false);
    expect(canTransition('RESOLVED', 'CLOSED')).toBe(true);
    for (const s of TICKET_STATUSES) expect(canTransition('CLOSED', s)).toBe(false);
    expect(TRANSITIONS.CLOSED).toEqual([]);
  });

  it('walks OPEN → UNDER_INSPECTION → IN_PROGRESS → RESOLVED → CLOSED with full history', async () => {
    const t = await newTicket();
    await assign(eng, t.id, eng.id).expect(200);
    await status(eng, t.id, { status: 'UNDER_INSPECTION', comment: 'Going to check bearings' }).expect(200);
    await status(eng, t.id, { status: 'IN_PROGRESS' }).expect(200);
    const resolved = await status(eng, t.id, {
      status: 'RESOLVED',
      resolution: { summary: 'Replaced drive-end bearing', rootCause: 'Lubrication failure', actionsTaken: 'Bearing replaced, alignment checked' },
    });
    expect(resolved.status).toBe(200);
    expect(resolved.body.data.resolution).toMatchObject({ summary: 'Replaced drive-end bearing' });
    expect(resolved.body.data.resolvedAt).toBeTruthy();

    const closed = await status(eng, t.id, { status: 'CLOSED' });
    expect(closed.body.data.status).toBe('CLOSED');
    expect(closed.body.data.closedAt).toBeTruthy();
    expect(closed.body.data.permissions).toMatchObject({ changeStatus: false, comment: false, allowedTransitions: [] });

    const history = await request(app).get(`/api/v1/tickets/${t.id}/history`).set('Authorization', op.auth);
    expect(history.body.data.map((h: { type: string; toStatus: string | null }) => `${h.type}:${h.toStatus ?? ''}`)).toEqual([
      'created:OPEN',
      'assigned:',
      'status_changed:UNDER_INSPECTION',
      'status_changed:IN_PROGRESS',
      'status_changed:RESOLVED',
      'status_changed:CLOSED',
    ]);
    const inspection = history.body.data[2];
    expect(inspection).toMatchObject({ fromStatus: 'OPEN', comment: 'Going to check bearings', actor: { id: eng.id } });
    expect(inspection.at).toBeTruthy();
    expect(await AuditLogModel.countDocuments({ action: 'ticket.status_changed' })).toBe(4);
  });

  it('rejects invalid transitions with INVALID_STATUS_TRANSITION and the allowed list', async () => {
    const t = await newTicket();
    await assign(eng, t.id, eng.id).expect(200);
    const res = await status(eng, t.id, { status: 'CLOSED' });
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('INVALID_STATUS_TRANSITION');
    expect(res.body.error.details.allowed).toEqual(['UNDER_INSPECTION', 'IN_PROGRESS']);
  });

  it('requires an assignee before any status change', async () => {
    const t = await newTicket();
    const res = await status(admin, t.id, { status: 'UNDER_INSPECTION' });
    expect(res.status).toBe(409);
    expect(res.body.error.message).toMatch(/Assign/);
  });

  it('requires resolution details to resolve, and a reason to reopen', async () => {
    const t = await newTicket();
    await assign(eng, t.id, eng.id).expect(200);
    await status(eng, t.id, { status: 'IN_PROGRESS' }).expect(200);
    expect((await status(eng, t.id, { status: 'RESOLVED' })).status).toBe(400);
    await status(eng, t.id, { status: 'RESOLVED', resolution: { summary: 'Tightened gland packing' } }).expect(200);

    expect((await status(eng, t.id, { status: 'IN_PROGRESS' })).status).toBe(400);
    const reopened = await status(eng, t.id, { status: 'IN_PROGRESS', comment: 'Leak returned after 2 hours' });
    expect(reopened.status).toBe(200);
    expect(reopened.body.data.resolution).toBeNull();
  });

  it('only the assigned engineer or an admin may change status', async () => {
    const t = await newTicket();
    await assign(eng, t.id, eng.id).expect(200);
    expect((await status(eng2, t.id, { status: 'IN_PROGRESS' })).status).toBe(403);
    expect((await status(op, t.id, { status: 'IN_PROGRESS' })).status).toBe(403);
    expect((await status(admin, t.id, { status: 'IN_PROGRESS' })).status).toBe(200);
  });

  it('exposes per-user permissions on the ticket', async () => {
    const t = await newTicket();
    const asEng = await request(app).get(`/api/v1/tickets/${t.id}`).set('Authorization', eng.auth);
    expect(asEng.body.data.permissions).toMatchObject({ accept: true, changeStatus: false });
    const asOp = await request(app).get(`/api/v1/tickets/${t.id}`).set('Authorization', op.auth);
    expect(asOp.body.data.permissions).toMatchObject({ view: true, comment: true, accept: false, assign: false, changeStatus: false });
  });
});

describe('comments', () => {
  it('reporter and engineers can comment; closed tickets reject comments', async () => {
    const t = await newTicket();
    const c1 = await request(app).post(`/api/v1/tickets/${t.id}/comments`).set('Authorization', op.auth).send({ body: 'Noise is getting louder' });
    expect(c1.status).toBe(201);
    expect(c1.body.data).toMatchObject({ body: 'Noise is getting louder', author: { id: op.id } });
    await request(app).post(`/api/v1/tickets/${t.id}/comments`).set('Authorization', eng.auth).send({ body: 'On my way' }).expect(201);

    const detail = await request(app).get(`/api/v1/tickets/${t.id}`).set('Authorization', op.auth);
    expect(detail.body.data.comments).toHaveLength(2);

    await assign(eng, t.id, eng.id).expect(200);
    await status(eng, t.id, { status: 'IN_PROGRESS' }).expect(200);
    await status(eng, t.id, { status: 'RESOLVED', resolution: { summary: 'Fixed the issue' } }).expect(200);
    await status(eng, t.id, { status: 'CLOSED' }).expect(200);
    expect((await request(app).post(`/api/v1/tickets/${t.id}/comments`).set('Authorization', op.auth).send({ body: 'late' })).status).toBe(409);
  });

  it('rejects empty comments', async () => {
    const t = await newTicket();
    expect((await request(app).post(`/api/v1/tickets/${t.id}/comments`).set('Authorization', op.auth).send({ body: '   ' })).status).toBe(400);
  });
});
