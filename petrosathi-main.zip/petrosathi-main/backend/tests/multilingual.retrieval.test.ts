/**
 * Multilingual retrieval with the REAL chosen embedding model (multilingual-e5-small) on the
 * demo corpus. Skipped — and reported as skipped — unless the model is already cached in
 * MODEL_CACHE_DIR (run `npm run rag:benchmark` once to download it); tests never download.
 */
import { describe, expect, it } from 'vitest';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { createLocalEmbedding } from '../src/rag/embeddings/localEmbedding.js';
import { createMemoryStore } from '../src/rag/vectorStore/memoryStore.js';
import { extractPdfPages } from '../src/rag/pdf.js';
import { chunkPages } from '../src/rag/chunker.js';
import { DEMO_DOCUMENTS } from '../src/rag/demoContent.js';
import { buildDemoPdf } from '../src/rag/demoPdf.js';

const MODEL = 'Xenova/multilingual-e5-small';
const cached = existsSync(path.join(process.env.MODEL_CACHE_DIR!, ...MODEL.split('/')));

describe.skipIf(!cached)(`multilingual retrieval (${MODEL}, local)`, () => {
  const emb = createLocalEmbedding(MODEL, process.env.MODEL_CACHE_DIR!);
  const store = createMemoryStore();
  const ready = (async () => {
    for (const doc of DEMO_DOCUMENTS) {
      const { pages } = await extractPdfPages(Buffer.from(await buildDemoPdf(doc)));
      const { chunks } = chunkPages(pages, 1000, 200);
      const vectors = await emb.embedDocuments(chunks.map((c) => c.text));
      await store.upsert(
        chunks.map((c, i) => ({
          id: `${doc.key}:${i}`,
          embedding: vectors[i]!,
          text: c.text,
          metadata: { documentId: doc.key, documentName: doc.title, documentType: doc.documentType, pageNumber: c.pageNumber, section: c.section, equipmentIds: [], equipmentCodes: [], equipmentTypes: doc.equipmentTypes, source: 'preloaded', chunkIndex: i, embeddingModel: MODEL },
        })),
      );
    }
  })();

  it.each([
    ['en', 'The mechanical seal is leaking, what should I report?', '5 Mechanical seal leakage'],
    ['hi', 'मैकेनिकल सील से रिसाव हो रहा है, क्या रिपोर्ट करूं?', '5 Mechanical seal leakage'],
    ['te', 'కంప్రెసర్‌పై లూబ్ ఆయిల్ ప్రెషర్ తక్కువ అలారం', '4 Low lube oil pressure'],
    ['ta', 'செப்பரேட்டர் அருகே வாயு வாசனை வருகிறது, எப்படி புகாரளிப்பது?', '3 How to report a leak or gas smell'],
    ['hi-en', 'pump mein kankad jaisi awaaz, suction pressure low hai', '6 Cavitation and low suction pressure'],
  ])('%s query finds the right English section in the top 5', async (_lang, query, section) => {
    await ready;
    const hits = await store.query(await emb.embedQuery(query), 5);
    expect(hits.map((h) => h.metadata.section)).toContain(section);
  }, 120_000);

  it('applies the equipment-type filter on top of semantic ranking', async () => {
    await ready;
    const hits = await store.query(await emb.embedQuery('high temperature'), 5, { equipmentType: 'compressor' });
    expect(hits.length).toBeGreaterThan(0);
    // The safety guide is also tagged "compressor"; every hit must carry the tag.
    expect(hits.every((h) => h.metadata.equipmentTypes.includes('compressor'))).toBe(true);
    expect(hits.some((h) => h.metadata.documentId === 'pump' || h.metadata.documentId === 'hx')).toBe(false);
  }, 120_000);
});
