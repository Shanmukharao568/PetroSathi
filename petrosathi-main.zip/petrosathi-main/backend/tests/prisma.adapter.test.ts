/**
 * Tests the REAL Gnani Prisma adapter against a LOCAL STUB server that implements the
 * protocol as documented on docs.gnani.ai. These tests do NOT contact Gnani and do not prove
 * the live service behaves identically — they prove the adapter speaks the documented protocol.
 */
import { afterEach, describe, expect, it } from 'vitest';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { WebSocketServer } from 'ws';
import { createGnaniPrismaService } from '../src/providers/gnani/gnaniPrismaService.js';
import { ProviderError } from '../src/providers/gnani/prisma.types.js';
import { fakeMp3, pcmTone } from './helpers/audio.js';

const servers: { close: () => void }[] = [];
afterEach(() => {
  while (servers.length) servers.pop()!.close();
});

function tempMp3(): string {
  const p = path.join(process.env.AUDIO_UPLOAD_DIR!, `adapter-${Date.now()}-${Math.random()}.mp3`);
  writeFileSync(p, fakeMp3());
  return p;
}

interface Captured {
  headers: http.IncomingHttpHeaders;
  body: string;
}

async function stubRest(handler: (cap: Captured, res: http.ServerResponse, n: number) => void) {
  let n = 0;
  const server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => handler({ headers: req.headers, body: Buffer.concat(chunks).toString('latin1') }, res, n++));
  });
  await new Promise<void>((r) => server.listen(0, r));
  servers.push({ close: () => server.close() });
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}/stt/v3`;
}

const json = (res: http.ServerResponse, status: number, body: unknown) => {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
};

const base = { apiKeyId: 'test-key-id', wsUrl: 'ws://unused', model: 'prisma-v3.0', timeoutMs: 2000, maxRetries: 2 };

describe('Prisma REST adapter (stub of documented API)', () => {
  it('sends X-API-Key-ID and the documented multipart fields, and parses the documented response', async () => {
    let captured: Captured | null = null;
    const restUrl = await stubRest((cap, res) => {
      captured = cap;
      json(res, 200, { success: true, request_id: 'req-1', transcript: ' पंप में कंपन ', model: 'prisma-v3.0', detected_language_code: 'hi-IN', processing_time: 0.5 });
    });
    const svc = createGnaniPrismaService({ ...base, restUrl });
    const r = await svc.transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'indic-auto' });

    expect(r).toEqual({ provider: 'gnani-prisma', transcript: 'पंप में कंपन', detectedLanguage: 'hi-IN', model: 'prisma-v3.0', requestId: 'req-1', truncated: false });
    expect(captured!.headers['x-api-key-id']).toBe('test-key-id');
    expect(captured!.headers['content-type']).toMatch(/multipart\/form-data/);
    expect(captured!.body).toMatch(/name="audio_file"; filename="audio.mp3"/);
    expect(captured!.body).toMatch(/name="language_code"\r\n\r\nindic-auto/);
    expect(captured!.body).toMatch(/name="model"\r\n\r\nprisma-v3.0/);
  });

  it('omits the model field when no model is configured', async () => {
    let body = '';
    const restUrl = await stubRest((cap, res) => {
      body = cap.body;
      json(res, 200, { success: true, transcript: 'x', model: 'prisma-v2.5' });
    });
    await createGnaniPrismaService({ ...base, model: undefined, restUrl }).transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' });
    expect(body).not.toMatch(/name="model"/);
  });

  it('maps the documented 400 error envelope to a "rejected" error with the provider code', async () => {
    const restUrl = await stubRest((_c, res) => json(res, 400, { success: false, error: { type: 'MAX_AUDIO_DURATION_EXCEEDED', message: 'Audio longer than 30s' } }));
    const err = await createGnaniPrismaService({ ...base, restUrl })
      .transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' })
      .catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ProviderError);
    expect(err).toMatchObject({ kind: 'rejected', providerCode: 'MAX_AUDIO_DURATION_EXCEEDED' });
  });

  it('maps 401 to an auth error and does not retry it', async () => {
    let calls = 0;
    const restUrl = await stubRest((_c, res) => {
      calls++;
      json(res, 401, { detail: { error_code: 'INVALID_API_KEY', message: 'bad', status_code: 401 } });
    });
    const err = await createGnaniPrismaService({ ...base, restUrl }).transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' }).catch((e: unknown) => e);
    expect(err).toMatchObject({ kind: 'auth' });
    expect(calls).toBe(1);
  });

  it('retries 503 with backoff and then succeeds', async () => {
    const restUrl = await stubRest((_c, res, n) => (n === 0 ? json(res, 503, {}) : json(res, 200, { success: true, transcript: 'ok' })));
    const r = await createGnaniPrismaService({ ...base, restUrl }).transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' });
    expect(r.transcript).toBe('ok');
  });

  it('times out instead of hanging', async () => {
    const restUrl = await stubRest(() => {
      /* never respond */
    });
    const err = await createGnaniPrismaService({ ...base, restUrl, timeoutMs: 300 })
      .transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' })
      .catch((e: unknown) => e);
    expect(err).toMatchObject({ kind: 'timeout' });
  });

  it('rejects an unexpected success shape as a protocol error', async () => {
    const restUrl = await stubRest((_c, res) => json(res, 200, { ok: true }));
    const err = await createGnaniPrismaService({ ...base, restUrl }).transcribeFile({ filePath: tempMp3(), fileName: 'audio.mp3', languageCode: 'en-IN' }).catch((e: unknown) => e);
    expect(err).toMatchObject({ kind: 'protocol' });
  });
});

describe('Prisma streaming adapter (stub of documented protocol)', () => {
  async function stubWs(opts: { reject401?: boolean } = {}) {
    const server = http.createServer();
    const state = { headers: {} as http.IncomingHttpHeaders, frameSizes: [] as number[], textMessages: [] as string[] };
    const wss = new WebSocketServer({ noServer: true });
    server.on('upgrade', (req, socket, head) => {
      state.headers = req.headers;
      if (opts.reject401) {
        socket.write('HTTP/1.1 401 Unauthorized\r\nContent-Length: 0\r\n\r\n');
        socket.destroy();
        return;
      }
      wss.handleUpgrade(req, socket, head, (ws) => {
        ws.send(JSON.stringify({ type: 'connected', message: 'ok', config: { sample_rate: 16000, chunk_size: 512 } }));
        ws.on('message', (data, isBinary) => {
          if (isBinary) {
            state.frameSizes.push((data as Buffer).length);
            return;
          }
          const msg = data.toString();
          state.textMessages.push(msg);
          if (JSON.parse(msg).type === 'commit') {
            ws.send(JSON.stringify({ type: 'processing', timestamp: 't' }));
            setTimeout(() => {
              ws.send(JSON.stringify({ type: 'transcript', text: 'pump vibration high', segment_index: 1, segment_id: 'r-seg-1', detected_language_code: 'en-IN', audio_duration_ms: 1000, is_final: true }));
            }, 50);
          }
        });
      });
    });
    await new Promise<void>((r) => server.listen(0, r));
    servers.push({ close: () => { wss.close(); server.close(); } });
    return { url: `ws://127.0.0.1:${(server.address() as AddressInfo).port}/stt/v3/stream`, state };
  }

  it('sends documented upgrade headers, exact 1,024-byte frames, commit, and yields segments', async () => {
    const { url, state } = await stubWs();
    const svc = createGnaniPrismaService({ ...base, restUrl: 'http://unused', wsUrl: url, finishQuietMs: 200, finishMaxMs: 3000 });
    const segments: unknown[] = [];
    const stream = await svc.openStream('en-IN', { onSegment: (s) => segments.push(s), onFatal: () => {} });

    const audio = pcmTone(0.5); // 16,000 bytes → 15 full frames + a 640-byte remainder
    for (let i = 0; i < audio.length; i += 3000) stream.sendAudio(audio.subarray(i, i + 3000));
    await stream.finish();

    expect(state.headers['x-api-key-id']).toBe('test-key-id');
    expect(state.headers['language_code']).toBe('en-IN');
    expect(state.headers['model']).toBe('prisma-v3.0');
    expect(state.headers['x-sample-rate']).toBe('16000');
    expect(state.frameSizes.length).toBe(16);
    expect(state.frameSizes.every((n) => n === 1024)).toBe(true);
    expect(state.textMessages).toEqual([JSON.stringify({ type: 'commit' })]);
    expect(segments).toEqual([{ text: 'pump vibration high', segmentIndex: 1, detectedLanguage: 'en-IN', audioDurationMs: 1000 }]);
  });

  it('maps a 401 handshake to an auth error', async () => {
    const { url } = await stubWs({ reject401: true });
    const err = await createGnaniPrismaService({ ...base, restUrl: 'http://unused', wsUrl: url })
      .openStream('en-IN', { onSegment: () => {}, onFatal: () => {} })
      .catch((e: unknown) => e);
    expect(err).toMatchObject({ kind: 'auth' });
  });
});
