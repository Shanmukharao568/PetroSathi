import { describe, expect, it } from 'vitest';
import { apiRouter } from '../src/routes/index.js';
import { openApiDocument } from '../src/docs/openapi.js';

interface Layer {
  route?: { path: string; methods: Record<string, boolean> };
  name: string;
  regexp: RegExp;
  handle: { stack?: Layer[] };
}

/** Mount prefix of an Express 4 router layer, e.g. /^\/auth\/?(?=\/|$)/i → "/auth". */
function mountPath(layer: Layer): string {
  return layer.regexp.source
    .replace('^', '')
    .replace('\\/?(?=\\/|$)', '')
    .replace(/\\\//g, '/');
}

/** Every "METHOD /path" actually served under /api/v1, with :param → {param}. */
function servedRoutes(): string[] {
  const out: string[] = [];
  const walk = (stack: Layer[], prefix: string) => {
    for (const layer of stack) {
      if (layer.route) {
        for (const m of Object.keys(layer.route.methods)) {
          const p = `${prefix}${layer.route.path === '/' ? '' : layer.route.path}`.replace(/:(\w+)/g, '{$1}') || '/';
          out.push(`${m.toUpperCase()} ${p}`);
        }
      } else if (layer.name === 'router' && layer.handle.stack) {
        walk(layer.handle.stack, prefix + mountPath(layer));
      }
    }
  };
  walk((apiRouter as unknown as { stack: Layer[] }).stack, '');
  return [...new Set(out)].sort();
}

function documentedRoutes(): string[] {
  const out: string[] = [];
  for (const [path, ops] of Object.entries(openApiDocument.paths)) {
    for (const m of Object.keys(ops)) out.push(`${m.toUpperCase()} ${path}`);
  }
  return out.sort();
}

describe('OpenAPI document matches the real routes', () => {
  it('documents every served endpoint and nothing that does not exist', () => {
    const served = servedRoutes();
    const documented = documentedRoutes();
    expect(served.length).toBeGreaterThan(40);
    // Walker sanity: nested routers, params and every method are discovered.
    expect(served).toEqual(
      expect.arrayContaining([
        'POST /auth/login',
        'GET /health',
        'PATCH /users/{id}/password',
        'POST /complaints/drafts/{id}/confirm',
        'GET /tickets/{id}/references',
        'DELETE /documents/{id}',
        'PATCH /notifications/read-all',
        'GET /audit-logs/facets',
        'GET /dashboard',
      ]),
    );
    expect(served.filter((r) => !documented.includes(r)), 'served but undocumented').toEqual([]);
    expect(documented.filter((r) => !served.includes(r)), 'documented but not served').toEqual([]);
  });

  it('marks every endpoint except login, sign-up and health as requiring a bearer token', () => {
    const open = new Set(['POST /auth/login', 'POST /auth/register', 'GET /health']);
    for (const [path, ops] of Object.entries(openApiDocument.paths)) {
      for (const [m, op] of Object.entries(ops as Record<string, { security?: unknown[] }>)) {
        const key = `${m.toUpperCase()} ${path}`;
        if (open.has(key)) expect(op.security, key).toBeUndefined();
        else expect(op.security, key).toBeDefined();
      }
    }
  });
});
