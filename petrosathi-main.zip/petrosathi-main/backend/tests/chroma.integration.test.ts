/**
 * Runs against a REAL ChromaDB server (CHROMA_URL, default http://localhost:8000).
 * Skipped — and reported as skipped — when no server is reachable. Start one with `npm run chroma`.
 */
import { afterAll, describe, expect, it } from 'vitest';
import { ChromaClient } from 'chromadb';
import { createChromaStore } from '../src/rag/vectorStore/chromaStore.js';
import type { ChunkRecord } from '../src/rag/vectorStore/types.js';

const url = process.env.CHROMA_URL ?? 'http://localhost:8000';
const reachable = await fetch(`${url}/api/v2/heartbeat`, { signal: AbortSignal.timeout(1500) })
  .then((r) => r.ok)
  .catch(() => false);

const collection = `petrosathi_test_${Date.now()}`;

function unit(v: number[]): number[] {
  const n = Math.hypot(...v);
  return v.map((x) => x / n);
}

function rec(id: string, documentId: string, embedding: number[], meta: Partial<ChunkRecord['metadata']> = {}): ChunkRecord {
  return {
    id,
    embedding: unit(embedding),
    text: `chunk ${id}`,
    metadata: {
      documentId,
      documentName: `Doc ${documentId}`,
      documentType: 'manual',
      pageNumber: 3,
      section: '3 High vibration',
      equipmentIds: [],
      equipmentCodes: [],
      equipmentTypes: [],
      source: 'upload',
      chunkIndex: 0,
      embeddingModel: 'test',
      ...meta,
    },
  };
}

describe.skipIf(!reachable)(`ChromaDB integration (${url})`, () => {
  const store = createChromaStore({ url, collection });

  afterAll(async () => {
    const u = new URL(url);
    await new ChromaClient({ host: u.hostname, port: Number(u.port || 80) }).deleteCollection({ name: collection }).catch(() => {});
  });

  it('upserts, queries with cosine similarity and round-trips metadata (including arrays)', async () => {
    await store.upsert([
      rec('a:0', 'docA', [1, 0, 0], { equipmentCodes: ['P-101'], equipmentTypes: ['pump'], equipmentIds: ['64b7f0c2a1b2c3d4e5f60718'] }),
      rec('b:0', 'docB', [0, 1, 0], { equipmentCodes: ['C-301'], equipmentTypes: ['compressor'], documentType: 'troubleshooting', source: 'preloaded' }),
      rec('c:0', 'docC', [0.7, 0.7, 0]),
    ]);
    const hits = await store.query(unit([1, 0.05, 0]), 3);
    expect(hits[0]!.id).toBe('a:0');
    expect(hits[0]!.score).toBeGreaterThan(0.99);
    expect(hits[0]!.metadata).toMatchObject({ documentId: 'docA', pageNumber: 3, section: '3 High vibration', equipmentCodes: ['P-101'], equipmentTypes: ['pump'] });
    expect(hits.at(-1)!.id).toBe('b:0');
  });

  it('filters by equipment code / type ($contains on array metadata), document type, source and id', async () => {
    const q = unit([1, 1, 1]);
    expect((await store.query(q, 5, { equipmentCode: 'C-301' })).map((h) => h.id)).toEqual(['b:0']);
    expect((await store.query(q, 5, { equipmentType: 'pump' })).map((h) => h.id)).toEqual(['a:0']);
    expect((await store.query(q, 5, { documentType: 'troubleshooting' })).map((h) => h.id)).toEqual(['b:0']);
    expect((await store.query(q, 5, { source: 'preloaded' })).map((h) => h.id)).toEqual(['b:0']);
    expect((await store.query(q, 5, { documentId: 'docC' })).map((h) => h.id)).toEqual(['c:0']);
    // Untagged documents never match an equipment filter.
    expect((await store.query(q, 5, { equipmentCode: 'P-999' }))).toEqual([]);
    expect((await store.query(q, 5, { equipmentCode: 'P-101', documentType: 'manual' })).map((h) => h.id)).toEqual(['a:0']);
  });

  it('deletes every vector of a document (vector cleanup)', async () => {
    await store.upsert([rec('a:1', 'docA', [1, 0.1, 0])]);
    expect(await store.countByDocument('docA')).toBe(2);
    await store.deleteByDocument('docA');
    expect(await store.countByDocument('docA')).toBe(0);
    expect((await store.query(unit([1, 0, 0]), 5)).some((h) => h.metadata.documentId === 'docA')).toBe(false);
  });

  it('health check succeeds', async () => {
    await expect(store.health()).resolves.toBeUndefined();
  });
});
