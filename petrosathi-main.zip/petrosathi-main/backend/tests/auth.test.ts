import { describe, expect, it } from 'vitest';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createUser, DEFAULT_PASSWORD, userWithToken } from './helpers/factories.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';
import { UserModel } from '../src/modules/users/user.model.js';

const app = createApp();
useTestDatabase();

describe('POST /auth/login', () => {
  it('logs in with valid credentials and never returns password data', async () => {
    const { email } = await createUser({ role: 'engineer' });
    const res = await request(app).post('/api/v1/auth/login').send({ email, password: DEFAULT_PASSWORD });

    expect(res.status).toBe(200);
    expect(res.body.data.token).toEqual(expect.any(String));
    expect(res.body.data.user).toMatchObject({ email, role: 'engineer' });
    expect(JSON.stringify(res.body)).not.toMatch(/passwordHash|tokenVersion/);
    expect(await AuditLogModel.countDocuments({ action: 'auth.login.success' })).toBe(1);
  });

  it('is case-insensitive on email', async () => {
    const { email } = await createUser();
    const res = await request(app).post('/api/v1/auth/login').send({ email: email.toUpperCase(), password: DEFAULT_PASSWORD });
    expect(res.status).toBe(200);
  });

  it('rejects a wrong password with a generic message', async () => {
    const { email } = await createUser();
    const res = await request(app).post('/api/v1/auth/login').send({ email, password: 'Wrong-Password-1' });
    expect(res.status).toBe(401);
    expect(res.body.error).toMatchObject({ code: 'INVALID_CREDENTIALS', message: 'Invalid email or password' });
  });

  it('rejects an unknown email with the same generic message', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({ email: 'nobody@example.test', password: 'Whatever-123' });
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('INVALID_CREDENTIALS');
  });

  it('rejects an inactive user', async () => {
    const { email } = await createUser({ isActive: false });
    const res = await request(app).post('/api/v1/auth/login').send({ email, password: DEFAULT_PASSWORD });
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('ACCOUNT_DISABLED');
  });

  it('validates the request body', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({ email: 'not-an-email' });
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('public sign-up can never choose a role (no privilege escalation)', async () => {
    const res = await request(app)
      .post('/api/v1/auth/register')
      .send({ name: 'Sneaky', email: 'x@example.test', password: DEFAULT_PASSWORD, role: 'admin' });
    expect(res.status).toBe(400);
    expect(await UserModel.exists({ email: 'x@example.test' })).toBeNull();
  });
});

describe('token handling', () => {
  it('GET /auth/me returns the current user', async () => {
    const op = await userWithToken(app, 'operator');
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', op.auth);
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ id: op.id, role: 'operator' });
  });

  it('rejects requests without a token', async () => {
    const res = await request(app).get('/api/v1/auth/me');
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('UNAUTHORIZED');
  });

  it('rejects a malformed token', async () => {
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', 'Bearer not.a.jwt');
    expect(res.status).toBe(401);
  });

  it('rejects a token signed with a different secret', async () => {
    const { id } = await createUser();
    const forged = jwt.sign({ sub: id, role: 'admin', tv: 0 }, 'some-other-secret-that-is-long-enough!!', {
      issuer: 'petrosathi-api',
      audience: 'petrosathi-client',
    });
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', `Bearer ${forged}`);
    expect(res.status).toBe(401);
  });

  it('rejects an expired token with TOKEN_EXPIRED', async () => {
    const { id } = await createUser();
    const expired = jwt.sign(
      { sub: id, role: 'operator', tv: 0, exp: Math.floor(Date.now() / 1000) - 60 },
      process.env.JWT_SECRET!,
      { issuer: 'petrosathi-api', audience: 'petrosathi-client' },
    );
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', `Bearer ${expired}`);
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('TOKEN_EXPIRED');
  });

  it('logout revokes the token', async () => {
    const op = await userWithToken(app, 'operator');
    const out = await request(app).post('/api/v1/auth/logout').set('Authorization', op.auth);
    expect(out.status).toBe(204);
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', op.auth);
    expect(res.status).toBe(401);
  });

  it('a token stops working immediately after the user is deactivated', async () => {
    const admin = await userWithToken(app, 'admin');
    const op = await userWithToken(app, 'operator');
    await request(app).patch(`/api/v1/users/${op.id}`).set('Authorization', admin.auth).send({ isActive: false }).expect(200);
    const res = await request(app).get('/api/v1/auth/me').set('Authorization', op.auth);
    expect(res.status).toBe(401);
  });
});

describe('forced password change', () => {
  it('blocks normal routes until the temporary password is changed, then issues a new token', async () => {
    const admin = await userWithToken(app, 'admin', { mustChangePassword: true });

    // /auth/me is allowed and reports the flag
    const me = await request(app).get('/api/v1/auth/me').set('Authorization', admin.auth);
    expect(me.body.data.mustChangePassword).toBe(true);

    // Other routes are blocked
    const blocked = await request(app).get('/api/v1/users').set('Authorization', admin.auth);
    expect(blocked.status).toBe(403);
    expect(blocked.body.error.code).toBe('PASSWORD_CHANGE_REQUIRED');

    // Weak password rejected by policy
    const weak = await request(app)
      .patch(`/api/v1/users/${admin.id}/password`)
      .set('Authorization', admin.auth)
      .send({ currentPassword: DEFAULT_PASSWORD, newPassword: 'short' });
    expect(weak.status).toBe(400);

    // Wrong current password rejected
    const wrong = await request(app)
      .patch(`/api/v1/users/${admin.id}/password`)
      .set('Authorization', admin.auth)
      .send({ currentPassword: 'Not-The-One-1', newPassword: 'Brand-New-Pass-9' });
    expect(wrong.status).toBe(400);

    const changed = await request(app)
      .patch(`/api/v1/users/${admin.id}/password`)
      .set('Authorization', admin.auth)
      .send({ currentPassword: DEFAULT_PASSWORD, newPassword: 'Brand-New-Pass-9' });
    expect(changed.status).toBe(200);
    expect(changed.body.data.user.mustChangePassword).toBe(false);

    // Old token revoked; new token works on normal routes
    expect((await request(app).get('/api/v1/auth/me').set('Authorization', admin.auth)).status).toBe(401);
    const ok = await request(app).get('/api/v1/users').set('Authorization', `Bearer ${changed.body.data.token}`);
    expect(ok.status).toBe(200);
  });
});
