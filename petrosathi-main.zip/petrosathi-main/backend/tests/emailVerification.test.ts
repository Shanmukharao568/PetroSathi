import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { userWithToken } from './helpers/factories.js';
import { testOutbox } from '../src/utils/mailer.js';
import { EmailOtpModel } from '../src/modules/auth/emailOtp.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';
import { UserModel } from '../src/modules/users/user.model.js';
import { maskEmail } from '../src/modules/auth/emailVerification.service.js';

const app = createApp();
useTestDatabase();

beforeEach(() => {
  testOutbox.length = 0;
});

const unverified = (role: 'operator' | 'engineer' | 'admin' = 'operator') => userWithToken(app, role, { emailVerified: false });
const sendCode = (auth: string) => request(app).post('/api/v1/auth/email/send-code').set('Authorization', auth);
const verify = (auth: string, code: string) => request(app).post('/api/v1/auth/email/verify').set('Authorization', auth).send({ code });
const lastCode = () => /\b(\d{6})\b/.exec(testOutbox.at(-1)!.text)![1]!;

describe('email verification with a one-time code', () => {
  it('blocks the app until the email is verified, then unblocks it', async () => {
    const op = await unverified();

    // Sign-in works and tells the client verification is pending.
    const me = await request(app).get('/api/v1/auth/me').set('Authorization', op.auth);
    expect(me.status).toBe(200);
    expect(me.body.data).toMatchObject({ emailVerified: false, emailVerificationRequired: true });

    // Everything else is refused with a clear code.
    const blocked = await request(app).get('/api/v1/tickets').set('Authorization', op.auth);
    expect(blocked.status).toBe(403);
    expect(blocked.body.error.code).toBe('EMAIL_VERIFICATION_REQUIRED');

    const sent = await sendCode(op.auth);
    expect(sent.status).toBe(200);
    expect(sent.body.data).toMatchObject({ sentTo: maskEmail(op.email), delivery: 'server-log' });
    expect(testOutbox).toHaveLength(1);
    expect(testOutbox[0]!.to).toBe(op.email);
    expect(testOutbox[0]!.html).toContain(lastCode());

    const ok = await verify(op.auth, lastCode());
    expect(ok.status).toBe(200);
    expect(ok.body.data).toMatchObject({ emailVerified: true, emailVerificationRequired: false });
    expect(ok.body.data.emailVerifiedAt).toBeTruthy();

    expect((await request(app).get('/api/v1/tickets').set('Authorization', op.auth)).status).toBe(200);
    expect(await EmailOtpModel.countDocuments()).toBe(0); // the code is single-use
    expect(await AuditLogModel.countDocuments({ action: 'user.email_verified' })).toBe(1);
  });

  it('accepts a code typed with spaces, and only stores a hash of it', async () => {
    const op = await unverified();
    await sendCode(op.auth);
    const code = lastCode();
    const stored = await EmailOtpModel.findOne({ userId: op.id });
    expect(stored!.codeHash).not.toContain(code);
    expect((await verify(op.auth, `${code.slice(0, 3)} ${code.slice(3)}`)).status).toBe(200);
  });

  it('counts wrong codes and requires a new code after too many', async () => {
    const op = await unverified();
    await sendCode(op.auth);
    const good = lastCode();
    const wrong = good === '000000' ? '111111' : '000000';

    const first = await verify(op.auth, wrong);
    expect(first.status).toBe(400);
    expect(first.body.error).toMatchObject({ code: 'OTP_INVALID', details: { attemptsLeft: 4 } });
    for (let i = 0; i < 3; i++) await verify(op.auth, wrong);
    const locked = await verify(op.auth, wrong);
    expect(locked.body.error.code).toBe('OTP_EXPIRED');

    // Even the right code is useless now.
    expect((await verify(op.auth, good)).body.error.code).toBe('OTP_EXPIRED');
  });

  it('rejects expired codes', async () => {
    const op = await unverified();
    await sendCode(op.auth);
    await EmailOtpModel.updateOne({ userId: op.id }, { expiresAt: new Date(Date.now() - 1000) });
    const res = await verify(op.auth, lastCode());
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('OTP_EXPIRED');
  });

  it('enforces a resend cooldown, after which a new code replaces the old one', async () => {
    const op = await unverified();
    await sendCode(op.auth);
    const firstCode = lastCode();

    const tooSoon = await sendCode(op.auth);
    expect(tooSoon.status).toBe(429);
    expect(tooSoon.body.error.details.retryAfterSeconds).toBeGreaterThan(0);
    expect(testOutbox).toHaveLength(1);

    await EmailOtpModel.updateOne({ userId: op.id }, { sentAt: new Date(Date.now() - 120_000) });
    expect((await sendCode(op.auth)).status).toBe(200);
    const secondCode = lastCode();
    if (secondCode !== firstCode) expect((await verify(op.auth, firstCode)).body.error.code).toBe('OTP_INVALID');
    expect((await verify(op.auth, secondCode)).status).toBe(200);
  });

  it("one user's code does not verify another user", async () => {
    const a = await unverified();
    const b = await unverified();
    await sendCode(a.auth);
    const codeForA = lastCode();
    await sendCode(b.auth);
    if (codeForA !== lastCode()) {
      expect((await verify(b.auth, codeForA)).status).toBe(400);
    }
    expect((await UserModel.findById(b.id))!.emailVerified).toBe(false);
  });

  it('asks for the temporary password change first, and refuses when already verified', async () => {
    const pending = await userWithToken(app, 'engineer', { emailVerified: false, mustChangePassword: true });
    const res = await sendCode(pending.auth);
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('PASSWORD_CHANGE_REQUIRED');

    const done = await userWithToken(app, 'engineer'); // factory default: verified
    expect((await sendCode(done.auth)).status).toBe(409);
  });

  it('validates the code format', async () => {
    const op = await unverified();
    expect((await verify(op.auth, '12ab56')).status).toBe(400);
    expect((await verify(op.auth, '12345')).status).toBe(400);
  });

  it('masks addresses shown to the user', () => {
    expect(maskEmail('ravi.kumar@example.com')).toBe('ra••••••••@example.com');
    expect(maskEmail('ab@x.io')).toBe('a•••@x.io');
  });
});
