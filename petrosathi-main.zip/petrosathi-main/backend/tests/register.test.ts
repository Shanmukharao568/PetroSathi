import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createUser, DEFAULT_PASSWORD } from './helpers/factories.js';
import { testOutbox } from '../src/utils/mailer.js';
import { UserModel } from '../src/modules/users/user.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';

const app = createApp();
useTestDatabase();

beforeEach(() => {
  testOutbox.length = 0;
});

const signUp = (body: Record<string, unknown>) => request(app).post('/api/v1/auth/register').send(body);
const valid = { name: 'Lakshmi Reddy', email: 'Lakshmi.R@Example.test', password: DEFAULT_PASSWORD, preferredLanguage: 'te-IN' };

describe('public sign-up', () => {
  it('creates a Field Operator, signs them in, and requires the email code before anything else', async () => {
    const res = await signUp(valid);
    expect(res.status).toBe(201);
    expect(res.body.data.token).toEqual(expect.any(String));
    expect(res.body.data.user).toMatchObject({
      email: 'lakshmi.r@example.test',
      role: 'operator',
      preferredLanguage: 'te-IN',
      mustChangePassword: false,
      emailVerified: false,
      emailVerificationRequired: true,
    });
    expect(JSON.stringify(res.body)).not.toMatch(/passwordHash|Correct-Horse/);
    const auth = `Bearer ${res.body.data.token}`;

    // Locked until the email is verified.
    const blocked = await request(app).get('/api/v1/tickets').set('Authorization', auth);
    expect(blocked.body.error.code).toBe('EMAIL_VERIFICATION_REQUIRED');

    await request(app).post('/api/v1/auth/email/send-code').set('Authorization', auth).expect(200);
    const code = /\b(\d{6})\b/.exec(testOutbox.at(-1)!.text)![1]!;
    await request(app).post('/api/v1/auth/email/verify').set('Authorization', auth).send({ code }).expect(200);
    expect((await request(app).get('/api/v1/tickets').set('Authorization', auth)).status).toBe(200);

    // The chosen password works for normal sign-in, and the sign-up is audited.
    const login = await request(app).post('/api/v1/auth/login').send({ email: valid.email, password: DEFAULT_PASSWORD });
    expect(login.status).toBe(200);
    expect(await AuditLogModel.countDocuments({ action: 'user.registered' })).toBe(1);
  });

  it('refuses an email that already has an account', async () => {
    const existing = await createUser();
    const res = await signUp({ ...valid, email: existing.email.toUpperCase() });
    expect(res.status).toBe(409);
    expect(await UserModel.countDocuments({ email: existing.email })).toBe(1);
  });

  it('enforces the password policy and rejects privileged or unknown fields', async () => {
    expect((await signUp({ ...valid, password: 'short1A' })).status).toBe(400);
    expect((await signUp({ ...valid, password: 'alllowercase123' })).status).toBe(400);
    expect((await signUp({ ...valid, email: 'not-an-email' })).status).toBe(400);
    expect((await signUp({ ...valid, name: 'x' })).status).toBe(400);
    for (const extra of [{ role: 'admin' }, { role: 'engineer' }, { isActive: true }, { emailVerified: true }, { mustChangePassword: false }]) {
      expect((await signUp({ ...valid, ...extra })).status).toBe(400);
    }
    expect(await UserModel.countDocuments()).toBe(0);
  });
});
