import { describe, expect, it } from 'vitest';
import { createGeminiEmbedding, GeminiEmbeddingError } from '../src/rag/embeddings/geminiEmbedding.js';
import { parseEnv } from '../src/config/env.js';

type Req = { url: string; headers: Record<string, string>; body: { requests: { model: string; taskType: string; outputDimensionality: number; content: { parts: { text: string }[] } }[] } };

function fakeFetch(responses: ((req: Req) => Response)[]) {
  const calls: Req[] = [];
  const impl = (async (url: string, init: RequestInit) => {
    const req: Req = { url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) };
    calls.push(req);
    const next = responses.shift() ?? ((r: Req) => ok(r, 4));
    return next(req);
  }) as unknown as typeof fetch;
  return { impl, calls };
}

const ok = (req: Req, dims: number) =>
  new Response(JSON.stringify({ embeddings: req.body.requests.map((_, i) => ({ values: Array.from({ length: dims }, (_, j) => (j === 0 ? 3 : j === 1 ? 4 : 0) + i * 0) })) }), { status: 200 });

const noSleep = async () => {};

describe('Gemini embedding provider', () => {
  it('sends retrieval task types, the requested size and the key in a header; returns unit vectors', async () => {
    const f = fakeFetch([(r) => ok(r, 4), (r) => ok(r, 4)]);
    const p = createGeminiEmbedding({ apiKey: 'k-123', dimensions: 4, fetchImpl: f.impl, sleep: noSleep });
    const docs = await p.embedDocuments(['a', 'b']);
    const q = await p.embedQuery('q');

    expect(p.model).toBe('gemini-embedding-001-4');
    expect(f.calls[0]!.url).toBe('https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:batchEmbedContents');
    expect(f.calls[0]!.url).not.toContain('k-123');
    expect(f.calls[0]!.headers['x-goog-api-key']).toBe('k-123');
    expect(f.calls[0]!.body.requests.map((r) => r.taskType)).toEqual(['RETRIEVAL_DOCUMENT', 'RETRIEVAL_DOCUMENT']);
    expect(f.calls[0]!.body.requests[0]!.outputDimensionality).toBe(4);
    expect(f.calls[1]!.body.requests[0]!.taskType).toBe('RETRIEVAL_QUERY');
    expect(docs[0]).toEqual([0.6, 0.8, 0, 0]);
    expect(Math.hypot(...q)).toBeCloseTo(1);
  });

  it('splits large inputs into batches of 100', async () => {
    const f = fakeFetch([]);
    const p = createGeminiEmbedding({ apiKey: 'k', dimensions: 4, fetchImpl: f.impl, sleep: noSleep });
    const out = await p.embedDocuments(Array.from({ length: 250 }, (_, i) => `t${i}`));
    expect(out).toHaveLength(250);
    expect(f.calls.map((c) => c.body.requests.length)).toEqual([100, 100, 50]);
  });

  it('retries rate limits (429) using the server-suggested delay, then succeeds', async () => {
    const waits: number[] = [];
    const f = fakeFetch([() => new Response('{"error":{"details":[{"retryDelay":"7s"}]}}', { status: 429 }), (r) => ok(r, 4)]);
    const p = createGeminiEmbedding({ apiKey: 'k', dimensions: 4, fetchImpl: f.impl, sleep: async (ms) => void waits.push(ms) });
    await p.embedQuery('x');
    expect(waits).toEqual([7000]);
    expect(f.calls).toHaveLength(2);
  });

  it('fails fast on configuration errors without retrying', async () => {
    const f = fakeFetch([() => new Response('{"error":{"code":400,"message":"API key not valid."}}', { status: 400 })]);
    const p = createGeminiEmbedding({ apiKey: 'bad', dimensions: 4, fetchImpl: f.impl, sleep: noSleep });
    await expect(p.embedQuery('x')).rejects.toThrow(GeminiEmbeddingError);
    await expect(createGeminiEmbedding({ apiKey: 'bad', dimensions: 4, fetchImpl: fakeFetch([() => new Response('{"error":{"message":"API key not valid."}}', { status: 400 })]).impl, sleep: noSleep }).embedQuery('x')).rejects.toThrow(/HTTP 400\): API key not valid/);
    expect(f.calls).toHaveLength(1);
  });

  it('rejects responses with the wrong vector size', async () => {
    const f = fakeFetch([(r) => ok(r, 8)]);
    const p = createGeminiEmbedding({ apiKey: 'k', dimensions: 4, fetchImpl: f.impl, sleep: noSleep });
    await expect(p.embedQuery('x')).rejects.toThrow(/expected 4 dimensions/);
  });

  it('requires an API key, and a calibrated threshold in production', () => {
    const base = { JWT_SECRET: 'x'.repeat(40), EMBEDDING_PROVIDER: 'gemini' };
    expect(() => parseEnv(base)).toThrow(/EMBEDDING_API_KEY: required/);
    expect(() => parseEnv({ ...base, EMBEDDING_API_KEY: 'k', NODE_ENV: 'production', EMAIL_VERIFICATION_REQUIRED: 'false' })).toThrow(/RAG_MIN_RELEVANCE_SCORE: required/);
    expect(parseEnv({ ...base, EMBEDDING_API_KEY: 'k', NODE_ENV: 'production', EMAIL_VERIFICATION_REQUIRED: 'false', RAG_MIN_RELEVANCE_SCORE: '0.6' }).EMBEDDING_DIMENSIONS).toBe(768);
  });
});
