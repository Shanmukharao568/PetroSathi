import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import WebSocket from 'ws';
import { createApp } from '../src/app.js';
import { attachVoiceSocket, activeVoiceSessionCount, APP_PROTOCOL } from '../src/ws/voiceStream.js';
import { useTestDatabase } from './helpers/testDb.js';
import { userWithToken } from './helpers/factories.js';
import { pcmTone } from './helpers/audio.js';
import { ConversationModel } from '../src/modules/conversations/conversation.model.js';
import { setPrismaProviderForTests } from '../src/providers/gnani/index.js';
import { createMockPrismaService, MOCK_PREFIX } from '../src/providers/gnani/mockPrismaService.js';
import type { PrismaProvider } from '../src/providers/gnani/prisma.types.js';

useTestDatabase();

let server: http.Server;
let url: string;

beforeAll(async () => {
  server = http.createServer(createApp());
  attachVoiceSocket(server);
  await new Promise<void>((r) => server.listen(0, r));
  url = `ws://127.0.0.1:${(server.address() as AddressInfo).port}/api/v1/voice/stream`;
});
afterAll(() => new Promise<void>((r) => server.close(() => r())));
afterEach(() => setPrismaProviderForTests(null));

type Msg = Record<string, unknown> & { type: string };

/** Opens an app socket and records every JSON message and the close code. */
function connect(token: string | null, opts: { origin?: string } = {}) {
  const protocols = token ? [APP_PROTOCOL, `bearer.${token}`] : [APP_PROTOCOL];
  const ws = new WebSocket(url, protocols, { headers: { origin: opts.origin ?? 'http://localhost:5173' } });
  const messages: Msg[] = [];
  const closed = new Promise<{ code: number }>((resolve) => ws.on('close', (code) => resolve({ code })));
  const status = new Promise<number>((resolve) => {
    ws.on('unexpected-response', (_req, res) => resolve(res.statusCode ?? 0));
    ws.on('open', () => resolve(101));
  });
  ws.on('error', () => {});
  ws.on('message', (d, isBinary) => {
    if (!isBinary) messages.push(JSON.parse(d.toString()) as Msg);
  });
  const waitFor = (type: string, timeoutMs = 4000) =>
    new Promise<Msg>((resolve, reject) => {
      const started = Date.now();
      const t = setInterval(() => {
        const m = messages.find((x) => x.type === type);
        if (m) {
          clearInterval(t);
          resolve(m);
        } else if (Date.now() - started > timeoutMs) {
          clearInterval(t);
          reject(new Error(`timed out waiting for ${type}; got ${JSON.stringify(messages)}`));
        }
      }, 10);
    });
  return { ws, messages, closed, status, waitFor };
}

async function sendPcm(ws: WebSocket, audio: Buffer, frame = 3200) {
  for (let i = 0; i < audio.length; i += frame) ws.send(audio.subarray(i, i + frame));
}

describe('voice stream: handshake', () => {
  it('rejects connections without a token (401)', async () => {
    const c = connect(null);
    expect(await c.status).toBe(401);
  });

  it('rejects an invalid token (401)', async () => {
    const c = connect('not-a-jwt');
    expect(await c.status).toBe(401);
  });

  it('rejects foreign origins (403)', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token, { origin: 'https://evil.example' });
    expect(await c.status).toBe(403);
  });

  it('allows only one concurrent session per user (409)', async () => {
    const op = await userWithToken(app(), 'operator');
    const first = connect(op.token);
    expect(await first.status).toBe(101);
    const second = connect(op.token);
    expect(await second.status).toBe(409);
    first.ws.close();
    await first.closed;
  });
});

describe('voice stream: session (mock provider)', () => {
  it('start → audio → stop yields labelled transcript, completed, a stored conversation, and a clean close', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'te-IN' }));
    const ready = await c.waitFor('session_ready');
    expect(ready).toMatchObject({ provider: 'mock', language: 'te-IN', sampleRate: 16000, encoding: 'pcm_s16le', channels: 1 });

    await sendPcm(c.ws, pcmTone(1));
    c.ws.send(JSON.stringify({ type: 'stop' }));

    const seg = await c.waitFor('transcript');
    expect(String(seg.text).startsWith(MOCK_PREFIX)).toBe(true);
    const done = await c.waitFor('completed');
    expect(done).toMatchObject({ provider: 'mock', audioMode: 'stream', language: 'te-IN', segmentCount: 1, audioDurationMs: 1000 });
    expect((await c.closed).code).toBe(1000);

    const conv = await ConversationModel.findById(done.conversationId as string);
    expect(conv).toMatchObject({ audioMode: 'stream', provider: 'mock' });
    expect(activeVoiceSessionCount()).toBe(0);
  });

  it('completes with an empty transcript and no conversation when there is too little audio', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    await c.waitFor('session_ready');
    c.ws.send(pcmTone(0.05));
    c.ws.send(JSON.stringify({ type: 'stop' }));
    const done = await c.waitFor('completed');
    expect(done).toMatchObject({ conversationId: null, transcript: '' });
    expect(await ConversationModel.countDocuments()).toBe(0);
  });

  it('rejects audio before start (NOT_STARTED, close 1008)', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(pcmTone(0.1));
    expect((await c.waitFor('error')).code).toBe('NOT_STARTED');
    expect((await c.closed).code).toBe(1008);
  });

  it('rejects odd-length (non-PCM16) frames (INVALID_AUDIO_FRAME, close 1007)', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    await c.waitFor('session_ready');
    c.ws.send(Buffer.alloc(101));
    expect((await c.waitFor('error')).code).toBe('INVALID_AUDIO_FRAME');
    expect((await c.closed).code).toBe(1007);
  });

  it('closes with 1009 when a frame exceeds the payload limit', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    await c.waitFor('session_ready');
    c.ws.send(Buffer.alloc(64 * 1024));
    expect((await c.closed).code).toBe(1009);
    await new Promise((r) => setTimeout(r, 50));
    expect(activeVoiceSessionCount()).toBe(0);
  });

  it('rejects unsupported languages (close 1008)', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'fr-FR' }));
    expect((await c.waitFor('error')).code).toBe('UNSUPPORTED_LANGUAGE');
    expect((await c.closed).code).toBe(1008);
  });

  it('reports malformed control messages without killing the session', async () => {
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send('{not json');
    expect((await c.waitFor('error')).recoverable).toBe(true);
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    await c.waitFor('session_ready');
    c.ws.close();
    await c.closed;
  });

  it('client disconnect mid-stream aborts the provider and saves nothing', async () => {
    let aborted = false;
    const mock = createMockPrismaService();
    const spy: PrismaProvider = {
      ...mock,
      openStream: async (lang, cb) => {
        const s = await mock.openStream(lang, cb);
        return { ...s, abort: () => { aborted = true; s.abort(); } };
      },
    };
    setPrismaProviderForTests(spy);

    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    await c.waitFor('session_ready');
    await sendPcm(c.ws, pcmTone(0.5));
    c.ws.terminate();
    await c.closed;
    await new Promise((r) => setTimeout(r, 100));

    expect(aborted).toBe(true);
    expect(activeVoiceSessionCount()).toBe(0);
    expect(await ConversationModel.countDocuments()).toBe(0);
  });

  it('surfaces provider connection failures as an error event', async () => {
    const { ProviderError } = await import('../src/providers/gnani/prisma.types.js');
    setPrismaProviderForTests({
      id: 'gnani-prisma',
      transcribeFile: async () => { throw new Error('unused'); },
      openStream: async () => { throw new ProviderError('unavailable', 'down'); },
    });
    const op = await userWithToken(app(), 'operator');
    const c = connect(op.token);
    await c.status;
    c.ws.send(JSON.stringify({ type: 'start', language: 'en-IN' }));
    const err = await c.waitFor('error');
    expect(err).toMatchObject({ code: 'PROVIDER_ERROR', recoverable: false });
    expect((await c.closed).code).toBe(1011);
  });
});

// userWithToken needs an Express app for the login call.
let _app: ReturnType<typeof createApp> | null = null;
function app() {
  return (_app ??= createApp());
}
