import { describe, expect, it } from 'vitest';
import { buildMongoFilter, vectorIndexDefinition } from '../src/rag/vectorStore/mongoStore.js';

describe('MongoDB Atlas vector store', () => {
  it('builds $vectorSearch filters with the same semantics as the Chroma filters', () => {
    expect(buildMongoFilter(undefined)).toBeUndefined();
    expect(buildMongoFilter({})).toBeUndefined();
    expect(buildMongoFilter({ equipmentCode: 'P-101' })).toEqual({ equipmentCodes: { $eq: 'P-101' } });
    expect(buildMongoFilter({ documentType: 'manual', equipmentType: 'pump', source: 'upload' })).toEqual({
      $and: [{ documentType: { $eq: 'manual' } }, { source: { $eq: 'upload' } }, { equipmentTypes: { $eq: 'pump' } }],
    });
  });

  it('indexes every field a filter can use', () => {
    const def = vectorIndexDefinition(384);
    expect(def.fields[0]).toEqual({ type: 'vector', path: 'embedding', numDimensions: 384, similarity: 'cosine' });
    const filterPaths = def.fields.filter((f) => f.type === 'filter').map((f) => f.path);
    const all = { documentId: 'd', documentType: 'manual', source: 'upload' as const, equipmentCode: 'P-1', equipmentType: 'pump' };
    const used = (buildMongoFilter(all) as { $and: Record<string, unknown>[] }).$and.map((c) => Object.keys(c)[0]);
    expect(filterPaths.sort()).toEqual(used.sort());
  });
});
