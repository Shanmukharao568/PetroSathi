/**
 * The REAL Timbre adapter against a LOCAL STUB of the documented API (docs.gnani.ai/api/TTS).
 * Does not contact Gnani.
 */
import { afterEach, describe, expect, it } from 'vitest';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { createGnaniTimbreService } from '../src/providers/gnani/gnaniTimbreService.js';
import { parseEnv } from '../src/config/env.js';

const servers: http.Server[] = [];
afterEach(() => {
  while (servers.length) servers.pop()!.close();
});

interface Seen {
  headers: http.IncomingHttpHeaders;
  body: Record<string, unknown>;
}

async function stub(handler: (seen: Seen, res: http.ServerResponse, n: number) => void, delayMs = 0) {
  let n = 0;
  let active = 0;
  const stats = { maxConcurrent: 0, calls: 0 };
  const server = http.createServer((req, res) => {
    active++;
    stats.calls++;
    stats.maxConcurrent = Math.max(stats.maxConcurrent, active);
    const chunks: Buffer[] = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () =>
      setTimeout(() => {
        res.on('finish', () => active--);
        handler({ headers: req.headers, body: JSON.parse(Buffer.concat(chunks).toString()) }, res, n++);
      }, delayMs),
    );
  });
  await new Promise<void>((r) => server.listen(0, r));
  servers.push(server);
  return { url: `http://127.0.0.1:${(server.address() as AddressInfo).port}/api/v1/tts/inference`, stats };
}

const audio = (res: http.ServerResponse) => {
  res.writeHead(200, { 'Content-Type': 'audio/mpeg' });
  res.end(Buffer.from('ID3-fake-mp3-bytes'));
};
const cfg = (url: string, over: Partial<{ model: string; voice: string }> = {}) => ({ apiKeyId: 'k', url, model: 'timbre-v3.0', voice: 'Shivani', timeoutMs: 2000, ...over });

describe('Timbre adapter (stub of documented API)', () => {
  it('sends the documented header and body, returns the audio bytes', async () => {
    let seen: Seen | null = null;
    const { url } = await stub((s, res) => {
      seen = s;
      audio(res);
    });
    const r = await createGnaniTimbreService(cfg(url)).synthesize('नमस्ते', 'hi-IN');
    expect(r.contentType).toBe('audio/mpeg');
    expect(r.audio.toString()).toBe('ID3-fake-mp3-bytes');
    expect(seen!.headers['x-api-key-id']).toBe('k');
    expect(seen!.body).toMatchObject({ text: 'नमस्ते', model: 'timbre-v3.0', voice: 'Shivani', language: 'hi-IN', speed: 1.0, audio_config: { container: 'mp3', sample_rate: 24000 } });
  });

  it('never reports success without audio (JSON 200 → error)', async () => {
    const { url } = await stub((_s, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end('{"ok":true}');
    });
    await expect(createGnaniTimbreService(cfg(url)).synthesize('hello', 'en-IN')).rejects.toMatchObject({ kind: 'protocol' });
  });

  it('maps documented errors: 400 flat body → rejected, 401 detail → auth', async () => {
    const bad = await stub((_s, res) => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, message: 'Invalid request: Field required at body -> text', status_code: 400 }));
    });
    await expect(createGnaniTimbreService(cfg(bad.url)).synthesize('hello', 'en-IN')).rejects.toMatchObject({ kind: 'rejected' });

    const unauth = await stub((_s, res) => {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ detail: { error_code: 'INVALID_API_KEY', message: 'Unauthorized', status_code: 401 } }));
    });
    await expect(createGnaniTimbreService(cfg(unauth.url)).synthesize('hello', 'en-IN')).rejects.toMatchObject({ kind: 'auth', providerCode: 'INVALID_API_KEY' });
  });

  it('retries once on 429 ("Only 1 active request")', async () => {
    const { url, stats } = await stub((_s, res, n) => {
      if (n === 0) {
        res.writeHead(429, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ detail: { error_code: 'RATE_LIMITED', message: 'Only 1 active request is allowed at a time.' } }));
      } else audio(res);
    });
    await createGnaniTimbreService(cfg(url)).synthesize('hello', 'en-IN');
    expect(stats.calls).toBe(2);
  });

  it('serialises requests (one active at a time) and caches identical prompts', async () => {
    const { url, stats } = await stub((_s, res) => audio(res), 80);
    const svc = createGnaniTimbreService(cfg(url));
    await Promise.all([svc.synthesize('one', 'en-IN'), svc.synthesize('two', 'en-IN'), svc.synthesize('three', 'en-IN')]);
    expect(stats.maxConcurrent).toBe(1);
    await svc.synthesize('one', 'en-IN');
    expect(stats.calls).toBe(3);
  });

  it('refuses languages the configured voice does not speak, without calling the API', async () => {
    const { url, stats } = await stub((_s, res) => audio(res));
    const svc = createGnaniTimbreService(cfg(url, { model: 'timbre-v2.5', voice: 'Nalini' }));
    expect(svc.languages).toEqual(['hi-IN']);
    await expect(svc.synthesize('hello', 'ta-IN')).rejects.toMatchObject({ kind: 'rejected' });
    expect(stats.calls).toBe(0);
  });
});

describe('Phase 5 configuration rules', () => {
  const base = { JWT_SECRET: 'x'.repeat(40) };
  const real = { ...base, AI_PROVIDER_MODE: 'real', GNANI_API_KEY_ID: 'k', GNANI_PRISMA_STT_URL: 'https://a.example/stt', GNANI_PRISMA_WS_URL: 'wss://a.example/ws' };

  it('refuses real Evon (no documented API) unless mock is chosen explicitly', () => {
    expect(() => parseEnv(real)).toThrow(/EVON_PROVIDER_MODE/);
    expect(() => parseEnv({ ...base, EVON_PROVIDER_MODE: 'real' })).toThrow(/EVON_PROVIDER_MODE/);
    expect(parseEnv({ ...real, EVON_PROVIDER_MODE: 'mock' }).EVON_PROVIDER_MODE).toBe('mock');
  });

  it('treats an empty EVON_PROVIDER_MODE as unset', () => {
    expect(parseEnv({ ...base, EVON_PROVIDER_MODE: '' }).EVON_PROVIDER_MODE).toBeUndefined();
  });

  it('validates Timbre model and voice when configured in real mode', () => {
    const ok = { ...real, EVON_PROVIDER_MODE: 'mock', GNANI_TIMBRE_API_URL: 'https://a.example/tts' };
    expect(() => parseEnv({ ...ok, GNANI_TIMBRE_MODEL: 'timbre-v3.0', GNANI_TIMBRE_VOICE: 'Shivani' })).not.toThrow();
    expect(() => parseEnv({ ...ok, GNANI_TIMBRE_MODEL: 'timbre-v3.0', GNANI_TIMBRE_VOICE: 'Nalini' })).toThrow(/GNANI_TIMBRE_VOICE/);
    expect(() => parseEnv({ ...ok, GNANI_TIMBRE_MODEL: 'timbre-v9', GNANI_TIMBRE_VOICE: 'Shivani' })).toThrow(/GNANI_TIMBRE_MODEL/);
  });
});
