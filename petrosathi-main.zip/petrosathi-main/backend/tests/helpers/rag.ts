import { PDFDocument, StandardFonts } from 'pdf-lib';
import { DEMO_DOCUMENTS } from '../../src/rag/demoContent.js';
import { buildDemoPdf } from '../../src/rag/demoPdf.js';

export const pumpDoc = DEMO_DOCUMENTS.find((d) => d.key === 'pump')!;
export const compressorDoc = DEMO_DOCUMENTS.find((d) => d.key === 'compressor')!;

export async function demoPdf(key: 'pump' | 'compressor' | 'safety' | 'hx'): Promise<Buffer> {
  return Buffer.from(await buildDemoPdf(DEMO_DOCUMENTS.find((d) => d.key === key)!));
}

/** A valid PDF whose page has no text (like a scanned image page). */
export async function textlessPdf(): Promise<Buffer> {
  const pdf = await PDFDocument.create();
  pdf.addPage([595, 842]);
  return Buffer.from(await pdf.save());
}

/** Small text PDF with given page texts (one line per entry). */
export async function simplePdf(pages: string[][]): Promise<Buffer> {
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  for (const lines of pages) {
    const page = pdf.addPage([595, 842]);
    let y = 780;
    for (const line of lines) {
      page.drawText(line, { x: 50, y, size: 11, font });
      y -= 16;
    }
  }
  return Buffer.from(await pdf.save());
}
