import request from 'supertest';
import type { Express } from 'express';
import { UserModel } from '../../src/modules/users/user.model.js';
import { hashPassword } from '../../src/utils/password.js';
import { EquipmentModel } from '../../src/modules/equipment/equipment.model.js';
import type { Role } from '../../src/config/constants.js';

export const DEFAULT_PASSWORD = 'Correct-Horse-42';

let counter = 0;

export async function createUser(
  overrides: Partial<{ name: string; email: string; role: Role; isActive: boolean; mustChangePassword: boolean; emailVerified: boolean; password: string }> = {},
) {
  counter += 1;
  const { password = DEFAULT_PASSWORD, ...rest } = overrides;
  const user = await UserModel.create({
    name: `Test User ${counter}`,
    email: `user${counter}@example.test`,
    role: 'operator',
    mustChangePassword: false,
    // Most tests are about other features; the email-verification tests opt out explicitly.
    emailVerified: true,
    ...rest,
    passwordHash: await hashPassword(password),
  });
  return { user, id: String(user._id), email: user.email, password };
}

export async function loginAs(app: Express, email: string, password = DEFAULT_PASSWORD): Promise<string> {
  const res = await request(app).post('/api/v1/auth/login').send({ email, password });
  if (res.status !== 200) throw new Error(`login failed (${res.status}): ${JSON.stringify(res.body)}`);
  return res.body.data.token as string;
}

let eqCounter = 100;
export async function createEquipment(overrides: Record<string, unknown> = {}) {
  eqCounter += 1;
  const eq = await EquipmentModel.create({
    equipmentCode: `P-${eqCounter}`,
    name: `Test Pump ${eqCounter}`,
    type: 'pump',
    plant: 'Test Plant',
    ...overrides,
  });
  return { equipment: eq, id: String(eq._id), code: eq.equipmentCode };
}

let keyCounter = 0;
export const newIdempotencyKey = () => `test-key-${Date.now()}-${++keyCounter}`;

/** Creates a user of the given role and returns a valid bearer token for it. */
export async function userWithToken(app: Express, role: Role, overrides: Parameters<typeof createUser>[0] = {}) {
  const u = await createUser({ role, ...overrides });
  const token = await loginAs(app, u.email, u.password);
  return { ...u, token, auth: `Bearer ${token}` };
}
