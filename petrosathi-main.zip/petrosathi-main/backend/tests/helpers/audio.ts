import { readdirSync } from 'node:fs';

/** Bytes that pass MP3 signature detection. Not decodable audio — the mock provider never decodes. */
export function fakeMp3(bytes = 4096): Buffer {
  const header = Buffer.from([0x49, 0x44, 0x33, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]); // "ID3" v2.4
  return Buffer.concat([header, Buffer.alloc(bytes, 0x55)]);
}

/** PCM16LE mono 16 kHz sine wave. */
export function pcmTone(seconds: number, hz = 440): Buffer {
  const samples = Math.round(16000 * seconds);
  const buf = Buffer.alloc(samples * 2);
  for (let i = 0; i < samples; i++) {
    buf.writeInt16LE(Math.round(Math.sin((2 * Math.PI * hz * i) / 16000) * 8000), i * 2);
  }
  return buf;
}

export function audioDirEntries(): string[] {
  return readdirSync(process.env.AUDIO_UPLOAD_DIR!);
}
