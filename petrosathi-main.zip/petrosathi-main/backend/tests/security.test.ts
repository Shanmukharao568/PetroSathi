import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import WebSocket from 'ws';
import request from 'supertest';
import { apiDocsEnabled, createApp } from '../src/app.js';
import { parseEnv } from '../src/config/env.js';
import { attachVoiceSocket, APP_PROTOCOL, clientIp, resetUpgradeLimiter, UPGRADES_PER_MINUTE } from '../src/ws/voiceStream.js';
import { extractPdfPages, PdfValidationError } from '../src/rag/pdf.js';
import { simplePdf } from './helpers/rag.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createUser } from './helpers/factories.js';

useTestDatabase();
const app = createApp();

describe('proxy trust and client IP', () => {
  it('does not trust X-Forwarded-For by default', () => {
    expect(parseEnv({ JWT_SECRET: 'x'.repeat(40) }).TRUST_PROXY).toBe(0);
    expect(app.get('trust proxy')).toBe(0);
  });

  it('only believes X-Forwarded-For for the configured number of hops', () => {
    const req = { headers: { 'x-forwarded-for': '6.6.6.6, 203.0.113.9' }, socket: { remoteAddress: '10.0.0.2' } } as unknown as http.IncomingMessage;
    expect(clientIp(req, 0)).toBe('10.0.0.2'); // direct: spoofed header ignored
    expect(clientIp(req, 1)).toBe('203.0.113.9'); // one proxy: the address it saw
    expect(clientIp(req, 2)).toBe('6.6.6.6');
  });
});

describe('API docs exposure', () => {
  it('is on outside production, off in production unless explicitly enabled', () => {
    expect(apiDocsEnabled({ NODE_ENV: 'development', ENABLE_API_DOCS: undefined })).toBe(true);
    expect(apiDocsEnabled({ NODE_ENV: 'production', ENABLE_API_DOCS: undefined })).toBe(false);
    expect(apiDocsEnabled({ NODE_ENV: 'production', ENABLE_API_DOCS: true })).toBe(true);
    expect(apiDocsEnabled({ NODE_ENV: 'development', ENABLE_API_DOCS: false })).toBe(false);
  });
});

describe('untrusted input hardening', () => {
  it('rejects NoSQL operator injection in query strings and bodies', async () => {
    const admin = await createUser({ role: 'admin' });
    const login = await request(app).post('/api/v1/auth/login').send({ email: admin.email, password: admin.password });
    const auth = `Bearer ${login.body.data.token}`;
    expect((await request(app).get('/api/v1/users?role[$ne]=operator').set('Authorization', auth)).status).toBe(400);
    expect((await request(app).post('/api/v1/auth/login').send({ email: { $ne: null }, password: { $ne: null } })).status).toBe(400);
    expect((await request(app).get('/api/v1/tickets?search[$regex]=.*').set('Authorization', auth)).status).toBe(400);
  });

  it('refuses PDFs above the page cap', async () => {
    const pdf = await simplePdf([['one'], ['two'], ['three']]);
    await expect(extractPdfPages(pdf, 2)).rejects.toBeInstanceOf(PdfValidationError);
    await expect(extractPdfPages(pdf, 2)).rejects.toThrow(/limit is 2/);
    expect((await extractPdfPages(pdf, 3)).pageCount).toBe(3);
  });

  it('never returns stack traces or internals in error responses', async () => {
    const res = await request(app).post('/api/v1/auth/login').set('Content-Type', 'application/json').send('{"broken"');
    expect(JSON.stringify(res.body)).not.toMatch(/at .*\.(ts|js):\d+/);
  });
});

describe('WebSocket upgrade flood protection', () => {
  let server: http.Server;
  let url: string;
  beforeAll(async () => {
    server = http.createServer(createApp());
    attachVoiceSocket(server);
    await new Promise<void>((r) => server.listen(0, r));
    url = `ws://127.0.0.1:${(server.address() as AddressInfo).port}/api/v1/voice/stream`;
  });
  afterAll(() => new Promise<void>((r) => server.close(() => r())));
  afterEach(() => resetUpgradeLimiter());

  const attempt = () =>
    new Promise<number>((resolve) => {
      const ws = new WebSocket(url, [APP_PROTOCOL, 'bearer.invalid'], { headers: { origin: 'http://localhost:5173' } });
      ws.on('unexpected-response', (_req, res) => resolve(res.statusCode ?? 0));
      ws.on('open', () => resolve(101));
      ws.on('error', () => {});
    });

  it(`rejects more than ${UPGRADES_PER_MINUTE} upgrade attempts per minute from one IP with 429`, async () => {
    const codes: number[] = [];
    for (let i = 0; i < UPGRADES_PER_MINUTE + 2; i++) codes.push(await attempt());
    expect(codes.slice(0, UPGRADES_PER_MINUTE).every((c) => c === 401)).toBe(true);
    expect(codes.slice(UPGRADES_PER_MINUTE)).toEqual([429, 429]);
  });
});
