import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { EnvValidationError, parseEnv } from '../src/config/env.js';

const app = createApp();

describe('foundation: HTTP', () => {
  it('GET /api/v1/health returns the success envelope', async () => {
    const res = await request(app).get('/api/v1/health');
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.service).toBe('petrosathi-api');
    expect(res.body.data.aiProviderMode).toBe('mock');
    // No DB connection in this test → reported honestly as degraded.
    expect(res.body.data.status).toBe('degraded');
  });

  it('unknown routes return a 404 error envelope', async () => {
    const res = await request(app).get('/api/v1/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body).toMatchObject({ success: false, error: { code: 'NOT_FOUND' } });
  });

  it('malformed JSON returns 400 BAD_REQUEST', async () => {
    const res = await request(app)
      .post('/api/v1/health')
      .set('Content-Type', 'application/json')
      .send('{"broken":');
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('BAD_REQUEST');
  });

  it('sets security headers and hides x-powered-by', async () => {
    const res = await request(app).get('/api/v1/health');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });

  it('serves the OpenAPI document', async () => {
    const res = await request(app).get('/api/docs.json');
    expect(res.status).toBe(200);
    expect(res.body.openapi).toBe('3.1.0');
  });
});

describe('foundation: environment validation', () => {
  const base = { JWT_SECRET: 'x'.repeat(40) };

  it('accepts mock mode without Gnani credentials', () => {
    const env = parseEnv({ ...base, AI_PROVIDER_MODE: 'mock' });
    expect(env.AI_PROVIDER_MODE).toBe('mock');
    expect(env.GNANI_API_KEY_ID).toBeUndefined();
  });

  it('fails clearly in real mode when credentials are missing (no silent mock fallback)', () => {
    expect(() => parseEnv({ ...base, AI_PROVIDER_MODE: 'real', GNANI_API_KEY_ID: '' })).toThrow(
      EnvValidationError,
    );
    try {
      parseEnv({ ...base, AI_PROVIDER_MODE: 'real' });
    } catch (e) {
      expect((e as EnvValidationError).problems.join(' ')).toContain('GNANI_API_KEY_ID');
    }
  });

  it('rejects a short JWT secret without echoing its value', () => {
    try {
      parseEnv({ JWT_SECRET: 'tooshort' });
      expect.unreachable();
    } catch (e) {
      expect((e as Error).message).toContain('JWT_SECRET');
      expect((e as Error).message).not.toContain('tooshort');
    }
  });

  it('rejects chunk overlap >= chunk size', () => {
    expect(() => parseEnv({ ...base, RAG_CHUNK_SIZE: '500', RAG_CHUNK_OVERLAP: '500' })).toThrow(
      /RAG_CHUNK_OVERLAP/,
    );
  });
});
