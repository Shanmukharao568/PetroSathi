import { existsSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterAll } from 'vitest';

// Per-file temporary audio directory so tests can assert that audio files are deleted.
const audioTmp = mkdtempSync(path.join(tmpdir(), 'petrosathi-audio-'));
process.env.AUDIO_UPLOAD_DIR = audioTmp;
const docTmp = mkdtempSync(path.join(tmpdir(), 'petrosathi-docs-'));
process.env.DOCUMENT_UPLOAD_DIR = docTmp;
afterAll(() => {
  rmSync(audioTmp, { recursive: true, force: true });
  rmSync(docTmp, { recursive: true, force: true });
});
// Automated tests use the labelled mock embedding + in-memory store (no model download, no Chroma).
process.env.EMBEDDING_PROVIDER = 'mock';
// Pin settings a developer's backend/.env may change (e.g. pointing at a hosted deployment).
process.env.VECTOR_STORE = 'chroma';
process.env.EMBEDDING_MODEL = '';
process.env.RAG_MIN_RELEVANCE_SCORE = '';
// Real local model cache (only used by the opt-in multilingual test when already downloaded).
process.env.MODEL_CACHE_DIR = path.resolve(process.cwd(), '.models');
process.env.CLIENT_URL = 'http://localhost:5173';

// Test environment: deterministic, mock providers only, no real credentials.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test_secret_that_is_long_enough_for_validation_0123456789';
process.env.JWT_EXPIRES_IN = '1h';
process.env.BCRYPT_SALT_ROUNDS = '10';
process.env.AI_PROVIDER_MODE = 'mock';
process.env.LOG_LEVEL = 'silent';

// Reuse a locally installed mongod for mongodb-memory-server instead of downloading one.
if (!process.env.MONGOMS_SYSTEM_BINARY) {
  const candidates = [
    'C:/Program Files/MongoDB/Server/8.0/bin/mongod.exe',
    'C:/Program Files/MongoDB/Server/7.0/bin/mongod.exe',
    '/usr/bin/mongod',
    '/usr/local/bin/mongod',
    '/opt/homebrew/bin/mongod',
  ];
  const found = candidates.find((p) => existsSync(p));
  if (found) process.env.MONGOMS_SYSTEM_BINARY = found;
}
