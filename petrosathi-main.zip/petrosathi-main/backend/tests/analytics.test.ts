import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { useTestDatabase } from './helpers/testDb.js';
import { createEquipment, newIdempotencyKey, userWithToken } from './helpers/factories.js';
import { TicketModel } from '../src/modules/tickets/ticket.model.js';
import { AuditLogModel } from '../src/modules/audit/auditLog.model.js';
import { ComplaintDraftModel } from '../src/modules/complaints/draft.model.js';
import { monthKeys } from '../src/modules/analytics/analytics.service.js';

const app = createApp();
useTestDatabase();

type U = Awaited<ReturnType<typeof userWithToken>>;
let admin: U, op: U, op2: U, eng: U, eng2: U;
let pumpId: string, compId: string;
let seq = 0;

const H = 3600_000;
const at = (iso: string) => new Date(iso);

/** Inserts a ticket directly with controlled timestamps (analytics are computed from these). */
async function ticket(o: {
  equipment: 'pump' | 'comp';
  reporter?: U;
  createdAt: string;
  status?: string;
  severity?: string;
  category?: string;
  symptoms?: string[];
  resolvedAfterHours?: number;
  assignedTo?: U | null;
}) {
  seq += 1;
  const created = at(o.createdAt);
  const resolvedAt = o.resolvedAfterHours !== undefined ? new Date(created.getTime() + o.resolvedAfterHours * H) : null;
  return TicketModel.create({
    ticketNumber: `TKT-TEST-${String(seq).padStart(4, '0')}`,
    equipmentId: o.equipment === 'pump' ? pumpId : compId,
    equipmentCode: o.equipment === 'pump' ? 'P-101' : 'C-301',
    reportedBy: (o.reporter ?? op).id,
    assignedTo: o.assignedTo ? o.assignedTo.id : null,
    description: 'Seeded analytics ticket',
    symptoms: o.symptoms ?? [],
    category: o.category ?? 'mechanical',
    severity: o.severity ?? 'unknown',
    status: o.status ?? 'OPEN',
    source: 'manual',
    resolvedAt,
    resolution: resolvedAt ? { summary: 'Fixed in test', resolvedBy: (o.assignedTo ?? eng).id, resolvedAt } : null,
    history: [{ type: 'created', actor: (o.reporter ?? op).id, at: created, toStatus: 'OPEN' }],
    createdAt: created,
  });
}

beforeEach(async () => {
  seq = 0;
  [admin, op, op2, eng, eng2] = await Promise.all([
    userWithToken(app, 'admin'),
    userWithToken(app, 'operator'),
    userWithToken(app, 'operator'),
    userWithToken(app, 'engineer'),
    userWithToken(app, 'engineer'),
  ]);
  pumpId = (await createEquipment({ equipmentCode: 'P-101', type: 'pump' })).id;
  compId = (await createEquipment({ equipmentCode: 'C-301', type: 'compressor' })).id;
});

const get = (path: string, auth = admin.auth) => request(app).get(`/api/v1${path}`).set('Authorization', auth);

describe('GET /analytics/tickets', () => {
  beforeEach(async () => {
    await ticket({ equipment: 'pump', createdAt: '2026-03-10T06:00:00Z', status: 'RESOLVED', severity: 'high', resolvedAfterHours: 10, symptoms: ['vibration'] });
    await ticket({ equipment: 'pump', createdAt: '2026-03-20T06:00:00Z', status: 'CLOSED', severity: 'high', resolvedAfterHours: 20, symptoms: ['vibration', 'noise'] });
    await ticket({ equipment: 'pump', createdAt: '2026-05-05T06:00:00Z', status: 'IN_PROGRESS', severity: 'critical', category: 'safety', assignedTo: eng, symptoms: ['leak'] });
    await ticket({ equipment: 'comp', createdAt: '2026-05-15T06:00:00Z', status: 'OPEN', severity: 'medium', category: 'process' });
    await ticket({ equipment: 'comp', createdAt: '2025-01-15T06:00:00Z', status: 'CLOSED', resolvedAfterHours: 5 }); // outside range
  });

  it('buckets created/resolved by month with zero-filled gaps and exact averages', async () => {
    const res = await get('/analytics/tickets?from=2026-03-01&to=2026-06-30');
    expect(res.status).toBe(200);
    expect(res.body.data.monthly).toEqual([
      { month: '2026-03', created: 2, resolved: 2 },
      { month: '2026-04', created: 0, resolved: 0 },
      { month: '2026-05', created: 2, resolved: 0 },
      { month: '2026-06', created: 0, resolved: 0 },
    ]);
    expect(res.body.data.byStatus).toMatchObject({ OPEN: 1, IN_PROGRESS: 1, RESOLVED: 1, CLOSED: 1, UNDER_INSPECTION: 0 });
    expect(res.body.data.bySeverity).toMatchObject({ high: 2, critical: 1, medium: 1, low: 0, unknown: 0 });
    expect(res.body.data.byCategory).toMatchObject({ mechanical: 2, safety: 1, process: 1 });
    // (10 h + 20 h) / 2 — the out-of-range 5 h ticket is excluded
    expect(res.body.data.resolution).toMatchObject({ averageHours: 15, resolvedCount: 2 });
    expect(res.body.data.resolution.bySeverity.find((s: { severity: string }) => s.severity === 'high')).toEqual({ severity: 'high', averageHours: 15, resolvedCount: 2 });
    expect(res.body.data.resolution.bySeverity.find((s: { severity: string }) => s.severity === 'low').averageHours).toBeNull();
  });

  it('reports no average when nothing was resolved, instead of inventing one', async () => {
    const res = await get('/analytics/tickets?from=2026-05-01&to=2026-05-31');
    expect(res.body.data.resolution).toMatchObject({ averageHours: null, resolvedCount: 0 });
  });

  it('validates the range', async () => {
    expect((await get('/analytics/tickets?from=2026-06-01&to=2026-01-01')).status).toBe(400);
    expect((await get('/analytics/tickets?from=not-a-date')).status).toBe(400);
    expect((await get('/analytics/tickets?from=2010-01-01&to=2026-01-01')).status).toBe(400);
  });

  it('defaults to the last 12 months', async () => {
    const res = await get('/analytics/tickets');
    expect(res.body.data.monthly).toHaveLength(12);
  });

  it('month keys span year boundaries', () => {
    expect(monthKeys({ from: at('2025-11-15T00:00:00Z'), to: at('2026-02-10T00:00:00Z') })).toEqual(['2025-11', '2025-12', '2026-01', '2026-02']);
  });
});

describe('GET /analytics/equipment', () => {
  it('ranks equipment, counts active/critical, and finds recurring issues with top symptoms', async () => {
    await ticket({ equipment: 'pump', createdAt: '2026-03-01T06:00:00Z', symptoms: ['vibration', 'noise'] });
    await ticket({ equipment: 'pump', createdAt: '2026-03-08T06:00:00Z', symptoms: ['vibration'], severity: 'critical' });
    await ticket({ equipment: 'pump', createdAt: '2026-03-15T06:00:00Z', symptoms: ['vibration', 'leak'], status: 'CLOSED', resolvedAfterHours: 3 });
    await ticket({ equipment: 'comp', createdAt: '2026-03-20T06:00:00Z', symptoms: ['overheating'] });

    const res = await get('/analytics/equipment?from=2026-03-01&to=2026-03-31');
    expect(res.body.data.topEquipment).toEqual([
      expect.objectContaining({ equipmentCode: 'P-101', type: 'pump', total: 3, active: 2, critical: 1 }),
      expect.objectContaining({ equipmentCode: 'C-301', type: 'compressor', total: 1, active: 1, critical: 0 }),
    ]);
    expect(res.body.data.recurringIssues).toHaveLength(1); // C-301 has only one complaint
    expect(res.body.data.recurringIssues[0]).toMatchObject({ equipmentCode: 'P-101', count: 3, topSymptoms: [{ symptom: 'vibration', count: 3 }, expect.any(Object), expect.any(Object)] });
    expect(res.body.data.recurringIssues[0].lastReportedAt).toBe('2026-03-15T06:00:00.000Z');
    expect(res.body.data.byEquipmentType).toEqual([{ type: 'pump', count: 3 }, { type: 'compressor', count: 1 }]);
  });
});

describe('GET /analytics/overview', () => {
  it('summarises live counts across tickets, users, equipment, documents and drafts', async () => {
    const now = new Date();
    const recent = (daysAgo: number) => new Date(now.getTime() - daysAgo * 24 * H).toISOString();
    await ticket({ equipment: 'pump', createdAt: recent(5), severity: 'critical' });
    await ticket({ equipment: 'pump', createdAt: recent(4), severity: 'critical', status: 'UNDER_INSPECTION', assignedTo: eng });
    await ticket({ equipment: 'comp', createdAt: recent(3), status: 'RESOLVED', resolvedAfterHours: 6 });
    await ComplaintDraftModel.create({ userId: op.id, source: 'text', transcript: 'x', language: 'en-IN', extraction: { status: 'not_run' }, state: 'NEEDS_INFORMATION', idempotencyKey: 'k1', expiresAt: new Date(Date.now() + H) });

    const res = await get('/analytics/overview');
    expect(res.body.data.tickets).toMatchObject({
      total: 3,
      active: 2,
      unassignedActive: 1,
      activeBySeverity: { critical: 2 },
      createdInRange: 3,
      resolvedInRange: 1,
      bySource: { manual: 3, voice: 0 },
    });
    expect(res.body.data.resolution.averageHours).toBe(6);
    expect(res.body.data.users).toMatchObject({ admin: { active: 1 }, operator: { active: 2 }, engineer: { active: 2 } });
    expect(res.body.data.equipment.total).toBe(2);
    expect(res.body.data.openComplaintDrafts).toBe(1);
  });
});

describe('analytics access control', () => {
  it('operators and engineers cannot read analytics or audit logs', async () => {
    for (const u of [op, eng]) {
      for (const path of ['/analytics/overview', '/analytics/tickets', '/analytics/equipment', '/audit-logs', '/audit-logs/facets']) {
        expect((await get(path, u.auth)).status).toBe(403);
      }
    }
    expect((await request(app).get('/api/v1/analytics/overview')).status).toBe(401);
  });
});

describe('GET /dashboard (role-specific)', () => {
  it('operator: only their own tickets, drafts and notifications', async () => {
    await ticket({ equipment: 'pump', createdAt: '2026-03-01T06:00:00Z' });
    await ticket({ equipment: 'pump', createdAt: '2026-03-02T06:00:00Z', status: 'RESOLVED', resolvedAfterHours: 1 });
    await ticket({ equipment: 'comp', createdAt: '2026-03-03T06:00:00Z', reporter: op2 }); // someone else's
    await ComplaintDraftModel.create({ userId: op.id, source: 'text', transcript: 'x', language: 'en-IN', extraction: { status: 'not_run' }, fields: { equipmentCode: 'P-101', description: 'Seal dripping' }, state: 'NEEDS_INFORMATION', idempotencyKey: 'k2', expiresAt: new Date(Date.now() + H) });
    await ComplaintDraftModel.create({ userId: op2.id, source: 'text', transcript: 'x', language: 'en-IN', extraction: { status: 'not_run' }, state: 'DRAFT', idempotencyKey: 'k3', expiresAt: new Date(Date.now() + H) });

    const res = await get('/dashboard', op.auth);
    expect(res.body.data).toMatchObject({ role: 'operator', counts: { total: 2, active: 1, resolved: 1 } });
    expect(res.body.data.recentTickets).toHaveLength(2);
    expect(res.body.data.recentTickets.every((t: { equipmentCode: string }) => t.equipmentCode === 'P-101')).toBe(true);
    expect(res.body.data.openDrafts).toEqual([expect.objectContaining({ equipmentCode: 'P-101', state: 'NEEDS_INFORMATION' })]);
  });

  it('engineer: assigned counts, unassigned queue, severity-ordered work list, activity', async () => {
    await ticket({ equipment: 'pump', createdAt: '2026-03-01T06:00:00Z', assignedTo: eng, status: 'IN_PROGRESS', severity: 'critical' });
    await ticket({ equipment: 'pump', createdAt: '2026-03-02T06:00:00Z', assignedTo: eng, status: 'UNDER_INSPECTION', severity: 'low' });
    await ticket({ equipment: 'comp', createdAt: '2026-03-03T06:00:00Z', severity: 'high' }); // unassigned
    await ticket({ equipment: 'comp', createdAt: '2026-03-04T06:00:00Z', assignedTo: eng2, status: 'IN_PROGRESS', severity: 'critical' }); // not mine

    const res = await get('/dashboard', eng.auth);
    expect(res.body.data.counts).toMatchObject({ assignedTotal: 2, inProgress: 1, underInspection: 1, criticalAssigned: 1, unassigned: 1, unassignedCritical: 0 });
    expect(res.body.data.queue.map((t: { severity: string; assignedToMe: boolean }) => `${t.severity}:${t.assignedToMe}`)).toEqual(['critical:true', 'high:false', 'low:true']);
    expect(res.body.data.recentActivity.length).toBeGreaterThan(0);
    expect(res.body.data.recentActivity.every((a: { ticketNumber: string }) => a.ticketNumber !== 'TKT-TEST-0004')).toBe(true);
  });

  it('admin: overview summary plus recent audit entries', async () => {
    const res = await get('/dashboard', admin.auth);
    expect(res.body.data.role).toBe('admin');
    expect(res.body.data.summary.tickets).toBeDefined();
    expect(res.body.data.recentAudit.length).toBeGreaterThan(0); // logins of the seeded users
    expect(res.body.data.recentAudit[0]).toHaveProperty('action');
  });
});

describe('GET /audit-logs', () => {
  it('lists newest first with actor details, and filters by action, prefix, entity, actor and date', async () => {
    const t = await request(app).post('/api/v1/tickets').set('Authorization', op.auth).set('Idempotency-Key', newIdempotencyKey()).send({ equipmentCode: 'P-101', description: 'Audit trail test complaint' });
    await request(app).patch(`/api/v1/tickets/${t.body.data.id}/assign`).set('Authorization', eng.auth).send({ assigneeId: eng.id }).expect(200);
    await AuditLogModel.create({ actorId: admin.id, action: 'user.updated', entityType: 'User', entityId: op.id, createdAt: at('2024-01-01T00:00:00Z') });

    const all = await get('/audit-logs?limit=100');
    expect(all.status).toBe(200);
    const times = all.body.data.map((a: { createdAt: string }) => a.createdAt);
    expect([...times].sort().reverse()).toEqual(times);

    const assigned = await get('/audit-logs?action=ticket.assigned');
    expect(assigned.body.data).toHaveLength(1);
    expect(assigned.body.data[0].actorId).toMatchObject({ name: expect.any(String), role: 'engineer' });

    const ticketEvents = await get('/audit-logs?action=ticket.');
    expect(ticketEvents.body.data.map((a: { action: string }) => a.action).sort()).toEqual(['ticket.assigned', 'ticket.created']);

    expect((await get(`/audit-logs?entityType=MaintenanceTicket&entityId=${t.body.data.id}`)).body.data).toHaveLength(2);
    expect((await get(`/audit-logs?actorId=${op.id}&action=ticket.`)).body.data.map((a: { action: string }) => a.action)).toEqual(['ticket.created']);
    expect((await get('/audit-logs?from=2023-12-31&to=2024-01-02')).body.data.map((a: { action: string }) => a.action)).toEqual(['user.updated']);
    expect((await get('/audit-logs?from=2024-02-01&to=2024-01-01')).status).toBe(400);
    expect((await get('/audit-logs?action=DROP TABLE')).status).toBe(400);
  });

  it('paginates and exposes facets for filters', async () => {
    const page = await get('/audit-logs?limit=2&page=1');
    expect(page.body.data).toHaveLength(2);
    expect(page.body.meta.pagination.total).toBeGreaterThanOrEqual(5);
    const facets = await get('/audit-logs/facets');
    expect(facets.body.data.actions).toContain('auth.login.success');
    expect(facets.body.data.entityTypes).toContain('User');
  });
});

describe('timezone-aware ranges', () => {
  it('interprets range days in ANALYTICS_TIMEZONE (Asia/Kolkata, UTC+05:30)', async () => {
    const { zonedDayBounds } = await import('../src/modules/analytics/analytics.service.js');
    const b = zonedDayBounds('2026-06-30', 'Asia/Kolkata');
    expect(b.start.toISOString()).toBe('2026-06-29T18:30:00.000Z');
    expect(b.end.toISOString()).toBe('2026-06-30T18:29:59.999Z');
    expect(zonedDayBounds('2026-01-01', 'UTC').start.toISOString()).toBe('2026-01-01T00:00:00.000Z');
  });
});
